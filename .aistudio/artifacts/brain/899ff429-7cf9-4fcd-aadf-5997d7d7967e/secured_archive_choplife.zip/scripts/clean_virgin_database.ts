/**
 * Choplife Republic — Virgin Database Cleaner
 * Command: npx tsx scripts/clean_virgin_database.ts
 *
 * Implements Section 3.3 Safe Database Cleanup:
 * 1. Backs up current database to data/choplife_ops_db.backup-before-virgin-clean.json
 * 2. Purges test orders, checks, shifts, cash movements, payments, reconciliations
 * 3. Purges test stock requests, purchase orders, GRNs, stock ledger movements, wastage
 * 4. Purges test notifications, customer care tickets, customers, wallet transactions, house accounts
 * 5. Purges test audit logs and active session tokens
 * 6. Resets physical stock balances to 0 for all canonical inventory items
 * 7. Removes dynamically injected test inventory items (inv-1793... / TEST-COND...)
 * 8. Resets all 66 dining tables to status: 'available' with guestCount: 0
 * 9. Preserves all canonical configuration: 3 branches, 9 categories, 200 products, 10 roles, 8 assets, 6 receipt templates, CMS content
 */

import fs from 'fs';
import path from 'path';

const DB_PATH = path.join(process.cwd(), 'data', 'choplife_ops_db.json');
const BACKUP_PATH = path.join(process.cwd(), 'data', 'choplife_ops_db.backup-before-virgin-clean.json');

function cleanDatabase() {
  console.log('--- Choplife Republic Virgin Database Cleaner ---');

  if (!fs.existsSync(DB_PATH)) {
    console.error('Database file not found at', DB_PATH);
    process.exit(1);
  }

  const raw = fs.readFileSync(DB_PATH, 'utf-8');
  fs.writeFileSync(BACKUP_PATH, raw, 'utf-8');
  console.log(`Backed up existing database to: ${BACKUP_PATH}`);

  const db = JSON.parse(raw);

  // 1. Purge Operational Transactions
  db.orders = {};
  db.checks = {};
  db.shifts = {};
  db.cashMovements = [];
  db.paymentTransactions = {};
  db.processedWebhookEvents = {};
  db.accountingExportBatches = [];
  db.reconciliations = [];
  db.deliveryTasks = {};
  db.heldTickets = {};
  db.printJobs = [];

  // 2. Purge Procurement & Inventory Movements
  db.requests = {};
  db.purchaseOrders = {};
  db.goodsReceiptNotes = {};
  db.ledger = [];
  db.wastage = [];
  db.stockCounts = {};
  db.productionBatches = {};
  db.stockAlerts = {};

  // 3. Purge Customer, Loyalty, Catering & Support Records
  db.customers = {};
  db.walletTransactions = [];
  db.houseAccounts = {};
  db.houseAccountCharges = [];
  db.houseAccountPayments = [];
  db.cateringEvents = {};
  db.customerCareTickets = {};
  db.notifications = {};

  // 4. Purge Sessions & Test Audit Logs
  db.sessions = {};
  db.resetTokens = {};
  db.auditLogs = [];

  // 5. Clean Inventory Items: Keep canonical items only, set physical balances to 0
  const CANONICAL_ITEM_IDS = new Set([
    'inv-protein-chicken',
    'inv-protein-beef',
    'inv-ing-rice-basmati',
    'inv-ing-springroll-wrap',
    'inv-ing-pita-bread',
    'inv-spice-suya-blend',
    'inv-pack-thermal-box',
    'inv-bev-zobo-flower',
  ]);

  const cleanedInventory: Record<string, any> = {};
  for (const [id, item] of Object.entries(db.inventory || {})) {
    // Retain only canonical items or non-test items
    if (CANONICAL_ITEM_IDS.has(id)) {
      const it = item as any;
      it.currentStock = { general_store: 0, gra: 0, okabere: 0, ugbowo: 0 };
      if (it.locationStock) {
        for (const loc of Object.keys(it.locationStock)) {
          it.locationStock[loc].stockOnHand = 0;
          it.locationStock[loc].availableStock = 0;
          it.locationStock[loc].reservedStock = 0;
        }
      }
      cleanedInventory[id] = it;
    }
  }
  db.inventory = cleanedInventory;

  // 6. Reset Tables: 66 tables all available
  for (const table of Object.values(db.tables || {}) as any[]) {
    table.status = 'available';
    table.guestCount = 0;
    table.updatedAt = new Date().toISOString();
  }

  // Save clean database
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2), 'utf-8');
  console.log(`Pristine Virgin Database saved to ${DB_PATH}.`);
  console.log('Statistics:');
  console.log(`  Orders: ${Object.keys(db.orders).length}`);
  console.log(`  Checks: ${Object.keys(db.checks).length}`);
  console.log(`  Shifts: ${Object.keys(db.shifts).length}`);
  console.log(`  Inventory Items: ${Object.keys(db.inventory).length}`);
  console.log(`  Tables: ${Object.keys(db.tables).length}`);
  console.log(`  Audit Logs: ${db.auditLogs.length}`);
}

cleanDatabase();
