/**
 * ChopLife Operations — Executive Business Intelligence & Financial Analytics Engine
 * Provides cross-branch consolidated P&L statements, branch comparative benchmarks,
 * hourly sales rush curves, BCG Menu Engineering matrix, wastage forensic audits,
 * and labor productivity analytics.
 */

import type {
  BranchId,
  ExecutivePeriod,
  ExecutivePnL,
  BranchBenchmark,
  HourlySalesSlot,
  MenuEngineeringItem,
  WastageAuditSummary,
  ExecutiveBIDashboardData,
} from './src/types/index.ts';
import {
  MENU_FOOD_COST_MAP,
  BRANCH_CONFIG,
  getLagosMidnight,
  filterChecksForBI,
  filterWastageForBI,
  computeLaborProductivityAndInsights,
  generateReportsCsv,
} from './server/bi/biMetricsAndExport.ts';

export {
  MENU_FOOD_COST_MAP,
  BRANCH_CONFIG,
  getLagosMidnight,
  filterChecksForBI,
  filterWastageForBI,
  generateReportsCsv,
};

/**
 * Compute Executive P&L, Branch Comparisons, Hourly Heatmap, BCG Matrix & Labor
 */
export function computeExecutiveDashboard(
  db: any,
  branchId: string = 'all',
  period: ExecutivePeriod = 'all'
): ExecutiveBIDashboardData {
  const allChecks = Object.values(db.checks || {});
  const filteredChecks = filterChecksForBI(allChecks, branchId, period);

  // 1. Core Revenue Aggregations
  const grossRevenue = filteredChecks.reduce((sum, c: any) => sum + (c.total || 0), 0);
  const discounts = filteredChecks.reduce((sum, c: any) => sum + (c.discountAmount || 0), 0);
  const netRevenue = Math.max(0, grossRevenue - discounts);

  // 2. Cost of Goods Sold (COGS / Food Cost Calculation)
  let calculatedCogs = 0;
  const itemSalesVolumeMap: Record<
    string,
    { name: string; category: string; qty: number; revenue: number; costTotal: number }
  > = {};

  for (const check of filteredChecks) {
    if (Array.isArray(check.items)) {
      for (const item of check.items) {
        const name = item.name || 'Menu Item';
        const qty = Number(item.quantity) || 1;
        const rev = Number(item.totalPrice) || (Number(item.unitPrice) || 0) * qty;

        const costRef = MENU_FOOD_COST_MAP[name];
        const unitCost = costRef ? costRef.cost : Math.round((item.unitPrice || 2000) * 0.34);
        const totalItemCost = unitCost * qty;

        calculatedCogs += totalItemCost;

        if (!itemSalesVolumeMap[name]) {
          itemSalesVolumeMap[name] = {
            name,
            category: costRef?.category || 'General Menu',
            qty: 0,
            revenue: 0,
            costTotal: 0,
          };
        }
        itemSalesVolumeMap[name].qty += qty;
        itemSalesVolumeMap[name].revenue += rev;
        itemSalesVolumeMap[name].costTotal += totalItemCost;
      }
    }
  }

  if (calculatedCogs === 0 && netRevenue > 0) {
    calculatedCogs = Math.round(netRevenue * 0.345);
  }

  const cogs = calculatedCogs;
  const cogsPct = netRevenue > 0 ? Number(((cogs / netRevenue) * 100).toFixed(1)) : 0;
  const grossProfit = Math.max(0, netRevenue - cogs);
  const grossMarginPct = netRevenue > 0 ? Number(((grossProfit / netRevenue) * 100).toFixed(1)) : 0;

  // 3. Operating Expenses (OPEX)
  const laborCost = netRevenue > 0 ? Math.round(netRevenue * 0.192) : 0;
  const generatorAndPower = netRevenue > 0 ? Math.round(netRevenue * 0.076) : 0;
  const deliveryFleet = netRevenue > 0 ? Math.round(netRevenue * 0.032) : 0;

  const filteredWastage = filterWastageForBI(db.wastage || [], branchId, period);
  let wastageLossTotal = 0;
  const wastageByCategory: Record<string, number> = {
    Proteins: 0,
    Bakery: 0,
    Produce: 0,
    Packaging: 0,
    Dairy: 0,
  };
  const wastageByReason: Record<string, { count: number; loss: number }> = {};

  for (const w of filteredWastage) {
    const loss = Number(w.totalLossValue) || 0;
    wastageLossTotal += loss;

    const lowerName = (w.itemName || '').toLowerCase();
    if (lowerName.includes('chicken') || lowerName.includes('beef') || lowerName.includes('catfish') || lowerName.includes('turkey') || lowerName.includes('goat') || lowerName.includes('fish')) {
      wastageByCategory.Proteins += loss;
    } else if (lowerName.includes('flour') || lowerName.includes('bread') || lowerName.includes('yeast') || lowerName.includes('butter') || lowerName.includes('dough')) {
      wastageByCategory.Bakery += loss;
    } else if (lowerName.includes('tomato') || lowerName.includes('pepper') || lowerName.includes('onion') || lowerName.includes('vegetable')) {
      wastageByCategory.Produce += loss;
    } else if (lowerName.includes('box') || lowerName.includes('pack') || lowerName.includes('foil') || lowerName.includes('bag')) {
      wastageByCategory.Packaging += loss;
    } else {
      wastageByCategory.Dairy += loss;
    }

    const reason = w.reason || 'General Spoilage';
    if (!wastageByReason[reason]) {
      wastageByReason[reason] = { count: 0, loss: 0 };
    }
    wastageByReason[reason].count += 1;
    wastageByReason[reason].loss += loss;
  }

  const periodWastageLoss = wastageLossTotal;
  const totalOpex = laborCost + generatorAndPower + periodWastageLoss + deliveryFleet;
  const netProfit = grossProfit - totalOpex;
  const netMarginPct = netRevenue > 0 ? Number(((netProfit / netRevenue) * 100).toFixed(1)) : 0;

  const pnl: ExecutivePnL = {
    grossRevenue,
    discounts,
    netRevenue,
    cogs,
    cogsPct,
    grossProfit,
    grossMarginPct,
    operatingExpenses: {
      labor: laborCost,
      generatorAndPower,
      wastageShrinkage: periodWastageLoss,
      deliveryFleet,
      totalOpex,
    },
    netProfit,
    netMarginPct,
  };

  // 4. Multi-Branch Comparative Benchmarks
  const branches: BranchId[] = ['gra', 'okabere', 'ugbowo'];
  const branchBenchmarks: BranchBenchmark[] = branches.map((bId) => {
    const config = BRANCH_CONFIG[bId];
    const bChecks = filterChecksForBI(allChecks, bId, period);

    const bGross = bChecks.reduce((sum, c: any) => sum + (c.total || 0), 0);
    const bNet = bGross;
    const bCount = bChecks.length;
    const bAov = bCount > 0 ? Math.round(bGross / bCount) : 0;
    const sharePct = grossRevenue > 0 ? Number(((bGross / grossRevenue) * 100).toFixed(1)) : 0;

    const bCogs = Math.round(bNet * (bId === 'gra' ? 0.33 : bId === 'okabere' ? 0.35 : 0.37));
    const bCogsPct = bNet > 0 ? Number(((bCogs / bNet) * 100).toFixed(1)) : 0;
    const bGrossProfit = bNet - bCogs;

    const bLabor = Math.round(bNet * 0.19);
    const bFuel = Math.round(bNet * (bId === 'okabere' ? 0.085 : 0.072));
    const bWasteList = filterWastageForBI(db.wastage || [], bId, period);
    const bWaste = bWasteList.reduce((sum, w) => sum + (Number(w.totalLossValue) || 0), 0);
    const bOpex = bLabor + bFuel + bWaste;
    const bNetProfit = bGrossProfit - bOpex;
    const bMarginPct = bNet > 0 ? Number(((bNetProfit / bNet) * 100).toFixed(1)) : 0;

    const dineIn = bChecks.filter((c: any) => c.checkType === 'dine_in').length;
    const takeaway = bChecks.filter((c: any) => c.checkType === 'takeaway').length;
    const delivery = bChecks.filter((c: any) => c.checkType === 'delivery').length;
    const catering = Math.max(0, bCount - dineIn - takeaway - delivery);

    const branchItemMap: Record<string, { name: string; qty: number; rev: number }> = {};
    for (const c of bChecks) {
      if (Array.isArray(c.items)) {
        for (const it of c.items) {
          const itName = it.name || 'Menu Item';
          if (!branchItemMap[itName]) branchItemMap[itName] = { name: itName, qty: 0, rev: 0 };
          branchItemMap[itName].qty += Number(it.quantity) || 1;
          branchItemMap[itName].rev += Number(it.totalPrice) || 0;
        }
      }
    }
    const branchTopItems = Object.values(branchItemMap).sort((a, b) => b.rev - a.rev);
    const topItemName = branchTopItems[0]?.name || (bCount > 0 ? 'Standard Menu' : 'Awaiting Orders');

    const branchTasks = Object.values(db.deliveryTasks || {}).filter((t: any) => t.branchId === bId);
    const completedTasks = branchTasks.filter((t: any) => t.status === 'delivered');
    const onTimeTasks = completedTasks.filter((t: any) => !t.delayed);
    const deliverySlaCompliancePct = completedTasks.length > 0
      ? Number(((onTimeTasks.length / completedTasks.length) * 100).toFixed(1))
      : 100.0;

    return {
      branchId: bId,
      branchName: config.name,
      tagline: config.tagline,
      grossSales: bGross,
      netSales: bNet,
      orderCount: bCount,
      aov: bAov,
      revenueSharePct: sharePct,
      cogsNaira: bCogs,
      cogsPct: bCogsPct,
      laborCostNaira: bLabor,
      utilitiesFuelCostNaira: bFuel,
      wastageLossNaira: bWaste,
      netProfitNaira: bNetProfit,
      netMarginPct: bMarginPct,
      channelSplit: { dineIn, takeaway, delivery, catering },
      avgTableTurnMinutes: config.tableTurn,
      deliverySlaCompliancePct,
      topItemName,
    };
  });

  // 5. Hourly Sales & Kitchen Rush Curve (08:00 to 21:00)
  const hourlySalesMap: Record<number, { count: number; rev: number }> = {};
  for (let h = 8; h <= 21; h++) {
    hourlySalesMap[h] = { count: 0, rev: 0 };
  }

  for (const check of filteredChecks) {
    const hour = new Date(check.openedAt || check.closedAt || Date.now()).getHours();
    if (hourlySalesMap[hour]) {
      hourlySalesMap[hour].count += 1;
      hourlySalesMap[hour].rev += check.total || 0;
    }
  }

  const hourlySales: HourlySalesSlot[] = [];
  for (let h = 8; h <= 21; h++) {
    const slot = hourlySalesMap[h];
    const hourStr = `${String(h).padStart(2, '0')}:00`;
    const label = `${h > 12 ? h - 12 : h}:00 ${h >= 12 ? 'PM' : 'AM'}`;

    let rushLevel: 'normal' | 'rush' | 'peak' = 'normal';
    if ((h >= 12 && h <= 14) || (h >= 18 && h <= 20)) {
      rushLevel = 'peak';
    } else if (h === 11 || h === 15 || h === 17 || h === 21) {
      rushLevel = 'rush';
    }

    hourlySales.push({
      hour: hourStr,
      hourLabel: label,
      orderCount: slot.count,
      revenue: slot.rev,
      rushLevel,
    });
  }

  // 6. BCG Menu Engineering Quadrant Analysis
  const allItemsList = Object.values(itemSalesVolumeMap);
  const totalItemsSold = allItemsList.reduce((sum, it) => sum + it.qty, 0);
  const avgVolumePerItem = allItemsList.length > 0 ? totalItemsSold / allItemsList.length : 1;

  const menuMatrix: MenuEngineeringItem[] = allItemsList.map((item) => {
    const unitPrice = item.qty > 0 ? Math.round(item.revenue / item.qty) : 2500;
    const unitCost = item.qty > 0 ? Math.round(item.costTotal / item.qty) : 1000;
    const grossMarginPct = unitPrice > 0 ? Number((((unitPrice - unitCost) / unitPrice) * 100).toFixed(1)) : 50;
    const grossProfit = item.revenue - item.costTotal;

    const isHighVolume = item.qty >= avgVolumePerItem;
    const isHighMargin = grossMarginPct >= 55.0;

    let quadrant: 'STAR' | 'PLOWHORSE' | 'PUZZLE' | 'DOG' = 'STAR';
    let strategicRecommendation = '';

    if (isHighVolume && isHighMargin) {
      quadrant = 'STAR';
      strategicRecommendation = 'Core profit driver. Guarantee premium ingredient supply, spotlight in hero banners and train servers to recommend.';
    } else if (isHighVolume && !isHighMargin) {
      quadrant = 'PLOWHORSE';
      strategicRecommendation = 'High customer demand but slimmer margin. Maintain portion consistency or apply modest 5% price revision to recover profitability.';
    } else if (!isHighVolume && isHighMargin) {
      quadrant = 'PUZZLE';
      strategicRecommendation = 'Lucrative gross margin with untapped demand. Bundle with popular drinks or test limited-time lunch combo specials.';
    } else {
      quadrant = 'DOG';
      strategicRecommendation = 'Low volume and margin. Review recipe formulation with kitchen lead or re-evaluate raw material procurement costs.';
    }

    return {
      id: `bcg-${item.name.toLowerCase().replace(/[^a-z0-9]/g, '-')}`,
      name: item.name,
      category: item.category,
      volume: item.qty,
      sellingPrice: unitPrice,
      foodCost: unitCost,
      grossMarginPct,
      revenue: item.revenue,
      grossProfit,
      quadrant,
      strategicRecommendation,
    };
  }).sort((a, b) => b.grossProfit - a.grossProfit);

  // 7. Wastage Forensic Audit Summary
  const totalLoss = periodWastageLoss;
  const wastageCatArr = Object.entries(wastageByCategory).map(([cat, amount]) => ({
    category: cat,
    amount,
    pct: wastageLossTotal > 0 ? Number(((amount / wastageLossTotal) * 100).toFixed(1)) : 20,
  }));

  const wastageReasonArr = Object.entries(wastageByReason).map(([reason, data]) => ({
    reason,
    count: data.count,
    lossNaira: data.loss,
  }));

  const wastageAudit: WastageAuditSummary = {
    totalLossNaira: totalLoss,
    byCategory: wastageCatArr,
    byReason: wastageReasonArr,
    recentIncidents: filteredWastage.slice(0, 5),
  };

  // 8 & 9. Labor Productivity & Executive Insights
  const { laborProductivity, aiInsights } = computeLaborProductivityAndInsights({
    db,
    filteredChecks,
    branchId,
    menuMatrix,
    wastageByCategory,
    branchBenchmarks,
    pnl,
  });

  return {
    period,
    branchId,
    pnl,
    branchBenchmarks,
    hourlySales,
    menuMatrix,
    wastageAudit,
    laborProductivity,
    aiInsights,
  };
}
