import crypto from 'crypto';
import {
  roundMoney,
  mapTenderToAccountCode,
  resolveBranchLabel,
} from './chartAndTaxHelpers.ts';
import type {
  ChartOfAccountEntry,
  TaxTreatmentMode,
  JournalLine,
  JournalEntryDocument,
  AccountingLedgerReport,
  AccountingBuildOptions,
} from './chartAndTaxHelpers.ts';

export function appendAuxiliaryLedgerEntriesAndFinalize(params: {
  db: any;
  options: AccountingBuildOptions;
  chart: Record<string, ChartOfAccountEntry>;
  branchFilter: string;
  period: 'today' | '7days' | '30days' | '7d' | '30d' | 'custom' | 'all' | string;
  configuredTaxMode: TaxTreatmentMode;
  accountantConfirmed: boolean;
  matchesBranch: (recordBranchId?: string, allowCommissaryWhenAll?: boolean) => boolean;
  matchesDate: (isoTimestamp?: string) => boolean;
  entries: JournalEntryDocument[];
  pushEntry: (
    sourceType: JournalLine['sourceType'],
    sourceId: string,
    sourceRef: string,
    timestamp: string,
    branchId: string,
    rawLines: {
      accountCode: string;
      debit: number;
      credit: number;
      memo: string;
      taxCode?: string;
    }[]
  ) => void;
  salesTotals: {
    grossSalesCollected: number;
    discountsGranted: number;
    netFoodAndBeverageRevenue: number;
    deliveryFeeRevenue: number;
    outputVatPayable: number;
    refundsReversed: number;
    totalCogsRecognized: number;
  };
}): AccountingLedgerReport {
  const {
    db,
    options,
    chart,
    branchFilter,
    period,
    configuredTaxMode,
    accountantConfirmed,
    matchesBranch,
    matchesDate,
    entries,
    pushEntry,
    salesTotals,
  } = params;

  let grnInventoryAdditions = 0;
  let wastageWriteOffs = 0;
  let operatingExpensesPaidOut = 0;

  // 3. Verified Goods Receipt Notes (`db.goodsReceiptNotes`)
  const grnList = Object.values(db?.goodsReceiptNotes || {}) as any[];
  grnList.sort(
    (a, b) => new Date(a.receivedAt || a.createdAt || 0).getTime() - new Date(b.receivedAt || b.createdAt || 0).getTime()
  );

  for (const grn of grnList) {
    if (grn.status && grn.status !== 'verified') continue;
    const ts = grn.receivedAt || grn.createdAt;
    const loc = grn.receivingLocation || grn.branchId || 'general_store';
    if (!matchesBranch(loc, true) || !matchesDate(ts) || grn.isDemo || grn.dataOrigin === 'demo') continue;

    const acceptedValue = roundMoney(
      Number(
        grn.actualAcceptedValue ??
          grn.totalAcceptedValue ??
          (Array.isArray(grn.items || grn.lines)
            ? (grn.items || grn.lines).reduce(
                (s: number, l: any) => s + Number(l.acceptedQty ?? l.receivedQuantity ?? 0) * Number(l.unitPrice ?? 0),
                0
              )
            : 0)
      )
    );
    if (acceptedValue <= 0) continue;

    const ref = grn.grnNumber || grn.id;
    pushEntry('GRN_PURCHASE', grn.id, ref, ts, loc, [
      {
        accountCode: '1300',
        debit: acceptedValue,
        credit: 0,
        memo: `GRN stock intake ${ref} (${grn.supplierName || 'Trade Supplier'}, Inv: ${grn.supplierInvoiceNumber || 'N/A'})`,
      },
      {
        accountCode: '2000',
        debit: 0,
        credit: acceptedValue,
        memo: `Supplier trade payable for ${ref} (${grn.supplierName || 'Trade Supplier'})`,
      },
    ]);
    grnInventoryAdditions = roundMoney(grnInventoryAdditions + acceptedValue);
  }

  // 4. Inventory Wastage & Spoilage Write-Offs (`db.wastage`)
  const wastageList = Array.isArray(db?.wastage) ? db.wastage : Object.values(db?.wastage || {});
  wastageList.sort((a: any, b: any) => new Date(a.timestamp || 0).getTime() - new Date(b.timestamp || 0).getTime());

  for (const wst of wastageList) {
    if (wst.isDemo || wst.dataOrigin === 'demo' || String(wst.itemId || '').startsWith('demo-')) continue;
    const ts = wst.timestamp || wst.createdAt;
    const loc = wst.locationId || wst.branchId || 'gra';
    if (!matchesBranch(loc, true) || !matchesDate(ts)) continue;

    const costLost = roundMoney(
      Number(wst.estimatedCostLost ?? wst.totalLossValue ?? Number(wst.quantity || 0) * Number(wst.unitCost || 0)) || 0
    );
    if (costLost <= 0) continue;

    const ref = wst.referenceNo || wst.id || `WST-${ts.slice(0, 10)}`;
    pushEntry('WASTAGE_WRITEOFF', wst.id || ref, ref, ts, loc, [
      {
        accountCode: '6300',
        debit: costLost,
        credit: 0,
        memo: `Wastage write-off: ${wst.quantity} ${wst.unit || ''} ${wst.itemName || ''} (${wst.reason || 'Spoilage'})`,
      },
      {
        accountCode: '1300',
        debit: 0,
        credit: costLost,
        memo: `Inventory relief for wastage ${ref}`,
      },
    ]);
    wastageWriteOffs = roundMoney(wastageWriteOffs + costLost);
  }

  // 5. Cash Drawer Movements (`db.cashMovements`)
  const cashMoves = Array.isArray(db?.cashMovements) ? db.cashMovements : Object.values(db?.cashMovements || {});
  cashMoves.sort((a: any, b: any) => new Date(a.timestamp || 0).getTime() - new Date(b.timestamp || 0).getTime());

  for (const mv of cashMoves) {
    const ts = mv.timestamp || mv.createdAt;
    const loc = mv.branchId || 'gra';
    if (!matchesBranch(loc, false) || !matchesDate(ts)) continue;

    const amt = roundMoney(Number(mv.amount || 0));
    if (amt <= 0) continue;

    const ref = mv.id || `CSH-${ts.slice(0, 10)}`;
    const reasonText = String(mv.reason || '').toLowerCase();

    if (mv.type === 'paid_out') {
      const expAcct =
        reasonText.includes('diesel') || reasonText.includes('fuel') || reasonText.includes('generator') || reasonText.includes('power')
          ? '6100'
          : reasonText.includes('soap') || reasonText.includes('clean') || reasonText.includes('kitchen') || reasonText.includes('gas')
          ? '6200'
          : '6400';

      pushEntry('OPERATING_EXPENSE', mv.id || ref, ref, ts, loc, [
        {
          accountCode: expAcct,
          debit: amt,
          credit: 0,
          memo: `Register paid-out expense: ${mv.reason || 'Branch operating expense'}`,
        },
        {
          accountCode: '1010',
          debit: 0,
          credit: amt,
          memo: `Cash paid out from register drawer (${mv.staffName || 'Cashier'})`,
        },
      ]);
      operatingExpensesPaidOut = roundMoney(operatingExpensesPaidOut + amt);
    } else if (mv.type === 'safe_drop') {
      pushEntry('SAFE_DROP', mv.id || ref, ref, ts, loc, [
        {
          accountCode: '1015',
          debit: amt,
          credit: 0,
          memo: `Vault safe drop from register: ${mv.reason || 'Shift liquidity drop'}`,
        },
        {
          accountCode: '1010',
          debit: 0,
          credit: amt,
          memo: `Cash removed from register drawer to vault safe`,
        },
      ]);
    }
  }

  // 6. Customer Wallet Top-Ups (`db.walletTransactions` where type === 'credit')
  const walletTxs = Array.isArray(db?.walletTransactions) ? db.walletTransactions : Object.values(db?.walletTransactions || {});
  walletTxs.sort((a: any, b: any) => new Date(a.timestamp || 0).getTime() - new Date(b.timestamp || 0).getTime());

  for (const wtx of walletTxs) {
    if (wtx.type !== 'credit') continue;
    const ts = wtx.timestamp || wtx.createdAt;
    const loc = wtx.branchId || 'gra';
    if (!matchesBranch(loc, true) || !matchesDate(ts)) continue;

    const amt = roundMoney(Number(wtx.amount || 0));
    if (amt <= 0) continue;

    const tenderAcct = mapTenderToAccountCode(wtx.paymentMethod || 'pos_terminal');
    const ref = wtx.reference || wtx.id || `WLT-${ts.slice(0, 10)}`;
    pushEntry('WALLET_TOPUP', wtx.id || ref, ref, ts, loc, [
      {
        accountCode: tenderAcct,
        debit: amt,
        credit: 0,
        memo: `Customer wallet top-up received (${wtx.customerName || 'Loyalty Member'}, ref: ${ref})`,
      },
      {
        accountCode: '2300',
        debit: 0,
        credit: amt,
        memo: `Deferred wallet liability credited for ${wtx.customerName || 'Loyalty Member'}`,
      },
    ]);
  }

  // 7. Corporate House Account Remittances (`db.houseAccountPayments`)
  const housePmts = Array.isArray(db?.houseAccountPayments) ? db.houseAccountPayments : Object.values(db?.houseAccountPayments || {});
  housePmts.sort((a: any, b: any) => new Date(a.timestamp || 0).getTime() - new Date(b.timestamp || 0).getTime());

  for (const pmt of housePmts) {
    const ts = pmt.timestamp;
    const loc = pmt.branchId || 'gra';
    if (!matchesBranch(loc, true) || !matchesDate(ts)) continue;

    const amt = roundMoney(Number(pmt.amount || 0));
    if (amt <= 0) continue;

    const bankCode = mapTenderToAccountCode(pmt.paymentMethod || 'bank_transfer');
    const ref = pmt.receiptNumber || pmt.id;
    pushEntry('HOUSE_ACCOUNT_REMITTANCE', pmt.id, ref, ts, loc, [
      {
        accountCode: bankCode,
        debit: amt,
        credit: 0,
        memo: `Corporate house account remittance from ${pmt.companyName || 'Corporate Client'} (${pmt.bankReference || ref})`,
      },
      {
        accountCode: '1100',
        debit: 0,
        credit: amt,
        memo: `Accounts Receivable settlement for ${pmt.companyName || 'Corporate Client'}`,
      },
    ]);
  }

  const allLines: JournalLine[] = entries.flatMap((e) => e.lines);
  const totalDebits = roundMoney(allLines.reduce((s, l) => s + l.debit, 0));
  const totalCredits = roundMoney(allLines.reduce((s, l) => s + l.credit, 0));
  const variance = roundMoney(Math.abs(totalDebits - totalCredits));

  if (variance !== 0) {
    throw new Error(`Ledger trial balance out of balance: totalDebits=${totalDebits}, totalCredits=${totalCredits}`);
  }

  const tbMap = new Map<string, { totalDebit: number; totalCredit: number }>();
  for (const l of allLines) {
    const curr = tbMap.get(l.accountCode) || { totalDebit: 0, totalCredit: 0 };
    curr.totalDebit = roundMoney(curr.totalDebit + l.debit);
    curr.totalCredit = roundMoney(curr.totalCredit + l.credit);
    tbMap.set(l.accountCode, curr);
  }

  const trialBalanceByAccount = Array.from(tbMap.entries())
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([code, totals]) => {
      const acct = chart[code];
      const netBalance =
        acct.normalBalance === 'DEBIT'
          ? roundMoney(totals.totalDebit - totals.totalCredit)
          : roundMoney(totals.totalCredit - totals.totalDebit);
      return {
        accountCode: code,
        accountName: acct.name,
        type: acct.type,
        totalDebit: totals.totalDebit,
        totalCredit: totals.totalCredit,
        netBalance,
      };
    });

  const digestPayload = JSON.stringify({
    branchFilter,
    period,
    startDate: options.startDate || '',
    endDate: options.endDate || '',
    taxMode: configuredTaxMode,
    lines: allLines.map((l) => ({
      sourceId: l.sourceId,
      accountCode: l.accountCode,
      debit: l.debit,
      credit: l.credit,
    })),
  });
  const exportDigest = crypto.createHash('sha256').update(digestPayload).digest('hex').slice(0, 24);

  if (options.preventDuplicateExport) {
    db.accountingExports = db.accountingExports || {};
    const existingBatch = db.accountingExports[exportDigest];
    if (existingBatch && !options.allowReExport) {
      throw new Error(
        `DUPLICATE_EXPORT_BLOCKED: Journal batch with digest ${exportDigest} was already exported on ${existingBatch.exportedAt} by ${existingBatch.exportedBy}. Pass allowReExport=true to re-download.`
      );
    }
    db.accountingExports[exportDigest] = {
      digest: exportDigest,
      branchId: branchFilter,
      period,
      startDate: options.startDate || null,
      endDate: options.endDate || null,
      taxMode: configuredTaxMode,
      transactionCount: entries.length,
      totalDebits,
      totalCredits,
      exportedAt: new Date().toISOString(),
      exportedBy: options.exportedBy || 'system',
    };
  }

  return {
    branchId: branchFilter,
    branchName: resolveBranchLabel(branchFilter),
    period,
    startDate: options.startDate,
    endDate: options.endDate,
    taxMode: configuredTaxMode,
    vatRatePct: configuredTaxMode === 'exempt' ? 0 : 7.5,
    accountantTaxPolicyStatus: accountantConfirmed ? 'CONFIRMED' : 'PENDING_ACCOUNTANT_CONFIRMATION',
    generatedAt: new Date().toISOString(),
    entries,
    lines: allLines,
    trialBalanceByAccount,
    summary: {
      transactionCount: entries.length,
      lineCount: allLines.length,
      totalDebits,
      totalCredits,
      variance,
      isBalanced: variance === 0,
      ...salesTotals,
      grnInventoryAdditions,
      wastageWriteOffs,
      operatingExpensesPaidOut,
    },
    exportDigest,
  };
}
