import type { Request, Response, NextFunction } from 'express';
import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import { CANONICAL_PRIVILEGE_CATEGORIES } from '../../src/data/rbacCatalogue.ts';
import type {
  DbDatabase,
  DbStaffAccount,
  DbSession,
  DbAuditLog,
} from '../../server_db.ts';

export const SESSION_COOKIE_NAME = 'choplife_staff_session';

export function hashPasswordBcrypt(password: string): string {
  return bcrypt.hashSync(password, 10);
}

export function validateStaffPasswordPolicy(password: string): { valid: boolean; error?: string } {
  if (!password || typeof password !== 'string' || password.length < 8) {
    return { valid: false, error: 'Password must be at least 8 characters long.' };
  }
  if (!/[A-Za-z]/.test(password) || !/[0-9!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(password)) {
    return {
      valid: false,
      error: 'Password must contain at least one letter and at least one number or special character.',
    };
  }
  return { valid: true };
}

export function verifyStaffPassword(password: string, staff: DbStaffAccount): { valid: boolean; needsRehash: boolean } {
  if (!password || !staff.passwordHash) return { valid: false, needsRehash: false };

  if (staff.passwordHash.startsWith('$2a$') || staff.passwordHash.startsWith('$2b$')) {
    try {
      const valid = bcrypt.compareSync(password, staff.passwordHash);
      return { valid, needsRehash: false };
    } catch {
      return { valid: false, needsRehash: false };
    }
  }

  if (staff.salt) {
    try {
      const derivedKey = crypto.scryptSync(password, staff.salt, 64);
      const keyBuffer = Buffer.from(derivedKey.toString('hex'), 'hex');
      const hashBuffer = Buffer.from(staff.passwordHash, 'hex');
      if (keyBuffer.length === hashBuffer.length && crypto.timingSafeEqual(keyBuffer, hashBuffer)) {
        return { valid: true, needsRehash: true };
      }
    } catch {
      return { valid: false, needsRehash: false };
    }
  }

  return { valid: false, needsRehash: false };
}

export function hashPassword(password: string, salt?: string): { hash: string; salt: string } {
  const generatedSalt = salt || crypto.randomBytes(16).toString('hex');
  const derivedKey = crypto.scryptSync(password, generatedSalt, 64);
  return {
    hash: derivedKey.toString('hex'),
    salt: generatedSalt,
  };
}

export function verifyPassword(password: string, hash: string, salt: string): boolean {
  try {
    const derivedKey = crypto.scryptSync(password, salt, 64);
    const keyBuffer = Buffer.from(derivedKey.toString('hex'), 'hex');
    const hashBuffer = Buffer.from(hash, 'hex');
    if (keyBuffer.length !== hashBuffer.length) return false;
    return crypto.timingSafeEqual(keyBuffer, hashBuffer);
  } catch {
    return false;
  }
}

interface RateLimitRecord {
  attempts: number;
  lockoutUntil: number;
}
const rateLimitMap: Map<string, RateLimitRecord> = new Map();
const MAX_ATTEMPTS = 5;
const LOCKOUT_DURATION_MS = 15 * 60 * 1000;

export function checkRateLimit(identifier: string): { isLocked: boolean; remainingSeconds?: number } {
  const record = rateLimitMap.get(identifier);
  const now = Date.now();
  if (!record) return { isLocked: false };

  if (record.lockoutUntil > now) {
    const remainingSeconds = Math.ceil((record.lockoutUntil - now) / 1000);
    return { isLocked: true, remainingSeconds };
  }

  if (record.lockoutUntil <= now && record.attempts >= MAX_ATTEMPTS) {
    rateLimitMap.delete(identifier);
    return { isLocked: false };
  }

  return { isLocked: false };
}

export function recordFailedAttempt(identifier: string) {
  const record = rateLimitMap.get(identifier) || { attempts: 0, lockoutUntil: 0 };
  record.attempts += 1;
  if (record.attempts >= MAX_ATTEMPTS) {
    record.lockoutUntil = Date.now() + LOCKOUT_DURATION_MS;
  }
  rateLimitMap.set(identifier, record);
}

export function clearRateLimit(identifier: string) {
  rateLimitMap.delete(identifier);
}

export function createAuthAndRbacHelpers(deps: {
  getDb: () => DbDatabase;
  saveDatabase: () => void;
}) {
  const { getDb, saveDatabase } = deps;

  function logAuditEvent(
    staffName: string,
    staffRole: string,
    branchId: string,
    actionType: string,
    details: string,
    metadata?: Record<string, any>
  ) {
    const db = getDb();
    const log: DbAuditLog = {
      id: `audit-${Date.now()}-${crypto.randomBytes(4).toString('hex')}`,
      timestamp: new Date().toISOString(),
      staffName,
      staffRole,
      branchId,
      actionType,
      details,
      metadata,
    };
    db.auditLogs.unshift(log);
    if (db.auditLogs.length > 2000) {
      db.auditLogs.pop();
    }
    saveDatabase();
  }

  function getSessionFromRequest(req: Request): DbSession | null {
    const db = getDb();
    const token = req.cookies?.[SESSION_COOKIE_NAME] || req.headers.authorization?.replace('Bearer ', '');
    if (!token) return null;

    const session = db.sessions[token];
    if (!session) return null;

    const now = Date.now();
    if (session.expiresAt < now) {
      delete db.sessions[token];
      saveDatabase();
      return null;
    }

    const IDLE_TIMEOUT_MS = 4 * 60 * 60 * 1000;
    if (now - session.lastActivity > IDLE_TIMEOUT_MS) {
      delete db.sessions[token];
      saveDatabase();
      return null;
    }

    session.lastActivity = now;
    saveDatabase();
    return session;
  }

  function requireAuth(req: Request, res: Response, next: NextFunction) {
    const db = getDb();
    const session = getSessionFromRequest(req);
    if (!session) {
      return res.status(401).json({ error: 'Unauthorized. Valid staff session required.' });
    }

    const staff = db.staff[session.staffId];
    if (!staff || staff.status === 'suspended') {
      delete db.sessions[session.token];
      saveDatabase();
      return res.status(403).json({ error: 'Staff account suspended or no longer active.' });
    }

    (req as any).session = session;
    (req as any).staff = staff;
    next();
  }

  function requireRole(allowedRoles: string[]) {
    return (req: Request, res: Response, next: NextFunction) => {
      const staff = (req as any).staff as DbStaffAccount;
      if (!staff) return res.status(401).json({ error: 'Unauthorized.' });

      if (staff.role === 'super_admin' || staff.role === 'admin') {
        return next();
      }

      if (!allowedRoles.includes(staff.role)) {
        return res.status(403).json({
          error: `Forbidden: role '${staff.role}' is not authorized for this operation.`,
          requiredRoles: allowedRoles,
        });
      }
      next();
    };
  }

  function getStaffPrivileges(staff: DbStaffAccount): string[] {
    const db = getDb();
    if (staff.role === 'super_admin' || staff.role === 'admin') {
      const allCodes = CANONICAL_PRIVILEGE_CATEGORIES.flatMap((c) => c.privileges.map((p) => p.code));
      return ['*', ...allCodes];
    }

    let basePrivileges: string[] = [];

    const roleObj = db.roles?.[`role-${staff.role}`] ||
      Object.values(db.roles || {}).find((r) => r.code === staff.role || r.id === staff.role);

    if (roleObj && Array.isArray(roleObj.privileges)) {
      basePrivileges = [...roleObj.privileges];
    } else {
      const roleMap: Record<string, string[]> = {
        branch_manager: [
          'backoffice.access', 'staff.view', 'pos.access', 'pos.check.create', 'pos.check.settle',
          'pos.check.split', 'pos.table.transfer', 'pos.discount.apply', 'pos.item.void',
          'pos.receipt.reprint', 'pos.kds.bump', 'menu.view', 'menu.availability.toggle',
          'inventory.view', 'inventory.adjust', 'inventory.transfer', 'inventory.purchase_order',
          'inventory.grn.receive', 'inventory.wastage.record', 'shifts.open', 'shifts.cash_movement',
          'shifts.close', 'shifts.zreport.view', 'finance.eod.reconcile', 'customer.view',
          'customer.wallet.topup', 'catering.manage', 'customercare.tickets.manage', 'delivery.view',
          'delivery.assign', 'delivery.handover_pin.view', 'delivery.free_authorise',
          'delivery.cod.reconcile', 'delivery.status.update', 'security.audit.view', 'reports.view',
          'hardware.printers.view', 'hardware.printers.manage', 'hardware.printers.test',
          'hardware.templates.edit', 'hardware.templates.reset',
          'content.edit', 'content.publish', 'menu.category.manage', 'menu.create', 'menu.publish', 'menu.edit'
        ],
        content_editor: [
          'backoffice.access', 'content.edit', 'content.publish'
        ],
        menu_manager: [
          'backoffice.access', 'menu.view', 'menu.edit', 'menu.create', 'menu.publish',
          'menu.category.manage', 'menu.availability.toggle', 'menu.recipe.view'
        ],
        cashier: [
          'pos.access', 'pos.check.create', 'pos.check.settle', 'pos.check.split',
          'pos.table.transfer', 'pos.receipt.reprint', 'shifts.open', 'shifts.close',
          'shifts.cash_movement', 'customer.view', 'customer.wallet.topup', 'hardware.printers.view'
        ],
        kitchen_lead: [
          'pos.kds.bump', 'menu.view', 'inventory.view', 'inventory.wastage.record', 'catering.manage',
          'hardware.printers.view', 'hardware.printers.test'
        ],
        storekeeper: [
          'inventory.view', 'inventory.adjust', 'inventory.transfer', 'inventory.purchase_order',
          'inventory.grn.receive', 'inventory.wastage.record', 'reports.view', 'hardware.printers.view'
        ],
        dispatch_lead: [
          'delivery.view', 'delivery.assign', 'delivery.handover_pin.view',
          'delivery.cod.reconcile', 'delivery.status.update'
        ],
        rider: [
          'delivery.view', 'delivery.status.update'
        ],
        auditor: [
          'backoffice.access', 'staff.view', 'inventory.view', 'menu.view', 'menu.recipe.view',
          'shifts.zreport.view', 'finance.ledger.view', 'security.audit.view',
          'security.sessions.view', 'reports.view', 'reports.export', 'customer.view', 'delivery.view',
          'hardware.printers.view'
        ],
        accountant: [
          'backoffice.access', 'shifts.zreport.view', 'finance.ledger.view', 'finance.eod.reconcile',
          'security.audit.view', 'reports.view', 'reports.export', 'inventory.view'
        ],
        customer_care: [
          'customer.view', 'customercare.tickets.manage', 'delivery.view', 'pos.access', 'catering.manage'
        ],
        receptionist: [
          'pos.access', 'pos.check.create', 'pos.table.transfer', 'customer.view', 'catering.manage'
        ]
      };

      basePrivileges = roleMap[staff.role] || [];
    }

    if (Array.isArray(staff.customPrivileges)) {
      return Array.from(new Set([...basePrivileges, ...staff.customPrivileges]));
    }

    return basePrivileges;
  }

  function hasPermission(staff: DbStaffAccount, permissionCode: string): boolean {
    if (staff.role === 'super_admin' || staff.role === 'admin') return true;
    const privileges = getStaffPrivileges(staff);
    if (privileges.includes('*') || privileges.includes(permissionCode)) return true;
    const [domain] = permissionCode.split('.');
    if (domain && privileges.includes(`${domain}.*`)) return true;
    return false;
  }

  function requirePermission(permissionCode: string) {
    return (req: Request, res: Response, next: NextFunction) => {
      const staff = (req as any).staff as DbStaffAccount;
      if (!staff) return res.status(401).json({ error: 'Unauthorized. Staff authentication required.' });

      if (hasPermission(staff, permissionCode)) {
        return next();
      }

      logAuditEvent(
        staff.name,
        staff.role,
        staff.branchId,
        'PERMISSION_DENIED',
        `Access denied: Missing privilege '${permissionCode}' for ${staff.name} (${staff.role})`
      );

      return res.status(403).json({
        error: `Access Denied: Missing required privilege '${permissionCode}'.`,
        missingPermission: permissionCode,
        staffRole: staff.role,
      });
    };
  }

  function requireBranchAccess(req: Request, res: Response, next: NextFunction) {
    const staff = (req as any).staff as DbStaffAccount;
    if (!staff) return res.status(401).json({ error: 'Unauthorized.' });

    if (['super_admin', 'corporate_admin', 'auditor', 'accountant'].includes(staff.role)) {
      return next();
    }

    const requestedBranch = (req.params.branchId || req.query.branchId || req.body?.branchId) as string | undefined;

    if (requestedBranch === 'all') {
      return res.status(403).json({
        error: `Access denied. Enterprise-wide 'all' scope is restricted to corporate administrators and auditors.`,
      });
    }

    const staffAllowedBranches = Array.from(
      new Set([staff.branchId, ...(staff.allowedBranchIds || [])].filter(Boolean))
    );

    if (requestedBranch && !staffAllowedBranches.includes(requestedBranch)) {
      return res.status(403).json({
        error: `Access denied. Staff member is assigned to [${staffAllowedBranches.join(', ')}] and cannot access '${requestedBranch}'.`,
      });
    }

    if (req.query && !req.query.branchId) (req.query as any).branchId = staff.branchId;
    if (req.body && typeof req.body === 'object' && !req.body.branchId) req.body.branchId = staff.branchId;

    next();
  }

  return {
    logAuditEvent,
    getSessionFromRequest,
    requireAuth,
    requireRole,
    getStaffPrivileges,
    hasPermission,
    requirePermission,
    requireBranchAccess,
  };
}
