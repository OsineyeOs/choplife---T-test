import { Router } from 'express';
import crypto from 'crypto';
import type {
  DbDatabase,
  DbStaffAccount,
  DbCheck,
  DbCheckItem,
} from '../../server_db.ts';
import { dispatchTermiiSms } from '../../server_notifications.ts';
import { evaluateInventoryReorderAlerts } from './stockAlertService.ts';

export function createOrderInventoryDepleter(deps: {
  getDb: () => DbDatabase;
  saveDatabaseSync: () => void;
  logAuditEvent: (
    staffName: string,
    staffRole: string,
    branchId: string,
    actionType: string,
    details: string,
    metadata?: Record<string, any>
  ) => void;
}) {
  const { getDb, saveDatabaseSync, logAuditEvent } = deps;

  return function depleteInventoryForOrder(
    items: DbCheckItem[],
    branchId: string,
    orderRef: string,
    staff: DbStaffAccount
  ) {
    const db = getDb();
    for (const it of items) {
      const targetProdId = it.productId || (it as any).menuItemId || '';
      const itName = (it.name || '').toLowerCase();
      const recipe = Object.values(db.recipes).find(
        (r: any) =>
          r.menuProductId === targetProdId ||
          r.productId === targetProdId ||
          (r.menuProductName && itName.includes(r.menuProductName.toLowerCase())) ||
          (itName.includes('jollof') && r.id.includes('jollof')) ||
          (itName.includes('shawarma') && r.id.includes('shawarma')) ||
          (itName.includes('chops') && r.id.includes('mini'))
      );

      if (recipe && Array.isArray(recipe.ingredients)) {
        for (const ing of recipe.ingredients) {
          const invItem = db.inventory[ing.ingredientItemId];
          if (invItem) {
            const rawRecipeQty = (Number(ing.quantity || 0) * Number(it.quantity || 1)) / Number(recipe.yieldPortions || 1);
            const unitFactor =
              ing.unit && invItem.baseUnit && ing.unit !== invItem.baseUnit && Number(invItem.recipeUnitFactor) > 0
                ? Number(invItem.recipeUnitFactor)
                : 1;
            const qtyToDeduct = Number((rawRecipeQty * unitFactor).toFixed(4));
            const currentOnHand = invItem.locationStock?.[branchId]?.stockOnHand ?? invItem.currentStock?.[branchId] ?? 0;
            const newOnHand = Number(Math.max(0, currentOnHand - qtyToDeduct).toFixed(4));

            if (!invItem.locationStock) invItem.locationStock = {};
            if (!invItem.locationStock[branchId]) {
              invItem.locationStock[branchId] = {
                stockOnHand: newOnHand,
                availableStock: newOnHand,
                reservedStock: 0,
                minThreshold: 10,
                parLevel: 50,
                reorderLevel: 20,
                reorderQuantity: 30,
                unitCost: invItem.costPerUnit || 1000,
              };
            } else {
              invItem.locationStock[branchId].stockOnHand = newOnHand;
              invItem.locationStock[branchId].availableStock = newOnHand;
            }

            if (invItem.currentStock) {
              invItem.currentStock[branchId] = newOnHand;
            }

            const unitCost = invItem.costPerUnit || 1000;
            db.ledger.unshift({
              id: `tx-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`,
              referenceNo: orderRef,
              referenceId: orderRef,
              timestamp: new Date().toISOString(),
              date: new Date().toISOString().split('T')[0],
              itemId: invItem.id,
              itemName: invItem.name,
              sku: invItem.sku || 'SKU-GEN',
              locationId: branchId,
              transactionType: 'POS_DEPLETION',
              quantityDelta: -qtyToDeduct,
              unit: invItem.baseUnit || invItem.unit || ing.unit || 'units',
              unitCost,
              totalValue: Number((qtyToDeduct * unitCost).toFixed(2)),
              balanceBefore: currentOnHand,
              balanceAfter: newOnHand,
              performedByStaffId: staff.id,
              performedByName: staff.name,
              performedByRole: staff.role,
              notes: `Recipe depletion for ${it.name} (x${it.quantity}) - Order #${orderRef}`,
            });
          }
        }
      }
    }

    try {
      evaluateInventoryReorderAlerts({
        db,
        saveDatabaseSync,
        dispatchTermiiSms,
        logAuditEvent,
        locationFilter: branchId,
        triggeredByStaff: {
          name: staff?.name || 'POS Depletion Engine',
          role: staff?.role || 'system',
          branchId,
        },
      });
    } catch (err) {
      console.error('[STOCK ALERT] Evaluation after depletion failed:', err);
    }
  };
}

export function createPosOfflineAndTableTransferRouter(deps: {
  getDb: () => DbDatabase;
  saveDatabaseSync: () => void;
  requireAuth: any;
  depleteInventoryForOrder: (
    items: DbCheckItem[],
    branchId: string,
    orderRef: string,
    staff: DbStaffAccount
  ) => void;
  logAuditEvent: (
    staffName: string,
    staffRole: string,
    branchId: string,
    actionType: string,
    details: string,
    metadata?: Record<string, any>
  ) => void;
}): Router {
  const router = Router();
  const {
    getDb,
    saveDatabaseSync,
    requireAuth,
    depleteInventoryForOrder,
    logAuditEvent,
  } = deps;

  // 4.3B Offline POS Transaction Reconciliation Engine
  router.post(['/api/pos/sync-offline', '/api/pos/offline/sync'], requireAuth, (req, res) => {
    const db = getDb();
    try {
      const currentStaff = (req as any).staff as DbStaffAccount;
      const rawItems = req.body.items || req.body.queue || [];
      if (!Array.isArray(rawItems) || rawItems.length === 0) {
        return res.json({ success: true, syncedCount: 0, syncedIds: [], results: [] });
      }

      const syncedIds: string[] = [];
      const results: any[] = [];
      const now = new Date().toISOString();

      for (const item of rawItems) {
        try {
          const { id, action, payload } = item;
          const normAction = String(action || '').toUpperCase();
          if (normAction === 'CREATE_CHECK' || normAction === 'PAY_CHECK') {
            const checkId = payload.id || `chk-off-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
            const branchId = payload.branchId || currentStaff.branchId || 'gra';

            if (db.checks[checkId] && db.checks[checkId].paymentStatus === 'paid') {
              syncedIds.push(id);
              results.push({ id, checkNumber: db.checks[checkId].checkNumber, status: 'already_synced' });
              continue;
            }

            const check: DbCheck = {
              id: checkId,
              checkNumber: payload.checkNumber || `CHK-${String(Object.keys(db.checks).length + 1).padStart(5, '0')}`,
              branchId,
              tableId: payload.tableId,
              tableNumber: payload.tableNumber,
              checkType: payload.checkType || 'dine_in',
              status: payload.status || (action === 'PAY_CHECK' ? 'paid' : 'open'),
              customerName: payload.customerName || 'Offline Customer',
              customerPhone: payload.customerPhone || '',
              guestCount: payload.guestCount || 1,
              items: (payload.items || []).map((it: any) => ({
                id: it.id || `item-${Date.now()}-${crypto.randomBytes(2).toString('hex')}`,
                productId: it.productId,
                name: it.name,
                quantity: it.quantity || 1,
                unitPrice: it.unitPrice || 0,
                totalPrice: (it.unitPrice || 0) * (it.quantity || 1),
                notes: it.notes,
                status: it.status || 'sent_to_kitchen',
                sentToKitchenAt: it.sentToKitchenAt || now,
                customization: it.customization,
              })),
              subtotal: payload.subtotal || 0,
              discountAmount: payload.discountAmount || 0,
              discountPercent: payload.discountPercent || 0,
              discountReason: payload.discountReason,
              packagingFee: payload.packagingFee || 0,
              deliveryFee: payload.deliveryFee || 0,
              total: payload.total || 0,
              paymentStatus: action === 'PAY_CHECK' ? 'paid' : (payload.paymentStatus || 'unpaid'),
              paymentMethod: payload.paymentMethod,
              paymentDetails: payload.paymentDetails,
              paidAt: action === 'PAY_CHECK' ? (payload.paidAt || now) : undefined,
              settledByStaffId: currentStaff.id,
              settledByName: currentStaff.name,
              openedAt: payload.openedAt || now,
              openedByStaffId: currentStaff.id,
              openedByName: currentStaff.name,
              notes: payload.notes ? `${payload.notes} [Synced from Offline POS]` : '[Synced from Offline POS]',
            };

            db.checks[checkId] = check;

            if (check.paymentStatus === 'paid' && check.paymentMethod === 'cash') {
              const activeShift = Object.values(db.shifts).find(
                (s) => s.branchId === check.branchId && s.status === 'open'
              );
              if (activeShift) {
                activeShift.totalCashSales += check.total;
                activeShift.expectedCashInTill += check.total;
                db.cashMovements.push({
                  id: `cm-off-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`,
                  shiftId: activeShift.id,
                  branchId: check.branchId,
                  timestamp: now,
                  movementType: 'cash_sale',
                  amount: check.total,
                  reason: `Offline reconciled cash payment for ${check.checkNumber}`,
                  staffId: currentStaff.id,
                  staffName: currentStaff.name,
                  recipientOrRef: check.checkNumber,
                });
              }
            }

            try {
              depleteInventoryForOrder(
                check.items,
                check.branchId,
                check.checkNumber,
                { id: 'offline-sync', name: 'Offline Engine', role: 'cashier', branchId: check.branchId } as any
              );
            } catch {}

            syncedIds.push(id);
            results.push({ id, checkNumber: check.checkNumber, status: 'synced' });
          } else {
            syncedIds.push(id);
            results.push({ id, status: 'acknowledged' });
          }
        } catch (err: any) {
          console.error('[OFFLINE SYNC ITEM ERROR]', err);
        }
      }

      saveDatabaseSync();
      res.json({ success: true, syncedCount: syncedIds.length, syncedIds, results });
    } catch (err: any) {
      console.error('[OFFLINE SYNC ERROR]', err);
      res.status(500).json({ error: err.message });
    }
  });

  // Transfer Check to Another Table
  router.post('/api/pos/checks/:id/transfer-table', requireAuth, (req, res) => {
    const db = getDb();
    const { id } = req.params;
    const { newTableId, newTableNumber } = req.body;
    const currentStaff = (req as any).staff as DbStaffAccount;
    const check = db.checks[id];

    if (!check) return res.status(404).json({ error: 'Check not found.' });

    const oldTableId = check.tableId;
    const oldTableNumber = check.tableNumber;

    if (oldTableId && db.tables[oldTableId]) {
      db.tables[oldTableId].status = 'available';
      db.tables[oldTableId].currentCheckId = undefined;
      db.tables[oldTableId].updatedAt = new Date().toISOString();
    }

    check.tableId = newTableId;
    check.tableNumber = newTableNumber;

    if (newTableId && db.tables[newTableId]) {
      db.tables[newTableId].status = 'ordering';
      db.tables[newTableId].currentCheckId = check.id;
      db.tables[newTableId].guestCount = check.guestCount;
      db.tables[newTableId].updatedAt = new Date().toISOString();
    }

    saveDatabaseSync();
    logAuditEvent(
      currentStaff.name,
      currentStaff.role,
      currentStaff.branchId,
      'STATUS_CHANGED',
      `Transferred check ${check.checkNumber} from ${oldTableNumber} to ${newTableNumber}`
    );

    res.json({ success: true, check });
  });

  return router;
}
