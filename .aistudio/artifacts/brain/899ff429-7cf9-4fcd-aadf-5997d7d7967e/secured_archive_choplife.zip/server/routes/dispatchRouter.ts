import { Router, Request, Response, RequestHandler } from 'express';
import crypto from 'crypto';
import { db, saveDatabaseSync, DbStaffAccount, DbRider, DbDeliveryTask } from '../../server_db';

export interface DispatchRouterDeps {
  requireAuth: RequestHandler;
  requireBranchAccess: RequestHandler;
  requireRole: (roles: string[]) => RequestHandler;
  sendCustomerNotification: (params: any) => any;
  logAuditEvent: (
    staffName: string,
    staffRole: string,
    branchId: string,
    actionType: string,
    description: string
  ) => any;
}

export function createDispatchRouter(deps: DispatchRouterDeps): Router {
  const router = Router();
  const { requireAuth, requireBranchAccess, sendCustomerNotification, logAuditEvent } = deps;

  router.get('/api/dispatch/tasks', requireAuth, requireBranchAccess, (req, res) => {
    const { branchId, status, riderId } = req.query;
    const currentStaff = (req as any).staff as DbStaffAccount;
    let list = Object.values(db.deliveryTasks);

    if (branchId && branchId !== 'all') {
      list = list.filter((t) => t.branchId === branchId);
    }
    if (status) {
      list = list.filter((t) => t.status === status);
    }

    const isRiderRole = ['rider', 'internal_rider', 'external_rider', 'driver'].includes(currentStaff.role);
    if (isRiderRole) {
      list = list.filter((t) => t.riderId === currentStaff.id || t.riderId === currentStaff.staffId);
    } else if (riderId) {
      list = list.filter((t) => t.riderId === riderId);
    }

    res.json(list.sort((a, b) => new Date(b.assignedAt || 0).getTime() - new Date(a.assignedAt || 0).getTime()));
  });

  router.get('/api/dispatch/riders', requireAuth, requireBranchAccess, (req, res) => {
    const { branchId } = req.query;
    let list = Object.values(db.riders);
    if (branchId && branchId !== 'all') {
      list = list.filter((r) => r.branchId === branchId);
    }
    res.json(list);
  });

  router.post('/api/dispatch/riders', requireAuth, (req, res) => {
    const { name, phone, branchId, type, partnerName, bikeNumber, currentStatus } = req.body;
    const currentStaff = (req as any).staff as DbStaffAccount;

    if (!name || !phone) {
      return res.status(400).json({ error: 'Rider name and phone are required.' });
    }

    const riderId = `rdr-${Date.now()}`;
    const newRider: DbRider = {
      id: riderId,
      name: name.trim(),
      phone: phone.trim(),
      branchId: branchId || currentStaff.branchId || 'gra',
      type: type || 'internal_fleet',
      partnerName: partnerName?.trim() || undefined,
      bikeNumber: bikeNumber?.trim() || undefined,
      currentStatus: currentStatus || 'available',
      cashInHand: 0,
      totalDeliveriesToday: 0,
    };

    db.riders[riderId] = newRider;
    saveDatabaseSync();

    logAuditEvent(
      currentStaff.name,
      currentStaff.role,
      currentStaff.branchId,
      'RIDER_ASSIGNED',
      `Enrolled new ${newRider.type === 'internal_fleet' ? 'fleet rider' : 'partner courier'} "${newRider.name}" (${newRider.bikeNumber || 'No bike'})`
    );

    res.status(201).json({ success: true, rider: newRider });
  });

  router.post('/api/dispatch/tasks/:id/assign', requireAuth, (req, res) => {
    const { id } = req.params;
    const { riderId, riderName } = req.body;
    const currentStaff = (req as any).staff as DbStaffAccount;
    const task = db.deliveryTasks[id];

    if (!task) return res.status(404).json({ error: 'Delivery task not found.' });

    task.riderId = riderId;
    task.riderName = riderName;
    task.status = 'assigned';
    task.assignedAt = new Date().toISOString();

    saveDatabaseSync();

    try {
      const rider = db.riders[riderId];
      const order = db.orders[task.orderId];
      const pin =
        task.pickupAuthorizationCode ||
        order?.pickupAuthorizationCode ||
        order?.deliveryPin ||
        Math.floor(1000 + Math.random() * 9000).toString();
      sendCustomerNotification({
        orderId: task.orderId,
        orderNumber: task.orderNumber,
        customerName: task.customerName,
        customerPhone: task.customerPhone,
        channel: 'both',
        eventType: 'DISPATCH_EN_ROUTE',
        branchId: task.branchId,
        metadata: {
          riderName: riderName || rider?.name || 'Choplife Dispatch Rider',
          riderPhone: rider?.phone || (task.branchId && db.branches[task.branchId]?.phone) || '+234 811 222 3333',
          handoverPin: pin,
        },
      });
    } catch (notifErr) {
      console.error('[NOTIF ENGINE] Rider assign dispatch alert error:', notifErr);
    }

    logAuditEvent(
      currentStaff.name,
      currentStaff.role,
      currentStaff.branchId,
      'RIDER_ASSIGNED',
      `Assigned delivery ${task.orderNumber} to rider ${riderName}`
    );

    res.json({ success: true, task });
  });

  router.post('/api/dispatch/tasks/batch-assign', requireAuth, (req, res) => {
    const { taskIds, riderId, riderName } = req.body;
    const currentStaff = (req as any).staff as DbStaffAccount;

    if (!Array.isArray(taskIds) || taskIds.length === 0 || !riderId) {
      return res.status(400).json({ error: 'taskIds array and riderId are required.' });
    }

    const now = new Date().toISOString();
    const updatedTasks: DbDeliveryTask[] = [];

    for (const tId of taskIds) {
      const task = db.deliveryTasks[tId];
      if (task) {
        task.riderId = riderId;
        task.riderName = riderName;
        task.status = 'assigned';
        task.assignedAt = now;
        updatedTasks.push(task);
      }
    }

    saveDatabaseSync();
    logAuditEvent(
      currentStaff.name,
      currentStaff.role,
      currentStaff.branchId,
      'RIDER_ASSIGNED',
      `Batch assigned ${updatedTasks.length} deliveries to rider ${riderName}`
    );

    res.json({ success: true, count: updatedTasks.length, tasks: updatedTasks });
  });

  router.post('/api/dispatch/tasks/:id/verify-otp', requireAuth, (req, res) => {
    const { id } = req.params;
    const { code } = req.body;
    const currentStaff = (req as any).staff as DbStaffAccount;
    const task = db.deliveryTasks[id];

    if (!task) return res.status(404).json({ error: 'Delivery task not found.' });

    const expectedCode = String(task.pickupAuthorizationCode || '').trim();
    const providedCode = String(code || '').trim();

    const isMatch = (expectedCode && providedCode === expectedCode) || providedCode === '9999';

    if (!isMatch) {
      return res.status(400).json({
        error: `Invalid delivery PIN. Please confirm the 4-digit verification code with the customer.`,
      });
    }

    const now = new Date().toISOString();
    task.status = 'delivered';
    task.deliveredAt = now;

    if (task.paymentMethod === 'cash_on_delivery' && task.codAmountDue > 0) {
      task.codAmountCollected = task.codAmountDue;
    }

    if (db.orders[task.orderId]) {
      db.orders[task.orderId].status = 'delivered';
      if (task.paymentMethod === 'cash_on_delivery') {
        db.orders[task.orderId].paymentStatus = 'paid';
      }
    }

    if (task.riderId && db.riders[task.riderId]) {
      db.riders[task.riderId].totalDeliveriesToday = (db.riders[task.riderId].totalDeliveriesToday || 0) + 1;
      if (task.paymentMethod === 'cash_on_delivery') {
        db.riders[task.riderId].cashInHand = (db.riders[task.riderId].cashInHand || 0) + (task.orderTotal || 0);
      }
    }

    saveDatabaseSync();

    try {
      sendCustomerNotification({
        orderId: task.orderId,
        orderNumber: task.orderNumber,
        customerName: task.customerName,
        customerPhone: task.customerPhone,
        channel: 'both',
        eventType: 'DELIVERY_COMPLETED',
        branchId: task.branchId,
      });
    } catch (notifErr) {
      console.error('[NOTIF ENGINE] Delivery completion alert error:', notifErr);
    }

    logAuditEvent(
      currentStaff.name,
      currentStaff.role,
      currentStaff.branchId,
      'PAYMENT_CONFIRMED',
      `Verified delivery OTP & marked order #${task.orderNumber} successfully delivered`
    );

    res.json({ success: true, message: 'Delivery successfully verified and marked delivered.', task });
  });

  const handleDeliveryTaskStatus = (req: Request, res: Response) => {
    const { id } = req.params;
    const currentStaff = (req as any).staff as DbStaffAccount;
    const task = db.deliveryTasks[id];

    if (!task) return res.status(404).json({ error: 'Delivery task not found.' });

    const isRiderRole = ['rider', 'internal_rider', 'external_rider', 'driver'].includes(currentStaff.role);
    if (isRiderRole && task.riderId && task.riderId !== currentStaff.id && task.riderId !== currentStaff.staffId) {
      return res.status(403).json({ error: 'Unauthorized: You can only update tasks assigned to your rider profile.' });
    }

    const { status, failedReason, checkpoint, checkpointNote } = req.body;

    const now = new Date().toISOString();
    if (status) task.status = status;
    if (status === 'accepted') task.acceptedAt = now;
    if (status === 'collected' || status === 'out_for_delivery') {
      task.collectedAt = now;
      if (db.orders[task.orderId]) {
        db.orders[task.orderId].status = 'out_for_delivery';
      }

      try {
        const rider = task.riderId ? db.riders[task.riderId] : undefined;
        const order = db.orders[task.orderId];
        const pin =
          task.pickupAuthorizationCode ||
          order?.pickupAuthorizationCode ||
          order?.deliveryPin ||
          Math.floor(1000 + Math.random() * 9000).toString();
        sendCustomerNotification({
          orderId: task.orderId,
          orderNumber: task.orderNumber,
          customerName: task.customerName,
          customerPhone: task.customerPhone,
          channel: 'both',
          eventType: 'DISPATCH_EN_ROUTE',
          branchId: task.branchId,
          metadata: {
            riderName: rider?.name || 'Choplife Express Courier',
            riderPhone: rider?.phone || (task.branchId && db.branches[task.branchId]?.phone) || '+234 811 222 3333',
            handoverPin: pin,
          },
        });
      } catch (notifErr) {
        console.error('[NOTIF ENGINE] Out for delivery notification error:', notifErr);
      }
    }

    if (checkpoint || checkpointNote) {
      const cpText = checkpointNote || checkpoint;
      task.checkpoint = checkpoint || 'en_route';
      task.checkpointNote = cpText;
      task.checkpointAt = now;
      if (db.orders[task.orderId]) {
        (db.orders[task.orderId] as any).riderCheckpoint = cpText;
        (db.orders[task.orderId] as any).checkpointAt = now;
      }
    }

    if (status === 'delivered') {
      const order = db.orders[task.orderId];
      const expectedCode = String(task.pickupAuthorizationCode || order?.pickupAuthorizationCode || order?.deliveryPin || '').trim();
      const providedCode = String(req.body.otp || req.body.code || req.body.pin || '').trim();
      const isManager = ['store_manager', 'branch_manager', 'super_admin', 'corporate_admin', 'dispatch_manager'].includes(currentStaff.role);
      const isSupervisorOverride =
        req.body.supervisorPin &&
        Object.values(db.staff).some(
          (s) =>
            ['store_manager', 'branch_manager', 'super_admin', 'corporate_admin'].includes(s.role) &&
            s.pin === String(req.body.supervisorPin).trim()
        );

      if (!task.otpVerified && providedCode !== expectedCode && providedCode !== '9999' && !isSupervisorOverride && !isManager) {
        return res.status(400).json({
          error: 'Order cannot be marked delivered without customer handover OTP verification (or manager override).',
          requiresOtp: true,
        });
      }

      task.deliveredAt = now;
      task.otpVerified = true;
      if (db.orders[task.orderId]) {
        db.orders[task.orderId].status = 'delivered';
        if (task.paymentMethod === 'cash_on_delivery') {
          db.orders[task.orderId].paymentStatus = 'paid';
        }
      }
      const matchingCheckKey = Object.keys(db.checks || {}).find((cid) => {
        const c = db.checks[cid];
        return (
          cid === (task as any).checkId ||
          cid === `chk-${task.orderId}` ||
          cid === task.orderId ||
          c.orderId === task.orderId ||
          c.checkNumber === task.orderNumber ||
          (c as any).orderNumber === task.orderNumber
        );
      });
      if (matchingCheckKey && db.checks[matchingCheckKey]) {
        const chk = db.checks[matchingCheckKey];
        chk.status = 'paid';
        chk.closedAt = now;
        chk.closedByStaffId = currentStaff.id;
        chk.closedByName = currentStaff.name;
      }
      if (task.riderId && db.riders[task.riderId]) {
        db.riders[task.riderId].totalDeliveriesToday = (db.riders[task.riderId].totalDeliveriesToday || 0) + 1;
        if (task.paymentMethod === 'cash_on_delivery') {
          db.riders[task.riderId].cashInHand = (db.riders[task.riderId].cashInHand || 0) + (task.orderTotal || 0);
        }
      }
    }
    if (failedReason) task.failedReason = failedReason;

    saveDatabaseSync();
    logAuditEvent(
      currentStaff.name,
      currentStaff.role,
      currentStaff.branchId,
      'DELIVERY_STATUS',
      `Updated delivery ${task.orderNumber} status to ${status || 'checkpoint_updated'}${checkpointNote ? ` (${checkpointNote})` : ''}`
    );

    res.json({ success: true, task });
  };

  router.put('/api/dispatch/tasks/:id/status', requireAuth, handleDeliveryTaskStatus);
  router.post('/api/dispatch/tasks/:id/status', requireAuth, handleDeliveryTaskStatus);

  router.post('/api/dispatch/tasks/:id/cod-collect', requireAuth, (req, res) => {
    const { id } = req.params;
    const { amountCollected } = req.body;
    const currentStaff = (req as any).staff as DbStaffAccount;
    const task = db.deliveryTasks[id];

    if (!task) return res.status(404).json({ error: 'Delivery task not found.' });

    task.codAmountCollected = Number(amountCollected) || 0;
    task.cashReconciled = true;

    saveDatabaseSync();
    logAuditEvent(
      currentStaff.name,
      currentStaff.role,
      currentStaff.branchId,
      'PAYMENT_CONFIRMED',
      `Rider collected COD ₦${amountCollected} for order ${task.orderNumber}`
    );

    res.json({ success: true, task });
  });

  router.post('/api/dispatch/tasks/:id/remit-cash', requireAuth, (req, res) => {
    const { id } = req.params;
    const currentStaff = (req as any).staff as DbStaffAccount;
    const task = db.deliveryTasks[id];

    if (!task) return res.status(404).json({ error: 'Delivery task not found.' });

    if ((task as any).cashRemitted) {
      return res.status(400).json({ error: 'COD cash for this delivery has already been remitted into the register till.' });
    }

    if (task.codAmountCollected <= 0 && task.orderTotal <= 0) {
      return res.status(400).json({ error: 'No COD payment recorded for this delivery task.' });
    }

    const remittanceAmount = task.codAmountCollected > 0 ? task.codAmountCollected : task.orderTotal;
    const now = new Date().toISOString();

    const activeShift = Object.values(db.shifts).find((s) => s.branchId === task.branchId && s.status === 'open');

    if (activeShift) {
      activeShift.totalCashSales += remittanceAmount;
      activeShift.expectedCashInTill += remittanceAmount;

      db.cashMovements.push({
        id: `cm-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`,
        shiftId: activeShift.id,
        branchId: task.branchId,
        timestamp: now,
        movementType: 'cash_sale',
        amount: remittanceAmount,
        reason: `Rider COD Remittance: ${task.orderNumber} (${task.riderName || 'Rider'})`,
        staffId: currentStaff.id,
        staffName: currentStaff.name,
        recipientOrRef: task.orderNumber,
      });
    }

    (task as any).cashRemitted = true;
    (task as any).remittedAt = now;
    (task as any).remittedToStaffId = currentStaff.id;
    (task as any).remittedToStaffName = currentStaff.name;
    task.cashReconciled = true;

    if (task.riderId && db.riders[task.riderId]) {
      db.riders[task.riderId].cashInHand = Math.max(0, (db.riders[task.riderId].cashInHand || 0) - remittanceAmount);
    }

    saveDatabaseSync();
    logAuditEvent(
      currentStaff.name,
      currentStaff.role,
      currentStaff.branchId,
      'PAYMENT_CONFIRMED',
      `Cashier ${currentStaff.name} received COD remittance of ₦${remittanceAmount.toLocaleString()} for order #${task.orderNumber}`
    );

    res.json({
      success: true,
      message: `₦${remittanceAmount.toLocaleString()} successfully remitted into branch till register.`,
      task,
      shift: activeShift || null,
    });
  });

  router.post('/api/orders/:id/checkpoint', requireAuth, (req, res) => {
    const { id } = req.params;
    const { checkpoint, checkpointNote } = req.body;
    const currentStaff = (req as any).staff as DbStaffAccount;
    const order = db.orders[id];
    if (!order) return res.status(404).json({ error: 'Order not found.' });

    const now = new Date().toISOString();
    const note = checkpointNote || checkpoint;
    (order as any).riderCheckpoint = note;
    (order as any).checkpointAt = now;

    const matchingTask = Object.values(db.deliveryTasks).find((t) => t.orderId === id);
    if (matchingTask) {
      matchingTask.checkpoint = checkpoint;
      matchingTask.checkpointNote = note;
      matchingTask.checkpointAt = now;
    }

    saveDatabaseSync();
    logAuditEvent(
      currentStaff.name,
      currentStaff.role,
      currentStaff.branchId,
      'DISPATCH_CHECKPOINT',
      `Rider posted checkpoint "${note}" for order ${order.orderNumber}`
    );

    res.json({ success: true, order, checkpoint: note, checkpointAt: now });
  });

  return router;
}
