import express from 'express';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import type {
  DbDatabase,
  DbStaffAccount,
  DbCmsContent,
} from '../../server_db.ts';
import { createMenuCatalogueRouter } from './menuCatalogueRouter.ts';

export interface CmsAndMenuRouterDeps {
  getDb: () => DbDatabase;
  saveDatabaseSync: () => void;
  seedCmsAndMenuCatalogue: () => void;
  requireAuth: express.RequestHandler;
  hasPermission: (staff: DbStaffAccount, permissionCode: string) => boolean;
  logAuditEvent: (
    staffName: string,
    role: string,
    branchId: string,
    eventType: string,
    description: string
  ) => void;
  uploadsDir: string;
}

export const DEFAULT_DELIVERY_ZONES: Record<string, { name: string; fee: number; estimatedMinutes: string; active: boolean }> = {
  'GRA Core': { name: 'GRA Core (Ihama / Adesuwa / Boundary Rd)', fee: 700, estimatedMinutes: '25–35 mins', active: true },
  'Ring Road / Airport Rd': { name: 'Ring Road / Airport Road / King Square', fee: 700, estimatedMinutes: '30–45 mins', active: true },
  'Okabere / Sapele Rd': { name: 'Okabere Road / Sapele Road / Limit', fee: 700, estimatedMinutes: '25–40 mins', active: true },
  'Ugbowo / Uselu': { name: 'Ugbowo Campus / Uselu / BDPA', fee: 700, estimatedMinutes: '25–40 mins', active: true },
  'Ekenwan / Siluko': { name: 'Ekenwan Road / Siluko Road / Oliha', fee: 900, estimatedMinutes: '35–50 mins', active: true },
  Standard: { name: 'Benin City Standard Delivery Zone', fee: 700, estimatedMinutes: '30–45 mins', active: true },
};

export function createCmsAndMenuRouter(deps: CmsAndMenuRouterDeps): express.Router {
  const router = express.Router();
  const {
    getDb,
    saveDatabaseSync,
    seedCmsAndMenuCatalogue,
    requireAuth,
    hasPermission,
    logAuditEvent,
    uploadsDir,
  } = deps;

  // ==========================================
  // 3.55 WEBSITE CONTENT (CMS), DELIVERY ZONES & IMAGE UPLOAD API
  // ==========================================
  router.get('/api/delivery/zones', (_req, res) => {
    const db = getDb();
    if (!db.cmsContent) {
      seedCmsAndMenuCatalogue();
    }
    const zones = db.cmsContent?.deliveryZones || DEFAULT_DELIVERY_ZONES;
    res.json(zones);
  });

  router.put('/api/delivery/zones', requireAuth, (req, res) => {
    const db = getDb();
    const currentStaff = (req as any).staff as DbStaffAccount;
    const isAuthorized =
      ['super_admin', 'admin', 'corporate_admin', 'branch_manager', 'content_editor'].includes(currentStaff.role) ||
      hasPermission(currentStaff, 'content.edit');
    if (!isAuthorized) {
      return res.status(403).json({ error: 'Forbidden: Insufficient privileges to update delivery zones.' });
    }
    if (!db.cmsContent) {
      seedCmsAndMenuCatalogue();
    }
    const incomingZones = req.body.deliveryZones || req.body;
    if (!incomingZones || typeof incomingZones !== 'object') {
      return res.status(400).json({ error: 'Valid deliveryZones map is required.' });
    }
    const sanitized: Record<string, { name: string; fee: number; estimatedMinutes: string; active: boolean }> = {};
    for (const [key, val] of Object.entries(incomingZones)) {
      const z = val as any;
      const fee = Number(z?.fee);
      if (Number.isNaN(fee) || fee < 0) {
        return res.status(400).json({ error: `Invalid delivery fee for zone '${key}'. Fee must be >= 0.` });
      }
      sanitized[key] = {
        name: String(z?.name || key).trim(),
        fee,
        estimatedMinutes: String(z?.estimatedMinutes || '30–45 mins').trim(),
        active: z?.active !== undefined ? Boolean(z.active) : true,
      };
    }
    db.cmsContent!.deliveryZones = sanitized;
    if (db.cmsDraft) {
      db.cmsDraft.deliveryZones = sanitized;
    }
    saveDatabaseSync();
    logAuditEvent(
      currentStaff.name,
      currentStaff.role,
      currentStaff.branchId,
      'DELIVERY_ZONES_UPDATED',
      `Updated delivery zone fees (${Object.keys(sanitized).length} zones)`
    );
    res.json({ success: true, deliveryZones: sanitized });
  });

  router.post('/api/uploads/image', requireAuth, (req, res) => {
    const currentStaff = (req as any).staff as DbStaffAccount;
    const isAuthorized =
      ['super_admin', 'admin', 'corporate_admin', 'branch_manager', 'content_editor', 'menu_manager'].includes(
        currentStaff.role
      ) ||
      hasPermission(currentStaff, 'content.edit') ||
      hasPermission(currentStaff, 'menu.edit');

    if (!isAuthorized) {
      return res.status(403).json({ error: 'Forbidden: Insufficient privileges to upload media files.' });
    }

    const { fileName, mimeType, dataBase64 } = req.body || {};
    if (!fileName || !mimeType || !dataBase64 || typeof dataBase64 !== 'string') {
      return res.status(400).json({ error: 'fileName, mimeType, and dataBase64 are required.' });
    }

    const allowedMime: Record<string, string> = {
      'image/jpeg': '.jpg',
      'image/jpg': '.jpg',
      'image/png': '.png',
      'image/webp': '.webp',
    };
    const cleanMime = String(mimeType).toLowerCase().trim();
    const ext = allowedMime[cleanMime];
    if (!ext) {
      return res.status(400).json({ error: `Unsupported image type '${mimeType}'. Allowed types: JPEG, PNG, WebP.` });
    }

    const rawBase64 = dataBase64.includes(',') ? dataBase64.split(',')[1] : dataBase64;
    let buffer: Buffer;
    try {
      buffer = Buffer.from(rawBase64, 'base64');
    } catch {
      return res.status(400).json({ error: 'Malformed base64 image payload.' });
    }

    const maxBytes = 5 * 1024 * 1024;
    if (buffer.length < 12) {
      return res.status(400).json({ error: 'Uploaded file is empty or corrupted.' });
    }
    if (buffer.length > maxBytes) {
      return res.status(400).json({ error: 'Image exceeds the maximum 5 MB file size limit.' });
    }

    const isJpeg = buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff;
    const isPng = buffer[0] === 0x89 && buffer[1] === 0x50 && buffer[2] === 0x4e && buffer[3] === 0x47;
    const isWebp =
      buffer.subarray(0, 4).toString('ascii') === 'RIFF' && buffer.subarray(8, 12).toString('ascii') === 'WEBP';

    if ((ext === '.jpg' && !isJpeg) || (ext === '.png' && !isPng) || (ext === '.webp' && !isWebp)) {
      return res.status(400).json({
        error: 'Binary file signature does not match the declared image MIME type. Upload rejected.',
      });
    }

    const baseSlug =
      path
        .basename(String(fileName), path.extname(String(fileName)))
        .toLowerCase()
        .replace(/[^a-z0-9_-]/g, '-')
        .replace(/-+/g, '-')
        .slice(0, 40) || 'image';
    const uniqueName = `${baseSlug}-${Date.now()}-${crypto.randomBytes(3).toString('hex')}${ext}`;
    const targetPath = path.join(uploadsDir, uniqueName);

    if (!targetPath.startsWith(uploadsDir)) {
      return res.status(400).json({ error: 'Invalid upload file path.' });
    }

    fs.writeFileSync(targetPath, buffer);
    const publicUrl = `/uploads/${uniqueName}`;

    logAuditEvent(
      currentStaff.name,
      currentStaff.role,
      currentStaff.branchId,
      'MEDIA_UPLOADED',
      `Uploaded image '${uniqueName}' (${Math.round(buffer.length / 1024)} KB)`
    );

    res.status(201).json({
      success: true,
      filename: uniqueName,
      url: publicUrl,
      sizeBytes: buffer.length,
      mimeType: cleanMime,
    });
  });

  router.delete('/api/uploads/image/:filename', requireAuth, (req, res) => {
    const currentStaff = (req as any).staff as DbStaffAccount;
    const isAuthorized =
      ['super_admin', 'admin', 'corporate_admin', 'branch_manager', 'content_editor', 'menu_manager'].includes(
        currentStaff.role
      ) ||
      hasPermission(currentStaff, 'content.edit') ||
      hasPermission(currentStaff, 'menu.edit');

    if (!isAuthorized) {
      return res.status(403).json({ error: 'Forbidden: Insufficient privileges to delete uploaded media.' });
    }

    const safeFilename = path.basename(String(req.params.filename || ''));
    if (!safeFilename || safeFilename.includes('..')) {
      return res.status(400).json({ error: 'Invalid filename.' });
    }

    const targetPath = path.join(uploadsDir, safeFilename);
    if (!targetPath.startsWith(uploadsDir) || !fs.existsSync(targetPath)) {
      return res.status(404).json({ error: 'Uploaded image file not found.' });
    }

    fs.unlinkSync(targetPath);
    logAuditEvent(
      currentStaff.name,
      currentStaff.role,
      currentStaff.branchId,
      'MEDIA_DELETED',
      `Deleted uploaded image '${safeFilename}'`
    );
    res.json({ success: true, message: `Deleted uploaded image ${safeFilename}.` });
  });

  router.get('/api/cms/content', (req, res) => {
    const db = getDb();
    if (!db.cmsContent) {
      seedCmsAndMenuCatalogue();
    }
    if (!db.cmsContent!.deliveryZones) {
      db.cmsContent!.deliveryZones = DEFAULT_DELIVERY_ZONES;
    }
    const viewMode = String(req.query.mode || req.query.view || '').toLowerCase();
    if (viewMode === 'draft' && db.cmsDraft) {
      return res.json(db.cmsDraft);
    }
    if (viewMode === 'editor') {
      return res.json({
        ...db.cmsContent,
        draft: db.cmsDraft || db.cmsContent,
      });
    }
    res.json(db.cmsContent);
  });

  router.put('/api/cms/content', requireAuth, (req, res) => {
    const db = getDb();
    const currentStaff = (req as any).staff as DbStaffAccount;
    const isAuthorized =
      currentStaff.role === 'super_admin' ||
      currentStaff.role === 'admin' ||
      currentStaff.role === 'corporate_admin' ||
      currentStaff.role === 'branch_manager' ||
      currentStaff.role === 'content_editor' ||
      hasPermission(currentStaff, 'content.edit') ||
      hasPermission(currentStaff, 'content.publish');

    if (!isAuthorized) {
      return res.status(403).json({ error: 'Forbidden: Insufficient privileges to update website CMS content.' });
    }

    const { hero, contactInfo, banners, articles, status, bankTransferConfig, deliveryZones } = req.body;
    if (!db.cmsContent) {
      seedCmsAndMenuCatalogue();
    }

    const now = new Date().toISOString();
    const baseDraft: DbCmsContent = JSON.parse(JSON.stringify(db.cmsDraft || db.cmsContent));

    if (hero) baseDraft.hero = { ...baseDraft.hero, ...hero };
    if (contactInfo) baseDraft.contactInfo = { ...baseDraft.contactInfo, ...contactInfo };
    if (Array.isArray(banners)) baseDraft.banners = banners;
    if (Array.isArray(articles)) baseDraft.articles = articles;
    if (bankTransferConfig !== undefined) baseDraft.bankTransferConfig = bankTransferConfig;
    if (deliveryZones !== undefined) baseDraft.deliveryZones = deliveryZones;
    baseDraft.updatedAt = now;
    baseDraft.updatedBy = `${currentStaff.name} (${currentStaff.role})`;

    if (status === 'draft') {
      baseDraft.status = 'draft';
      db.cmsDraft = baseDraft;
      saveDatabaseSync();
      logAuditEvent(
        currentStaff.name,
        currentStaff.role,
        currentStaff.branchId,
        'CMS_DRAFT_SAVED',
        `Saved website CMS draft without overwriting live published storefront`
      );
      return res.json({
        success: true,
        mode: 'draft',
        cmsContent: baseDraft,
        publishedContent: db.cmsContent,
      });
    }

    baseDraft.status = 'published';
    baseDraft.publishedAt = now;
    baseDraft.publishedBy = `${currentStaff.name} (${currentStaff.role})`;
    db.cmsContent = JSON.parse(JSON.stringify(baseDraft));
    db.cmsDraft = JSON.parse(JSON.stringify(baseDraft));

    saveDatabaseSync();
    logAuditEvent(
      currentStaff.name,
      currentStaff.role,
      currentStaff.branchId,
      'CMS_CONTENT_PUBLISHED',
      `Published website CMS content to live storefront`
    );

    res.json({ success: true, mode: 'published', cmsContent: db.cmsContent });
  });

  router.use(createMenuCatalogueRouter(deps));

  return router;
}
