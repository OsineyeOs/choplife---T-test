import express from 'express';
import type { DbDatabase, DbStaffAccount } from '../../server_db.ts';
import { createBranchesAndRbacRouter } from './branchesAndRbacRouter.ts';

export interface StaffAndRbacRouterDeps {
  getDb: () => DbDatabase;
  saveDatabaseSync: () => void;
  requireAuth: express.RequestHandler;
  requireRole: (roles: string[]) => express.RequestHandler;
  requirePermission: (permissionCode: string) => express.RequestHandler;
  logAuditEvent: (
    staffName: string,
    role: string,
    branchId: string,
    eventType: string,
    description: string
  ) => void;
  hashPasswordBcrypt: (plainText: string) => string;
  verifyStaffPassword: (plainText: string, staff: DbStaffAccount) => { valid: boolean; needsUpgrade?: boolean };
  validateStaffPasswordPolicy: (password: string) => { valid: boolean; error?: string };
  getStaffPrivileges: (staff: DbStaffAccount) => string[];
}

export function createStaffAndRbacRouter(deps: StaffAndRbacRouterDeps): express.Router {
  const router = express.Router();
  const {
    getDb,
    saveDatabaseSync,
    requireAuth,
    requireRole,
    logAuditEvent,
    hashPasswordBcrypt,
    getStaffPrivileges,
  } = deps;

  // ==========================================
  // 3. STAFF ACCOUNT MANAGEMENT (Admin / Super Admin)
  // ==========================================
  router.get(
    '/api/staff/accounts',
    requireAuth,
    requireRole(['super_admin', 'corporate_admin', 'admin', 'branch_manager', 'auditor']),
    (req, res) => {
      const db = getDb();
      const currentStaff = (req as any).staff as DbStaffAccount;
      const isBranchManager = currentStaff.role === 'branch_manager';
      const isAuditor = currentStaff.role === 'auditor';

      let list = Object.values(db.staff);

      if (isBranchManager) {
        const mgrBranch = currentStaff.branchId;
        list = list.filter((s) => {
          const allowed = s.allowedBranchIds || [s.branchId];
          return s.branchId === mgrBranch || allowed.includes(mgrBranch);
        });
      }

      const mapped = list.map((s) => {
        if (isAuditor) {
          return {
            id: s.id,
            staffId: s.staffId,
            name: s.name,
            workEmail: s.workEmail ? `${s.workEmail.split('@')[0].slice(0, 2)}***@chopliferepublic.com` : undefined,
            phone: '[REDACTED_FOR_AUDITOR]',
            role: s.role,
            branchId: s.branchId,
            allowedBranchIds: s.allowedBranchIds || [s.branchId],
            dateOfBirth: s.dateOfBirth,
            guarantorName: s.guarantorName,
            guarantorPhone: '[REDACTED_FOR_AUDITOR]',
            guarantorRelationship: s.guarantorRelationship,
            status: s.status,
            createdAt: s.createdAt,
            updatedAt: s.updatedAt,
          };
        }

        return {
          id: s.id,
          staffId: s.staffId,
          name: s.name,
          workEmail: s.workEmail,
          phone: s.phone,
          role: s.role,
          branchId: s.branchId,
          allowedBranchIds: s.allowedBranchIds || [s.branchId],
          dateOfBirth: s.dateOfBirth,
          guarantorName: s.guarantorName,
          guarantorPhone: s.guarantorPhone,
          guarantorRelationship: s.guarantorRelationship,
          guarantorAddress: s.guarantorAddress,
          guarantorWorkplace: s.guarantorWorkplace,
          status: s.status,
          createdAt: s.createdAt,
          updatedAt: s.updatedAt,
        };
      });

      res.json(mapped);
    }
  );

  router.get(
    '/api/staff/accounts/:id',
    requireAuth,
    requireRole(['super_admin', 'corporate_admin', 'admin', 'branch_manager', 'auditor']),
    (req, res) => {
      const db = getDb();
      const currentStaff = (req as any).staff as DbStaffAccount;
      const { id } = req.params;
      const s = db.staff[id] || Object.values(db.staff).find((acc) => acc.staffId.toLowerCase() === id.toLowerCase());

      if (!s) return res.status(404).json({ error: 'Staff account not found.' });

      if (currentStaff.role === 'branch_manager') {
        const mgrBranch = currentStaff.branchId;
        const allowed = s.allowedBranchIds || [s.branchId];
        if (s.branchId !== mgrBranch && !allowed.includes(mgrBranch)) {
          return res.status(403).json({ error: 'Access denied: Staff account belongs to another branch.' });
        }
      }

      if (currentStaff.role === 'auditor') {
        return res.json({
          id: s.id,
          staffId: s.staffId,
          name: s.name,
          workEmail: s.workEmail ? `${s.workEmail.split('@')[0].slice(0, 2)}***@chopliferepublic.com` : undefined,
          phone: '[REDACTED_FOR_AUDITOR]',
          role: s.role,
          branchId: s.branchId,
          allowedBranchIds: s.allowedBranchIds || [s.branchId],
          dateOfBirth: s.dateOfBirth,
          guarantorName: s.guarantorName,
          guarantorPhone: '[REDACTED_FOR_AUDITOR]',
          guarantorRelationship: s.guarantorRelationship,
          status: s.status,
          createdAt: s.createdAt,
          updatedAt: s.updatedAt,
        });
      }

      res.json({
        id: s.id,
        staffId: s.staffId,
        name: s.name,
        workEmail: s.workEmail,
        phone: s.phone,
        role: s.role,
        branchId: s.branchId,
        allowedBranchIds: s.allowedBranchIds || [s.branchId],
        customPrivileges: s.customPrivileges,
        dateOfBirth: s.dateOfBirth,
        guarantorName: s.guarantorName,
        guarantorPhone: s.guarantorPhone,
        guarantorRelationship: s.guarantorRelationship,
        guarantorAddress: s.guarantorAddress,
        guarantorWorkplace: s.guarantorWorkplace,
        status: s.status,
        createdAt: s.createdAt,
        updatedAt: s.updatedAt,
      });
    }
  );

  router.post(
    ['/api/staff/accounts', '/api/admin/staff', '/api/staff'],
    requireAuth,
    requireRole(['super_admin', 'corporate_admin', 'admin']),
    (req, res) => {
      const db = getDb();
      const { staffId, name, workEmail, phone, role, branchId, allowedBranchIds, customPrivileges, initialPassword } = req.body;
      const currentStaff = (req as any).staff as DbStaffAccount;

      if (!staffId || !name || !workEmail || !role || !branchId || !initialPassword) {
        return res.status(400).json({ error: 'Missing required staff fields.' });
      }

      for (const s of Object.values(db.staff)) {
        if (s.workEmail.toLowerCase() === workEmail.trim().toLowerCase()) {
          return res.status(400).json({ error: 'Work email already in use.' });
        }
        if (s.staffId.toLowerCase() === staffId.trim().toLowerCase()) {
          return res.status(400).json({ error: 'Staff ID already in use.' });
        }
      }

      const effectiveAllowedBranches =
        Array.isArray(allowedBranchIds) && allowedBranchIds.length > 0
          ? Array.from(new Set([branchId, ...allowedBranchIds]))
          : [branchId];

      const hash = hashPasswordBcrypt(initialPassword);
      const newId = `staff-${Date.now()}`;
      const newStaff: DbStaffAccount = {
        id: newId,
        staffId: staffId.trim().toUpperCase(),
        name: name.trim(),
        workEmail: workEmail.trim().toLowerCase(),
        phone: phone || '',
        role,
        branchId,
        allowedBranchIds: effectiveAllowedBranches,
        customPrivileges: Array.isArray(customPrivileges) ? customPrivileges : undefined,
        passwordHash: hash,
        status: 'active',
        mustChangePassword: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        dateOfBirth: req.body.dateOfBirth?.trim() || undefined,
        guarantorName: req.body.guarantorName?.trim() || undefined,
        guarantorPhone: req.body.guarantorPhone?.trim() || undefined,
        guarantorRelationship: req.body.guarantorRelationship?.trim() || undefined,
        guarantorAddress: req.body.guarantorAddress?.trim() || undefined,
        guarantorWorkplace: req.body.guarantorWorkplace?.trim() || undefined,
      };

      db.staff[newId] = newStaff;
      saveDatabaseSync();

      logAuditEvent(
        currentStaff.name,
        currentStaff.role,
        currentStaff.branchId,
        'STAFF_CREATED',
        `Created staff account: ${newStaff.name} (${newStaff.staffId}, Role: ${newStaff.role}, Branches: [${effectiveAllowedBranches.join(', ')}])`
      );

      res.status(201).json({
        success: true,
        staff: {
          id: newStaff.id,
          staffId: newStaff.staffId,
          name: newStaff.name,
          workEmail: newStaff.workEmail,
          phone: newStaff.phone,
          role: newStaff.role,
          branchId: newStaff.branchId,
          allowedBranchIds: newStaff.allowedBranchIds,
          customPrivileges: newStaff.customPrivileges,
          privileges: getStaffPrivileges(newStaff),
          status: newStaff.status,
          dateOfBirth: newStaff.dateOfBirth,
          guarantorName: newStaff.guarantorName,
          guarantorPhone: newStaff.guarantorPhone,
        },
      });
    }
  );

  router.put(
    ['/api/staff/accounts/:id', '/api/staff/:id'],
    requireAuth,
    requireRole(['super_admin', 'corporate_admin', 'admin']),
    (req, res) => {
      const db = getDb();
      const { id } = req.params;
      const staff = db.staff[id];
      const currentStaff = (req as any).staff as DbStaffAccount;

      if (!staff) return res.status(404).json({ error: 'Staff account not found.' });

      if (
        staff.role === 'super_admin' &&
        (req.body.status === 'suspended' || (req.body.role && req.body.role !== 'super_admin'))
      ) {
        const activeSuperAdmins = Object.values(db.staff).filter(
          (s) => s.role === 'super_admin' && s.status === 'active' && s.id !== staff.id
        );
        if (activeSuperAdmins.length === 0) {
          return res.status(400).json({ error: 'Cannot demote or suspend the last active Super Administrator.' });
        }
      }

      const {
        name,
        phone,
        role,
        branchId,
        allowedBranchIds,
        customPrivileges,
        status,
        dateOfBirth,
        guarantorName,
        guarantorPhone,
        guarantorRelationship,
        guarantorAddress,
        guarantorWorkplace,
      } = req.body;
      const roleChanged = Boolean(role && role !== staff.role);
      const suspendedNow = status === 'suspended' || status === 'inactive';

      if (name) staff.name = name.trim();
      if (phone !== undefined) staff.phone = phone.trim();
      if (role) staff.role = role;
      if (branchId) staff.branchId = branchId;
      if (Array.isArray(allowedBranchIds) && allowedBranchIds.length > 0) {
        staff.allowedBranchIds = Array.from(new Set([staff.branchId, ...allowedBranchIds]));
      }
      if (Array.isArray(customPrivileges)) {
        staff.customPrivileges = customPrivileges;
      }
      if (status) staff.status = status;
      if (dateOfBirth !== undefined) staff.dateOfBirth = dateOfBirth ? String(dateOfBirth).trim() : undefined;
      if (guarantorName !== undefined) staff.guarantorName = guarantorName ? String(guarantorName).trim() : undefined;
      if (guarantorPhone !== undefined) staff.guarantorPhone = guarantorPhone ? String(guarantorPhone).trim() : undefined;
      if (guarantorRelationship !== undefined)
        staff.guarantorRelationship = guarantorRelationship ? String(guarantorRelationship).trim() : undefined;
      if (guarantorAddress !== undefined) staff.guarantorAddress = guarantorAddress ? String(guarantorAddress).trim() : undefined;
      if (guarantorWorkplace !== undefined)
        staff.guarantorWorkplace = guarantorWorkplace ? String(guarantorWorkplace).trim() : undefined;
      staff.updatedAt = new Date().toISOString();

      for (const [token, sess] of Object.entries(db.sessions)) {
        if (sess.staffId === staff.id) {
          if (suspendedNow || roleChanged) {
            delete db.sessions[token];
          } else {
            sess.role = staff.role;
            sess.branchId = staff.branchId;
          }
        }
      }

      saveDatabaseSync();
      logAuditEvent(
        currentStaff.name,
        currentStaff.role,
        currentStaff.branchId,
        'STAFF_MODIFIED',
        `Updated staff ${staff.name} (${staff.staffId})`
      );

      const { passwordHash: _ph, salt: _s, ...safeStaff } = staff;
      res.json({
        success: true,
        message: 'Staff account updated successfully.',
        staff: { ...safeStaff, privileges: getStaffPrivileges(staff) },
      });
    }
  );

  router.delete(
    ['/api/staff/accounts/:id', '/api/staff/:id'],
    requireAuth,
    requireRole(['super_admin', 'corporate_admin', 'admin']),
    (req, res) => {
      const db = getDb();
      const { id } = req.params;
      const staff = db.staff[id];
      const currentStaff = (req as any).staff as DbStaffAccount;

      if (!staff) return res.status(404).json({ error: 'Staff account not found.' });
      if (staff.id === 'staff-admin-001' || staff.id === currentStaff.id) {
        return res.status(400).json({ error: 'Cannot delete primary Super Administrator or active self account.' });
      }

      delete db.staff[id];
      for (const [token, sess] of Object.entries(db.sessions)) {
        if (sess.staffId === id) {
          delete db.sessions[token];
        }
      }
      saveDatabaseSync();
      logAuditEvent(
        currentStaff.name,
        currentStaff.role,
        currentStaff.branchId,
        'STAFF_DELETED',
        `Deleted staff account ${staff.name} (${staff.staffId})`
      );
      res.json({ success: true, message: 'Staff account deleted.' });
    }
  );

  router.get('/api/staff/birthdays/upcoming', requireAuth, (req, res) => {
    const db = getDb();
    const daysAhead = Math.max(1, Math.min(365, Number(req.query.days) || 30));
    const today = new Date();
    const currentMonth = today.getMonth();
    const currentDay = today.getDate();

    const upcoming: Array<{
      staffId: string;
      id: string;
      name: string;
      role: string;
      branchId: string;
      phone: string;
      dateOfBirth: string;
      birthdayThisYear: string;
      daysUntil: number;
      turningAge: number;
    }> = [];

    for (const staff of Object.values(db.staff || {})) {
      if (!staff.dateOfBirth || staff.status !== 'active') continue;
      const parts = staff.dateOfBirth.split('-');
      if (parts.length !== 3) continue;
      const birthYear = parseInt(parts[0], 10);
      const birthMonth = parseInt(parts[1], 10) - 1;
      const birthDay = parseInt(parts[2], 10);

      let nextBday = new Date(today.getFullYear(), birthMonth, birthDay);
      if (nextBday.getTime() < new Date(today.getFullYear(), currentMonth, currentDay).getTime()) {
        nextBday = new Date(today.getFullYear() + 1, birthMonth, birthDay);
      }

      const diffMs = nextBday.getTime() - new Date(today.getFullYear(), currentMonth, currentDay).getTime();
      const daysUntil = Math.round(diffMs / (1000 * 60 * 60 * 24));

      if (daysUntil <= daysAhead) {
        const turningAge = nextBday.getFullYear() - birthYear;
        upcoming.push({
          staffId: staff.staffId,
          id: staff.id,
          name: staff.name,
          role: staff.role,
          branchId: staff.branchId,
          phone: staff.phone,
          dateOfBirth: staff.dateOfBirth,
          birthdayThisYear: nextBday.toISOString().split('T')[0],
          daysUntil,
          turningAge,
        });
      }
    }

    upcoming.sort((a, b) => a.daysUntil - b.daysUntil);
    res.json({ success: true, count: upcoming.length, upcoming });
  });

  router.use(createBranchesAndRbacRouter(deps));

  return router;
}
