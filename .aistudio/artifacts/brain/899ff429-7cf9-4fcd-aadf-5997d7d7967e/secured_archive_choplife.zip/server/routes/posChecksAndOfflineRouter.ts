import { Router } from 'express';
import crypto from 'crypto';
import {
  verifyWalletPin,
  calculateLoyaltyPoints,
} from '../../server_db.ts';
import type {
  DbDatabase,
  DbStaffAccount,
  DbCheck,
  DbCheckItem,
} from '../../server_db.ts';
import {
  createOrderInventoryDepleter,
  createPosOfflineAndTableTransferRouter,
} from '../services/posInventoryAndOfflineService.ts';

export { createOrderInventoryDepleter };

export function createPosChecksAndOfflineRouter(deps: {
  getDb: () => DbDatabase;
  saveDatabaseSync: () => void;
  requireAuth: any;
  requireBranchAccess: any;
  depleteInventoryForOrder: (
    items: DbCheckItem[],
    branchId: string,
    orderRef: string,
    staff: DbStaffAccount
  ) => void;
  logAuditEvent: (
    staffName: string,
    staffRole: string,
    branchId: string,
    actionType: string,
    details: string,
    metadata?: Record<string, any>
  ) => void;
}): Router {
  const router = Router();
  const {
    getDb,
    saveDatabaseSync,
    requireAuth,
    requireBranchAccess,
    depleteInventoryForOrder,
    logAuditEvent,
  } = deps;

  router.get('/api/pos/checks', requireAuth, requireBranchAccess, (req, res) => {
    const db = getDb();
    const { branchId, status } = req.query;
    let list = Object.values(db.checks);

    if (branchId && branchId !== 'all') {
      list = list.filter((c) => c.branchId === branchId);
    }
    if (status) {
      list = list.filter((c) => c.status === status);
    }

    res.json(list.sort((a, b) => new Date(b.openedAt).getTime() - new Date(a.openedAt).getTime()));
  });

  router.get('/api/pos/checks/:id', requireAuth, (req, res) => {
    const db = getDb();
    const currentStaff = (req as any).staff as DbStaffAccount;
    const check = db.checks[req.params.id];
    if (!check) return res.status(404).json({ error: 'Check not found.' });

    const isGlobalStaff = ['super_admin', 'corporate_admin', 'auditor'].includes(currentStaff.role);
    if (!isGlobalStaff && check.branchId !== currentStaff.branchId) {
      return res.status(403).json({ error: 'Access denied: Check belongs to another branch.' });
    }

    res.json(check);
  });

  router.post('/api/pos/checks', requireAuth, (req, res) => {
    const db = getDb();
    const currentStaff = (req as any).staff as DbStaffAccount;
    const isGlobal = ['super_admin', 'corporate_admin', 'auditor'].includes(currentStaff.role);
    const targetBranch = isGlobal ? (req.body.branchId || currentStaff.branchId) : currentStaff.branchId;

    const {
      id,
      tableId,
      tableNumber,
      checkType = 'dine_in',
      customerName = 'Walk-in Customer',
      customerPhone,
      guestCount = 1,
      items = [],
      discountAmount = 0,
      discountPercent = 0,
      discountReason,
      supervisorPin,
      packagingFee = 0,
      deliveryFee = 0,
      notes,
    } = req.body;

    const validatedItems = items.map((it: any) => {
      const qty = Math.max(1, Math.floor(Number(it.quantity) || 1));
      const price = Math.max(0, Number(it.unitPrice) || 0);
      return {
        id: it.id || `item-${Date.now()}-${crypto.randomBytes(2).toString('hex')}`,
        productId: it.productId,
        name: it.name || 'Menu Item',
        quantity: qty,
        unitPrice: price,
        totalPrice: price * qty,
        notes: it.notes,
        status: it.status || 'pending',
        sentToKitchenAt: it.sentToKitchenAt,
        customization: it.customization,
      };
    });

    const subtotal = validatedItems.reduce((sum: number, it: any) => sum + it.totalPrice, 0);
    const validPackagingFee = Math.max(0, Number(packagingFee) || 0);
    const validDeliveryFee = Math.max(0, Number(deliveryFee) || 0);

    const pct = Math.max(0, Math.min(100, Number(discountPercent) || 0));
    let amt = Math.max(0, Number(discountAmount) || 0);
    if (pct > 0) {
      amt = Math.min(subtotal, Math.round((subtotal * pct) / 100));
    } else {
      amt = Math.min(subtotal, amt);
    }

    const isManager = ['store_manager', 'branch_manager', 'super_admin', 'corporate_admin'].includes(currentStaff.role);
    if ((pct > 10 || amt > 2000) && !isManager) {
      const cleanPin = String(supervisorPin || '').trim();
      const supervisor = Object.values(db.staff).find(
        (s) =>
          ['store_manager', 'branch_manager', 'super_admin', 'corporate_admin'].includes(s.role) &&
          (s.branchId === targetBranch || s.role === 'super_admin') &&
          s.pin === cleanPin
      );

      if (!supervisor) {
        return res.status(403).json({
          error: 'Discounts exceeding 10% or ₦2,000 require a valid Manager Supervisor PIN.',
        });
      }

      logAuditEvent(
        supervisor.name,
        supervisor.role,
        targetBranch,
        'DISCOUNT_OVERRIDE_APPROVED',
        `Manager approved ${pct}% (₦${amt.toLocaleString()}) discount on check for ${customerName}. Reason: ${discountReason || 'VIP courtesy'}`
      );
    }

    const total = Math.max(0, subtotal - amt + validPackagingFee + validDeliveryFee);

    const checkId = id || `chk-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
    const isNew = !db.checks[checkId];

    const check: DbCheck = {
      id: checkId,
      checkNumber: db.checks[checkId]?.checkNumber || `CHK-${String(Object.keys(db.checks).length + 1).padStart(5, '0')}`,
      branchId: targetBranch,
      tableId,
      tableNumber,
      checkType,
      status: db.checks[checkId]?.status || 'open',
      customerName,
      customerPhone,
      guestCount: Math.max(1, Number(guestCount) || 1),
      items: validatedItems,
      subtotal,
      discountAmount: amt,
      discountPercent: pct,
      discountReason,
      packagingFee: validPackagingFee,
      deliveryFee: validDeliveryFee,
      total,
      paymentStatus: db.checks[checkId]?.paymentStatus || 'unpaid',
      openedAt: db.checks[checkId]?.openedAt || new Date().toISOString(),
      openedByStaffId: db.checks[checkId]?.openedByStaffId || currentStaff.id,
      openedByName: db.checks[checkId]?.openedByName || currentStaff.name,
      notes,
    };

    db.checks[checkId] = check;

    if (tableId && db.tables[tableId]) {
      db.tables[tableId].status = 'ordering';
      db.tables[tableId].currentCheckId = checkId;
      db.tables[tableId].guestCount = guestCount;
      db.tables[tableId].updatedAt = new Date().toISOString();
    }

    saveDatabaseSync();
    logAuditEvent(
      currentStaff.name,
      currentStaff.role,
      currentStaff.branchId,
      isNew ? 'ORDER_CREATED' : 'ORDER_EDITED',
      `${isNew ? 'Opened' : 'Updated'} check ${check.checkNumber} (${check.tableNumber || check.checkType}) Total: ₦${total}`
    );

    res.json({ success: true, check });
  });

  router.post('/api/pos/checks/:id/send-to-kitchen', requireAuth, (req, res) => {
    const db = getDb();
    const { id } = req.params;
    const currentStaff = (req as any).staff as DbStaffAccount;
    const check = db.checks[id];

    if (!check) return res.status(404).json({ error: 'Check not found.' });

    const now = new Date().toISOString();
    check.status = 'sent_to_kitchen';
    check.items.forEach((it) => {
      if (it.status === 'pending') {
        it.status = 'sent_to_kitchen';
        it.sentToKitchenAt = now;
      }
    });

    if (check.tableId && db.tables[check.tableId]) {
      db.tables[check.tableId].status = 'kitchen_prep';
      db.tables[check.tableId].updatedAt = now;
    }

    saveDatabaseSync();
    logAuditEvent(
      currentStaff.name,
      currentStaff.role,
      currentStaff.branchId,
      'STATUS_CHANGED',
      `Sent check ${check.checkNumber} to kitchen (${check.items.length} items)`
    );

    res.json({ success: true, check });
  });

  router.post('/api/pos/checks/:id/pay', requireAuth, (req, res) => {
    const db = getDb();
    const { id } = req.params;
    const currentStaff = (req as any).staff as DbStaffAccount;
    const { paymentMethod = 'cash', paymentDetails = {}, shiftId } = req.body;
    const check = db.checks[id];

    if (!check) return res.status(404).json({ error: 'Check not found.' });

    if (check.status === 'paid' || check.paymentStatus === 'paid') {
      return res.status(409).json({
        error: `Check ${check.checkNumber} has already been settled and paid.`,
        check,
      });
    }

    let targetCustomer: any = null;
    if (paymentMethod === 'wallet') {
      const customerId = paymentDetails.customerId;
      if (!customerId) {
        return res.status(400).json({ error: 'Customer ID or account selection is required for Digital Wallet payments.' });
      }
      targetCustomer = db.customers[customerId];
      if (!targetCustomer) {
        return res.status(404).json({ error: 'Customer account not found for wallet debit.' });
      }
      if (targetCustomer.status !== 'active') {
        return res.status(400).json({ error: 'Customer wallet account is suspended or inactive.' });
      }
      if (Number(targetCustomer.walletBalance || 0) < check.total) {
        return res.status(400).json({
          error: `Insufficient wallet balance. Available: ₦${Number(targetCustomer.walletBalance || 0).toLocaleString()}, Check Total: ₦${check.total.toLocaleString()}`,
          availableBalance: targetCustomer.walletBalance,
        });
      }
      const isManagerOverride = ['store_manager', 'branch_manager', 'super_admin', 'corporate_admin'].includes(currentStaff.role) && Boolean(paymentDetails.managerOverride);
      if (!verifyWalletPin(paymentDetails.walletPin, targetCustomer) && !isManagerOverride) {
        return res.status(400).json({ error: 'Invalid or missing 4-digit customer security PIN.' });
      }
    }

    let targetHouseAccount: any = null;
    if (paymentMethod === 'house_account') {
      const accountId = paymentDetails.houseAccountId;
      if (!accountId) {
        return res.status(400).json({ error: 'Corporate House Account selection is required.' });
      }
      targetHouseAccount = db.houseAccounts[accountId];
      if (!targetHouseAccount) {
        return res.status(404).json({ error: 'Corporate House Account not found.' });
      }
      if (targetHouseAccount.status !== 'active') {
        return res.status(400).json({ error: 'This corporate house account is on hold or inactive.' });
      }
      const projectedBalance = Number(targetHouseAccount.currentBalance || 0) + check.total;
      if (projectedBalance > targetHouseAccount.creditLimit) {
        return res.status(400).json({
          error: `Credit limit exceeded. Current Balance: ₦${targetHouseAccount.currentBalance.toLocaleString()}, Check: ₦${check.total.toLocaleString()}, Credit Limit: ₦${targetHouseAccount.creditLimit.toLocaleString()}`,
          creditLimit: targetHouseAccount.creditLimit,
          currentBalance: targetHouseAccount.currentBalance,
        });
      }
    }

    const isCashPayment = paymentMethod === 'cash' || (paymentMethod === 'split' && (paymentDetails.splitCashAmount || 0) > 0);
    const activeShift = shiftId ? db.shifts[shiftId] : Object.values(db.shifts).find((s) => s.branchId === check.branchId && s.status === 'open');

    if (isCashPayment && !activeShift && !req.body.bypassShiftCheck) {
      return res.status(400).json({
        error: 'NO_ACTIVE_SHIFT: An active shift register must be opened on this branch before accepting cash payments.',
        requiresShift: true,
        branchId: check.branchId,
      });
    }

    const now = new Date().toISOString();
    check.status = 'paid';
    check.paymentStatus = 'paid';
    check.paymentMethod = paymentMethod;
    check.paymentDetails = paymentDetails;
    check.closedAt = now;
    check.closedByStaffId = currentStaff.id;
    check.closedByName = currentStaff.name;

    if (check.tableId && db.tables[check.tableId]) {
      db.tables[check.tableId].status = 'available';
      db.tables[check.tableId].currentCheckId = undefined;
      db.tables[check.tableId].guestCount = 0;
      db.tables[check.tableId].updatedAt = now;
    }

    if (paymentMethod === 'wallet' && targetCustomer) {
      const prevBal = Number(targetCustomer.walletBalance || 0);
      const newBal = prevBal - check.total;
      targetCustomer.walletBalance = newBal;

      db.walletTransactions.push({
        id: `wtx-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`,
        customerId: targetCustomer.id,
        customerName: targetCustomer.name,
        type: 'debit_order',
        amount: check.total,
        previousBalance: prevBal,
        newBalance: newBal,
        orderId: check.checkNumber,
        checkId: check.id,
        branchId: check.branchId,
        staffName: currentStaff.name,
        timestamp: now,
        note: `Settled check ${check.checkNumber} via digital wallet`,
      });
    }

    if (paymentMethod === 'house_account' && targetHouseAccount) {
      targetHouseAccount.currentBalance = Number(targetHouseAccount.currentBalance || 0) + check.total;
      db.houseAccountCharges.push({
        id: `hchg-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`,
        accountId: targetHouseAccount.id,
        companyName: targetHouseAccount.companyName,
        checkId: check.id,
        checkNumber: check.checkNumber,
        amount: check.total,
        authorizedSigner: paymentDetails.authorizedSigner || 'Authorized Representative',
        department: paymentDetails.department || 'General Hospitality',
        branchId: check.branchId,
        timestamp: now,
        staffName: currentStaff.name,
        status: 'unbilled',
        notes: paymentDetails.notes || `Charged to house account by ${currentStaff.name}`,
      });
    }

    const customerToReward = targetCustomer || (paymentDetails.customerId ? db.customers[paymentDetails.customerId] : null) || (check.customerPhone ? Object.values(db.customers).find((c: any) => c.phone === check.customerPhone) : null);
    if (customerToReward && !(check as any).loyaltyPointsAwardedAt) {
      customerToReward.visitCount = (customerToReward.visitCount || 0) + 1;
      customerToReward.lifetimeSpend = (customerToReward.lifetimeSpend || 0) + check.total;
      customerToReward.lastVisitDate = now;

      const pointsEarned = calculateLoyaltyPoints(check);
      customerToReward.loyaltyPoints = (customerToReward.loyaltyPoints || 0) + pointsEarned;
      (check as any).loyaltyPointsEarned = pointsEarned;
      (check as any).loyaltyPointsAwardedAt = now;
      (check as any).loyaltyCustomerId = customerToReward.id;

      if (check.total >= 3000 && (customerToReward.stampCount || 0) < 10) {
        customerToReward.stampCount = (customerToReward.stampCount || 0) + 1;
      }

      if (customerToReward.lifetimeSpend >= 1000000) customerToReward.tier = 'platinum';
      else if (customerToReward.lifetimeSpend >= 500000) customerToReward.tier = 'gold';
      else if (customerToReward.lifetimeSpend >= 200000) customerToReward.tier = 'silver';
      else customerToReward.tier = 'bronze';
    }

    if (activeShift) {
      activeShift.totalOrders += 1;
      if (paymentMethod === 'cash') {
        const cashAmt = paymentDetails.cashTendered ? Math.min(check.total, paymentDetails.cashTendered) : check.total;
        activeShift.totalCashSales += cashAmt;
        activeShift.expectedCashInTill += cashAmt;

        db.cashMovements.push({
          id: `cm-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`,
          shiftId: activeShift.id,
          branchId: check.branchId,
          timestamp: now,
          movementType: 'cash_sale',
          amount: cashAmt,
          reason: `Cash payment for ${check.checkNumber}`,
          staffId: currentStaff.id,
          staffName: currentStaff.name,
          recipientOrRef: check.checkNumber,
        });
      } else if (paymentMethod === 'pos_terminal') {
        activeShift.totalPosSales += check.total;
      } else if (paymentMethod === 'bank_transfer') {
        activeShift.totalTransferSales += check.total;
      } else if (paymentMethod === 'split') {
        const cashPart = paymentDetails.splitCashAmount || 0;
        const posPart = paymentDetails.splitPosAmount || 0;
        activeShift.totalCashSales += cashPart;
        activeShift.totalPosSales += posPart;
        activeShift.expectedCashInTill += cashPart;

        if (cashPart > 0) {
          db.cashMovements.push({
            id: `cm-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`,
            shiftId: activeShift.id,
            branchId: check.branchId,
            timestamp: now,
            movementType: 'cash_sale',
            amount: cashPart,
            reason: `Split cash payment for ${check.checkNumber}`,
            staffId: currentStaff.id,
            staffName: currentStaff.name,
            recipientOrRef: check.checkNumber,
          });
        }
      }
    }

    depleteInventoryForOrder(check.items, check.branchId, check.checkNumber, currentStaff);

    saveDatabaseSync();
    logAuditEvent(
      currentStaff.name,
      currentStaff.role,
      currentStaff.branchId,
      'PAYMENT_CONFIRMED',
      `Settled check ${check.checkNumber} via ${paymentMethod}. Total: ₦${check.total}`
    );

    res.json({ success: true, check });
  });

  // Mount Offline Sync & Table Transfer Routes
  router.use(createPosOfflineAndTableTransferRouter(deps));

  return router;
}
