import { Router } from 'express';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import type { DbDatabase, DbStaffAccount, DbSession } from '../../server_db.ts';
import {
  SESSION_COOKIE_NAME,
  hashPasswordBcrypt,
  validateStaffPasswordPolicy,
  verifyStaffPassword,
  checkRateLimit,
  recordFailedAttempt,
  clearRateLimit,
} from '../middleware/authAndRbac.ts';

export function createAuthAndHealthRouter(deps: {
  getDb: () => DbDatabase;
  reloadDb: () => DbDatabase;
  saveDatabase: () => void;
  saveDatabaseSync: () => void;
  port: number;
  requireAuth: any;
  requireRole: any;
  getSessionFromRequest: (req: any) => DbSession | null;
  getStaffPrivileges: (staff: DbStaffAccount) => string[];
  logAuditEvent: (
    staffName: string,
    staffRole: string,
    branchId: string,
    actionType: string,
    details: string,
    metadata?: Record<string, any>
  ) => void;
}): Router {
  const router = Router();
  const {
    getDb,
    reloadDb,
    saveDatabase,
    saveDatabaseSync,
    port,
    requireAuth,
    requireRole,
    getSessionFromRequest,
    getStaffPrivileges,
    logAuditEvent,
  } = deps;

  // 1. Health & System Provisioning Status
  router.get('/api/health', (_req, res) => {
    const db = getDb();
    res.json({
      status: 'ok',
      healthy: true,
      timestamp: new Date().toISOString(),
      service: 'Choplife Republic Operations Engine',
      version: '2.0.0',
      port,
      staffCount: Object.keys(db.staff).length,
      activeChecksCount: Object.keys(db.checks).length,
      shiftsCount: Object.keys(db.shifts).length,
      persistence: 'durable_relational_json_wal',
    });
  });

  // Superadmin Database Snapshot Reload Endpoint
  router.post('/api/admin/db/reload', requireAuth, requireRole(['super_admin']), (req, res) => {
    if (req.body && req.body.snapshot && typeof req.body.snapshot === 'object') {
      const dbFilePath = process.env.CHOPLIFE_DB_FILE
        ? path.resolve(process.env.CHOPLIFE_DB_FILE)
        : path.join(process.cwd(), 'data', 'choplife_ops_db.json');
      fs.writeFileSync(dbFilePath, JSON.stringify(req.body.snapshot, null, 2), 'utf-8');
    }
    const db = reloadDb();
    res.json({
      success: true,
      message: 'Database reloaded from disk into memory.',
      staffCount: Object.keys(db.staff).length,
      ordersCount: Object.keys(db.orders).length,
    });
  });

  router.get('/api/auth/staff/status', (_req, res) => {
    const db = getDb();
    const staffList = Object.values(db.staff);
    res.json({
      isProvisioned: staffList.length > 0,
      activeStaffCount: staffList.length,
    });
  });

  // Setup Initial Super Admin
  router.post('/api/auth/staff/setup-admin', (req, res) => {
    const db = getDb();
    const staffList = Object.values(db.staff);
    if (staffList.length > 0) {
      return res.status(400).json({ error: 'System has already been provisioned with an administrator.' });
    }

    const { fullName, workEmail, phone, password, branchId = 'gra' } = req.body;

    if (!fullName || !workEmail || !password) {
      return res.status(400).json({ error: 'Full name, work email, and password are required.' });
    }

    const cleanEmail = String(workEmail).trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      return res.status(400).json({ error: 'A valid work email address is required.' });
    }

    if (String(password).length < 8) {
      return res.status(400).json({ error: 'Password must be at least 8 characters long.' });
    }

    const validBranchIds = new Set(['gra', 'okabere', 'ugbowo', ...Object.keys(db.branches || {})]);
    const cleanBranchId = String(branchId || 'gra').trim();
    if (!validBranchIds.has(cleanBranchId)) {
      return res.status(400).json({
        error: `Invalid branchId '${cleanBranchId}'. Must be one of: ${Array.from(validBranchIds).join(', ')}.`,
      });
    }

    const hash = hashPasswordBcrypt(password);
    const adminId = `staff-${Date.now()}`;
    const newAdmin: DbStaffAccount = {
      id: adminId,
      staffId: 'STF-001',
      name: String(fullName).trim(),
      workEmail: cleanEmail,
      phone: phone || '+234 815 817 7897',
      role: 'super_admin',
      branchId: cleanBranchId,
      allowedBranchIds: ['gra', 'okabere', 'ugbowo'],
      passwordHash: hash,
      status: 'active',
      mustChangePassword: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    db.staff[adminId] = newAdmin;

    const sessionToken = crypto.randomBytes(32).toString('hex');
    const session: DbSession = {
      token: sessionToken,
      staffId: adminId,
      role: 'super_admin',
      branchId: cleanBranchId,
      createdAt: Date.now(),
      expiresAt: Date.now() + 12 * 60 * 60 * 1000,
      lastActivity: Date.now(),
    };
    db.sessions[sessionToken] = session;
    saveDatabaseSync();

    res.cookie(SESSION_COOKIE_NAME, sessionToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 12 * 60 * 60 * 1000,
    });

    logAuditEvent(
      newAdmin.name,
      newAdmin.role,
      newAdmin.branchId,
      'STAFF_CREATED',
      `Initial Super Admin provisioned: ${newAdmin.name} (${newAdmin.workEmail})`
    );

    res.json({
      success: true,
      message: 'Super Administrator created and authenticated successfully.',
      staff: {
        id: newAdmin.id,
        staffId: newAdmin.staffId,
        name: newAdmin.name,
        workEmail: newAdmin.workEmail,
        phone: newAdmin.phone,
        role: newAdmin.role,
        branchId: newAdmin.branchId,
        status: newAdmin.status,
      },
      token: sessionToken,
    });
  });

  // 2. Staff Authentication & Sessions
  router.post('/api/auth/staff/login', (req, res) => {
    const db = getDb();
    const emailOrStaffId = req.body.emailOrStaffId || req.body.identifier || req.body.email;
    const { password } = req.body;
    const clientIp = req.ip || req.socket.remoteAddress || 'unknown';
    const rateLimitKey = `${clientIp}_${(emailOrStaffId || '').trim().toLowerCase()}`;

    const rateCheck = checkRateLimit(rateLimitKey);
    if (rateCheck.isLocked) {
      return res.status(429).json({
        error: `Too many failed login attempts. Please wait ${rateCheck.remainingSeconds} seconds before trying again.`,
        lockoutSeconds: rateCheck.remainingSeconds,
      });
    }

    if (!emailOrStaffId || !password) {
      recordFailedAttempt(rateLimitKey);
      return res.status(400).json({ error: 'Please provide your work email/staff ID and password.' });
    }

    const cleanIdentifier = emailOrStaffId.trim().toLowerCase();

    let matchedStaff: DbStaffAccount | null = null;
    for (const staff of Object.values(db.staff)) {
      if (
        staff.workEmail.toLowerCase() === cleanIdentifier ||
        staff.staffId.toLowerCase() === cleanIdentifier ||
        ((cleanIdentifier === 'admin@choplife.ng' || cleanIdentifier === 'oluwaseun.osineye@gmail.com') && staff.id === 'staff-admin-001')
      ) {
        matchedStaff = staff;
        break;
      }
    }

    if (!matchedStaff) {
      recordFailedAttempt(rateLimitKey);
      logAuditEvent('Unknown Staff', 'anonymous', 'system', 'LOGIN_FAILED', `Failed login attempt for: ${cleanIdentifier}`);
      return res.status(401).json({ error: 'Invalid email/staff ID or password.' });
    }

    if (matchedStaff.status === 'suspended' || (matchedStaff.status as string) === 'inactive') {
      logAuditEvent(
        matchedStaff.name,
        matchedStaff.role,
        matchedStaff.branchId,
        'LOGIN_BLOCKED_SUSPENDED',
        `Suspended staff account attempted login: ${matchedStaff.workEmail}`
      );
      return res.status(403).json({ error: 'Staff account is suspended or inactive. Contact an administrator.' });
    }

    const nowMs = Date.now();
    if (matchedStaff.lockoutUntil && matchedStaff.lockoutUntil > nowMs) {
      const remainingSecs = Math.ceil((matchedStaff.lockoutUntil - nowMs) / 1000);
      return res.status(429).json({
        error: `Staff account is temporarily locked due to 5 consecutive failed attempts. Please retry in ${remainingSecs} seconds.`,
        lockoutSeconds: remainingSecs,
      });
    }

    const authResult = verifyStaffPassword(password, matchedStaff);
    if (!authResult.valid) {
      matchedStaff.failedLoginAttempts = (matchedStaff.failedLoginAttempts || 0) + 1;
      if (matchedStaff.failedLoginAttempts >= 5) {
        matchedStaff.lockoutUntil = Date.now() + 15 * 60 * 1000;
      }
      saveDatabaseSync();
      recordFailedAttempt(rateLimitKey);
      logAuditEvent(matchedStaff.name, matchedStaff.role, matchedStaff.branchId, 'LOGIN_FAILED', `Invalid password attempt for: ${matchedStaff.workEmail} (attempt ${matchedStaff.failedLoginAttempts}/5)`);

      if (matchedStaff.failedLoginAttempts >= 5) {
        return res.status(429).json({
          error: 'Too many failed login attempts. Account locked for 15 minutes.',
          lockoutSeconds: 900,
        });
      }

      return res.status(401).json({
        error: `Invalid email/staff ID or password. (${5 - matchedStaff.failedLoginAttempts} attempt(s) remaining)`,
        attemptsRemaining: 5 - matchedStaff.failedLoginAttempts,
      });
    }

    clearRateLimit(rateLimitKey);
    matchedStaff.failedLoginAttempts = 0;
    matchedStaff.lockoutUntil = undefined;
    matchedStaff.lastLoginAt = new Date().toISOString();
    matchedStaff.lastLoginIp = clientIp;

    if (authResult.needsRehash) {
      matchedStaff.passwordHash = hashPasswordBcrypt(password);
      delete matchedStaff.salt;
      logAuditEvent(matchedStaff.name, matchedStaff.role, matchedStaff.branchId, 'PASSWORD_HASH_UPGRADED', `Upgraded password hashing algorithm to bcrypt for ${matchedStaff.workEmail}`);
    }

    const sessionToken = crypto.randomBytes(32).toString('hex');
    const session: DbSession = {
      token: sessionToken,
      staffId: matchedStaff.id,
      role: matchedStaff.role,
      branchId: matchedStaff.branchId,
      createdAt: Date.now(),
      expiresAt: Date.now() + 12 * 60 * 60 * 1000,
      lastActivity: Date.now(),
    };
    db.sessions[sessionToken] = session;
    saveDatabaseSync();

    res.cookie(SESSION_COOKIE_NAME, sessionToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 12 * 60 * 60 * 1000,
    });

    logAuditEvent(matchedStaff.name, matchedStaff.role, matchedStaff.branchId, 'LOGIN_SUCCESS', `Staff logged in: ${matchedStaff.name} (bcrypt verified)`);

    res.json({
      success: true,
      staff: {
        id: matchedStaff.id,
        staffId: matchedStaff.staffId,
        name: matchedStaff.name,
        workEmail: matchedStaff.workEmail,
        phone: matchedStaff.phone,
        role: matchedStaff.role,
        branchId: matchedStaff.branchId,
        allowedBranchIds: matchedStaff.allowedBranchIds || [matchedStaff.branchId],
        privileges: getStaffPrivileges(matchedStaff),
        status: matchedStaff.status,
        mustChangePassword: matchedStaff.mustChangePassword,
      },
      token: sessionToken,
    });
  });

  router.post('/api/auth/staff/logout', (req, res) => {
    const db = getDb();
    const session = getSessionFromRequest(req);
    if (session) {
      const staff = db.staff[session.staffId];
      if (staff) {
        logAuditEvent(staff.name, staff.role, staff.branchId, 'LOGOUT', `Staff logged out: ${staff.name}`);
      }
      delete db.sessions[session.token];
      saveDatabase();
    }
    res.clearCookie(SESSION_COOKIE_NAME);
    res.json({ success: true, message: 'Logged out successfully.' });
  });

  router.post('/api/auth/staff/pin-login', (_req, res) => {
    return res.status(403).json({ error: 'Quick PIN login has been disabled in production. Please use secure password authentication.' });
  });

  router.get('/api/auth/staff/me', requireAuth, (req, res) => {
    const staff = (req as any).staff as DbStaffAccount;
    res.json({
      id: staff.id,
      staffId: staff.staffId,
      name: staff.name,
      workEmail: staff.workEmail,
      phone: staff.phone,
      role: staff.role,
      branchId: staff.branchId,
      allowedBranchIds: staff.allowedBranchIds || [staff.branchId],
      privileges: getStaffPrivileges(staff),
      status: staff.status,
      mustChangePassword: staff.mustChangePassword,
    });
  });

  router.post('/api/auth/staff/forgot-password', (req, res) => {
    const db = getDb();
    const { email } = req.body;
    const clientIp = req.ip || req.socket.remoteAddress || 'unknown';
    const rateLimitKey = `forgot_pwd_${clientIp}_${(email || '').trim().toLowerCase()}`;

    const rateCheck = checkRateLimit(rateLimitKey);
    if (rateCheck.isLocked) {
      return res.status(429).json({
        error: `Too many password reset requests. Please wait ${rateCheck.remainingSeconds} seconds before trying again.`,
        lockoutSeconds: rateCheck.remainingSeconds,
      });
    }

    if (!email) {
      recordFailedAttempt(rateLimitKey);
      return res.status(400).json({ error: 'Please enter your work email.' });
    }

    recordFailedAttempt(rateLimitKey);
    const cleanEmail = email.trim().toLowerCase();
    let matchedStaff: DbStaffAccount | null = null;
    for (const staff of Object.values(db.staff)) {
      if (staff.workEmail.toLowerCase() === cleanEmail) {
        matchedStaff = staff;
        break;
      }
    }

    if (matchedStaff) {
      for (const tok of Object.values(db.resetTokens || {})) {
        if (tok.staffId === matchedStaff.id && !tok.used) {
          tok.used = true;
        }
      }

      const resetToken = crypto.randomBytes(24).toString('hex');
      db.resetTokens[resetToken] = {
        token: resetToken,
        staffId: matchedStaff.id,
        expiresAt: Date.now() + 15 * 60 * 1000,
        used: false,
      };
      saveDatabase();

      logAuditEvent(
        matchedStaff.name,
        matchedStaff.role,
        matchedStaff.branchId,
        'PASSWORD_RESET',
        `Password reset token generated for ${matchedStaff.workEmail}`
      );

      console.info(`[SECURITY AUDIT] Staff password reset token generated for ${matchedStaff.workEmail}`);

      return res.json({
        success: true,
        message: 'If an account matches this work email, reset instructions have been generated.',
      });
    }

    res.json({
      success: true,
      message: 'If an account matches this work email, reset instructions have been generated.',
    });
  });

  router.post('/api/auth/staff/reset-password', (req, res) => {
    const db = getDb();
    const { token, newPassword } = req.body;
    const clientIp = req.ip || req.socket.remoteAddress || 'unknown';
    const rateLimitKey = `reset_pwd_${clientIp}`;

    const rateCheck = checkRateLimit(rateLimitKey);
    if (rateCheck.isLocked) {
      return res.status(429).json({
        error: `Too many failed reset attempts. Please wait ${rateCheck.remainingSeconds} seconds before trying again.`,
        lockoutSeconds: rateCheck.remainingSeconds,
      });
    }

    if (!token || !newPassword) {
      recordFailedAttempt(rateLimitKey);
      return res.status(400).json({ error: 'Recovery PIN/token and new password are required.' });
    }

    const policyCheck = validateStaffPasswordPolicy(newPassword);
    if (!policyCheck.valid) {
      return res.status(400).json({ error: policyCheck.error });
    }

    const cleanToken = String(token).trim();
    const resetRecord =
      db.resetTokens[cleanToken] ||
      db.resetTokens[cleanToken.toUpperCase()] ||
      Object.values(db.resetTokens || {}).find((r) => r.token.toLowerCase() === cleanToken.toLowerCase());

    if (!resetRecord || resetRecord.used || resetRecord.expiresAt < Date.now()) {
      recordFailedAttempt(rateLimitKey);
      return res.status(400).json({ error: 'Invalid or expired password reset token/PIN.' });
    }

    const staff = db.staff[resetRecord.staffId];
    if (!staff) {
      recordFailedAttempt(rateLimitKey);
      return res.status(400).json({ error: 'Staff account not found.' });
    }

    clearRateLimit(rateLimitKey);
    staff.passwordHash = hashPasswordBcrypt(newPassword);
    delete staff.salt;
    staff.mustChangePassword = false;
    staff.failedLoginAttempts = 0;
    delete staff.lockoutUntil;
    staff.updatedAt = new Date().toISOString();
    resetRecord.used = true;

    for (const tok of Object.values(db.resetTokens || {})) {
      if (tok.staffId === staff.id) {
        tok.used = true;
      }
    }

    for (const [sessToken, sess] of Object.entries(db.sessions)) {
      if (sess.staffId === staff.id) {
        delete db.sessions[sessToken];
      }
    }
    saveDatabaseSync();

    logAuditEvent(staff.name, staff.role, staff.branchId, 'PASSWORD_RESET', `Password successfully updated by ${staff.name}`);
    res.json({ success: true, message: 'Password updated successfully. You may now log in.' });
  });

  return router;
}
