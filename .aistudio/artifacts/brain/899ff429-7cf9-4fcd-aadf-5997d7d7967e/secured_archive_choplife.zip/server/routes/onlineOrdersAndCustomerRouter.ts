import { Router } from 'express';
import type {
  DbDatabase,
  DbStaffAccount,
  DbSession,
  DbCheck,
  DbCheckItem,
  DbDeliveryTask,
} from '../../server_db.ts';
import { DEFAULT_DELIVERY_ZONES } from './cmsAndMenuRouter.ts';
import { createCustomerOtpAndOrderOpsRouter } from './customerOtpAndOrderOpsRouter.ts';
import type { CustomerNotificationPayload } from '../services/customerNotificationService.ts';

export function createOnlineOrdersAndCustomerRouter(deps: {
  getDb: () => DbDatabase;
  saveDatabaseSync: () => void;
  requireAuth: any;
  requireBranchAccess: any;
  getSessionFromRequest: (req: any) => DbSession | null;
  depleteInventoryForOrder: (
    items: DbCheckItem[],
    branchId: string,
    orderRef: string,
    staff: DbStaffAccount
  ) => void;
  sendCustomerNotification: (payload: CustomerNotificationPayload) => any[];
  logAuditEvent: (
    staffName: string,
    staffRole: string,
    branchId: string,
    actionType: string,
    details: string,
    metadata?: Record<string, any>
  ) => void;
}): Router {
  const router = Router();
  const {
    getDb,
    saveDatabaseSync,
    getSessionFromRequest,
    depleteInventoryForOrder,
    sendCustomerNotification,
    logAuditEvent,
  } = deps;

  // 4.5 Unified Online Orders Creation Pipeline
  router.post('/api/orders', (req, res) => {
    const db = getDb();
    try {
      const {
        id,
        branchId = 'gra',
        orderType = 'delivery',
        items = [],
        subtotal = 0,
        deliveryFee = 0,
        packagingFee = 0,
        discount = 0,
        appliedCouponCode,
        total = 0,
        paymentMethod = 'cash_on_delivery',
        paymentStatus = 'pending',
        deliveryDetails = {},
        orderChannel = 'web_customer',
      } = req.body;

      const session = getSessionFromRequest(req);
      const reqStaff = session ? db.staff[session.staffId] : null;

      if (id && db.orders[id]) {
        const existingOrder = db.orders[id];
        const submittedPhone = String(
          deliveryDetails?.customerPhone || (req.body as any).customerPhone || ''
        ).replace(/[^0-9]/g, '');
        const existingPhone = String(existingOrder.deliveryDetails?.customerPhone || '').replace(/[^0-9]/g, '');
        const isSameCustomer =
          submittedPhone.length >= 8 &&
          existingPhone.length >= 8 &&
          submittedPhone.slice(-10) === existingPhone.slice(-10);

        if (!reqStaff && !isSameCustomer) {
          return res.status(409).json({
            error: 'Order ID already exists. Cannot retrieve existing order without matching customer verification.',
          });
        }

        return res.json({
          success: true,
          order: existingOrder,
          message: 'Existing order returned (idempotent request).',
        });
      }

      if (!items || !Array.isArray(items) || items.length === 0) {
        return res.status(400).json({ error: 'Order must contain at least one menu item.' });
      }

      const validBranches = new Set(['gra', 'okabere', 'ugbowo', ...Object.keys(db.branches || {})]);
      if (!validBranches.has(String(branchId))) {
        return res.status(400).json({ error: `Invalid branchId '${branchId}'.` });
      }

      const orderId = id || `ord-${Date.now()}`;
      const now = new Date().toISOString();
      const datePrefix = now.slice(0, 10).replace(/-/g, '');
      let orderNumber = (req.body.orderNumber && !Object.values(db.orders).some((o) => o.orderNumber === req.body.orderNumber))
        ? req.body.orderNumber
        : '';
      if (!orderNumber) {
        const todayCount = Object.values(db.orders).filter((o) => o.createdAt && o.createdAt.startsWith(now.slice(0, 10))).length + 1;
        let attempt = 0;
        do {
          orderNumber = `CL-${datePrefix}-${String(todayCount + attempt).padStart(4, '0')}`;
          attempt++;
        } while (Object.values(db.orders).some((o) => o.orderNumber === orderNumber));
      }
      const pickupCode = String(Math.floor(1000 + Math.random() * 9000));

      db.menuProducts = db.menuProducts || {};
      db.categories = db.categories || {};
      const normalizedItems: any[] = [];
      let authoritativeItemsSum = 0;

      for (const it of items) {
        const qty = Math.max(1, Number(it.quantity) || 1);
        const rawLookupId = String(it.productId || it.menuItemId || it.id || '').trim();
        const catalogProduct =
          db.menuProducts[rawLookupId] ||
          Object.values(db.menuProducts).find(
            (mp) => mp.id === rawLookupId || (it.name && mp.name.toLowerCase() === String(it.name).trim().toLowerCase())
          );

        let unitPrice = Math.max(0, Number(it.price ?? it.unitPrice ?? 0));

        if (catalogProduct) {
          if (catalogProduct.status && catalogProduct.status !== 'published') {
            return res.status(400).json({
              error: `Item '${catalogProduct.name}' is currently ${catalogProduct.status} and unavailable for ordering.`,
            });
          }

          const productCat = db.categories[catalogProduct.category];
          if (productCat && productCat.isActive === false) {
            return res.status(400).json({
              error: `Category '${productCat.name}' for item '${catalogProduct.name}' is currently inactive.`,
            });
          }

          if (
            catalogProduct.branchAvailability &&
            catalogProduct.branchAvailability[branchId] === false
          ) {
            return res.status(400).json({
              error: `Item '${catalogProduct.name}' is currently sold out / unavailable at the selected branch (${branchId.toUpperCase()}).`,
            });
          }

          const authoritativeBasePrice = Number(
            catalogProduct.branchPrices?.[branchId] !== undefined
              ? catalogProduct.branchPrices[branchId]
              : catalogProduct.basePrice
          );

          let verifiedExtrasDelta = 0;
          if (Array.isArray(it.selectedAddOns) && Array.isArray(catalogProduct.availableAddOns)) {
            for (const addOn of it.selectedAddOns) {
              const addOnId = typeof addOn === 'string' ? addOn : addOn?.id;
              const matchedAddOn = catalogProduct.availableAddOns.find((a: any) => a.id === addOnId || a.name === addOn?.name);
              if (matchedAddOn) {
                verifiedExtrasDelta += Number(matchedAddOn.price || 0) * Math.max(1, Number(addOn?.quantity) || 1);
              } else if (typeof addOn?.price === 'number' && addOn.price > 0) {
                verifiedExtrasDelta += addOn.price;
              }
            }
          }

          const minimumValidUnitPrice = authoritativeBasePrice + verifiedExtrasDelta;
          if (unitPrice < minimumValidUnitPrice || unitPrice === 0) {
            unitPrice = minimumValidUnitPrice;
          }
        }

        const lineTotal = unitPrice * qty;
        authoritativeItemsSum += lineTotal;
        normalizedItems.push({
          ...it,
          productId: catalogProduct?.id || rawLookupId || 'prod-custom',
          name: catalogProduct?.name || it.name || 'Menu Item',
          quantity: qty,
          price: unitPrice,
          unitPrice,
          totalPrice: lineTotal,
        });
      }

      const calculatedSubtotal = authoritativeItemsSum > 0 ? authoritativeItemsSum : Math.max(0, Number(subtotal) || 0);

      const explicitZone = deliveryDetails.deliveryZone || (req.body as any).deliveryZone;
      const requestedZone = String(explicitZone || 'Standard').trim();
      const configuredZones = db.cmsContent?.deliveryZones || DEFAULT_DELIVERY_ZONES;
      const matchedZoneConfig = configuredZones[requestedZone] || configuredZones.Standard;
      const branchBaseFee = Number(db.branches?.[branchId]?.deliveryFeeBase ?? matchedZoneConfig?.fee ?? 700);
      const authoritativeDeliveryFee =
        orderType === 'delivery' && explicitZone
          ? Math.max(Number(deliveryFee) || 0, matchedZoneConfig ? Number(matchedZoneConfig.fee) : branchBaseFee)
          : Math.max(0, Number(deliveryFee) || 0);

      const safeDeliveryFee = orderChannel === 'pos_counter' ? Math.max(0, Number(deliveryFee) || 0) : authoritativeDeliveryFee;
      const safePackagingFee = Math.max(0, Number(packagingFee) || 0);
      const safeDiscount = Math.min(calculatedSubtotal, Math.max(0, Number(discount) || 0));
      const calculatedTotal = Math.max(0, calculatedSubtotal + safeDeliveryFee + safePackagingFee - safeDiscount);

      const rawDeliveryInstructions = String(
        deliveryDetails.deliveryInstructions ??
          (req.body as any).deliveryInstructions ??
          deliveryDetails.deliveryNotes ??
          (req.body as any).deliveryNotes ??
          ''
      ).trim();
      const rawPreparationNotes = String(
        deliveryDetails.preparationNotes ?? (req.body as any).preparationNotes ?? ''
      ).trim();
      const rawSpecialOccasionNote = String(
        deliveryDetails.specialOccasionNote ?? (req.body as any).specialOccasionNote ?? ''
      )
        .trim()
        .slice(0, 160);

      const actualDeliveryDetails = {
        customerName: deliveryDetails.customerName || (req.body as any).customerName || 'Online Customer',
        customerPhone: deliveryDetails.customerPhone || (req.body as any).customerPhone || '0800-000-0000',
        customerEmail: deliveryDetails.customerEmail || (req.body as any).customerEmail || '',
        deliveryAddress: deliveryDetails.deliveryAddress || (req.body as any).deliveryAddress || 'Pickup at Store',
        deliveryZone: requestedZone,
        landmark: deliveryDetails.landmark || (req.body as any).landmark || '',
        deliveryNotes: rawDeliveryInstructions,
        deliveryInstructions: rawDeliveryInstructions,
        preparationNotes: rawPreparationNotes,
        specialOccasionNote: rawSpecialOccasionNote,
        specialOccasionDisclaimerAccepted: Boolean(rawSpecialOccasionNote),
        scheduledTime: deliveryDetails.scheduledTime || (req.body as any).scheduledTime || 'ASAP',
      };

      let validatedPaymentStatus: 'paid' | 'pending' | 'unpaid' | 'reconciliation_required' = 'pending';
      if (paymentMethod === 'cash_on_delivery') {
        validatedPaymentStatus = 'unpaid';
      } else if (paymentMethod === 'bank_transfer' && orderChannel !== 'pos_counter') {
        validatedPaymentStatus = 'reconciliation_required';
      } else if (orderChannel === 'pos_counter') {
        validatedPaymentStatus = (reqStaff && paymentStatus === 'paid') ? 'paid' : 'pending';
      } else {
        validatedPaymentStatus = 'pending';
      }

      const orderRecord = {
        id: orderId,
        orderNumber,
        branchId,
        orderType,
        items: normalizedItems,
        subtotal: calculatedSubtotal,
        deliveryFee: safeDeliveryFee,
        packagingFee: safePackagingFee,
        discount: safeDiscount,
        appliedCouponCode,
        total: calculatedTotal,
        paymentMethod,
        paymentStatus: validatedPaymentStatus,
        deliveryDetails: actualDeliveryDetails,
        orderChannel,
        status: 'confirmed',
        createdAt: now,
        updatedAt: now,
        estimatedDeliveryMinutes: orderType === 'delivery' ? 45 : 20,
        pickupAuthorizationCode: pickupCode,
        deliveryPin: pickupCode,
      };

      db.orders[orderId] = orderRecord;

      const checkId = `chk-${orderId}`;
      const checkItems = normalizedItems.map((it: any, idx: number) => {
        const uPrice = Number(it.price || it.unitPrice || 0);
        const qty = Number(it.quantity) || 1;
        return {
          id: it.id ? `item-${orderId}-${idx}` : `chk-item-${Date.now()}-${idx}`,
          productId: it.productId || it.id || it.menuItemId || 'prod-custom',
          menuItemId: it.productId || it.id || it.menuItemId || 'prod-custom',
          name: it.name,
          variantName: it.selectedVariant || undefined,
          quantity: qty,
          unitPrice: uPrice,
          totalPrice: Number(it.totalPrice || (uPrice * qty)),
          notes: it.notes || it.selectedSpiceLevel || '',
          status: 'sent_to_kitchen' as const,
          sentToKitchenAt: now,
        };
      });

      const kdsSummaryParts = [
        `Online Order #${orderNumber} [${orderType.toUpperCase()}]`,
        rawPreparationNotes ? `KITCHEN PREP: ${rawPreparationNotes}` : 'Standard preparation',
        rawSpecialOccasionNote ? `OCCASION REQUEST (Non-binding): "${rawSpecialOccasionNote}"` : '',
      ].filter(Boolean);

      const unifiedCheck: DbCheck = {
        id: checkId,
        checkNumber: orderNumber,
        branchId,
        checkType: orderType === 'dine-in' ? 'dine_in' : orderType === 'takeaway' ? 'takeaway' : 'delivery',
        status: 'sent_to_kitchen',
        customerName: actualDeliveryDetails.customerName,
        customerPhone: actualDeliveryDetails.customerPhone,
        guestCount: 1,
        items: checkItems,
        subtotal: calculatedSubtotal,
        packagingFee: safePackagingFee,
        deliveryFee: safeDeliveryFee,
        discountAmount: safeDiscount,
        total: calculatedTotal,
        paymentStatus: validatedPaymentStatus === 'paid' ? 'paid' : 'unpaid',
        paymentMethod: paymentMethod === 'cash_on_delivery' ? 'cash' : paymentMethod,
        openedAt: now,
        openedByStaffId: 'sys-web-storefront',
        openedByName: 'Online Customer Storefront',
        notes: kdsSummaryParts.join(' | '),
      };

      db.checks[checkId] = unifiedCheck;

      if (orderType === 'delivery' || orderType === 'takeaway') {
        const deliveryTask: DbDeliveryTask = {
          id: orderId,
          orderId,
          orderNumber,
          branchId,
          customerName: actualDeliveryDetails.customerName,
          customerPhone: actualDeliveryDetails.customerPhone,
          deliveryAddress: actualDeliveryDetails.deliveryAddress,
          deliveryZone: actualDeliveryDetails.deliveryZone,
          landmark: actualDeliveryDetails.landmark,
          orderTotal: calculatedTotal,
          paymentMethod,
          codAmountDue: paymentMethod === 'cash_on_delivery' ? calculatedTotal : 0,
          codAmountCollected: 0,
          status: 'pending',
          cashReconciled: false,
          pickupAuthorizationCode: pickupCode,
          notes: rawDeliveryInstructions,
        };
        db.deliveryTasks[orderId] = deliveryTask;
      }

      try {
        depleteInventoryForOrder(checkItems, branchId, orderNumber, {
          id: 'sys-web',
          staffId: 'SYS-WEB',
          name: 'Online Ordering Engine',
          role: 'system',
          branchId,
        } as any);
      } catch (invErr) {
        console.error('[ORDERS API] Inventory depletion notice:', invErr);
      }

      saveDatabaseSync();

      try {
        sendCustomerNotification({
          orderId: orderRecord.id,
          orderNumber: orderRecord.orderNumber,
          customerName: orderRecord.deliveryDetails.customerName,
          customerPhone: orderRecord.deliveryDetails.customerPhone,
          channel: 'both',
          eventType: 'ORDER_CONFIRMATION',
          branchId,
          metadata: {
            total: calculatedTotal,
            itemCount: items.length,
            orderType,
          },
        });
      } catch (notifErr) {
        console.error('[NOTIF ENGINE] Automated order confirmation trigger error:', notifErr);
      }

      logAuditEvent(
        orderRecord.deliveryDetails.customerName,
        'online_customer',
        branchId,
        'ORDER_CREATED',
        `Placed ${orderType.toUpperCase()} order #${orderNumber} for ₦${Number(total).toLocaleString()} (${items.length} items)`
      );

      res.status(201).json({
        success: true,
        order: orderRecord,
        check: unifiedCheck,
        message: 'Order created, routed to kitchen KDS, and queued for dispatch.',
      });
    } catch (error: any) {
      console.error('[ORDERS API ERROR]', error);
      res.status(500).json({ error: 'Failed to create order: ' + (error?.message || 'Server error') });
    }
  });

  // Public Customer Order Tracking Endpoint (must remain above /api/orders/:id)
  router.get('/api/orders/track', (req, res) => {
    const db = getDb();
    const { orderNumber, phone, orderId, pickupCode } = req.query;

    if (!orderNumber && !orderId) {
      return res.status(400).json({ error: 'Order number or order ID is required to track order.' });
    }

    const cleanOrderNum = String(orderNumber || '').trim().toUpperCase();
    const cleanPhone = String(phone || '').trim().replace(/[^0-9+]/g, '');
    const cleanId = String(orderId || '').trim();
    const cleanPickup = String(pickupCode || '').trim();

    if (!cleanPhone && !cleanPickup) {
      return res.status(400).json({
        error: 'For customer privacy, phone number or pickup code is required to track order status.',
      });
    }

    const matched = Object.values(db.orders).find((o: any) => {
      const oPhone = (o.deliveryDetails?.customerPhone || '').replace(/[^0-9]/g, '');
      const cleanDigits = cleanPhone.replace(/[^0-9]/g, '');
      const isPlaceholderPhone = oPhone === '08000000000' || oPhone.length < 8;
      const phoneMatches =
        !isPlaceholderPhone &&
        cleanDigits.length >= 8 &&
        oPhone.slice(-10) === cleanDigits.slice(-10);
      const pickupMatches = cleanPickup.length >= 4 && o.pickupAuthorizationCode === cleanPickup;

      if (cleanOrderNum && o.orderNumber?.toUpperCase() === cleanOrderNum) {
        return phoneMatches || pickupMatches;
      }
      if (cleanId && o.id === cleanId) {
        return phoneMatches || pickupMatches;
      }
      return false;
    });

    if (!matched) {
      return res.status(404).json({ error: 'Order not found. Please verify your order number and phone number.' });
    }

    res.json({
      id: matched.id,
      orderNumber: matched.orderNumber,
      branchId: matched.branchId,
      orderType: matched.orderType,
      status: matched.status,
      paymentStatus: matched.paymentStatus,
      paymentMethod: matched.paymentMethod,
      items: matched.items?.map((it: any) => ({
        name: it.name,
        quantity: it.quantity,
        price: it.price || it.unitPrice,
      })),
      subtotal: matched.subtotal,
      deliveryFee: matched.deliveryFee,
      packagingFee: matched.packagingFee,
      discount: matched.discount,
      total: matched.total,
      createdAt: matched.createdAt,
      estimatedDeliveryMinutes: matched.estimatedDeliveryMinutes,
      deliveryStatus: matched.deliveryStatus || 'preparing',
    });
  });

  // Mount Customer OTP, Profile, Order Listing/Status & Manager Override Routes
  router.use(createCustomerOtpAndOrderOpsRouter(deps));

  return router;
}
