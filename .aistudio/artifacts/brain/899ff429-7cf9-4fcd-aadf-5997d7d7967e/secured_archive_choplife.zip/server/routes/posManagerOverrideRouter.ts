import { Router } from 'express';
import type { DbDatabase, DbStaffAccount } from '../../server_db.ts';

export interface PosManagerOverrideDeps {
  getDb: () => DbDatabase;
  requireAuth: any;
  logAuditEvent: (
    staffName: string,
    staffRole: string,
    branchId: string,
    actionType: string,
    details: string,
    metadata?: Record<string, any>
  ) => void;
}

export function createPosManagerOverrideRouter(deps: PosManagerOverrideDeps): Router {
  const router = Router();
  const { getDb, requireAuth, logAuditEvent } = deps;

  router.post('/api/pos/manager-override', requireAuth, (req, res) => {
    const db = getDb();
    const { pin, supervisorPin, action, actionType, reason, checkId } = req.body || {};
    const rawPin = pin ?? supervisorPin;
    const effectiveAction = action || actionType;
    const currentStaff = (req as any).staff as DbStaffAccount;

    if (!rawPin) {
      res.status(400).json({ error: 'Manager PIN is required.' });
      return;
    }

    const cleanPin = rawPin.toString().trim();
    const authorizedRoles = ['super_admin', 'branch_manager', 'assistant_manager', 'supervisor', 'admin'];

    const supervisor = Object.values(db.staff).find(
      (s) => s.pin === cleanPin && authorizedRoles.includes(s.role) && s.status === 'active'
    );

    if (!supervisor) {
      logAuditEvent(
        currentStaff.name,
        currentStaff.role,
        currentStaff.branchId,
        'SECURITY_ALERT',
        `Unauthorized manager override attempt by ${currentStaff.name} for ${effectiveAction || 'action'}`
      );
      res.status(403).json({ error: 'Invalid supervisor PIN or unauthorized role. Authorization denied.' });
      return;
    }

    logAuditEvent(
      supervisor.name,
      supervisor.role,
      currentStaff.branchId,
      'MANAGER_OVERRIDE',
      `Manager ${supervisor.name} authorized ${effectiveAction || 'override'} on check ${checkId || 'N/A'}. Reason: ${reason || 'Approved'}. Initiated by: ${currentStaff.name}`
    );

    res.json({
      authorized: true,
      supervisor: {
        id: supervisor.id,
        name: supervisor.name,
        role: supervisor.role,
        staffId: supervisor.staffId,
      },
    });
  });

  return router;
}
