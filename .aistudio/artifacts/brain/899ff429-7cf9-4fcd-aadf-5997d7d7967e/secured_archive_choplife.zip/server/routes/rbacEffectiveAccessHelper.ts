import express from 'express';
import type { DbStaffAccount } from '../../server_db.ts';
import {
  CANONICAL_PRIVILEGE_CATEGORIES,
  CANONICAL_REPORTS,
  CANONICAL_ORDER_SUMMARY_COLUMNS,
} from '../../src/data/rbacCatalogue.ts';
import type { StaffAndRbacRouterDeps } from './staffAndRbacRouter.ts';

export function handleRbacEffectiveAccess(
  req: express.Request,
  res: express.Response,
  deps: StaffAndRbacRouterDeps
): void {
  const { getDb, getStaffPrivileges } = deps;
  const db = getDb();
  const currentStaff = (req as any).staff as DbStaffAccount;
  const { id } = req.params;
  const staff = db.staff[id] || Object.values(db.staff).find((s) => s.staffId.toLowerCase() === id.toLowerCase());

  if (!staff) {
    res.status(404).json({ error: 'Staff account not found.' });
    return;
  }

  const isSelf = staff.id === currentStaff.id || staff.staffId.toLowerCase() === currentStaff.staffId.toLowerCase();
  const isAdminOrManager = ['super_admin', 'corporate_admin', 'admin', 'branch_manager', 'auditor'].includes(
    currentStaff.role
  );

  if (!isSelf && !isAdminOrManager) {
    res.status(403).json({ error: 'Forbidden: Insufficient privileges to view other staff access profiles.' });
    return;
  }

  if (!isSelf && currentStaff.role === 'branch_manager') {
    const mgrBranch = currentStaff.branchId;
    const allowed = staff.allowedBranchIds || [staff.branchId];
    if (staff.branchId !== mgrBranch && !allowed.includes(mgrBranch)) {
      res.status(403).json({ error: 'Access denied: Staff member belongs to another branch.' });
      return;
    }
  }

  const privileges = getStaffPrivileges(staff);
  const isSuper = staff.role === 'super_admin' || staff.role === 'admin';

  const roleObj =
    db.roles?.[`role-${staff.role}`] ||
    Object.values(db.roles || {}).find((r) => r.code === staff.role || r.id === staff.role);

  const roleName = roleObj?.name || staff.role.replace('_', ' ').toUpperCase();
  const permittedReports = isSuper
    ? CANONICAL_REPORTS.map((r) => r.code)
    : roleObj?.reports || ['sales_summary'];
  const permittedColumns = isSuper
    ? CANONICAL_ORDER_SUMMARY_COLUMNS.map((c) => c.code)
    : roleObj?.orderSummaryColumns || ['subtotal', 'net_total'];

  const categories = CANONICAL_PRIVILEGE_CATEGORIES.map((cat) => {
    const privs = cat.privileges.map((p) => ({
      code: p.code,
      name: p.name,
      granted:
        isSuper ||
        privileges.includes('*') ||
        privileges.includes(p.code) ||
        privileges.includes(`${p.code.split('.')[0]}.*`),
    }));
    return {
      categoryKey: cat.key,
      categoryLabel: cat.label,
      totalAvailable: cat.privileges.length,
      grantedCount: privs.filter((p) => p.granted).length,
      privileges: privs,
    };
  });

  res.json({
    staffId: staff.staffId,
    name: staff.name,
    workEmail: staff.workEmail,
    roleId: staff.role,
    roleName,
    branchScope: staff.branchId,
    status: staff.status,
    mustChangePassword: staff.mustChangePassword,
    failedLoginAttempts: staff.failedLoginAttempts || 0,
    lockoutUntil: staff.lockoutUntil,
    lastLoginAt: staff.lastLoginAt,
    lastLoginIp: staff.lastLoginIp,
    effectivePrivileges: privileges,
    permittedReports,
    permittedColumns,
    categories,
  });
}
