import express from 'express';
import crypto from 'crypto';
import type { DbStaffAccount } from '../../server_db.ts';
import type { RoleDefinition } from '../../src/types/rbac.ts';
import {
  CANONICAL_PRIVILEGE_CATEGORIES,
  CANONICAL_REPORTS,
  CANONICAL_ORDER_SUMMARY_COLUMNS,
  DEFAULT_STANDARD_ROLES,
} from '../../src/data/rbacCatalogue.ts';
import type { StaffAndRbacRouterDeps } from './staffAndRbacRouter.ts';
import { handleRbacEffectiveAccess } from './rbacEffectiveAccessHelper.ts';

export function createBranchesAndRbacRouter(deps: StaffAndRbacRouterDeps): express.Router {
  const router = express.Router();
  const {
    getDb,
    saveDatabaseSync,
    requireAuth,
    requireRole,
    requirePermission,
    logAuditEvent,
    hashPasswordBcrypt,
    verifyStaffPassword,
    validateStaffPasswordPolicy,
    getStaffPrivileges,
  } = deps;

  // ==========================================
  // DYNAMIC BRANCH ADMINISTRATION REST API
  // ==========================================
  router.get('/api/branches', (_req, res) => {
    const db = getDb();
    db.branches = db.branches || {};
    res.json(Object.values(db.branches));
  });

  router.get('/api/branches/:id', (req, res) => {
    const db = getDb();
    const branch = db.branches?.[req.params.id];
    if (!branch) return res.status(404).json({ error: 'Branch not found.' });
    res.json(branch);
  });

  router.post('/api/branches', requireAuth, requireRole(['super_admin', 'corporate_admin', 'admin']), (req, res) => {
    const db = getDb();
    const { name, shortName, address, landmark, phone, whatsappNumber, openingHours, deliveryHours, estimatedDeliveryTime } =
      req.body;
    const currentStaff = (req as any).staff as DbStaffAccount;

    if (!name || !address || !phone) {
      return res.status(400).json({ error: 'Missing required branch fields: name, address, phone.' });
    }

    db.branches = db.branches || {};
    const id = (req.body.id || name.toLowerCase().replace(/[^a-z0-9]/g, '-').replace(/-+/g, '-')).trim();
    if (db.branches[id]) {
      return res.status(400).json({ error: `A branch with id '${id}' already exists.` });
    }

    const code = req.body.code || `BR-${id.toUpperCase().slice(0, 3)}-${Object.keys(db.branches).length + 1}`;

    const newBranch = {
      id,
      code,
      name: name.trim(),
      shortName: (shortName || name).trim(),
      address: address.trim(),
      landmark: landmark?.trim() || '',
      city: req.body.city || 'Benin City',
      state: req.body.state || 'Edo State',
      phone: phone.trim(),
      whatsappNumber: whatsappNumber?.trim() || phone.trim(),
      openingHours: openingHours || 'Mon–Sat: 8:00 AM – 8:00 PM',
      dineInHours: req.body.dineInHours || '8:00 AM – 8:00 PM',
      deliveryHours: deliveryHours || '8:00 AM – 5:00 PM',
      isOpen: req.body.isOpen !== undefined ? req.body.isOpen : true,
      estimatedDeliveryTime: estimatedDeliveryTime || '30–60 mins',
      deliveryFeeBase: req.body.deliveryFeeBase || 700,
      status: 'active',
      createdAt: new Date().toISOString(),
    };

    db.branches[id] = newBranch;
    saveDatabaseSync();

    logAuditEvent(
      currentStaff.name,
      currentStaff.role,
      currentStaff.branchId,
      'BRANCH_CREATED',
      `Created new branch: ${newBranch.name} (${newBranch.id}, Address: ${newBranch.address})`
    );

    res.status(201).json({ success: true, branch: newBranch });
  });

  router.put('/api/branches/:id', requireAuth, requireRole(['super_admin', 'corporate_admin', 'admin']), (req, res) => {
    const db = getDb();
    const { id } = req.params;
    const branch = db.branches?.[id];
    const currentStaff = (req as any).staff as DbStaffAccount;

    if (!branch) return res.status(404).json({ error: 'Branch not found.' });

    const {
      name,
      shortName,
      address,
      landmark,
      phone,
      whatsappNumber,
      openingHours,
      deliveryHours,
      isOpen,
      estimatedDeliveryTime,
      deliveryFeeBase,
      status,
    } = req.body;
    if (name) branch.name = name.trim();
    if (shortName) branch.shortName = shortName.trim();
    if (address) branch.address = address.trim();
    if (landmark !== undefined) branch.landmark = landmark.trim();
    if (phone) branch.phone = phone.trim();
    if (whatsappNumber !== undefined) branch.whatsappNumber = whatsappNumber.trim();
    if (openingHours) branch.openingHours = openingHours;
    if (deliveryHours) branch.deliveryHours = deliveryHours;
    if (isOpen !== undefined) branch.isOpen = isOpen;
    if (estimatedDeliveryTime) branch.estimatedDeliveryTime = estimatedDeliveryTime;
    if (deliveryFeeBase !== undefined) branch.deliveryFeeBase = deliveryFeeBase;
    if (status) branch.status = status;
    branch.updatedAt = new Date().toISOString();

    saveDatabaseSync();

    logAuditEvent(
      currentStaff.name,
      currentStaff.role,
      currentStaff.branchId,
      'BRANCH_UPDATED',
      `Updated branch: ${branch.name} (${branch.id})`
    );

    res.json({ success: true, branch });
  });

  router.post(
    '/api/staff/accounts/:id/reset-password',
    requireAuth,
    requireRole(['super_admin', 'corporate_admin', 'admin', 'branch_manager']),
    (req, res) => {
      const db = getDb();
      const { id } = req.params;
      const { temporaryPassword, newPassword } = req.body;
      const passwordToSet = temporaryPassword || newPassword;
      const currentStaff = (req as any).staff as DbStaffAccount;
      const staff = db.staff[id] || Object.values(db.staff).find((s) => s.staffId.toLowerCase() === id.toLowerCase());

      if (!staff) return res.status(404).json({ error: 'Staff account not found.' });

      if (currentStaff.role === 'branch_manager') {
        const allowed = staff.allowedBranchIds || [staff.branchId];
        if (staff.branchId !== currentStaff.branchId && !allowed.includes(currentStaff.branchId)) {
          return res.status(403).json({ error: 'Branch Manager can only reset passwords for staff in their own branch.' });
        }
        if (['super_admin', 'corporate_admin', 'admin'].includes(staff.role)) {
          return res.status(403).json({ error: 'Branch Manager cannot reset corporate or super administrator passwords.' });
        }
      }

      const policyCheck = validateStaffPasswordPolicy(passwordToSet);
      if (!policyCheck.valid) {
        return res.status(400).json({ error: policyCheck.error });
      }

      staff.passwordHash = hashPasswordBcrypt(passwordToSet);
      delete staff.salt;
      staff.mustChangePassword = req.body.mustChangePassword !== undefined ? Boolean(req.body.mustChangePassword) : true;
      staff.failedLoginAttempts = 0;
      delete staff.lockoutUntil;
      staff.updatedAt = new Date().toISOString();

      for (const [token, session] of Object.entries(db.sessions)) {
        if (session.staffId === staff.id) {
          delete db.sessions[token];
        }
      }
      for (const tok of Object.values(db.resetTokens || {})) {
        if (tok.staffId === staff.id) {
          tok.used = true;
        }
      }

      saveDatabaseSync();
      logAuditEvent(
        currentStaff.name,
        currentStaff.role,
        currentStaff.branchId,
        'PASSWORD_RESET',
        `Admin reset password for ${staff.name} (${staff.staffId}) - bcrypt secured`
      );

      res.json({ success: true, message: 'Password reset with bcrypt. Active sessions invalidated.' });
    }
  );

  router.post(
    '/api/staff/accounts/:id/generate-reset-pin',
    requireAuth,
    requireRole(['super_admin', 'corporate_admin', 'admin', 'branch_manager']),
    (req, res) => {
      const db = getDb();
      const { id } = req.params;
      const currentStaff = (req as any).staff as DbStaffAccount;
      const staff = db.staff[id] || Object.values(db.staff).find((s) => s.staffId.toLowerCase() === id.toLowerCase());

      if (!staff) return res.status(404).json({ error: 'Staff account not found.' });

      if (currentStaff.role === 'branch_manager') {
        const allowed = staff.allowedBranchIds || [staff.branchId];
        if (staff.branchId !== currentStaff.branchId && !allowed.includes(currentStaff.branchId)) {
          return res
            .status(403)
            .json({ error: 'Branch Manager can only generate recovery PINs for staff in their own branch.' });
        }
        if (['super_admin', 'corporate_admin', 'admin'].includes(staff.role)) {
          return res
            .status(403)
            .json({ error: 'Branch Manager cannot generate recovery PINs for corporate administrators.' });
        }
      }

      db.resetTokens = db.resetTokens || {};
      for (const tok of Object.values(db.resetTokens)) {
        if (tok.staffId === staff.id && !tok.used) {
          tok.used = true;
        }
      }

      const recoveryPin = `CL-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
      const expiresAt = Date.now() + 15 * 60 * 1000;
      db.resetTokens[recoveryPin] = {
        token: recoveryPin,
        staffId: staff.id,
        expiresAt,
        used: false,
      };

      saveDatabaseSync();
      logAuditEvent(
        currentStaff.name,
        currentStaff.role,
        currentStaff.branchId,
        'RECOVERY_PIN_GENERATED',
        `Generated single-use 15-minute recovery PIN for ${staff.name} (${staff.staffId})`
      );

      res.json({
        success: true,
        recoveryPin,
        expiresAt: new Date(expiresAt).toISOString(),
        expiresInMinutes: 15,
        staffId: staff.staffId,
        staffName: staff.name,
        message: 'Single-use recovery PIN generated. Valid for 15 minutes.',
      });
    }
  );

  router.post(
    '/api/staff/accounts/:id/revoke-sessions',
    requireAuth,
    requireRole(['super_admin', 'corporate_admin', 'admin']),
    (req, res) => {
      const db = getDb();
      const { id } = req.params;
      const staff = db.staff[id];
      const currentStaff = (req as any).staff as DbStaffAccount;

      if (!staff) return res.status(404).json({ error: 'Staff account not found.' });

      let revokedCount = 0;
      for (const [token, session] of Object.entries(db.sessions)) {
        if (session.staffId === staff.id) {
          delete db.sessions[token];
          revokedCount++;
        }
      }

      saveDatabaseSync();
      logAuditEvent(
        currentStaff.name,
        currentStaff.role,
        currentStaff.branchId,
        'SESSION_REVOKED',
        `Revoked ${revokedCount} active sessions for ${staff.name}`
      );
      res.json({ success: true, message: `Revoked ${revokedCount} active sessions.` });
    }
  );

  router.post('/api/auth/staff/change-password', requireAuth, (req, res) => {
    const staff = (req as any).staff as DbStaffAccount;
    const { currentPassword, newPassword } = req.body;

    if (!newPassword || newPassword.length < 8) {
      return res.status(400).json({ error: 'New password must be at least 8 characters long.' });
    }

    if (staff.passwordHash && !staff.mustChangePassword) {
      if (!currentPassword) {
        return res.status(400).json({ error: 'Current password is required.' });
      }
      const check = verifyStaffPassword(currentPassword, staff);
      if (!check.valid) {
        return res.status(401).json({ error: 'Incorrect current password.' });
      }
    }

    staff.passwordHash = hashPasswordBcrypt(newPassword);
    delete staff.salt;
    staff.mustChangePassword = false;
    staff.updatedAt = new Date().toISOString();
    saveDatabaseSync();

    logAuditEvent(
      staff.name,
      staff.role,
      staff.branchId,
      'PASSWORD_CHANGED',
      `Staff member ${staff.name} changed their password (bcrypt secured)`
    );

    res.json({ success: true, message: 'Password successfully changed and secured with bcrypt.' });
  });

  // ==========================================
  // 3.5 CONFIGURABLE RBAC & ROLES MANAGEMENT
  // ==========================================
  router.get('/api/rbac/permissions-catalogue', requireAuth, (_req, res) => {
    res.json({
      categories: CANONICAL_PRIVILEGE_CATEGORIES,
      reports: CANONICAL_REPORTS,
      orderSummaryColumns: CANONICAL_ORDER_SUMMARY_COLUMNS,
      standardRoles: DEFAULT_STANDARD_ROLES,
    });
  });

  router.get(
    '/api/rbac/roles',
    requireAuth,
    requireRole(['super_admin', 'corporate_admin', 'admin', 'branch_manager', 'auditor']),
    (_req, res) => {
      const db = getDb();
      db.roles = db.roles || {};
      const staffAccounts = Object.values(db.staff || {});

      const rolesList = Object.values(db.roles).map((r) => {
        const userCount = staffAccounts.filter(
          (s) => s.role === r.code || s.role === r.id || `role-${s.role}` === r.id
        ).length;
        return {
          ...r,
          userCount,
        };
      });

      res.json(rolesList);
    }
  );

  router.get(
    '/api/rbac/roles/:id',
    requireAuth,
    requireRole(['super_admin', 'corporate_admin', 'admin', 'branch_manager', 'auditor']),
    (req, res) => {
      const db = getDb();
      const { id } = req.params;
      const role = db.roles?.[id] || Object.values(db.roles || {}).find((r) => r.code === id);
      if (!role) return res.status(404).json({ error: 'Role not found.' });
      res.json(role);
    }
  );

  router.post('/api/rbac/roles', requireAuth, requirePermission('roles.manage'), (req, res) => {
    const db = getDb();
    const currentStaff = (req as any).staff as DbStaffAccount;
    const { name, code, description, privileges = [], reports = [], orderSummaryColumns = [] } = req.body;

    if (!name || !code) {
      return res.status(400).json({ error: 'Role name and unique code are required.' });
    }

    const cleanCode = code.trim().toLowerCase().replace(/\s+/g, '_');
    const roleId = `role-${cleanCode}`;

    if (db.roles?.[roleId] || Object.values(db.roles || {}).some((r) => r.code === cleanCode)) {
      return res.status(400).json({ error: `A role with code '${cleanCode}' already exists.` });
    }

    const newRole: RoleDefinition = {
      id: roleId,
      code: cleanCode,
      name: name.trim(),
      description: description?.trim() || '',
      isSystem: false,
      privileges,
      reports,
      orderSummaryColumns,
      updatedAt: new Date().toISOString(),
    };

    db.roles[roleId] = newRole;
    saveDatabaseSync();

    logAuditEvent(
      currentStaff.name,
      currentStaff.role,
      currentStaff.branchId,
      'ROLE_CREATED',
      `Created role '${newRole.name}' (${newRole.code}) with ${privileges.length} privileges, ${reports.length} reports`
    );

    res.status(201).json({ success: true, role: newRole });
  });

  router.put('/api/rbac/roles/:id', requireAuth, requirePermission('roles.manage'), (req, res) => {
    const db = getDb();
    const currentStaff = (req as any).staff as DbStaffAccount;
    const { id } = req.params;
    const role = db.roles?.[id] || Object.values(db.roles || {}).find((r) => r.code === id);

    if (!role) {
      return res.status(404).json({ error: 'Role not found.' });
    }

    const { name, description, privileges, reports, orderSummaryColumns } = req.body;

    if (name && !role.isSystem) role.name = name.trim();
    if (description !== undefined) role.description = description.trim();
    if (Array.isArray(privileges)) role.privileges = privileges;
    if (Array.isArray(reports)) role.reports = reports;
    if (Array.isArray(orderSummaryColumns)) role.orderSummaryColumns = orderSummaryColumns;
    role.updatedAt = new Date().toISOString();

    saveDatabaseSync();

    logAuditEvent(
      currentStaff.name,
      currentStaff.role,
      currentStaff.branchId,
      'ROLE_PERMISSIONS_UPDATED',
      `Updated permissions for role '${role.name}': ${role.privileges.length} privileges, ${role.reports.length} reports, ${role.orderSummaryColumns.length} columns`
    );

    res.json({ success: true, role });
  });

  router.get('/api/rbac/staff/:id/effective-access', requireAuth, (req, res) => {
    handleRbacEffectiveAccess(req, res, deps);
  });

  return router;
}
