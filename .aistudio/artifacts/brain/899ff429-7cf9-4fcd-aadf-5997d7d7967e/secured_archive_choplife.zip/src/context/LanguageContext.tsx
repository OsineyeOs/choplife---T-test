import React, { createContext, useContext, useState, useEffect } from 'react';

export type LanguageCode = 'en' | 'pcm' | 'bin' | 'fr' | 'yo';

export interface LanguageOption {
  code: LanguageCode;
  label: string;
  nativeName: string;
  flag: string;
  region: string;
}

export const SUPPORTED_LANGUAGES: LanguageOption[] = [
  {
    code: 'en',
    label: 'English',
    nativeName: 'English',
    flag: '🇬🇧',
    region: 'Official / Global',
  },
  {
    code: 'pcm',
    label: 'Pidgin',
    nativeName: 'Naija Pidgin',
    flag: '🇳🇬',
    region: 'Maximum Enjoyment Style',
  },
  {
    code: 'bin',
    label: 'Ẹ̀dó',
    nativeName: 'Ẹ̀dó (Benin)',
    flag: '🏛️',
    region: 'Benin City Native',
  },
  {
    code: 'fr',
    label: 'Français',
    nativeName: 'Français',
    flag: '🇫🇷',
    region: 'International',
  },
  {
    code: 'yo',
    label: 'Yorùbá',
    nativeName: 'Èdè Yorùbá',
    flag: '🇳🇬',
    region: 'Regional SW',
  },
];

const TRANSLATIONS: Record<LanguageCode, Record<string, string>> = {
  en: {
    'announcement.slogan': 'Enjoy Yourself, Is That Too Much To Ask? 100% Maximum Enjoyment!',
    'announcement.mobile': 'Fresh Small Chops • Bakery • Standard Delivery (30–90 mins)',
    'announcement.catering': 'Party & Catering',
    'announcement.branches': '3 Benin Branches',
    'announcement.whatsapp': 'WhatsApp Help',
    'nav.ordering_from': 'Ordering from',
    'nav.delivery': 'Delivery',
    'nav.pickup': 'Pickup',
    'nav.search_placeholder': 'Search shawarma, small chops, grills...',
    'nav.branches': 'Branches',
    'nav.account': 'Account',
    'nav.order_cart': 'ORDER CART',
    'nav.track_order': 'Track Order',
    'account.order_history': 'ORDER HISTORY',
    'account.order_history_desc': 'Live status tracking and 1-click reorder past meals',
    'account.total_spent': 'Total Spent',
    'account.no_orders_title': 'No orders placed yet',
    'account.no_orders_desc': 'Browse our approved menu items, build a custom small chops box, or order fresh bromate-free bread!',
    'account.browse_menu': 'Browse Menu & Order',
    'account.load_sample': 'Load Sample Order',
    'account.order_again': 'Order Again',
    'account.reorder_item': 'Reorder Item',
    'account.receipt': 'Receipt',
    'account.track': 'Track',
    'account.total_paid': 'TOTAL PAID',
    'account.fulfilled_by': 'Fulfilled by',
    'account.search_orders': 'Filter past orders...',
    'account.filter_all': 'All Orders',
    'account.filter_delivered': 'Delivered',
    'account.filter_active': 'Active / Preparing',
    'lang.language': 'Language',
  },
  pcm: {
    'announcement.slogan': 'Chop Life Well Well! Enjoyment No Get Limit • 100% Maximum Enjoyment!',
    'announcement.mobile': 'Fresh Hot Small Chops • Bakery Bread • Quick Delivery (30–90 mins)',
    'announcement.catering': 'Party & Shindig Packs',
    'announcement.branches': '3 Benin Spot',
    'announcement.whatsapp': 'WhatsApp Kitchen',
    'nav.ordering_from': 'You dey order from',
    'nav.delivery': 'Bring Am Come',
    'nav.pickup': 'I Go Carry Am',
    'nav.search_placeholder': 'Find shawarma, small chops, suya grills...',
    'nav.branches': 'Kitchens',
    'nav.account': 'My Profile',
    'nav.order_cart': 'CHOP BASKET',
    'nav.track_order': 'Follow Order',
    'account.order_history': 'CHOP HISTORY',
    'account.order_history_desc': 'Check wetin you don chop before and reorder sharp-sharp',
    'account.total_spent': 'Money We Don Chop',
    'account.no_orders_title': 'You never chop from us yet!',
    'account.no_orders_desc': 'Check our sweet menu, package custom small chops, or chop hot bromate-free bread!',
    'account.browse_menu': 'See Menu & Chop',
    'account.load_sample': 'Sample Chop History',
    'account.order_again': 'Chop Again',
    'account.reorder_item': 'Add This One',
    'account.receipt': 'Receipt Paper',
    'account.track': 'Follow Am',
    'account.total_paid': 'TOTAL WEY YOU PAY',
    'account.fulfilled_by': 'Cooked by',
    'account.search_orders': 'Search chop record...',
    'account.filter_all': 'All Orders',
    'account.filter_delivered': 'Don Deliver',
    'account.filter_active': 'De Fire For Kitchen',
    'lang.language': 'Language',
  },
  bin: {
    'announcement.slogan': 'Kóyo! Ghẹ dọ gbẹ ẹre vbe ChopLife • 100% Maximum Enjoyment!',
    'announcement.mobile': 'Emwanta Small Chops • Ebredi • Ọkọ Ékí (30–90 mins)',
    'announcement.catering': 'Ẹkí Ẹgúa',
    'announcement.branches': 'Ẹkí Ẹha vbe Benin',
    'announcement.whatsapp': 'WhatsApp Ẹkí',
    'nav.ordering_from': 'Ẹkí nọ gbẹ',
    'nav.delivery': 'Ọkọ Ékí',
    'nav.pickup': 'Mu Vb’uwa',
    'nav.search_placeholder': 'Gualọ shawarma, small chops, emwi ẹkí...',
    'nav.branches': 'Ẹkí Ẹha',
    'nav.account': 'Ẹmwẹ Mwen',
    'nav.order_cart': 'ẸKPỌ ÉKÍ',
    'nav.track_order': 'Khu Ẹkí',
    'account.order_history': 'ẸMWẸ ÉKÍ MWẸN',
    'account.order_history_desc': 'Ghe emwi u dọ re vbe ódé, dọ re vbọ gbẹ',
    'account.total_spent': 'Igho Ẹkí Kpao',
    'account.no_orders_title': 'U ma he dọ re emwi khian',
    'account.no_orders_desc': 'Ghe emwi evbare mẹn, dọ re small chops kevbe ebredi nọ bẹghẹ!',
    'account.browse_menu': 'Ghe Ékí & Dọ Re',
    'account.load_sample': 'Ghe Ékí Oghomwẹ',
    'account.order_again': 'Tún Dọ Re',
    'account.reorder_item': 'Mu Ọna Vbọ',
    'account.receipt': 'Ebe Ékí',
    'account.track': 'Khu Ẹre',
    'account.total_paid': 'IGHO KPATA',
    'account.fulfilled_by': 'Vbe ẹkí',
    'account.search_orders': 'Gualọ ẹmwẹ ékí...',
    'account.filter_all': 'Ékí Kpata',
    'account.filter_delivered': 'A kẹre nẹ',
    'account.filter_active': 'A ya lé vb’odẹ',
    'lang.language': 'Ẹvbe',
  },
  fr: {
    'announcement.slogan': 'Faites-vous plaisir! 100% Plaisir Maximum • Benin City!',
    'announcement.mobile': 'Small Chops Frais • Boulangerie • Livraison Standard (30–90 mins)',
    'announcement.catering': 'Événements & Traiteur',
    'announcement.branches': '3 Succursales à Benin',
    'announcement.whatsapp': 'Assistance WhatsApp',
    'nav.ordering_from': 'Commander de',
    'nav.delivery': 'Livraison',
    'nav.pickup': 'À Emporter',
    'nav.search_placeholder': 'Rechercher shawarma, grillades, beignets...',
    'nav.branches': 'Succursales',
    'nav.account': 'Compte',
    'nav.order_cart': 'PANIER',
    'nav.track_order': 'Suivre Commande',
    'account.order_history': 'HISTORIQUE DES COMMANDES',
    'account.order_history_desc': 'Suivi en direct et recommandation en 1 clic',
    'account.total_spent': 'Total Dépensé',
    'account.no_orders_title': 'Aucune commande enregistrée',
    'account.no_orders_desc': 'Explorez nos menus certifiés, créez votre box de beignets ou dégustez nos pains frais!',
    'account.browse_menu': 'Voir le Menu & Commander',
    'account.load_sample': 'Charger Exemple',
    'account.order_again': 'Commander à Nouveau',
    'account.reorder_item': 'Recommander Cet Article',
    'account.receipt': 'Reçu',
    'account.track': 'Suivre',
    'account.total_paid': 'TOTAL PAYÉ',
    'account.fulfilled_by': 'Préparé par',
    'account.search_orders': 'Filtrer les commandes...',
    'account.filter_all': 'Toutes',
    'account.filter_delivered': 'Livrées',
    'account.filter_active': 'En Cuisine / En Route',
    'lang.language': 'Langue',
  },
  yo: {
    'announcement.slogan': 'Gbádùn Ayé Rẹ! 100% Ìgbádùn Gidi • Ìlú Benin!',
    'announcement.mobile': 'Small Chops Tútù • Búrẹ́dì • Ìfiranṣẹ́ Kíákíá (30–90 mins)',
    'announcement.catering': 'Àpèjẹ & Ayẹyẹ',
    'announcement.branches': 'Èka 3 ní Benin',
    'announcement.whatsapp': 'Iranlọwọ WhatsApp',
    'nav.ordering_from': 'Paṣẹ láti èka',
    'nav.delivery': 'Fún Mi Nílé',
    'nav.pickup': 'Wá Gbà Á',
    'nav.search_placeholder': 'Wá shawarma, small chops, ẹran yíyan...',
    'nav.branches': 'Àwọn Èka',
    'nav.account': 'Àkọọ́lẹ̀',
    'nav.order_cart': 'ÀPÒ OÚNJẸ',
    'nav.track_order': 'Tọpinpin Paṣẹ',
    'account.order_history': 'ÀKỌSÍLẸ̀ OÚNJẸ TẸ́LẸ̀',
    'account.order_history_desc': 'Wo ipò oúnjẹ rẹ kí o sì tún paṣẹ ní ìṣẹ́jú àáyá',
    'account.total_spent': 'Gbogbo Owó Tó Ti San',
    'account.no_orders_title': 'Kò tíì sí àkọsílẹ̀ paṣẹ',
    'account.no_orders_desc': 'Wo àwọn oúnjẹ àtàtà wa, pèsè àpótí small chops tìrẹ, tàbí jẹ búrẹ́dì tútù!',
    'account.browse_menu': 'Wo Oúnjẹ & Paṣẹ',
    'account.load_sample': 'Wo Àpẹẹrẹ',
    'account.order_again': 'Tún Paṣẹ Gbogbo Ẹ̀',
    'account.reorder_item': 'Tún Paṣẹ Èyí',
    'account.receipt': 'Iwe Ẹ̀rí Owó',
    'account.track': 'Tọpinpin',
    'account.total_paid': 'APAPỌ OWÓ',
    'account.fulfilled_by': 'Pèsè láti',
    'account.search_orders': 'Ṣe àwárí oúnjẹ tẹ́lẹ̀...',
    'account.filter_all': 'Gbogbo Ẹ̀',
    'account.filter_delivered': 'Tí A Ti Gbé Dé',
    'account.filter_active': 'Ń Bẹ Ní Kíkè',
    'lang.language': 'Èdè',
  },
};

const STORAGE_KEY_LANGUAGE = 'choplife_language_v1';

function getInitialLanguage(): LanguageCode {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      const saved = window.localStorage.getItem(STORAGE_KEY_LANGUAGE);
      if (saved && (saved === 'en' || saved === 'pcm' || saved === 'bin' || saved === 'fr' || saved === 'yo')) {
        return saved as LanguageCode;
      }
    }
  } catch {}
  return 'en';
}

interface LanguageContextType {
  language: LanguageCode;
  setLanguage: (lang: LanguageCode) => void;
  currentLanguageOption: LanguageOption;
  languages: LanguageOption[];
  t: (key: string, fallback?: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<LanguageCode>(getInitialLanguage);

  const setLanguage = (lang: LanguageCode) => {
    setLanguageState(lang);
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        window.localStorage.setItem(STORAGE_KEY_LANGUAGE, lang);
      }
    } catch {}
  };

  const currentLanguageOption =
    SUPPORTED_LANGUAGES.find((l) => l.code === language) || SUPPORTED_LANGUAGES[0];

  const t = (key: string, fallback?: string): string => {
    const langDict = TRANSLATIONS[language] || TRANSLATIONS.en;
    if (langDict[key]) return langDict[key];
    const enDict = TRANSLATIONS.en;
    if (enDict[key]) return enDict[key];
    return fallback || key;
  };

  return (
    <LanguageContext.Provider
      value={{
        language,
        setLanguage,
        currentLanguageOption,
        languages: SUPPORTED_LANGUAGES,
        t,
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    return {
      language: 'en' as LanguageCode,
      setLanguage: () => {},
      currentLanguageOption: SUPPORTED_LANGUAGES[0],
      languages: SUPPORTED_LANGUAGES,
      t: (key: string, fallback?: string) => fallback || key,
    };
  }
  return context;
};
