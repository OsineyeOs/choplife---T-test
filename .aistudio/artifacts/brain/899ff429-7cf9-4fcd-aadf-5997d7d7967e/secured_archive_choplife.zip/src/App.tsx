import React, { useState, useEffect } from 'react';
import { AppProvider } from './context/AppContext';
import { LanguageProvider } from './context/LanguageContext';
import { Navbar } from './components/layout/Navbar';
import { MobileNav } from './components/layout/MobileNav';
import { Footer } from './components/layout/Footer';
import { HeroBanner } from './components/home/HeroBanner';
import { QuickBranchPicker } from './components/home/QuickBranchPicker';
import { DealsSection } from './components/home/DealsSection';
import { FavouritesSection } from './components/home/FavouritesSection';
import { SmallChopsHighlight } from './components/home/SmallChopsHighlight';
import { BakerySection } from './components/home/BakerySection';
import { MenuExplorer } from './components/menu/MenuExplorer';
import { ExperienceSection } from './components/home/ExperienceSection';
import { SocialProofReviews } from './components/home/SocialProofReviews';
import { ProductDetailModal } from './components/menu/ProductDetailModal';
import { SmallChopsBuilderModal } from './components/menu/SmallChopsBuilderModal';
import { CartDrawer } from './components/cart/CartDrawer';
import { CheckoutModal } from './components/checkout/CheckoutModal';
import { OrderTrackerModal } from './components/orders/OrderTrackerModal';
import { LocationsModal } from './components/locations/LocationsModal';
import { CateringModal } from './components/catering/CateringModal';
import { ReviewModal } from './components/reviews/ReviewModal';
import { AccountModal } from './components/account/AccountModal';
import { AiChatbotModal } from './components/ai/AiChatbotModal';
import { StaffLoginModal } from './components/auth/StaffLoginModal';
import { CartFeedbackToast } from './components/cart/CartFeedbackToast';
import { StaffOperationsWorkspace } from './components/staff/StaffOperationsWorkspace';
import { InterfaceLoginPortal } from './components/auth/InterfaceLoginPortal';
import { ErrorBoundary } from './components/common/ErrorBoundary';
import { useApp } from './context/AppContext';
import {
  ShieldAlert,
  ArrowRight,
  ArrowLeft,
  Store,
  ShieldCheck,
  LogOut,
} from 'lucide-react';

export type AppRoute = 'storefront' | 'pos' | 'admin';

export function getInitialRoute(): AppRoute {
  if (typeof window === 'undefined') return 'storefront';
  const path = (window.location.pathname || '').toLowerCase();
  const hash = (window.location.hash || '').toLowerCase().replace(/^#\/?/, '');

  if (path === '/pos' || path.startsWith('/pos/') || hash === 'pos' || hash.startsWith('pos/')) {
    return 'pos';
  }
  if (path === '/admin' || path.startsWith('/admin/') || hash === 'admin' || hash.startsWith('admin/')) {
    return 'admin';
  }
  return 'storefront';
}

export function ChoplifeApp() {
  const {
    isStaffLoginModalOpen,
    setIsStaffLoginModalOpen,
    currentStaff,
    logoutStaff,
    isStorefrontPreviewActive,
    setIsStorefrontPreviewActive,
    searchQuery,
  } = useApp();

  const [currentRoute, setCurrentRoute] = useState<AppRoute>(getInitialRoute);

  // Sync route on browser navigation (Back, Forward, hash change)
  useEffect(() => {
    const handleLocationChange = () => {
      setCurrentRoute(getInitialRoute());
    };
    window.addEventListener('popstate', handleLocationChange);
    window.addEventListener('hashchange', handleLocationChange);
    return () => {
      window.removeEventListener('popstate', handleLocationChange);
      window.removeEventListener('hashchange', handleLocationChange);
    };
  }, []);

  const navigateRoute = (newRoute: AppRoute) => {
    if (typeof window !== 'undefined') {
      const targetPath = newRoute === 'storefront' ? '/' : `/${newRoute}`;
      try {
        window.history.pushState(null, '', targetPath);
      } catch {
        // Fallback for restricted sandboxes
      }
      if (newRoute === 'storefront') {
        if (window.location.hash && (window.location.hash.includes('pos') || window.location.hash.includes('admin'))) {
          window.location.hash = '';
        }
      } else {
        window.location.hash = `#${newRoute}`;
      }
    }
    setCurrentRoute(newRoute);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const isSearching = Boolean(searchQuery && searchQuery.trim().length > 0);
  const canAccessBackend = [
    'super_admin',
    'corporate_admin',
    'admin',
    'branch_manager',
    'store_manager',
    'storekeeper',
    'accountant',
    'auditor',
    'content_editor',
    'menu_manager',
  ].includes(currentStaff?.role || '');

  // -------------------------------------------------------------
  // INTERFACE 2: FRONT-OFFICE OPERATIONS (/pos)
  // -------------------------------------------------------------
  if (currentRoute === 'pos') {
    if (!currentStaff) {
      return (
        <ErrorBoundary moduleName="Front-Office Login">
          <InterfaceLoginPortal mode="pos" onNavigateRoute={navigateRoute} />
        </ErrorBoundary>
      );
    }

    return (
      <ErrorBoundary moduleName="Front-Office Operations Workspace">
        <StaffOperationsWorkspace initialMode="pos" onNavigateRoute={navigateRoute} />
      </ErrorBoundary>
    );
  }

  // -------------------------------------------------------------
  // INTERFACE 3: BACK-OFFICE ADMINISTRATION (/admin)
  // -------------------------------------------------------------
  if (currentRoute === 'admin') {
    if (!currentStaff) {
      return (
        <ErrorBoundary moduleName="Back-Office Login">
          <InterfaceLoginPortal mode="admin" onNavigateRoute={navigateRoute} />
        </ErrorBoundary>
      );
    }

    // Role-based access validation for back-office administration
    if (!canAccessBackend) {
      return (
        <div className="min-h-screen bg-[#160E0C] text-[#FAF7F2] flex items-center justify-center p-4">
          <div className="max-w-md w-full bg-[#1C1210] border border-[#800D15] rounded-3xl p-8 text-center shadow-2xl space-y-5">
            <div className="w-16 h-16 mx-auto rounded-2xl bg-[#800D15]/30 border border-[#800D15] flex items-center justify-center text-[#EF4444]">
              <ShieldAlert className="w-8 h-8" />
            </div>
            <div>
              <h1 className="text-xl font-black text-[#FAF7F2] uppercase tracking-wide">
                Access Restricted
              </h1>
              <p className="text-xs text-[#A89689] mt-2 leading-relaxed">
                Your staff account (<strong>{currentStaff.name}</strong>, role:{' '}
                <span className="text-[#FFC700] uppercase font-bold">
                  {currentStaff.role.replace('_', ' ')}
                </span>
                ) is restricted to frontline operational duties and does not have administrative back-office privileges.
              </p>
            </div>
            <div className="pt-2 flex flex-col gap-2.5">
              <button
                onClick={() => navigateRoute('pos')}
                className="w-full py-3 px-4 rounded-xl bg-[#800D15] hover:bg-[#A3121B] text-white font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-md"
              >
                <Store className="w-4 h-4 text-[#FFC700]" />
                <span>Go to Front-Office POS &rarr;</span>
              </button>
              <button
                onClick={() => navigateRoute('storefront')}
                className="w-full py-2.5 px-4 rounded-xl bg-[#241311] hover:bg-[#36221E] text-[#A89689] hover:text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Return to Storefront</span>
              </button>
            </div>
          </div>
        </div>
      );
    }

    return (
      <ErrorBoundary moduleName="Back-Office Administration Workspace">
        <StaffOperationsWorkspace initialMode="admin" onNavigateRoute={navigateRoute} />
      </ErrorBoundary>
    );
  }

  // -------------------------------------------------------------
  // INTERFACE 1: CUSTOMER STOREFRONT (/)
  // -------------------------------------------------------------
  // If staff is authenticated and not in preview mode, give them quick access
  if (currentStaff && !isStorefrontPreviewActive && currentRoute === 'storefront') {
    // Staff can preview or use the storefront with an explicit top toolbar
  }

  return (
    <div className="min-h-screen bg-[#FAF7F2] text-[#241311] flex flex-col selection:bg-[#FFC700] selection:text-[#4D080F]">
      {/* Staff Storefront Navigation Bar when Staff is Authenticated */}
      {currentStaff && (
        <div className="bg-[#1C1210] border-b border-[#FFC700]/30 px-4 py-2 text-xs text-[#FAF7F2] flex items-center justify-between sticky top-0 z-50 shadow-md">
          <div className="flex items-center gap-2 font-medium">
            <span className="w-2 h-2 rounded-full bg-[#22C55E] animate-pulse" />
            <span className="font-bold text-[#FFC700]">Staff Active:</span>
            <span className="text-[#A89689] hidden sm:inline">
              <strong>{currentStaff.name}</strong> ({currentStaff.role.replace('_', ' ')})
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => navigateRoute('pos')}
              className="px-3 py-1 bg-[#800D15] hover:bg-[#A3121B] text-white text-xs font-bold rounded-lg border border-[#FFC700]/40 transition-all flex items-center gap-1.5 shadow-sm active:scale-95"
            >
              <Store className="w-3 h-3 text-[#FFC700]" />
              <span>POS Portal &rarr;</span>
            </button>
            {canAccessBackend && (
              <button
                onClick={() => navigateRoute('admin')}
                className="px-3 py-1 bg-[#FFC700] hover:bg-[#FFD733] text-[#4D080F] text-xs font-bold rounded-lg transition-all flex items-center gap-1.5 shadow-sm active:scale-95"
              >
                <ShieldCheck className="w-3 h-3 text-[#4D080F]" />
                <span>Admin Portal &rarr;</span>
              </button>
            )}
            <button
              onClick={async () => {
                await logoutStaff();
                navigateRoute('storefront');
              }}
              className="p-1 rounded-lg bg-[#241311] hover:bg-[#991B1B]/30 text-[#A89689] hover:text-[#EF4444] transition-colors"
              title="Logout Staff"
            >
              <LogOut className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Top Header Navigation */}
      <Navbar onNavigateRoute={navigateRoute} />

      {/* Main Page Layout */}
      <main className="flex-1 pb-20 md:pb-0">
        {/* 1. Hero Section with Brand Positioning & Order CTA */}
        {!isSearching && <HeroBanner />}

        {/* 2. Interactive Location / Branch Chooser */}
        {!isSearching && <QuickBranchPicker />}

        {/* 3. Full Multi-Category Menu Explorer with Live Search, Shortlist & Filters */}
        <MenuExplorer />

        {/* 4. Curated Spotlights (Hidden during active search to eliminate clutter) */}
        {!isSearching && (
          <>
            {/* Combos & Party Platters */}
            <DealsSection />

            {/* Dedicated Small Chops Spotlight & Box Builder Trigger */}
            <SmallChopsHighlight />

            {/* Dedicated Choplife Bakery Spotlight (100% Bromate-Free Bread) */}
            <BakerySection />

            {/* Dine-In, Lounge, Games & Private Table Reservations */}
            <ExperienceSection />

            {/* Social Proof, Google Reviews & Rating Showcase */}
            <SocialProofReviews />
          </>
        )}
      </main>

      {/* Rich Footer with Branch Details & WhatsApp Catalogue Shortcuts */}
      <Footer onNavigateRoute={navigateRoute} />

      {/* Mobile Sticky Bottom Navigation */}
      <MobileNav />

      {/* Modals & Overlays */}
      <CartFeedbackToast />
      <ProductDetailModal />
      <SmallChopsBuilderModal />
      <CartDrawer />
      <CheckoutModal />
      <OrderTrackerModal />
      <LocationsModal />
      <CateringModal />
      <ReviewModal />
      <AccountModal />
      <AiChatbotModal />
      <StaffLoginModal
        isOpen={isStaffLoginModalOpen}
        onClose={() => setIsStaffLoginModalOpen(false)}
      />
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <LanguageProvider>
        <AppProvider>
          <ChoplifeApp />
        </AppProvider>
      </LanguageProvider>
    </ErrorBoundary>
  );
}
