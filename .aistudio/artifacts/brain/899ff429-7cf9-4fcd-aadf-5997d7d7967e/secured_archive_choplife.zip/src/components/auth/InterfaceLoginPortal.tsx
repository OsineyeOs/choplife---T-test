import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Store,
  ShieldCheck,
  Lock,
  User,
  ArrowRight,
  ArrowLeft,
  AlertCircle,
  Sparkles,
  CheckCircle2,
  Clock,
  Eye,
  EyeOff,
} from 'lucide-react';

interface InterfaceLoginPortalProps {
  mode: 'pos' | 'admin';
  onNavigateRoute: (route: 'storefront' | 'pos' | 'admin') => void;
}

export const InterfaceLoginPortal: React.FC<InterfaceLoginPortalProps> = ({
  mode,
  onNavigateRoute,
}) => {
  const { loginStaff } = useApp();
  const [emailOrStaffId, setEmailOrStaffId] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [lockoutSeconds, setLockoutSeconds] = useState<number | null>(null);

  const isPos = mode === 'pos';

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailOrStaffId.trim() || !password) {
      setErrorMsg('Please enter both your Staff ID/Email and password.');
      return;
    }

    setIsLoading(true);
    setErrorMsg('');

    try {
      const res = await loginStaff(emailOrStaffId.trim(), password);
      if (!res.success) {
        if (res.lockoutSeconds) {
          setLockoutSeconds(res.lockoutSeconds);
        }
        setErrorMsg(res.error || 'Authentication failed. Please verify credentials.');
      } else {
        // Successful login: stay on the current route
        onNavigateRoute(mode);
      }
    } catch (err: any) {
      setErrorMsg(err?.message || 'Server error during authentication.');
    } finally {
      setIsLoading(false);
    }
  };

  const handlePresetSelect = (id: string, pass: string = 'ChopLife2025!') => {
    setEmailOrStaffId(id);
    setPassword(pass);
    setErrorMsg('');
  };

  return (
    <div className="min-h-screen bg-[#160E0C] text-[#FAF7F2] flex flex-col justify-between selection:bg-[#FFC700] selection:text-[#4D080F]">
      {/* Top Banner Navigation */}
      <header className="h-16 border-b border-[#36221E] px-4 md:px-8 flex items-center justify-between bg-[#1C1210]/80 backdrop-blur-md">
        <button
          onClick={() => onNavigateRoute('storefront')}
          className="flex items-center gap-3 hover:opacity-90 transition-opacity"
        >
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#800D15] to-[#4D080F] border border-[#FFC700]/30 flex items-center justify-center font-black text-[#FFC700] text-lg shadow-inner">
            C
          </div>
          <div className="text-left">
            <span className="font-extrabold text-sm tracking-wider uppercase text-[#FAF7F2]">
              Choplife Republic
            </span>
            <p className="text-[10px] text-[#A89689] font-mono">
              {isPos ? 'Front-Office POS Portal' : 'Back-Office Admin Portal'}
            </p>
          </div>
        </button>

        <div className="flex items-center gap-2">
          {isPos ? (
            <button
              onClick={() => onNavigateRoute('admin')}
              className="text-xs font-bold text-[#FFC700] hover:text-[#FFE066] px-3 py-1.5 rounded-lg border border-[#FFC700]/30 hover:bg-[#FFC700]/10 transition-all flex items-center gap-1.5"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Switch to Back-Office Admin &rarr;</span>
            </button>
          ) : (
            <button
              onClick={() => onNavigateRoute('pos')}
              className="text-xs font-bold text-[#FFC700] hover:text-[#FFE066] px-3 py-1.5 rounded-lg border border-[#FFC700]/30 hover:bg-[#FFC700]/10 transition-all flex items-center gap-1.5"
            >
              <Store className="w-3.5 h-3.5" />
              <span>Switch to Front-Office POS &rarr;</span>
            </button>
          )}

          <button
            onClick={() => onNavigateRoute('storefront')}
            className="text-xs font-bold text-[#C5B4A5] hover:text-white px-3 py-1.5 rounded-lg bg-[#241311] hover:bg-[#36221E] border border-[#36221E] transition-all flex items-center gap-1.5"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Storefront</span>
          </button>
        </div>
      </header>

      {/* Main Login Box */}
      <main className="flex-1 flex items-center justify-center p-4 md:p-8">
        <div className="max-w-md w-full bg-[#1C1210] border border-[#36221E] rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
          {/* Subtle Glow Effect */}
          <div className="absolute -top-24 -right-24 w-48 h-48 bg-[#800D15]/30 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-[#FFC700]/10 rounded-full blur-3xl pointer-events-none" />

          {/* Header */}
          <div className="text-center mb-6">
            <div className="w-14 h-14 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-[#800D15] to-[#4D080F] border border-[#FFC700]/40 flex items-center justify-center shadow-lg">
              {isPos ? (
                <Store className="w-7 h-7 text-[#FFC700]" />
              ) : (
                <ShieldCheck className="w-7 h-7 text-[#FFC700]" />
              )}
            </div>

            <div className="inline-block px-3 py-1 rounded-full bg-[#FFC700]/15 text-[#FFC700] text-[10px] font-mono font-bold uppercase tracking-wider mb-2 border border-[#FFC700]/30">
              {isPos ? 'Front-Office POS & Operations' : 'Back-Office Administration'}
            </div>

            <h1 className="text-xl sm:text-2xl font-black text-[#FAF7F2]">
              {isPos ? 'Frontline Staff Login' : 'Administrative Governance Login'}
            </h1>
            <p className="text-xs text-[#A89689] mt-1">
              {isPos
                ? 'Cashier Registers • Kitchen Display • Delivery Dispatch • Table Orders'
                : 'Executive Reports • Menu & CMS • Inventory • Staff & RBAC • Accounting'}
            </p>
          </div>

          {/* Error & Lockout Banner */}
          {errorMsg && (
            <div className="mb-5 p-3 rounded-xl bg-[#800D15]/30 border border-[#800D15] text-[#FFAAA6] text-xs flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 shrink-0 text-[#EF4444] mt-0.5" />
              <div className="flex-1">
                <p className="font-bold">{errorMsg}</p>
                {lockoutSeconds && lockoutSeconds > 0 && (
                  <p className="text-[11px] mt-1 text-[#FFC700]">
                    Brute-force protection: try again in {lockoutSeconds} seconds.
                  </p>
                )}
              </div>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-[#FAF7F2] uppercase tracking-wider mb-1.5">
                Staff ID or Work Email
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  value={emailOrStaffId}
                  onChange={(e) => setEmailOrStaffId(e.target.value)}
                  placeholder={isPos ? 'e.g., CL-CSH-001 or cashier@choplife.ng' : 'e.g., CL-ADM-001 or admin@choplife.ng'}
                  className="w-full bg-[#160E0C] border border-[#36221E] rounded-xl px-4 py-3 pl-10 text-sm text-[#FAF7F2] placeholder-[#6E5D57] focus:outline-none focus:border-[#FFC700] transition-colors"
                />
                <User className="w-4 h-4 text-[#A89689] absolute left-3.5 top-3.5" />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#FAF7F2] uppercase tracking-wider mb-1.5">
                Password
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter staff password"
                  className="w-full bg-[#160E0C] border border-[#36221E] rounded-xl px-4 py-3 pl-10 pr-10 text-sm text-[#FAF7F2] placeholder-[#6E5D57] focus:outline-none focus:border-[#FFC700] transition-colors"
                />
                <Lock className="w-4 h-4 text-[#A89689] absolute left-3.5 top-3.5" />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-3.5 text-[#A89689] hover:text-[#FAF7F2]"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading || Boolean(lockoutSeconds && lockoutSeconds > 0)}
              className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-[#800D15] to-[#A3121B] hover:from-[#A3121B] hover:to-[#B91C1C] text-white font-bold text-sm shadow-lg border border-[#FFC700]/30 transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed active:scale-[0.99]"
            >
              {isLoading ? (
                <span>Authenticating…</span>
              ) : (
                <>
                  <span>Sign In to {isPos ? 'Front-Office POS' : 'Back-Office Admin'}</span>
                  <ArrowRight className="w-4 h-4 text-[#FFC700]" />
                </>
              )}
            </button>
          </form>

          {/* Preset Persona Quick Buttons */}
          <div className="mt-6 pt-5 border-t border-[#36221E]">
            <p className="text-[11px] font-bold text-[#A89689] uppercase tracking-wider mb-2.5 text-center">
              Quick Personas (Password: ChopLife2025!)
            </p>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {isPos ? (
                <>
                  <button
                    type="button"
                    onClick={() => handlePresetSelect('CL-CSH-001')}
                    className="p-2 rounded-lg bg-[#241311] hover:bg-[#36221E] border border-[#36221E] text-left transition-colors"
                  >
                    <div className="font-bold text-[#FAF7F2]">Cashier (GRA)</div>
                    <div className="text-[10px] text-[#A89689]">CL-CSH-001</div>
                  </button>
                  <button
                    type="button"
                    onClick={() => handlePresetSelect('CL-KIT-001')}
                    className="p-2 rounded-lg bg-[#241311] hover:bg-[#36221E] border border-[#36221E] text-left transition-colors"
                  >
                    <div className="font-bold text-[#FAF7F2]">Kitchen Lead</div>
                    <div className="text-[10px] text-[#A89689]">CL-KIT-001</div>
                  </button>
                  <button
                    type="button"
                    onClick={() => handlePresetSelect('CL-RID-001')}
                    className="p-2 rounded-lg bg-[#241311] hover:bg-[#36221E] border border-[#36221E] text-left transition-colors"
                  >
                    <div className="font-bold text-[#FAF7F2]">Dispatch Rider</div>
                    <div className="text-[10px] text-[#A89689]">CL-RID-001</div>
                  </button>
                  <button
                    type="button"
                    onClick={() => handlePresetSelect('CL-MGR-001')}
                    className="p-2 rounded-lg bg-[#241311] hover:bg-[#36221E] border border-[#36221E] text-left transition-colors"
                  >
                    <div className="font-bold text-[#FAF7F2]">Branch Manager</div>
                    <div className="text-[10px] text-[#A89689]">CL-MGR-001</div>
                  </button>
                </>
              ) : (
                <>
                  <button
                    type="button"
                    onClick={() => handlePresetSelect('CL-ADM-001')}
                    className="p-2 rounded-lg bg-[#241311] hover:bg-[#36221E] border border-[#36221E] text-left transition-colors"
                  >
                    <div className="font-bold text-[#FFC700]">Super Admin</div>
                    <div className="text-[10px] text-[#A89689]">CL-ADM-001</div>
                  </button>
                  <button
                    type="button"
                    onClick={() => handlePresetSelect('CL-MGR-001')}
                    className="p-2 rounded-lg bg-[#241311] hover:bg-[#36221E] border border-[#36221E] text-left transition-colors"
                  >
                    <div className="font-bold text-[#FAF7F2]">Branch Manager</div>
                    <div className="text-[10px] text-[#A89689]">CL-MGR-001</div>
                  </button>
                  <button
                    type="button"
                    onClick={() => handlePresetSelect('CL-AUD-001')}
                    className="p-2 rounded-lg bg-[#241311] hover:bg-[#36221E] border border-[#36221E] text-left transition-colors"
                  >
                    <div className="font-bold text-[#FAF7F2]">Auditor</div>
                    <div className="text-[10px] text-[#A89689]">CL-AUD-001</div>
                  </button>
                  <button
                    type="button"
                    onClick={() => handlePresetSelect('CL-ACC-001')}
                    className="p-2 rounded-lg bg-[#241311] hover:bg-[#36221E] border border-[#36221E] text-left transition-colors"
                  >
                    <div className="font-bold text-[#FAF7F2]">Accountant</div>
                    <div className="text-[10px] text-[#A89689]">CL-ACC-001</div>
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="h-12 border-t border-[#36221E] px-4 flex items-center justify-between text-xs text-[#A89689] bg-[#1C1210]/60">
        <div>Choplife Republic &copy; 2026 • Benin City, Nigeria</div>
        <div className="flex items-center gap-4">
          <button
            onClick={() => onNavigateRoute('storefront')}
            className="hover:text-[#FFC700] transition-colors"
          >
            Storefront
          </button>
          <span>•</span>
          <button
            onClick={() => onNavigateRoute(isPos ? 'admin' : 'pos')}
            className="hover:text-[#FFC700] transition-colors"
          >
            {isPos ? 'Back-Office Admin' : 'Front-Office POS'}
          </button>
        </div>
      </footer>
    </div>
  );
};
