import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Star,
  CheckCircle2,
  ExternalLink,
  Heart,
  MessageSquare,
  Sparkles,
} from 'lucide-react';

export const ReviewModal: React.FC = () => {
  const {
    isReviewModalOpen,
    setIsReviewModalOpen,
    addReview,
    currentBranch,
    selectedBranchId,
  } = useApp();

  const [rating, setRating] = useState(5);
  const [name, setName] = useState('');
  const [comment, setComment] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);

  if (!isReviewModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addReview({
      customerName: name.trim() || 'Verified Customer',
      ratingOverall: rating,
      ratingFood: rating,
      ratingPackaging: rating,
      ratingDelivery: rating,
      comment: comment.trim() || 'Food was delicious, hot and packed with maximum enjoyment!',
      branchId: selectedBranchId,
      verified: true,
    });

    setIsSuccess(true);
    setTimeout(() => {
      setIsSuccess(false);
      setIsReviewModalOpen(false);
      setName('');
      setComment('');
      setRating(5);
    }, 2000);
  };

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200"
      id="review-modal"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          setIsReviewModalOpen(false);
        }
      }}
    >
      <div className="bg-white rounded-3xl w-full max-w-lg overflow-y-auto shadow-2xl border-2 border-[#FFC700] flex flex-col justify-between">
        
        {/* Header */}
        <div className="bg-[#4D080F] text-white p-5 sm:p-6 rounded-t-3xl flex items-center justify-between sticky top-0 z-20 shadow-md">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#FFC700] text-[#4D080F] flex items-center justify-center font-titan text-xl">
              ⭐
            </div>
            <div>
              <span className="text-[10px] font-titan uppercase tracking-widest text-[#FFC700] block">
                CUSTOMER FEEDBACK
              </span>
              <h2 className="font-titan text-xl sm:text-2xl text-white">
                RATE YOUR EXPERIENCE
              </h2>
            </div>
          </div>

          <button
            onClick={() => setIsReviewModalOpen(false)}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
            id="close-review-modal-btn"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 sm:p-6 space-y-6 flex-1">
          {isSuccess ? (
            <div className="py-12 text-center space-y-3">
              <CheckCircle2 className="w-14 h-14 text-emerald-600 mx-auto animate-bounce" />
              <h3 className="font-titan text-2xl text-[#4D080F]">Thank You For Your Feedback!</h3>
              <p className="text-xs font-montserrat text-[#7A6A65] max-w-xs mx-auto">
                Your review helps Choplife Republic maintain maximum enjoyment and premium service in Benin City.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Branch indicator */}
              <div className="bg-[#FAF7F2] p-3 rounded-2xl border border-[#E5DEC9] flex items-center justify-between text-xs font-montserrat">
                <span className="text-[#7A6A65]">Reviewing Branch:</span>
                <span className="font-bold text-[#4D080F]">{currentBranch.name}</span>
              </div>

              {/* Star Rating selector */}
              <div className="text-center space-y-2 py-2">
                <label className="text-xs font-titan uppercase tracking-wider text-[#4D080F] block">
                  HOW WAS YOUR OVERALL EXPERIENCE?
                </label>
                <div className="flex items-center justify-center gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setRating(star)}
                      className="p-1.5 transition-transform hover:scale-125 focus:outline-none"
                    >
                      <Star
                        className={`w-8 h-8 ${
                          star <= rating
                            ? 'text-[#FFC700] fill-[#FFC700]'
                            : 'text-gray-300'
                        }`}
                      />
                    </button>
                  ))}
                </div>
                <span className="text-xs font-montserrat font-bold text-[#E62E00]">
                  {rating === 5 ? 'Exceptional! 100% Maximum Enjoyment' : rating === 4 ? 'Very Good & Delicious' : rating === 3 ? 'Good Food' : 'Needs Improvement'}
                </span>
              </div>

              {/* Name input */}
              <div>
                <label className="text-[11px] font-montserrat font-bold text-[#5C4D49] mb-1 block">
                  Your Name (or Nickname) *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Osasere I."
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-2.5 text-xs font-montserrat text-[#241311] focus:outline-none focus:ring-2 focus:ring-[#E62E00]"
                />
              </div>

              {/* Comments */}
              <div>
                <label className="text-[11px] font-montserrat font-bold text-[#5C4D49] mb-1 block">
                  Tell us about the taste, packaging & service *
                </label>
                <textarea
                  required
                  rows={3}
                  placeholder="The small chops were so crispy, and the shawarma was loaded with cream! Delivery arrived in 30 minutes..."
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl p-3 text-xs font-montserrat text-[#241311] focus:outline-none focus:ring-2 focus:ring-[#E62E00]"
                />
              </div>

              {/* Google Profile Shortcut */}
              <div className="bg-[#FFF8E7] p-3.5 rounded-2xl border border-[#FFC700] flex items-center justify-between text-xs font-montserrat">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-[#4D080F]">Also review on Google Maps:</span>
                </div>
                <a
                  href={currentBranch.googleMapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-titan text-xs text-[#E62E00] flex items-center gap-1 hover:underline"
                >
                  <span>Google Profile</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                className="w-full bg-[#E62E00] hover:bg-[#C92200] text-white font-titan text-sm py-3.5 rounded-2xl shadow-md transition-transform active:scale-95 flex items-center justify-center gap-2"
                id="submit-review-btn"
              >
                <Sparkles className="w-4 h-4 text-[#FFC700]" />
                <span>POST VERIFIED REVIEW</span>
              </button>
            </form>
          )}
        </div>

      </div>
    </div>
  );
};
