import React, { useState, useEffect } from 'react';
import {
  Shield,
  Key,
  FileText,
  Columns,
  Check,
  Search,
  Plus,
  Save,
  RotateCcw,
  CheckSquare,
  Square,
  Users,
  AlertCircle,
  ChevronDown,
  ChevronRight,
  Sparkles,
} from 'lucide-react';
import {
  PrivilegeCategory,
  ReportItem,
  OrderSummaryColumn,
  RoleDefinition,
} from '../../types/rbac';

interface RolePermissionManagerProps {
  currentStaffRole?: string;
  showToast: (msg: string) => void;
}

export const RolePermissionManager: React.FC<RolePermissionManagerProps> = ({
  showToast,
}) => {
  const [roles, setRoles] = useState<RoleDefinition[]>([]);
  const [selectedRoleId, setSelectedRoleId] = useState<string>('role-admin');
  const [activeTab, setActiveTab] = useState<'privileges' | 'reports' | 'columns'>('privileges');
  const [categories, setCategories] = useState<PrivilegeCategory[]>([]);
  const [reportsList, setReportsList] = useState<ReportItem[]>([]);
  const [columnsList, setColumnsList] = useState<OrderSummaryColumn[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({
    back_office: true,
    pos_front_office: true,
    menu_items: true,
    inventory_procurement: true,
    accounting_finance: true,
    customer_loyalty: true,
    delivery_dispatch: true,
    security_audit: true,
  });

  // Local draft state for selected role
  const [draftPrivileges, setDraftPrivileges] = useState<string[]>([]);
  const [draftReports, setDraftReports] = useState<string[]>([]);
  const [draftColumns, setDraftColumns] = useState<string[]>([]);
  const [draftDescription, setDraftDescription] = useState<string>('');

  // Fetch catalogue and roles
  const loadData = async () => {
    setIsLoading(true);
    try {
      const token = localStorage.getItem('choplife_staff_token') || '';
      const authHeaders: Record<string, string> = {
        'Content-Type': 'application/json',
      };
      if (token) {
        authHeaders['Authorization'] = `Bearer ${token}`;
      }

      const [catRes, rolesRes] = await Promise.all([
        fetch('/api/rbac/permissions-catalogue', { headers: authHeaders }),
        fetch('/api/rbac/roles', { headers: authHeaders }),
      ]);

      let loadedRoles: RoleDefinition[] = [];

      if (catRes.ok) {
        const catData = await catRes.json();
        setCategories(catData.categories || []);
        setReportsList(catData.reports || []);
        setColumnsList(catData.orderSummaryColumns || []);
        if (Array.isArray(catData.standardRoles) && catData.standardRoles.length > 0) {
          loadedRoles = catData.standardRoles;
        }
      }

      if (rolesRes.ok) {
        const rolesData = await rolesRes.json();
        if (Array.isArray(rolesData) && rolesData.length > 0) {
          loadedRoles = rolesData;
        }
      }

      if (loadedRoles.length > 0) {
        setRoles(loadedRoles);
        setSelectedRoleId((prev) => {
          if (prev && loadedRoles.some((r) => r.id === prev || r.code === prev)) {
            return prev;
          }
          return loadedRoles[0].id || loadedRoles[0].code;
        });
      }
    } catch {
      showToast('Error loading RBAC role permissions.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Sync draft when selected role changes
  useEffect(() => {
    const role = roles.find((r) => r.id === selectedRoleId || r.code === selectedRoleId);
    if (role) {
      setDraftPrivileges([...(role.privileges || [])]);
      setDraftReports([...(role.reports || [])]);
      setDraftColumns([...(role.orderSummaryColumns || [])]);
      setDraftDescription(role.description || '');
    }
  }, [selectedRoleId, roles]);

  const selectedRole = roles.find((r) => r.id === selectedRoleId || r.code === selectedRoleId);

  const toggleCategoryExpand = (catKey: string) => {
    setExpandedCategories((prev) => ({ ...prev, [catKey]: !prev[catKey] }));
  };

  const handleTogglePrivilege = (code: string) => {
    setDraftPrivileges((prev) =>
      prev.includes(code) ? prev.filter((c) => c !== code) : [...prev, code]
    );
  };

  const handleToggleCategoryAll = (category: PrivilegeCategory) => {
    const catCodes = category.privileges.map((p) => p.code);
    const allSelected = catCodes.every((c) => draftPrivileges.includes(c));

    if (allSelected) {
      setDraftPrivileges((prev) => prev.filter((c) => !catCodes.includes(c)));
    } else {
      setDraftPrivileges((prev) => Array.from(new Set([...prev, ...catCodes])));
    }
  };

  const handleToggleReport = (code: string) => {
    setDraftReports((prev) =>
      prev.includes(code) ? prev.filter((c) => c !== code) : [...prev, code]
    );
  };

  const handleToggleColumn = (code: string) => {
    setDraftColumns((prev) =>
      prev.includes(code) ? prev.filter((c) => c !== code) : [...prev, code]
    );
  };

  const handleSaveRole = async () => {
    if (!selectedRole) return;
    setIsSaving(true);
    try {
      const token = localStorage.getItem('choplife_staff_token') || '';
      const authHeaders: Record<string, string> = {
        'Content-Type': 'application/json',
      };
      if (token) {
        authHeaders['Authorization'] = `Bearer ${token}`;
      }

      const res = await fetch(`/api/rbac/roles/${selectedRole.id}`, {
        method: 'PUT',
        headers: authHeaders,
        body: JSON.stringify({
          description: draftDescription,
          privileges: draftPrivileges,
          reports: draftReports,
          orderSummaryColumns: draftColumns,
        }),
      });

      if (res.ok) {
        showToast(`Permissions updated for ${selectedRole.name}.`);
        await loadData();
      } else {
        const err = await res.json();
        showToast(err.error || 'Failed to save role permissions.');
      }
    } catch {
      showToast('Error communicating with operations server.');
    } finally {
      setIsSaving(false);
    }
  };

  // Filtered categories and privileges based on search query
  const filteredCategories = categories
    .map((cat) => {
      const matchedPrivs = cat.privileges.filter(
        (p) =>
          p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.description.toLowerCase().includes(searchQuery.toLowerCase())
      );
      return {
        ...cat,
        privileges: matchedPrivs,
      };
    })
    .filter((cat) => cat.privileges.length > 0);

  return (
    <div className="bg-[#1C1210] border border-[#36221E] rounded-2xl overflow-hidden shadow-2xl flex flex-col h-[740px]">
      {/* Top Header */}
      <div className="p-4 bg-[#241311] border-b border-[#36221E] flex flex-wrap items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#800D15]/40 border border-[#800D15] flex items-center justify-center text-[#FFC700]">
            <Key className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-black text-[#FAF7F2]">Role & Permission Master</h2>
              <span className="bg-[#FFC700]/20 text-[#FFC700] border border-[#FFC700]/40 text-[10px] font-mono font-bold px-2 py-0.5 rounded-full">
                ChopLife Enterprise RBAC
              </span>
            </div>
            <p className="text-xs text-[#A89689]">
              Configure granular privilege matrices, operational reports, and order summary column visibility
            </p>
          </div>
        </div>

        {selectedRole && (
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                if (selectedRole) {
                  setDraftPrivileges([...(selectedRole.privileges || [])]);
                  setDraftReports([...(selectedRole.reports || [])]);
                  setDraftColumns([...(selectedRole.orderSummaryColumns || [])]);
                  setDraftDescription(selectedRole.description || '');
                  showToast('Draft changes reset.');
                }
              }}
              className="px-3 py-1.5 bg-[#241311] hover:bg-[#36221E] text-[#A89689] border border-[#36221E] rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all"
            >
              <RotateCcw className="w-3.5 h-3.5" /> Reset
            </button>
            <button
              onClick={handleSaveRole}
              disabled={isSaving}
              className="px-4 py-1.5 bg-[#FFC700] hover:bg-[#E6B200] text-[#4D080F] rounded-xl text-xs font-black uppercase flex items-center gap-1.5 shadow-md transition-all active:scale-95 disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              <span>{isSaving ? 'Saving...' : 'Save Role Permissions'}</span>
            </button>
          </div>
        )}
      </div>

      {/* Main Workspace Split */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Pane: Role Listing */}
        <div className="w-64 sm:w-72 border-r border-[#36221E] bg-[#160E0C] flex flex-col shrink-0">
          <div className="p-3 border-b border-[#36221E] flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-[#A89689] flex items-center gap-1.5">
              <Users className="w-3.5 h-3.5 text-[#FFC700]" /> User Roles ({roles.length})
            </span>
          </div>

          <div className="flex-1 overflow-y-auto divide-y divide-[#241311] p-1.5 space-y-1">
            {roles.map((r) => {
              const isSelected = r.id === selectedRoleId || r.code === selectedRoleId;
              return (
                <button
                  key={r.id}
                  onClick={() => setSelectedRoleId(r.id)}
                  className={`w-full p-2.5 rounded-xl text-left transition-all flex items-center justify-between group ${
                    isSelected
                      ? 'bg-[#800D15]/40 border border-[#FFC700]/50 shadow-md'
                      : 'hover:bg-[#241311] border border-transparent'
                  }`}
                >
                  <div className="min-w-0 pr-2">
                    <div className="flex items-center gap-1.5">
                      <p className={`text-xs font-black truncate ${isSelected ? 'text-[#FFC700]' : 'text-[#FAF7F2]'}`}>
                        {r.name}
                      </p>
                      {r.isSystem && (
                        <span className="text-[9px] bg-[#241311] text-[#A89689] px-1 rounded border border-[#36221E]">
                          System
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-[#A89689] truncate mt-0.5">{r.description}</p>
                  </div>
                  <span
                    className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold shrink-0 ${
                      isSelected ? 'bg-[#FFC700] text-[#4D080F]' : 'bg-[#241311] text-[#A89689]'
                    }`}
                  >
                    {r.userCount || 0}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Pane: Role Configuration Editor */}
        <div className="flex-1 flex flex-col bg-[#1C1210] overflow-hidden">
          {/* Role Header Banner & Tabs */}
          {selectedRole ? (
            <div className="p-4 border-b border-[#36221E] bg-[#241311] space-y-3 shrink-0">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h3 className="text-base font-black text-[#FAF7F2] flex items-center gap-2">
                    <span>{selectedRole.name}</span>
                    <span className="font-mono text-xs font-normal text-[#A89689]">({selectedRole.code})</span>
                  </h3>
                  <input
                    type="text"
                    value={draftDescription}
                    onChange={(e) => setDraftDescription(e.target.value)}
                    placeholder="Role operational purpose and responsibilities..."
                    className="mt-1 w-full sm:w-96 bg-[#160E0C] border border-[#36221E] rounded-lg px-2.5 py-1 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
                  />
                </div>

                {/* 3 Core RBAC Privilege Matrices */}
                <div className="flex bg-[#160E0C] p-1 rounded-xl border border-[#36221E]">
                  <button
                    onClick={() => setActiveTab('privileges')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
                      activeTab === 'privileges'
                        ? 'bg-[#FFC700] text-[#4D080F] shadow-xs'
                        : 'text-[#A89689] hover:text-[#FAF7F2]'
                    }`}
                  >
                    <Shield className="w-3.5 h-3.5" />
                    <span>Privilege</span>
                    <span className="font-mono text-[10px] ml-0.5 opacity-80">({draftPrivileges.length})</span>
                  </button>

                  <button
                    onClick={() => setActiveTab('reports')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
                      activeTab === 'reports'
                        ? 'bg-[#FFC700] text-[#4D080F] shadow-xs'
                        : 'text-[#A89689] hover:text-[#FAF7F2]'
                    }`}
                  >
                    <FileText className="w-3.5 h-3.5" />
                    <span>Reports</span>
                    <span className="font-mono text-[10px] ml-0.5 opacity-80">({draftReports.length})</span>
                  </button>

                  <button
                    onClick={() => setActiveTab('columns')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
                      activeTab === 'columns'
                        ? 'bg-[#FFC700] text-[#4D080F] shadow-xs'
                        : 'text-[#A89689] hover:text-[#FAF7F2]'
                    }`}
                  >
                    <Columns className="w-3.5 h-3.5" />
                    <span>Order Summary Columns</span>
                    <span className="font-mono text-[10px] ml-0.5 opacity-80">({draftColumns.length})</span>
                  </button>
                </div>
              </div>
            </div>
          ) : null}

          {/* Tab 1: Privilege Tree & Search */}
          {activeTab === 'privileges' && (
            <div className="flex-1 flex flex-col overflow-hidden p-4 space-y-3">
              {/* Search & Bulk Controls */}
              <div className="flex items-center justify-between gap-3 shrink-0">
                <div className="relative flex-1 max-w-md">
                  <Search className="w-4 h-4 absolute left-3 top-2.5 text-[#A89689]" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search privileges (e.g. discount, delivery, stock, settle)..."
                    className="w-full bg-[#160E0C] border border-[#36221E] rounded-xl pl-9 pr-3 py-2 text-xs text-[#FAF7F2] placeholder-[#736357] focus:outline-none focus:border-[#FFC700]"
                  />
                </div>

                <div className="flex items-center gap-2 text-xs">
                  <button
                    onClick={() => {
                      const all = categories.flatMap((c) => c.privileges.map((p) => p.code));
                      setDraftPrivileges(all);
                    }}
                    className="px-2.5 py-1 bg-[#241311] hover:bg-[#36221E] text-[#FFC700] rounded-lg border border-[#36221E] font-bold"
                  >
                    Grant All Privileges
                  </button>
                  <button
                    onClick={() => setDraftPrivileges([])}
                    className="px-2.5 py-1 bg-[#241311] hover:bg-[#36221E] text-rose-400 rounded-lg border border-[#36221E] font-bold"
                  >
                    Revoke All
                  </button>
                </div>
              </div>

              {/* Categorized Privileges List */}
              <div className="flex-1 overflow-y-auto space-y-3 pr-1">
                {filteredCategories.map((cat) => {
                  const isExpanded = expandedCategories[cat.key] !== false;
                  const catCodes = cat.privileges.map((p) => p.code);
                  const selectedCount = catCodes.filter((c) => draftPrivileges.includes(c)).length;
                  const isAll = selectedCount === catCodes.length && catCodes.length > 0;
                  const isSome = selectedCount > 0 && !isAll;

                  return (
                    <div
                      key={cat.key}
                      className="bg-[#160E0C] border border-[#36221E] rounded-2xl overflow-hidden shadow-xs"
                    >
                      {/* Category Header */}
                      <div className="p-3 bg-[#241311] border-b border-[#36221E] flex items-center justify-between">
                        <div
                          onClick={() => toggleCategoryExpand(cat.key)}
                          className="flex items-center gap-2 cursor-pointer select-none"
                        >
                          {isExpanded ? (
                            <ChevronDown className="w-4 h-4 text-[#FFC700]" />
                          ) : (
                            <ChevronRight className="w-4 h-4 text-[#A89689]" />
                          )}
                          <span className="font-black text-xs text-[#FAF7F2]">{cat.label}</span>
                          <span className="text-[10px] text-[#A89689] font-mono">
                            ({selectedCount}/{cat.privileges.length})
                          </span>
                        </div>

                        <button
                          onClick={() => handleToggleCategoryAll(cat)}
                          className="text-[11px] font-bold px-2 py-0.5 rounded bg-[#160E0C] hover:bg-[#2A1815] text-[#C5B4A5] border border-[#36221E] transition-all"
                        >
                          {isAll ? 'Deselect Category' : 'Select All'}
                        </button>
                      </div>

                      {/* Privileges in this category */}
                      {isExpanded && (
                        <div className="p-3 grid grid-cols-1 md:grid-cols-2 gap-2">
                          {cat.privileges.map((p) => {
                            const isChecked = draftPrivileges.includes(p.code);
                            return (
                              <div
                                key={p.id}
                                onClick={() => handleTogglePrivilege(p.code)}
                                className={`p-2.5 rounded-xl border cursor-pointer transition-all flex items-start gap-2.5 ${
                                  isChecked
                                    ? 'bg-[#800D15]/20 border-[#FFC700]/50 text-[#FAF7F2]'
                                    : 'bg-[#1C1210] border-[#36221E] text-[#A89689] hover:border-[#4D2924]'
                                }`}
                              >
                                <div
                                  className={`w-4 h-4 rounded mt-0.5 border flex items-center justify-center shrink-0 ${
                                    isChecked
                                      ? 'bg-[#FFC700] border-[#FFC700] text-[#4D080F]'
                                      : 'border-[#4D2924] bg-[#241311]'
                                  }`}
                                >
                                  {isChecked && <Check className="w-3 h-3 stroke-[3]" />}
                                </div>
                                <div className="min-w-0 flex-1">
                                  <div className="flex items-center justify-between gap-1">
                                    <p className={`text-xs font-bold leading-tight ${isChecked ? 'text-[#FAF7F2]' : 'text-[#C5B4A5]'}`}>
                                      {p.name}
                                    </p>
                                    <span className="text-[9px] font-mono opacity-60 shrink-0">{p.code}</span>
                                  </div>
                                  <p className="text-[10px] text-[#736357] leading-tight mt-0.5">{p.description}</p>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Tab 2: Reports Access */}
          {activeTab === 'reports' && (
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              <div className="p-3 bg-[#160E0C] border border-[#36221E] rounded-xl flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-[#FAF7F2]">Authoritative Operational & Tax Reports</h4>
                  <p className="text-[11px] text-[#A89689]">
                    Select which business reports staff in this role are permitted to view and export
                  </p>
                </div>
                <div className="flex gap-2 text-xs">
                  <button
                    onClick={() => setDraftReports(reportsList.map((r) => r.code))}
                    className="px-2.5 py-1 bg-[#241311] text-[#FFC700] rounded-lg border border-[#36221E] font-bold"
                  >
                    Select All
                  </button>
                  <button
                    onClick={() => setDraftReports([])}
                    className="px-2.5 py-1 bg-[#241311] text-rose-400 rounded-lg border border-[#36221E] font-bold"
                  >
                    Clear All
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {reportsList.map((rep) => {
                  const isChecked = draftReports.includes(rep.code);
                  return (
                    <div
                      key={rep.id}
                      onClick={() => handleToggleReport(rep.code)}
                      className={`p-3 rounded-2xl border cursor-pointer transition-all flex items-start gap-3 ${
                        isChecked
                          ? 'bg-[#800D15]/20 border-[#FFC700]/50 text-[#FAF7F2]'
                          : 'bg-[#160E0C] border-[#36221E] text-[#A89689] hover:border-[#4D2924]'
                      }`}
                    >
                      <div
                        className={`w-5 h-5 rounded-lg border flex items-center justify-center shrink-0 mt-0.5 ${
                          isChecked
                            ? 'bg-[#FFC700] border-[#FFC700] text-[#4D080F]'
                            : 'border-[#4D2924] bg-[#241311]'
                        }`}
                      >
                        {isChecked && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <p className={`text-xs font-bold ${isChecked ? 'text-[#FAF7F2]' : 'text-[#C5B4A5]'}`}>
                            {rep.name}
                          </p>
                          <span className="text-[9px] font-mono uppercase bg-[#241311] px-1.5 py-0.5 rounded text-[#A89689]">
                            {rep.category}
                          </span>
                        </div>
                        <p className="text-[11px] text-[#736357] mt-0.5">{rep.description}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Tab 3: Order Summary Columns */}
          {activeTab === 'columns' && (
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              <div className="p-3 bg-[#160E0C] border border-[#36221E] rounded-xl flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-[#FAF7F2]">Configurable Order Summary Fields</h4>
                  <p className="text-[11px] text-[#A89689]">
                    Enable or mask specific financial sub-fields displayed in order cards, check settlement, and receipts
                  </p>
                </div>
                <div className="flex gap-2 text-xs">
                  <button
                    onClick={() => setDraftColumns(columnsList.map((c) => c.code))}
                    className="px-2.5 py-1 bg-[#241311] text-[#FFC700] rounded-lg border border-[#36221E] font-bold"
                  >
                    Show All
                  </button>
                  <button
                    onClick={() => setDraftColumns(['subtotal', 'net_total'])}
                    className="px-2.5 py-1 bg-[#241311] text-rose-400 rounded-lg border border-[#36221E] font-bold"
                  >
                    Minimal
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {columnsList.map((col) => {
                  const isChecked = draftColumns.includes(col.code);
                  return (
                    <div
                      key={col.id}
                      onClick={() => handleToggleColumn(col.code)}
                      className={`p-3 rounded-2xl border cursor-pointer transition-all flex items-start gap-3 ${
                        isChecked
                          ? 'bg-[#800D15]/20 border-[#FFC700]/50 text-[#FAF7F2]'
                          : 'bg-[#160E0C] border-[#36221E] text-[#A89689] hover:border-[#4D2924]'
                      }`}
                    >
                      <div
                        className={`w-5 h-5 rounded-lg border flex items-center justify-center shrink-0 mt-0.5 ${
                          isChecked
                            ? 'bg-[#FFC700] border-[#FFC700] text-[#4D080F]'
                            : 'border-[#4D2924] bg-[#241311]'
                        }`}
                      >
                        {isChecked && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <p className={`text-xs font-bold ${isChecked ? 'text-[#FAF7F2]' : 'text-[#C5B4A5]'}`}>
                            {col.label}
                          </p>
                          <span className="text-[9px] font-mono text-[#A89689]">{col.code}</span>
                        </div>
                        <p className="text-[11px] text-[#736357] mt-0.5">{col.description}</p>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Order Summary Live Preview Card */}
              <div className="p-4 bg-[#160E0C] border border-[#36221E] rounded-2xl space-y-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#FFC700]">
                  Live UI Preview: Cashier Order Summary Breakdown
                </span>
                <div className="p-3 bg-[#241311] rounded-xl border border-[#36221E] max-w-sm space-y-1.5 text-xs font-mono">
                  {draftColumns.includes('subtotal') && (
                    <div className="flex justify-between text-[#A89689]">
                      <span>Subtotal (2 items)</span>
                      <span>₦12,500</span>
                    </div>
                  )}
                  {draftColumns.includes('packaging_fee') && (
                    <div className="flex justify-between text-[#A89689]">
                      <span>Packaging Clamshell</span>
                      <span>₦300</span>
                    </div>
                  )}
                  {draftColumns.includes('delivery_fee') && (
                    <div className="flex justify-between text-[#A89689]">
                      <span>Delivery Fee (GRA)</span>
                      <span>₦1,200</span>
                    </div>
                  )}
                  {draftColumns.includes('discount') && (
                    <div className="flex justify-between text-emerald-400">
                      <span>Discount (0%)</span>
                      <span>₦0</span>
                    </div>
                  )}
                  {draftColumns.includes('vat_tax') && (
                    <div className="flex justify-between text-[#A89689]">
                      <span>VAT (7.5%)</span>
                      <span>₦937</span>
                    </div>
                  )}
                  {draftColumns.includes('net_total') && (
                    <div className="flex justify-between pt-1 border-t border-[#36221E] font-bold text-sm text-[#FFC700]">
                      <span>NET AMOUNT</span>
                      <span>₦14,000</span>
                    </div>
                  )}
                  {draftColumns.includes('payment_method') && (
                    <div className="flex justify-between text-[10px] text-[#736357] pt-0.5">
                      <span>Payment Method</span>
                      <span>POS Terminal</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
