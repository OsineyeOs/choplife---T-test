import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { BranchId, Product, CartItem, StaffRole, StaffUser } from '../../types';
import {
  Store,
  LayoutGrid,
  ChefHat,
  Truck,
  Boxes,
  Clock,
  BarChart3,
  Users,
  ShieldCheck,
  Search,
  Plus,
  Minus,
  Trash2,
  Receipt,
  CreditCard,
  Banknote,
  Building,
  RotateCcw,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  LogOut,
  ExternalLink,
  Split,
  Tag,
  FileSpreadsheet,
  Lock,
  RefreshCw,
  Printer,
  Sliders,
  DollarSign,
  ArrowRight,
  Sparkles,
  Phone,
  Bell,
  MapPin,
  UtensilsCrossed,
  Filter,
  Eye,
  Calendar,
  AlertCircle,
  HelpCircle,
  Layers,
  ChevronRight,
  Download,
  Info,
  MoveRight,
  Award,
  Wallet,
  Scan,
  Menu,
  X,
  Globe,
} from 'lucide-react';
import { PasswordInput } from '../ui/PasswordInput';
import { MASTER_PRODUCTS, MENU_CATEGORIES } from '../../data/menu';
import { INVENTORY_LOCATIONS } from '../../data/inventoryMaster';
import { CustomerCareHub } from './CustomerCareHub';
import { LoyaltyAndHouseAccountsHub } from './LoyaltyAndHouseAccountsHub';
import { CashMovementModal, CloseShiftModal, ShiftZReportModal } from './ShiftManagementModals';
import { PosBillSplitModal, PosTableTransferModal } from './PosBillSplitModal';
import { CateringProductionPlanner } from '../catering/CateringProductionPlanner';
import { DispatchOperationsHub } from '../dispatch/DispatchOperationsHub';
import { MasterInventoryManager } from '../inventory/MasterInventoryManager';
import { NotificationHub } from '../notifications/NotificationHub';
import { ExecutiveBIDashboard } from '../analytics/ExecutiveBIDashboard';
import { HardwarePrinterModal } from '../pos/HardwarePrinterModal';
import { BarcodeDispatchScanner } from '../dispatch/BarcodeDispatchScanner';
import { OfflineSyncBar } from '../pos/OfflineSyncBar';
import { RolePermissionManager } from './RolePermissionManager';
import { EffectiveAccessModal } from './EffectiveAccessModal';
import { WebsiteCmsManager } from '../admin/WebsiteCmsManager';
import { MenuCatalogueManager } from '../admin/MenuCatalogueManager';
import { getCachedReceiptTemplate, dispatchCustomerReceipt } from '../../utils/hardwarePrinter';
import { resolveBranchDetails } from '../../utils/receiptRenderer';

export interface StaffOperationsWorkspaceProps {
  initialMode?: 'pos' | 'admin';
  onNavigateRoute?: (route: 'storefront' | 'pos' | 'admin') => void;
}

export const StaffOperationsWorkspace: React.FC<StaffOperationsWorkspaceProps> = ({
  initialMode,
  onNavigateRoute,
}) => {
  const {
    currentStaff,
    logoutStaff,
    branches,
    selectedBranchId,
    setSelectedBranchId,
    formatNaira,
    getProductPrice,
    isProductAvailable,
    setIsStorefrontPreviewActive,
    operationsActiveTab,
    setOperationsActiveTab,
  } = useApp();

  // Active Workspace Navigation Tab synchronized with AppContext
  const activeTab = operationsActiveTab;
  const setActiveTab = setOperationsActiveTab;

  // Three-Interface Architecture Taxonomy:
  // Interface B: POS & Frontline Operations (Cashier, Server, Kitchen, Rider, Dispatch)
  // Interface C: Restricted Operational Backend & Governance (Super Admin, Corporate Admin, Branch Manager, Accountant, Auditor)
  const isFrontlineRole = ['cashier', 'receptionist', 'customer_service', 'kitchen', 'kitchen_lead', 'rider', 'internal_rider', 'external_rider', 'dispatch_manager'].includes(currentStaff?.role || '');
  const canAccessBackend = ['super_admin', 'corporate_admin', 'admin', 'branch_manager', 'store_manager', 'storekeeper', 'accountant', 'auditor', 'content_editor', 'menu_manager'].includes(currentStaff?.role || '');

  // Default interface view based on staff role and initialMode
  const [interfaceView, setInterfaceView] = useState<'interface_b' | 'interface_c'>(() => {
    if (initialMode === 'admin' && canAccessBackend) return 'interface_c';
    if (initialMode === 'pos') return 'interface_b';
    return isFrontlineRole ? 'interface_b' : 'interface_c';
  });

  useEffect(() => {
    if (initialMode === 'admin' && canAccessBackend) {
      setInterfaceView('interface_c');
    } else if (initialMode === 'pos') {
      setInterfaceView('interface_b');
    }
  }, [initialMode, canAccessBackend]);

  // Operational Context
  const [activeBranchId, setActiveBranchId] = useState<BranchId>(
    (currentStaff?.branchId as string) === 'all' || !currentStaff?.branchId ? selectedBranchId : (currentStaff.branchId as BranchId)
  );

  // Time & Clock
  const [currentTime, setCurrentTime] = useState<string>('');
  useEffect(() => {
    const update = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString('en-GB', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          timeZone: 'Africa/Lagos',
        }) + ' WAT'
      );
    };
    update();
    const interval = setInterval(update, 1000);
    return () => clearInterval(interval);
  }, []);

  // -------------------------------------------------------------
  // SHARED STATE & DATA FETCHING
  // -------------------------------------------------------------
  const [tables, setTables] = useState<any[]>([]);
  const [checks, setChecks] = useState<any[]>([]);
  const [activeCheck, setActiveCheck] = useState<any | null>(null);
  const [kdsTickets, setKdsTickets] = useState<any[]>([]);
  const [currentShift, setCurrentShift] = useState<any | null>(null);
  const [shiftsHistory, setShiftsHistory] = useState<any[]>([]);
  const [deliveryTasks, setDeliveryTasks] = useState<any[]>([]);
  const [inventoryList, setInventoryList] = useState<any[]>([]);
  const [stockLedger, setStockLedger] = useState<any[]>([]);
  const [stockRequests, setStockRequests] = useState<any[]>([]);
  const [wastageLogs, setWastageLogs] = useState<any[]>([]);
  const [auditLogsList, setAuditLogsList] = useState<any[]>([]);
  const [staffAccountsList, setStaffAccountsList] = useState<any[]>([]);
  const [salesSummary, setSalesSummary] = useState<any | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  // Staff Account Management Modal State
  const [isStaffModalOpen, setIsStaffModalOpen] = useState<boolean>(false);
  const [editingStaffAccount, setEditingStaffAccount] = useState<any | null>(null);
  const [staffFormId, setStaffFormId] = useState<string>('');
  const [staffFormName, setStaffFormName] = useState<string>('');
  const [staffFormEmail, setStaffFormEmail] = useState<string>('');
  const [staffFormPhone, setStaffFormPhone] = useState<string>('');
  const [staffFormRole, setStaffFormRole] = useState<StaffRole>('cashier');
  const [staffFormBranch, setStaffFormBranch] = useState<BranchId>('gra');
  const [staffFormAllowedBranches, setStaffFormAllowedBranches] = useState<string[]>(['gra']);
  const [staffFormPassword, setStaffFormPassword] = useState<string>('');
  const [staffFormStatus, setStaffFormStatus] = useState<'active' | 'suspended' | 'deactivated'>('active');
  const [staffFormDob, setStaffFormDob] = useState<string>('');
  const [staffFormGuarantorName, setStaffFormGuarantorName] = useState<string>('');
  const [staffFormGuarantorPhone, setStaffFormGuarantorPhone] = useState<string>('');
  const [staffFormGuarantorRel, setStaffFormGuarantorRel] = useState<string>('');
  const [staffFormGuarantorAddress, setStaffFormGuarantorAddress] = useState<string>('');
  const [staffFormGuarantorWorkplace, setStaffFormGuarantorWorkplace] = useState<string>('');
  const [upcomingBirthdays, setUpcomingBirthdays] = useState<any[]>([]);

  // Hardware Printer & Barcode Scanner Modals
  const [isHardwarePrinterOpen, setIsHardwarePrinterOpen] = useState<boolean>(false);
  const [isBarcodeScannerOpen, setIsBarcodeScannerOpen] = useState<boolean>(false);
  const [isMobileNavOpen, setIsMobileNavOpen] = useState<boolean>(false);
  const [mobilePosView, setMobilePosView] = useState<'catalog' | 'check'>('catalog');

  // RBAC & Staff Sub-Tab State
  const [staffSubTab, setStaffSubTab] = useState<'directory' | 'roles'>('directory');
  const [isEffectiveAccessOpen, setIsEffectiveAccessOpen] = useState<boolean>(false);
  const [effectiveAccessStaffId, setEffectiveAccessStaffId] = useState<string | null>(null);
  const [resetCredentialsModal, setResetCredentialsModal] = useState<{
    id: string;
    name: string;
    staffId?: string;
    workEmail?: string;
    tempPass?: string;
    recoveryPin?: string;
    pinExpiresAt?: string;
  } | null>(null);
  const [adminNewPasswordInput, setAdminNewPasswordInput] = useState<string>('');
  const [isResetSubmitting, setIsResetSubmitting] = useState<boolean>(false);

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage(null), 4000);
  };

  const fetchUpcomingBirthdays = async () => {
    try {
      const res = await fetch('/api/staff/birthdays/upcoming?days=30', {
        headers: getAuthHeaders(),
      });
      if (res.ok) {
        const data = await res.json();
        setUpcomingBirthdays(data.upcoming || []);
      }
    } catch (err) {
      console.error('Failed to load upcoming birthdays:', err);
    }
  };

  // Staff account CRUD handlers
  const handleOpenNewStaffModal = () => {
    const isBranchMgr = currentStaff?.role === 'branch_manager';
    const defaultBranch = isBranchMgr ? ((currentStaff?.branchId as BranchId) || 'gra') : 'gra';
    setEditingStaffAccount(null);
    setStaffFormId(`STF-${Math.floor(1000 + Math.random() * 9000)}`);
    setStaffFormName('');
    setStaffFormEmail('');
    setStaffFormPhone('');
    setStaffFormRole('cashier');
    setStaffFormBranch(defaultBranch);
    setStaffFormAllowedBranches([defaultBranch]);
    setStaffFormPassword('Choplife@2026!');
    setStaffFormStatus('active');
    setStaffFormDob('');
    setStaffFormGuarantorName('');
    setStaffFormGuarantorPhone('');
    setStaffFormGuarantorRel('');
    setStaffFormGuarantorAddress('');
    setStaffFormGuarantorWorkplace('');
    setIsStaffModalOpen(true);
  };

  const handleEditStaffModal = (s: any) => {
    setEditingStaffAccount(s);
    setStaffFormId(s.staffId);
    setStaffFormName(s.name);
    setStaffFormEmail(s.workEmail);
    setStaffFormPhone(s.phone || '');
    setStaffFormRole(s.role);
    setStaffFormBranch(s.branchId);
    setStaffFormAllowedBranches(
      Array.isArray(s.allowedBranchIds) && s.allowedBranchIds.length > 0
        ? s.allowedBranchIds
        : [s.branchId]
    );
    setStaffFormPassword('');
    setStaffFormStatus(s.status || 'active');
    setStaffFormDob(s.dateOfBirth || '');
    setStaffFormGuarantorName(s.guarantorName || '');
    setStaffFormGuarantorPhone(s.guarantorPhone || '');
    setStaffFormGuarantorRel(s.guarantorRelationship || '');
    setStaffFormGuarantorAddress(s.guarantorAddress || '');
    setStaffFormGuarantorWorkplace(s.guarantorWorkplace || '');
    setIsStaffModalOpen(true);
  };

  const handleSaveStaffAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const allowedBranches = Array.from(
        new Set([staffFormBranch, ...staffFormAllowedBranches].filter(Boolean))
      );
      if (editingStaffAccount) {
        const res = await fetch(`/api/staff/accounts/${editingStaffAccount.id}`, {
          method: 'PUT',
          headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
          body: JSON.stringify({
            name: staffFormName,
            phone: staffFormPhone,
            role: staffFormRole,
            branchId: staffFormBranch,
            allowedBranchIds: allowedBranches,
            status: staffFormStatus,
            dateOfBirth: staffFormDob,
            guarantorName: staffFormGuarantorName,
            guarantorPhone: staffFormGuarantorPhone,
            guarantorRelationship: staffFormGuarantorRel,
            guarantorAddress: staffFormGuarantorAddress,
            guarantorWorkplace: staffFormGuarantorWorkplace,
          }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Failed to update staff account');
        showToast('Staff account updated successfully!', 'success');
      } else {
        const res = await fetch('/api/staff/accounts', {
          method: 'POST',
          headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
          body: JSON.stringify({
            staffId: staffFormId,
            name: staffFormName,
            workEmail: staffFormEmail,
            phone: staffFormPhone,
            role: staffFormRole,
            branchId: staffFormBranch,
            allowedBranchIds: allowedBranches,
            initialPassword: staffFormPassword,
            dateOfBirth: staffFormDob,
            guarantorName: staffFormGuarantorName,
            guarantorPhone: staffFormGuarantorPhone,
            guarantorRelationship: staffFormGuarantorRel,
            guarantorAddress: staffFormGuarantorAddress,
            guarantorWorkplace: staffFormGuarantorWorkplace,
          }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Failed to create staff account');
        showToast('New staff account created successfully!', 'success');
      }
      setIsStaffModalOpen(false);
      fetchStaffAccounts();
    } catch (err: any) {
      showToast(err.message || 'Staff operation failed', 'error');
    }
  };

  const handleResetStaffPassword = async (id: string, name: string) => {
    const targetAcc = staffAccountsList.find((s) => s.id === id);
    const suggestedPass = `ChopReset@${Math.floor(1000 + Math.random() * 9000)}`;
    setAdminNewPasswordInput(suggestedPass);
    setResetCredentialsModal({
      id,
      name,
      staffId: targetAcc?.staffId || id,
      workEmail: targetAcc?.workEmail || '',
    });
  };

  const handleSaveAdminPasswordReset = async () => {
    if (!resetCredentialsModal) return;
    setIsResetSubmitting(true);
    try {
      const res = await fetch(`/api/staff/accounts/${resetCredentialsModal.id}/reset-password`, {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({ temporaryPassword: adminNewPasswordInput }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Password reset failed');
      setResetCredentialsModal((prev) => (prev ? { ...prev, tempPass: adminNewPasswordInput } : null));
      showToast(`Password updated for ${resetCredentialsModal.name}. Active sessions invalidated.`, 'success');
      fetchStaffAccounts();
    } catch (err: any) {
      showToast(err.message || 'Password reset failed', 'error');
    } finally {
      setIsResetSubmitting(false);
    }
  };

  const handleGenerateStaffRecoveryPin = async () => {
    if (!resetCredentialsModal) return;
    setIsResetSubmitting(true);
    try {
      const res = await fetch(`/api/staff/accounts/${resetCredentialsModal.id}/generate-reset-pin`, {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to generate recovery PIN');
      setResetCredentialsModal((prev) =>
        prev ? { ...prev, recoveryPin: data.recoveryPin, pinExpiresAt: data.expiresAt } : null
      );
      showToast(`Single-use 15-minute recovery PIN generated for ${resetCredentialsModal.name}!`, 'success');
    } catch (err: any) {
      showToast(err.message || 'Recovery PIN generation failed', 'error');
    } finally {
      setIsResetSubmitting(false);
    }
  };

  const getAuthHeaders = (extra: Record<string, string> = {}) => {
    const token = localStorage.getItem('choplife_staff_token') || '';
    return {
      Authorization: `Bearer ${token}`,
      ...extra,
    };
  };

  // Fetch Tables & Checks
  const fetchTablesAndChecks = async () => {
    try {
      const headers = getAuthHeaders();
      const [resTables, resChecks, resShift] = await Promise.all([
        fetch(`/api/pos/tables?branchId=${activeBranchId}`, { headers }),
        fetch(`/api/pos/checks?branchId=${activeBranchId}`, { headers }),
        fetch(`/api/pos/shifts/current?branchId=${activeBranchId}`, { headers }),
      ]);
      if (resTables.ok) setTables(await resTables.json());
      if (resChecks.ok) {
        const loadedChecks = await resChecks.json();
        setChecks(loadedChecks);
        if (!activeCheck && loadedChecks.length > 0) {
          const openCheck = loadedChecks.find((c: any) => c.status === 'open' || c.status === 'sent_to_kitchen');
          if (openCheck) setActiveCheck(openCheck);
        }
      }
      if (resShift.ok) setCurrentShift(await resShift.json());
    } catch (err) {
      console.error('Failed to load POS tables/checks:', err);
    }
  };

  // Fetch KDS
  const fetchKds = async () => {
    try {
      const res = await fetch(`/api/pos/kds/tickets?branchId=${activeBranchId}&includeRecentBumped=true`, {
        headers: getAuthHeaders(),
      });
      if (res.ok) setKdsTickets(await res.json());
    } catch (err) {
      console.error('Failed to load KDS tickets:', err);
    }
  };

  // Fetch Dispatch
  const fetchDispatch = async () => {
    try {
      const res = await fetch(`/api/dispatch/tasks?branchId=${activeBranchId}`, {
        headers: getAuthHeaders(),
      });
      if (res.ok) setDeliveryTasks(await res.json());
    } catch (err) {
      console.error('Failed to load dispatch tasks:', err);
    }
  };

  // Fetch Inventory
  const fetchInventory = async () => {
    try {
      const headers = getAuthHeaders();
      const [resInv, resLedger, resReq, resWst] = await Promise.all([
        fetch('/api/inventory/items', { headers }),
        fetch('/api/inventory/ledger', { headers }),
        fetch('/api/inventory/requests', { headers }),
        fetch('/api/inventory/wastage', { headers }),
      ]);
      if (resInv.ok) setInventoryList(await resInv.json());
      if (resLedger.ok) setStockLedger(await resLedger.json());
      if (resReq.ok) setStockRequests(await resReq.json());
      if (resWst.ok) setWastageLogs(await resWst.json());
    } catch (err) {
      console.error('Failed to load inventory:', err);
    }
  };

  // Fetch Staff Accounts
  const fetchStaffAccounts = async () => {
    try {
      const res = await fetch('/api/staff/accounts', {
        headers: getAuthHeaders(),
      });
      if (res.ok) setStaffAccountsList(await res.json());
      fetchUpcomingBirthdays();
    } catch (err) {
      console.error('Failed to load staff accounts:', err);
    }
  };

  // Fetch Audit Logs
  const fetchAuditLogs = async () => {
    try {
      const res = await fetch(`/api/audit/logs?branchId=${activeBranchId}`, {
        headers: getAuthHeaders(),
      });
      if (res.ok) setAuditLogsList(await res.json());
    } catch (err) {
      console.error('Failed to load audit logs:', err);
    }
  };

  // Fetch Reports
  const fetchReports = async () => {
    try {
      const res = await fetch(`/api/reports/sales-summary?branchId=${activeBranchId}`, {
        headers: getAuthHeaders(),
      });
      if (res.ok) setSalesSummary(await res.json());
    } catch (err) {
      console.error('Failed to load sales summary:', err);
    }
  };

  // Trigger reload on tab or branch change
  useEffect(() => {
    fetchTablesAndChecks();
    if (activeTab === 'kds') fetchKds();
    if (activeTab === 'dispatch') fetchDispatch();
    if (activeTab === 'inventory') fetchInventory();
    if (activeTab === 'staff') fetchStaffAccounts();
    if (activeTab === 'audit') fetchAuditLogs();
    if (activeTab === 'reports') fetchReports();
  }, [activeBranchId, activeTab]);

  // Set default view by role
  useEffect(() => {
    if (currentStaff) {
      if (['kitchen_lead', 'kitchen', 'kitchen_supervisor', 'pastry_chef'].includes(currentStaff.role)) {
        setActiveTab('kds');
        setInterfaceView('interface_b');
      } else if (['dispatch_manager', 'rider', 'internal_rider', 'external_rider'].includes(currentStaff.role)) {
        setActiveTab('dispatch');
        setInterfaceView('interface_b');
      } else if (['cashier'].includes(currentStaff.role)) {
        setActiveTab('pos');
        setInterfaceView('interface_b');
      } else if (['customer_service', 'receptionist'].includes(currentStaff.role)) {
        setActiveTab('tables');
        setInterfaceView('interface_b');
      } else if (['content_editor'].includes(currentStaff.role)) {
        setActiveTab('cms');
        setInterfaceView('interface_c');
      } else if (['menu_manager'].includes(currentStaff.role)) {
        setActiveTab('menu_catalog');
        setInterfaceView('interface_c');
      } else if (['storekeeper', 'store_manager'].includes(currentStaff.role)) {
        setActiveTab('inventory');
        setInterfaceView('interface_c');
      } else if (['accountant'].includes(currentStaff.role)) {
        setActiveTab('reports');
        setInterfaceView('interface_c');
      } else if (['auditor'].includes(currentStaff.role)) {
        setActiveTab('audit');
        setInterfaceView('interface_c');
      } else if (['super_admin', 'corporate_admin', 'admin', 'branch_manager'].includes(currentStaff.role)) {
        setInterfaceView('interface_c');
      }
    }
  }, [currentStaff]);

  // -------------------------------------------------------------
  // POS SUB-MODULE STATE
  // -------------------------------------------------------------
  const [posCategory, setPosCategory] = useState<string>('all');
  const [posSearch, setPosSearch] = useState<string>('');
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState<boolean>(false);
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'pos_terminal' | 'bank_transfer' | 'split' | 'wallet' | 'house_account'>('cash');
  const [cashTendered, setCashTendered] = useState<string>('');
  const [posRrn, setPosRrn] = useState<string>('');
  const [transferRef, setTransferRef] = useState<string>('');
  const [splitCashAmount, setSplitCashAmount] = useState<string>('');
  const [splitPosAmount, setSplitPosAmount] = useState<string>('');

  // Loyalty & House Account Payment State
  const [posCustomers, setPosCustomers] = useState<any[]>([]);
  const [posHouseAccounts, setPosHouseAccounts] = useState<any[]>([]);
  const [selectedCustomerIdForPayment, setSelectedCustomerIdForPayment] = useState<string>('');
  const [walletPinForPayment, setWalletPinForPayment] = useState<string>('');
  const [selectedHouseAccountIdForPayment, setSelectedHouseAccountIdForPayment] = useState<string>('');
  const [authorizedSignerForPayment, setAuthorizedSignerForPayment] = useState<string>('');

  useEffect(() => {
    if (isPaymentModalOpen) {
      const headers = getAuthHeaders();
      // Load customers
      fetch('/api/customers', { headers })
        .then((r) => r.json())
        .then((d) => setPosCustomers(d.customers || []))
        .catch(console.error);

      // Load corporate house accounts
      fetch('/api/house-accounts', { headers })
        .then((r) => r.json())
        .then((d) => setPosHouseAccounts(d.accounts || []))
        .catch(console.error);
    }
  }, [isPaymentModalOpen]);

  const [isDiscountModalOpen, setIsDiscountModalOpen] = useState<boolean>(false);
  const [discountPercentInput, setDiscountPercentInput] = useState<number>(0);
  const [discountReasonInput, setDiscountReasonInput] = useState<string>('VIP Courtesy');
  const [isSplitBillModalOpen, setIsSplitBillModalOpen] = useState<boolean>(false);
  const [splitGuestCount, setSplitGuestCount] = useState<number>(2);
  const [isReceiptModalOpen, setIsReceiptModalOpen] = useState<boolean>(false);
  const [lastPaidCheck, setLastPaidCheck] = useState<any | null>(null);

  // Filtered Products for POS
  const filteredProducts = MASTER_PRODUCTS.filter((p) => {
    const matchesCat = posCategory === 'all' || p.category === posCategory;
    const matchesSearch =
      posSearch.trim() === '' ||
      p.name.toLowerCase().includes(posSearch.toLowerCase()) ||
      p.shortDescription.toLowerCase().includes(posSearch.toLowerCase());
    return matchesCat && matchesSearch;
  });

  // Open New Check Handler
  const handleOpenNewCheck = async (tableNum?: string, checkType: 'dine_in' | 'takeaway' | 'delivery' = 'dine_in') => {
    try {
      const res = await fetch('/api/pos/checks', {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          branchId: activeBranchId,
          tableNumber: tableNum || (checkType === 'dine_in' ? 'Table 01' : undefined),
          checkType,
          customerName: checkType === 'dine_in' ? (tableNum ? `Dine-In (${tableNum})` : 'Walk-in Table') : 'Takeaway Customer',
          guestCount: 1,
          items: [],
        }),
      });
      if (res.ok) {
        const data = await res.json();
        setActiveCheck(data.check);
        fetchTablesAndChecks();
        showToast(`Created new check #${data.check.checkNumber}`);
      }
    } catch (err) {
      showToast('Failed to open new check', 'error');
    }
  };

  // Add Item to Active Check
  const handleAddItemToCheck = async (product: Product) => {
    if (!activeCheck) {
      // Auto-create check if none open
      await handleOpenNewCheck();
      return;
    }

    const price = getProductPrice(product, activeBranchId);
    const existingIndex = activeCheck.items.findIndex((it: any) => it.productId === product.id && it.status === 'pending');

    let updatedItems = [...activeCheck.items];
    if (existingIndex >= 0) {
      const current = updatedItems[existingIndex];
      updatedItems[existingIndex] = {
        ...current,
        quantity: current.quantity + 1,
        totalPrice: (current.quantity + 1) * current.unitPrice,
      };
    } else {
      updatedItems.push({
        id: `item-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        productId: product.id,
        name: product.name,
        quantity: 1,
        unitPrice: price,
        totalPrice: price,
        status: 'pending',
      });
    }

    await saveCheckItems(updatedItems);
  };

  // Update Item Quantity
  const handleUpdateItemQty = async (itemId: string, delta: number) => {
    if (!activeCheck) return;
    let updatedItems = [...activeCheck.items];
    const idx = updatedItems.findIndex((it: any) => it.id === itemId);
    if (idx === -1) return;

    const newQty = updatedItems[idx].quantity + delta;
    if (newQty <= 0) {
      updatedItems.splice(idx, 1);
    } else {
      updatedItems[idx] = {
        ...updatedItems[idx],
        quantity: newQty,
        totalPrice: newQty * updatedItems[idx].unitPrice,
      };
    }

    await saveCheckItems(updatedItems);
  };

  // Save Check Items helper
  const saveCheckItems = async (items: any[]) => {
    if (!activeCheck) return;
    try {
      const res = await fetch('/api/pos/checks', {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          ...activeCheck,
          items,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        setActiveCheck(data.check);
        fetchTablesAndChecks();
      }
    } catch (err) {
      showToast('Failed to update check', 'error');
    }
  };

  // Send Active Check to Kitchen
  const handleSendToKitchen = async () => {
    if (!activeCheck) return;
    if (activeCheck.items.length === 0) {
      showToast('Cannot send empty check to kitchen', 'error');
      return;
    }
    try {
      const res = await fetch(`/api/pos/checks/${activeCheck.id}/send-to-kitchen`, {
        method: 'POST',
        headers: getAuthHeaders(),
      });
      if (res.ok) {
        const data = await res.json();
        setActiveCheck(data.check);
        fetchTablesAndChecks();
        showToast(`Sent check #${data.check.checkNumber} to Kitchen Display System!`);
      }
    } catch (err) {
      showToast('Error sending order to kitchen', 'error');
    }
  };

  // Pay and Complete Check
  const handleCompletePayment = async () => {
    if (!activeCheck) return;

    if (paymentMethod === 'wallet') {
      if (!selectedCustomerIdForPayment) {
        showToast('Please select a customer with an active digital wallet.', 'error');
        return;
      }
      const cust = posCustomers.find((c) => c.id === selectedCustomerIdForPayment);
      if (cust && cust.walletBalance < activeCheck.total) {
        showToast(
          `Insufficient wallet balance (₦${cust.walletBalance.toLocaleString()}). Required: ₦${activeCheck.total.toLocaleString()}`,
          'error'
        );
        return;
      }
      if (!walletPinForPayment) {
        showToast('Customer wallet PIN is required for settlement authorization.', 'error');
        return;
      }
    }

    if (paymentMethod === 'house_account') {
      if (!selectedHouseAccountIdForPayment) {
        showToast('Please select an authorized corporate house account.', 'error');
        return;
      }
      const acc = posHouseAccounts.find((a) => a.id === selectedHouseAccountIdForPayment);
      if (acc && acc.currentBalance + activeCheck.total > acc.creditLimit) {
        showToast(
          `Credit limit exceeded. Current: ₦${acc.currentBalance.toLocaleString()}, Limit: ₦${acc.creditLimit.toLocaleString()}`,
          'error'
        );
        return;
      }
    }

    try {
      const paymentDetails: any = {
        cashTendered: Number(cashTendered) || activeCheck.total,
        posRrn,
        transferRef,
        splitCashAmount: Number(splitCashAmount) || 0,
        splitPosAmount: Number(splitPosAmount) || 0,
        customerId: selectedCustomerIdForPayment || undefined,
        walletPin: walletPinForPayment || undefined,
        houseAccountId: selectedHouseAccountIdForPayment || undefined,
        authorizedSigner: authorizedSignerForPayment || undefined,
      };

      const res = await fetch(`/api/pos/checks/${activeCheck.id}/pay`, {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          paymentMethod,
          paymentDetails,
          shiftId: currentShift?.id,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setLastPaidCheck(data.check);
        setIsPaymentModalOpen(false);
        setIsReceiptModalOpen(true);
        setActiveCheck(null);
        setSelectedCustomerIdForPayment('');
        setSelectedHouseAccountIdForPayment('');
        setAuthorizedSignerForPayment('');
        fetchTablesAndChecks();
        showToast(
          `Check #${data.check.checkNumber} settled successfully via ${paymentMethod.replace('_', ' ').toUpperCase()}! (₦${data.check.total})`
        );
      } else {
        const errData = await res.json().catch(() => ({}));
        if (errData.requiresShift) {
          showToast('Active shift register required: Open a shift before accepting cash.', 'error');
          setIsPaymentModalOpen(false);
          setActiveTab('shifts');
        } else {
          showToast(errData.error || 'Failed to complete payment', 'error');
        }
      }
    } catch (err) {
      showToast('Failed to complete payment', 'error');
    }
  };

  // Apply Discount
  const handleApplyDiscount = async () => {
    if (!activeCheck) return;
    const discountAmt = Math.round((activeCheck.subtotal * discountPercentInput) / 100);
    try {
      const res = await fetch('/api/pos/checks', {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          ...activeCheck,
          discountPercent: discountPercentInput,
          discountAmount: discountAmt,
          discountReason: discountReasonInput,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        setActiveCheck(data.check);
        setIsDiscountModalOpen(false);
        showToast(`Applied ${discountPercentInput}% discount (₦${discountAmt})`);
      }
    } catch (err) {
      showToast('Failed to apply discount', 'error');
    }
  };

  // Dispatch Hub Operations: Remit Cash & Assign Rider
  const handleRemitCash = async (taskId: string) => {
    try {
      const res = await fetch(`/api/dispatch/tasks/${taskId}/remit-cash`, {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
      });
      const data = await res.json();
      if (res.ok) {
        showToast(data.message || 'COD payment remitted into branch till register.');
        fetchDispatch();
        fetchTablesAndChecks();
      } else {
        showToast(data.error || 'Failed to remit COD cash', 'error');
      }
    } catch (err) {
      showToast('Network error during COD remittance', 'error');
    }
  };

  const handleAssignRider = async (taskId: string, riderId: string) => {
    const rider = staffAccountsList.find((s) => s.id === riderId || s.staffId === riderId);
    try {
      const res = await fetch(`/api/dispatch/tasks/${taskId}/assign`, {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          riderId: rider?.id || riderId,
          riderName: rider?.name || 'Assigned Rider',
        }),
      });
      if (res.ok) {
        showToast(`Rider ${rider?.name || ''} assigned successfully!`);
        fetchDispatch();
      } else {
        const err = await res.json();
        showToast(err.error || 'Failed to assign rider', 'error');
      }
    } catch (err) {
      showToast('Failed to assign rider', 'error');
    }
  };

  // Inter-Branch Stock Indent Operations (DEFECT-P2-03)
  const handleDispatchStockRequest = async (requestId: string) => {
    try {
      const res = await fetch(`/api/inventory/requests/${requestId}/dispatch`, {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
      });
      if (res.ok) {
        showToast('Stock indent dispatched from source branch warehouse.');
        fetchInventory();
      } else {
        const err = await res.json();
        showToast(err.error || 'Failed to dispatch stock transfer', 'error');
      }
    } catch (err) {
      showToast('Failed to dispatch stock transfer', 'error');
    }
  };

  const handleReceiveStockRequest = async (requestId: string) => {
    try {
      const res = await fetch(`/api/inventory/requests/${requestId}/receive`, {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
      });
      if (res.ok) {
        showToast('Stock indent received and added to destination inventory.');
        fetchInventory();
      } else {
        const err = await res.json();
        showToast(err.error || 'Failed to receive stock transfer', 'error');
      }
    } catch (err) {
      showToast('Failed to receive stock transfer', 'error');
    }
  };

  // -------------------------------------------------------------
  // SHIFT MANAGEMENT SUB-MODULE STATE
  // -------------------------------------------------------------
  const [openingFloatInput, setOpeningFloatInput] = useState<string>('');
  const [isOpeningShiftModalOpen, setIsOpeningShiftModalOpen] = useState<boolean>(false);
  const [isCashMovementModalOpen, setIsCashMovementModalOpen] = useState<boolean>(false);
  const [cashMovementType, setCashMovementType] = useState<'safe_drop' | 'paid_out' | 'cash_refund' | 'adjustment'>('safe_drop');
  const [cashMovementAmount, setCashMovementAmount] = useState<string>('');
  const [cashMovementReason, setCashMovementReason] = useState<string>('');
  const [isClosingShiftModalOpen, setIsClosingShiftModalOpen] = useState<boolean>(false);
  const [countedCashInput, setCountedCashInput] = useState<string>('');
  const [closingNotesInput, setClosingNotesInput] = useState<string>('');
  const [isShiftZReportModalOpen, setIsShiftZReportModalOpen] = useState<boolean>(false);
  const [closedShiftReport, setClosedShiftReport] = useState<any | null>(null);

  // POS Extensions: Table Transfer
  const [isTableTransferModalOpen, setIsTableTransferModalOpen] = useState<boolean>(false);

  const handleOpenShift = async () => {
    if (!openingFloatInput || Number(openingFloatInput) < 0) {
      showToast('Please enter a valid opening float amount', 'error');
      return;
    }
    try {
      const res = await fetch('/api/pos/shifts/open', {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          branchId: activeBranchId,
          openingFloat: Number(openingFloatInput),
          registerId: 'POS-REG-01',
        }),
      });
      if (res.ok) {
        const data = await res.json();
        setCurrentShift(data.shift);
        setIsOpeningShiftModalOpen(false);
        showToast(`Shift ${data.shift.shiftNumber} opened with float ₦${data.shift.openingFloat}!`);
      } else {
        const err = await res.json();
        showToast(err.error || 'Failed to open shift', 'error');
      }
    } catch (err) {
      showToast('Error opening shift', 'error');
    }
  };

  const handleLogCashMovement = async () => {
    if (!currentShift || !cashMovementAmount || Number(cashMovementAmount) <= 0) {
      showToast('Please enter a valid cash amount', 'error');
      return;
    }
    try {
      const res = await fetch(`/api/pos/shifts/${currentShift.id}/cash-movement`, {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          movementType: cashMovementType,
          amount: Number(cashMovementAmount),
          reason: cashMovementReason || `${cashMovementType} record`,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        setCurrentShift(data.shift);
        setIsCashMovementModalOpen(false);
        setCashMovementAmount('');
        setCashMovementReason('');
        showToast(`Logged ${cashMovementType} of ₦${cashMovementAmount}!`);
      }
    } catch (err) {
      showToast('Failed to record cash movement', 'error');
    }
  };

  const handleCloseShift = async () => {
    if (!currentShift) return;
    try {
      const res = await fetch(`/api/pos/shifts/${currentShift.id}/close`, {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          countedCashInTill: Number(countedCashInput) || 0,
          notes: closingNotesInput,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        setClosedShiftReport(data.shift);
        setIsShiftZReportModalOpen(true);
        setCurrentShift(null);
        setIsClosingShiftModalOpen(false);
        showToast(`Shift ${data.shift.shiftNumber} closed! Z-Report Generated.`);
      }
    } catch (err) {
      showToast('Failed to close shift', 'error');
    }
  };

  // Handle Table Transfer
  const handleTransferTable = async (newTableId: string, newTableNumber: string) => {
    if (!activeCheck) return;
    try {
      const res = await fetch(`/api/pos/checks/${activeCheck.id}/transfer-table`, {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          newTableId,
          newTableNumber,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        setActiveCheck(data.check);
        setIsTableTransferModalOpen(false);
        fetchTablesAndChecks();
        showToast(`Check transferred to Table ${newTableNumber}!`);
      } else {
        const err = await res.json();
        showToast(err.error || 'Failed to transfer table', 'error');
      }
    } catch (err) {
      showToast('Error transferring table', 'error');
    }
  };

  // Handle Settle Split Bill
  const handleSettleSplitBill = async (splitPayload: any) => {
    if (!activeCheck) return;
    try {
      const res = await fetch(`/api/pos/checks/${activeCheck.id}/pay`, {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          paymentMethod: splitPayload.paymentMethod,
          paymentDetails: splitPayload.paymentDetails,
          activeShiftId: currentShift?.id,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setLastPaidCheck(data.check);
        setIsSplitBillModalOpen(false);
        setIsReceiptModalOpen(true);
        setActiveCheck(null);
        fetchTablesAndChecks();
        showToast(`Split bill settled for Check #${data.check.checkNumber}!`);
      } else {
        const err = await res.json();
        showToast(err.error || 'Split bill payment failed', 'error');
      }
    } catch (err) {
      showToast('Error settling split bill', 'error');
    }
  };

  // -------------------------------------------------------------
  // KDS TICKET ADVANCE, BUMP & RECALL
  // -------------------------------------------------------------
  const [kdsChannelFilter, setKdsChannelFilter] = useState<'all' | 'dine_in' | 'takeaway' | 'delivery'>('all');
  const [kdsShowBumped, setKdsShowBumped] = useState<boolean>(false);

  const handleAdvanceKdsItem = async (checkId: string, itemId: string, newStatus: string) => {
    try {
      await fetch(`/api/pos/kds/items/${checkId}/${itemId}/status`, {
        method: 'PUT',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({ status: newStatus }),
      });
      fetchKds();
    } catch (err) {
      console.error(err);
    }
  };

  const handleBumpKdsTicket = async (ticketId: string) => {
    try {
      const res = await fetch(`/api/pos/kds/tickets/${ticketId}/bump`, {
        method: 'POST',
        headers: getAuthHeaders(),
      });
      if (res.ok) {
        showToast('Ticket bumped & ready for pickup/delivery!', 'success');
        fetchKds();
      } else {
        showToast('Failed to bump ticket', 'error');
      }
    } catch {
      showToast('Network error bumping ticket', 'error');
    }
  };

  const handleRecallKdsTicket = async (ticketId: string) => {
    try {
      const res = await fetch(`/api/pos/kds/tickets/${ticketId}/recall`, {
        method: 'POST',
        headers: getAuthHeaders(),
      });
      if (res.ok) {
        showToast('Ticket recalled back to active preparation queue!', 'success');
        fetchKds();
      } else {
        showToast('Failed to recall ticket', 'error');
      }
    } catch {
      showToast('Network error recalling ticket', 'error');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#120B0A] text-[#FAF7F2] flex flex-col font-sans select-none overflow-hidden">
      {/* Toast Notification */}
      {toastMessage && (
        <div
          className={`fixed top-4 right-4 z-50 px-5 py-3 rounded-xl shadow-2xl font-medium text-sm flex items-center gap-3 transition-all animate-in slide-in-from-top-4 ${
            toastMessage.type === 'error' ? 'bg-[#991B1B] text-white' : 'bg-[#15803D] text-white'
          }`}
        >
          {toastMessage.type === 'error' ? <AlertCircle className="w-5 h-5" /> : <CheckCircle2 className="w-5 h-5" />}
          <span>{toastMessage.text}</span>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TOP PERSISTENT OPERATIONS BAR */}
      {/* ========================================================================= */}
      <header className="h-16 bg-[#1C1210] border-b border-[#36221E] px-4 flex items-center justify-between shrink-0 shadow-md">
        {/* Left: Brand & Hub Identity */}
        <div className="flex items-center gap-3 md:gap-4">
          {/* Mobile Navigation Toggle Button */}
          <button
            onClick={() => setIsMobileNavOpen(!isMobileNavOpen)}
            className="md:hidden p-2 rounded-xl bg-[#241311] border border-[#36221E] text-[#FFC700] hover:bg-[#36221E] active:scale-95 transition-all"
            aria-label="Toggle Navigation Menu"
          >
            {isMobileNavOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          </button>

          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#800D15] to-[#4D080F] border border-[#FFC700]/30 flex items-center justify-center font-black text-[#FFC700] text-lg shadow-inner">
              C
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-sm tracking-wider uppercase text-[#FAF7F2]">
                  Choplife Republic
                </span>
                <span className="px-2 py-0.5 rounded-md bg-[#FFC700]/15 text-[#FFC700] text-[10px] font-bold tracking-widest uppercase border border-[#FFC700]/30">
                  STAFF OPS
                </span>
              </div>
              <p className="text-[11px] text-[#A89689] flex items-center gap-1 font-mono">
                <Clock className="w-3 h-3 text-[#FFC700]" /> {currentTime}
              </p>
            </div>
          </div>

          <div className="h-8 w-px bg-[#36221E] hidden md:block" />

          {/* Branch Scoping Context */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-[#A89689] font-medium hidden sm:inline">Active Branch:</span>
            {currentStaff?.role === 'super_admin' || currentStaff?.role === 'corporate_admin' || currentStaff?.role === 'auditor' || currentStaff?.role === 'accountant' ? (
              <select
                value={activeBranchId}
                onChange={(e) => setActiveBranchId(e.target.value as BranchId)}
                className="bg-[#241311] border border-[#4D2924] text-[#FAF7F2] text-xs font-semibold rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-[#FFC700]"
              >
                <option value="gra">GRA Flagship (Okogo St)</option>
                <option value="okabere">Okabere Hub (Sapele Rd)</option>
                <option value="ugbowo">Ugbowo Hub (UNIBEN)</option>
              </select>
            ) : (
              <span className="px-2.5 py-1 bg-[#241311] border border-[#4D2924] text-xs font-bold text-[#FAF7F2] rounded-lg flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-[#FFC700]" />
                {activeBranchId === 'gra' ? 'GRA Flagship' : activeBranchId === 'okabere' ? 'Okabere Hub' : 'Ugbowo Campus Hub'}
              </span>
            )}
          </div>
        </div>

        {/* Right: Shift Status & Staff Identity */}
        <div className="flex items-center gap-3">
          {/* Shift Status Pill */}
          {currentShift ? (
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#15803D]/20 border border-[#15803D]/40 text-[#4ADE80] text-xs font-medium">
              <span className="w-2 h-2 rounded-full bg-[#22C55E] animate-pulse" />
              <span className="font-mono font-bold">{currentShift.shiftNumber}</span>
              <span className="text-[10px] opacity-80">(Float: ₦{currentShift.openingFloat.toLocaleString()})</span>
            </div>
          ) : (
            <button
              onClick={() => setIsOpeningShiftModalOpen(true)}
              className="px-3 py-1.5 rounded-lg bg-[#FFC700] hover:bg-[#E5B200] text-[#4D080F] text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm active:scale-95"
            >
              <Sparkles className="w-3.5 h-3.5" /> Open Shift
            </button>
          )}

          <div className="h-8 w-px bg-[#36221E]" />

          {/* Current Staff Badge */}
          <div className="flex items-center gap-2.5 bg-[#241311] border border-[#36221E] px-3 py-1.5 rounded-xl">
            <div className="w-7 h-7 rounded-lg bg-[#800D15] flex items-center justify-center text-xs font-bold text-[#FFC700]">
              {currentStaff?.name ? currentStaff.name.charAt(0) : 'S'}
            </div>
            <div className="text-left leading-tight hidden sm:block">
              <p className="text-xs font-bold text-[#FAF7F2] truncate max-w-[120px]">{currentStaff?.name || 'Staff User'}</p>
              <p className="text-[10px] text-[#A89689] uppercase tracking-wider font-semibold">{currentStaff?.role?.replace('_', ' ') || 'Cashier'}</p>
            </div>
          </div>

          {/* Hardware Printers Quick Trigger */}
          <button
            onClick={() => setIsHardwarePrinterOpen(true)}
            title="Hardware & Network Printers (TCP 9100 / ESC POS)"
            className="px-3 py-1.5 rounded-xl bg-[#241311] hover:bg-[#FFC700]/20 hover:border-[#FFC700]/50 text-[#C5B4A5] hover:text-[#FFC700] border border-[#36221E] text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs"
          >
            <Printer className="w-3.5 h-3.5 text-[#FFC700]" />
            <span className="hidden xl:inline">Printers</span>
          </button>

          {/* Barcode & QR Scanner Quick Trigger */}
          <button
            onClick={() => setIsBarcodeScannerOpen(true)}
            title="Hardware & Optical Barcode Scanner"
            className="px-3 py-1.5 rounded-xl bg-[#241311] hover:bg-[#FFC700]/20 hover:border-[#FFC700]/50 text-[#C5B4A5] hover:text-[#FFC700] border border-[#36221E] text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs"
          >
            <Scan className="w-3.5 h-3.5 text-[#FFC700]" />
            <span className="hidden xl:inline">Scanner</span>
          </button>

          {/* Direct Switcher between Front-Office POS and Back-Office Admin */}
          {interfaceView === 'interface_b' && canAccessBackend && (
            <button
              onClick={() => {
                if (onNavigateRoute) {
                  onNavigateRoute('admin');
                } else {
                  setInterfaceView('interface_c');
                  setActiveTab('reports');
                }
              }}
              title="Switch to Back-Office Administration"
              className="px-3 py-1.5 rounded-xl bg-[#FFC700] hover:bg-[#FFE066] text-[#4D080F] text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-[#4D080F]" />
              <span className="hidden sm:inline">Admin Portal &rarr;</span>
            </button>
          )}

          {interfaceView === 'interface_c' && (
            <button
              onClick={() => {
                if (onNavigateRoute) {
                  onNavigateRoute('pos');
                } else {
                  setInterfaceView('interface_b');
                  setActiveTab('pos');
                }
              }}
              title="Switch to Front-Office POS & Kitchen"
              className="px-3 py-1.5 rounded-xl bg-[#800D15] hover:bg-[#A3121B] text-[#FAF7F2] border border-[#FFC700]/30 text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs"
            >
              <Store className="w-3.5 h-3.5 text-[#FFC700]" />
              <span className="hidden sm:inline">POS Portal &rarr;</span>
            </button>
          )}

          {/* Customer Storefront View Switcher */}
          <button
            onClick={() => {
              if (onNavigateRoute) {
                onNavigateRoute('storefront');
              } else {
                setIsStorefrontPreviewActive(true);
              }
            }}
            title="Preview Customer Storefront"
            className="px-3 py-1.5 rounded-xl bg-[#241311] hover:bg-[#FFC700]/20 hover:border-[#FFC700]/50 text-[#C5B4A5] hover:text-[#FFC700] border border-[#36221E] text-xs font-bold flex items-center gap-1.5 transition-all"
          >
            <Eye className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Storefront</span>
          </button>

          {/* Secure Logout */}
          <button
            onClick={async () => {
              await logoutStaff();
              onNavigateRoute?.('storefront');
            }}
            title="Secure Staff Logout"
            className="p-2 rounded-xl bg-[#241311] hover:bg-[#991B1B]/30 hover:border-[#991B1B] text-[#A89689] hover:text-[#EF4444] border border-[#36221E] transition-all"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Offline Connectivity & Synchronizer Banner */}
      <OfflineSyncBar />

      {/* ========================================================================= */}
      {/* MAIN WORKSPACE BODY (SIDEBAR + MAIN CONTENT) */}
      {/* ========================================================================= */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Mobile Slide-out Drawer */}
        {isMobileNavOpen && (
          <div className="md:hidden fixed inset-0 z-50 flex">
            {/* Backdrop */}
            <div
              className="fixed inset-0 bg-black/70 backdrop-blur-xs"
              onClick={() => setIsMobileNavOpen(false)}
            />
            {/* Drawer Content */}
            <div className="relative w-72 max-w-[85vw] bg-[#160E0C] border-r border-[#36221E] h-full flex flex-col justify-between p-4 overflow-y-auto z-10">
              <div className="space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-[#36221E]">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-[#800D15] flex items-center justify-center font-bold text-[#FFC700] text-sm">
                      C
                    </div>
                    <span className="font-extrabold text-sm text-[#FAF7F2]">Staff Navigation</span>
                  </div>
                  <button
                    onClick={() => setIsMobileNavOpen(false)}
                    className="p-1.5 rounded-lg bg-[#241311] text-[#A89689] hover:text-[#FAF7F2]"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Interface Switcher for Manager / Admin Roles */}
                {canAccessBackend && (
                  <div className="flex bg-[#120B0A] p-1 rounded-xl border border-[#36221E] mb-2">
                    <button
                      onClick={() => {
                        setInterfaceView('interface_b');
                        if (['staff', 'audit', 'reports', 'inventory', 'cms', 'menu_catalog'].includes(activeTab)) {
                          setActiveTab('pos');
                        }
                      }}
                      className={`flex-1 py-1.5 px-2 text-[10px] font-black uppercase rounded-lg transition-all ${
                        interfaceView === 'interface_b'
                          ? 'bg-[#800D15] text-[#FAF7F2] shadow-sm border border-[#FFC700]/30'
                          : 'text-[#A89689] hover:text-[#FAF7F2]'
                      }`}
                    >
                      Front-Office
                    </button>
                    <button
                      onClick={() => {
                        setInterfaceView('interface_c');
                        if (['pos', 'tables', 'kds', 'dispatch'].includes(activeTab)) {
                          setActiveTab(currentStaff?.role === 'auditor' ? 'audit' : currentStaff?.role === 'accountant' ? 'reports' : currentStaff?.role === 'content_editor' ? 'cms' : currentStaff?.role === 'menu_manager' ? 'menu_catalog' : 'staff');
                        }
                      }}
                      className={`flex-1 py-1.5 px-2 text-[10px] font-black uppercase rounded-lg transition-all ${
                        interfaceView === 'interface_c'
                          ? 'bg-[#FFC700] text-[#4D080F] shadow-sm'
                          : 'text-[#A89689] hover:text-[#FAF7F2]'
                      }`}
                    >
                      Back-Office
                    </button>
                  </div>
                )}

                {isFrontlineRole && (
                  <div className="px-3 py-1.5 bg-[#800D15]/25 border border-[#800D15]/50 rounded-xl mb-2 text-[10px] font-bold text-[#FFC700] flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#22C55E]" />
                    <span>Front-Office Operations</span>
                  </div>
                )}

                <div className="space-y-1">
                  <div className="px-2 py-1 text-[10px] font-bold uppercase tracking-widest text-[#A89689]">
                    {interfaceView === 'interface_c' ? 'Back-Office Management' : 'Front-Office Operations'}
                  </div>

                  {interfaceView === 'interface_b' ? (
                    <>
                      <button
                        onClick={() => { setActiveTab('pos'); setIsMobileNavOpen(false); }}
                        className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl text-xs font-bold transition-all min-h-[44px] ${
                          activeTab === 'pos'
                            ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
                            : 'text-[#C5B4A5] hover:bg-[#241311] hover:text-[#FAF7F2]'
                        }`}
                      >
                        <Store className="w-4 h-4 text-[#FFC700]" />
                        <span>POS Register</span>
                      </button>

                      <button
                        onClick={() => { setActiveTab('tables'); setIsMobileNavOpen(false); }}
                        className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl text-xs font-bold transition-all min-h-[44px] ${
                          activeTab === 'tables'
                            ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
                            : 'text-[#C5B4A5] hover:bg-[#241311] hover:text-[#FAF7F2]'
                        }`}
                      >
                        <LayoutGrid className="w-4 h-4 text-[#FFC700]" />
                        <span>Dine-in Tables</span>
                      </button>

                      <button
                        onClick={() => { setActiveTab('kds'); setIsMobileNavOpen(false); }}
                        className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl text-xs font-bold transition-all min-h-[44px] ${
                          activeTab === 'kds'
                            ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
                            : 'text-[#C5B4A5] hover:bg-[#241311] hover:text-[#FAF7F2]'
                        }`}
                      >
                        <ChefHat className="w-4 h-4 text-[#FFC700]" />
                        <div className="flex-1 flex items-center justify-between">
                          <span>Kitchen Display</span>
                          {kdsTickets.length > 0 && (
                            <span className="px-2 py-0.5 bg-[#EF4444] text-white text-[10px] font-extrabold rounded-full">
                              {kdsTickets.length}
                            </span>
                          )}
                        </div>
                      </button>

                      <button
                        onClick={() => { setActiveTab('dispatch'); setIsMobileNavOpen(false); }}
                        className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl text-xs font-bold transition-all min-h-[44px] ${
                          activeTab === 'dispatch'
                            ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
                            : 'text-[#C5B4A5] hover:bg-[#241311] hover:text-[#FAF7F2]'
                        }`}
                      >
                        <Truck className="w-4 h-4 text-[#FFC700]" />
                        <span>Delivery Dispatch</span>
                      </button>

                      <button
                        onClick={() => { setActiveTab('shifts'); setIsMobileNavOpen(false); }}
                        className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl text-xs font-bold transition-all min-h-[44px] ${
                          activeTab === 'shifts'
                            ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
                            : 'text-[#C5B4A5] hover:bg-[#241311] hover:text-[#FAF7F2]'
                        }`}
                      >
                        <Clock className="w-4 h-4 text-[#FFC700]" />
                        <span>Cash Drawer & Shifts</span>
                      </button>

                      <button
                        onClick={() => { setActiveTab('catering'); setIsMobileNavOpen(false); }}
                        className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl text-xs font-bold transition-all min-h-[44px] ${
                          activeTab === 'catering'
                            ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
                            : 'text-[#C5B4A5] hover:bg-[#241311] hover:text-[#FAF7F2]'
                        }`}
                      >
                        <UtensilsCrossed className="w-4 h-4 text-[#FFC700]" />
                        <span>Catering Orders</span>
                      </button>

                      <button
                        onClick={() => { setActiveTab('customercare'); setIsMobileNavOpen(false); }}
                        className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl text-xs font-bold transition-all min-h-[44px] ${
                          activeTab === 'customercare'
                            ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
                            : 'text-[#C5B4A5] hover:bg-[#241311] hover:text-[#FAF7F2]'
                        }`}
                      >
                        <Phone className="w-4 h-4 text-[#FFC700]" />
                        <span>Customer Support</span>
                      </button>

                      <button
                        onClick={() => { setActiveTab('notifications'); setIsMobileNavOpen(false); }}
                        className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl text-xs font-bold transition-all min-h-[44px] ${
                          activeTab === 'notifications'
                            ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
                            : 'text-[#C5B4A5] hover:bg-[#241311] hover:text-[#FAF7F2]'
                        }`}
                      >
                        <Bell className="w-4 h-4 text-[#FFC700]" />
                        <span>Messages & Alerts</span>
                      </button>
                    </>
                  ) : (
                    <>
                      {['super_admin', 'corporate_admin', 'admin', 'branch_manager', 'auditor'].includes(currentStaff?.role || '') && (
                        <button
                          onClick={() => { setActiveTab('staff'); setIsMobileNavOpen(false); }}
                          className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl text-xs font-bold transition-all min-h-[44px] ${
                            activeTab === 'staff'
                              ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
                              : 'text-[#C5B4A5] hover:bg-[#241311] hover:text-[#FAF7F2]'
                          }`}
                        >
                          <Users className="w-4 h-4 text-[#FFC700]" />
                          <span>Staff Directory & RBAC</span>
                        </button>
                      )}

                      {['super_admin', 'corporate_admin', 'admin', 'branch_manager', 'menu_manager'].includes(currentStaff?.role || '') && (
                        <button
                          onClick={() => { setActiveTab('menu_catalog'); setIsMobileNavOpen(false); }}
                          className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl text-xs font-bold transition-all min-h-[44px] ${
                            activeTab === 'menu_catalog'
                              ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
                              : 'text-[#C5B4A5] hover:bg-[#241311] hover:text-[#FAF7F2]'
                          }`}
                        >
                          <UtensilsCrossed className="w-4 h-4 text-[#FFC700]" />
                          <span>Menu & Catalogue</span>
                        </button>
                      )}

                      {['super_admin', 'corporate_admin', 'admin', 'branch_manager', 'content_editor'].includes(currentStaff?.role || '') && (
                        <button
                          onClick={() => { setActiveTab('cms'); setIsMobileNavOpen(false); }}
                          className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl text-xs font-bold transition-all min-h-[44px] ${
                            activeTab === 'cms'
                              ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
                              : 'text-[#C5B4A5] hover:bg-[#241311] hover:text-[#FAF7F2]'
                          }`}
                        >
                          <Globe className="w-4 h-4 text-[#FFC700]" />
                          <span>Website Content (CMS)</span>
                        </button>
                      )}

                      {['super_admin', 'corporate_admin', 'admin', 'store_manager', 'branch_manager', 'accountant', 'auditor'].includes(currentStaff?.role || '') && (
                        <button
                          onClick={() => { setActiveTab('reports'); setIsMobileNavOpen(false); }}
                          className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl text-xs font-bold transition-all min-h-[44px] ${
                            activeTab === 'reports'
                              ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
                              : 'text-[#C5B4A5] hover:bg-[#241311] hover:text-[#FAF7F2]'
                          }`}
                        >
                          <BarChart3 className="w-4 h-4 text-[#FFC700]" />
                          <span>Executive Reports & BI</span>
                        </button>
                      )}

                      {['super_admin', 'corporate_admin', 'admin', 'store_manager', 'storekeeper', 'branch_manager', 'auditor', 'accountant'].includes(currentStaff?.role || '') && (
                        <button
                          onClick={() => { setActiveTab('inventory'); setIsMobileNavOpen(false); }}
                          className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl text-xs font-bold transition-all min-h-[44px] ${
                            activeTab === 'inventory'
                              ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
                            : 'text-[#C5B4A5] hover:bg-[#241311] hover:text-[#FAF7F2]'
                          }`}
                        >
                          <Boxes className="w-4 h-4 text-[#FFC700]" />
                          <span>Inventory & Purchasing</span>
                        </button>
                      )}

                      {['super_admin', 'corporate_admin', 'admin', 'auditor', 'accountant', 'branch_manager'].includes(currentStaff?.role || '') && (
                        <button
                          onClick={() => { setActiveTab('audit'); setIsMobileNavOpen(false); }}
                          className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl text-xs font-bold transition-all min-h-[44px] ${
                            activeTab === 'audit'
                              ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
                              : 'text-[#C5B4A5] hover:bg-[#241311] hover:text-[#FAF7F2]'
                          }`}
                        >
                          <ShieldCheck className="w-4 h-4 text-[#FFC700]" />
                          <span>Audit Logs</span>
                        </button>
                      )}

                      {['super_admin', 'corporate_admin', 'admin', 'branch_manager', 'accountant'].includes(currentStaff?.role || '') && (
                        <button
                          onClick={() => { setActiveTab('shifts'); setIsMobileNavOpen(false); }}
                          className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl text-xs font-bold transition-all min-h-[44px] ${
                            activeTab === 'shifts'
                              ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
                              : 'text-[#C5B4A5] hover:bg-[#241311] hover:text-[#FAF7F2]'
                          }`}
                        >
                          <Clock className="w-4 h-4 text-[#FFC700]" />
                          <span>Shift Reconciliations</span>
                        </button>
                      )}

                      {['super_admin', 'corporate_admin', 'admin', 'branch_manager', 'accountant'].includes(currentStaff?.role || '') && (
                        <button
                          onClick={() => { setActiveTab('loyalty_vip'); setIsMobileNavOpen(false); }}
                          className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl text-xs font-bold transition-all min-h-[44px] ${
                            activeTab === 'loyalty_vip'
                              ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
                              : 'text-[#C5B4A5] hover:bg-[#241311] hover:text-[#FAF7F2]'
                          }`}
                        >
                          <Award className="w-4 h-4 text-[#FFC700]" />
                          <span>Loyalty & House Accounts</span>
                        </button>
                      )}

                      <button
                        onClick={() => { setActiveTab('customercare'); setIsMobileNavOpen(false); }}
                        className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl text-xs font-bold transition-all min-h-[44px] ${
                          activeTab === 'customercare'
                            ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
                            : 'text-[#C5B4A5] hover:bg-[#241311] hover:text-[#FAF7F2]'
                        }`}
                      >
                        <Phone className="w-4 h-4 text-[#FFC700]" />
                        <span>Customer Support</span>
                      </button>

                      <button
                        onClick={() => { setActiveTab('notifications'); setIsMobileNavOpen(false); }}
                        className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl text-xs font-bold transition-all min-h-[44px] ${
                          activeTab === 'notifications'
                            ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
                            : 'text-[#C5B4A5] hover:bg-[#241311] hover:text-[#FAF7F2]'
                        }`}
                      >
                        <Bell className="w-4 h-4 text-[#FFC700]" />
                        <span>Messages & Alerts</span>
                      </button>

                      <button
                        onClick={() => { setActiveTab('catering'); setIsMobileNavOpen(false); }}
                        className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl text-xs font-bold transition-all min-h-[44px] ${
                          activeTab === 'catering'
                            ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
                            : 'text-[#C5B4A5] hover:bg-[#241311] hover:text-[#FAF7F2]'
                        }`}
                      >
                        <UtensilsCrossed className="w-4 h-4 text-[#FFC700]" />
                        <span>Catering Planner</span>
                      </button>
                    </>
                  )}
                </div>
              </div>

              <div className="pt-4 border-t border-[#36221E] space-y-2">
                <button
                  onClick={() => { setIsStorefrontPreviewActive(true); setIsMobileNavOpen(false); }}
                  className="w-full py-2.5 px-3 rounded-xl bg-[#241311] text-[#C5B4A5] hover:text-[#FFC700] text-xs font-bold flex items-center justify-center gap-2 border border-[#36221E]"
                >
                  <Eye className="w-4 h-4" /> Switch to Storefront
                </button>
                <button
                  onClick={() => logoutStaff()}
                  className="w-full py-2.5 px-3 rounded-xl bg-[#991B1B]/20 text-[#EF4444] text-xs font-bold flex items-center justify-center gap-2 border border-[#991B1B]/40"
                >
                  <LogOut className="w-4 h-4" /> Staff Logout
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Persistent Left Navigation (Desktop >= md) */}
        <aside className="hidden md:flex md:w-56 bg-[#160E0C] border-r border-[#36221E] flex-col justify-between shrink-0 p-3 overflow-y-auto">
          <div className="space-y-1">
            {/* Interface Switcher for Manager / Admin Roles */}
            {canAccessBackend && (
              <div className="flex bg-[#120B0A] p-1 rounded-xl border border-[#36221E] mb-2.5">
                <button
                  onClick={() => {
                    setInterfaceView('interface_b');
                    if (['staff', 'audit', 'reports', 'inventory', 'cms', 'menu_catalog'].includes(activeTab)) {
                      setActiveTab('pos');
                    }
                  }}
                  className={`flex-1 py-1 px-1.5 text-[10px] font-black uppercase rounded-lg transition-all ${
                    interfaceView === 'interface_b'
                      ? 'bg-[#800D15] text-[#FAF7F2] shadow-sm border border-[#FFC700]/30'
                      : 'text-[#A89689] hover:text-[#FAF7F2]'
                  }`}
                >
                  Front-Office
                </button>
                <button
                  onClick={() => {
                    setInterfaceView('interface_c');
                    if (['pos', 'tables', 'kds', 'dispatch'].includes(activeTab)) {
                      setActiveTab(currentStaff?.role === 'auditor' ? 'audit' : currentStaff?.role === 'accountant' ? 'reports' : currentStaff?.role === 'content_editor' ? 'cms' : currentStaff?.role === 'menu_manager' ? 'menu_catalog' : 'staff');
                    }
                  }}
                  className={`flex-1 py-1 px-1.5 text-[10px] font-black uppercase rounded-lg transition-all ${
                    interfaceView === 'interface_c'
                      ? 'bg-[#FFC700] text-[#4D080F] shadow-sm'
                      : 'text-[#A89689] hover:text-[#FAF7F2]'
                  }`}
                >
                  Back-Office
                </button>
              </div>
            )}

            {isFrontlineRole && (
              <div className="px-2.5 py-1.5 bg-[#800D15]/25 border border-[#800D15]/50 rounded-xl mb-2 text-[10px] font-bold text-[#FFC700] flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#22C55E]" />
                <span className="truncate">Front-Office Operations</span>
              </div>
            )}

            <div className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-widest text-[#A89689]">
              {interfaceView === 'interface_c' ? 'Back-Office Management' : 'Front-Office Operations'}
            </div>

            {interfaceView === 'interface_b' ? (
              <>
                <button
                  onClick={() => setActiveTab('pos')}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
                    activeTab === 'pos'
                      ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
                      : 'text-[#C5B4A5] hover:bg-[#241311] hover:text-[#FAF7F2]'
                  }`}
                >
                  <Store className="w-4 h-4 text-[#FFC700]" />
                  <span>POS Register</span>
                </button>

                <button
                  onClick={() => setActiveTab('tables')}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
                    activeTab === 'tables'
                      ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
                      : 'text-[#C5B4A5] hover:bg-[#241311] hover:text-[#FAF7F2]'
                  }`}
                >
                  <LayoutGrid className="w-4 h-4 text-[#FFC700]" />
                  <span>Dine-in Tables</span>
                </button>

                <button
                  onClick={() => setActiveTab('kds')}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
                    activeTab === 'kds'
                      ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
                      : 'text-[#C5B4A5] hover:bg-[#241311] hover:text-[#FAF7F2]'
                  }`}
                >
                  <ChefHat className="w-4 h-4 text-[#FFC700]" />
                  <div className="flex-1 flex items-center justify-between">
                    <span>Kitchen Display</span>
                    {kdsTickets.length > 0 && (
                      <span className="px-1.5 py-0.2 bg-[#EF4444] text-white text-[10px] font-extrabold rounded-full">
                        {kdsTickets.length}
                      </span>
                    )}
                  </div>
                </button>

                <button
                  onClick={() => setActiveTab('dispatch')}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
                    activeTab === 'dispatch'
                      ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
                      : 'text-[#C5B4A5] hover:bg-[#241311] hover:text-[#FAF7F2]'
                  }`}
                >
                  <Truck className="w-4 h-4 text-[#FFC700]" />
                  <span>Delivery Dispatch</span>
                </button>

                <button
                  onClick={() => setActiveTab('shifts')}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
                    activeTab === 'shifts'
                      ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
                      : 'text-[#C5B4A5] hover:bg-[#241311] hover:text-[#FAF7F2]'
                  }`}
                >
                  <Clock className="w-4 h-4 text-[#FFC700]" />
                  <span>Cash Drawer & Shifts</span>
                </button>

                <button
                  onClick={() => setActiveTab('catering')}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
                    activeTab === 'catering'
                      ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
                      : 'text-[#C5B4A5] hover:bg-[#241311] hover:text-[#FAF7F2]'
                  }`}
                >
                  <UtensilsCrossed className="w-4 h-4 text-[#FFC700]" />
                  <span>Catering Orders</span>
                </button>

                <button
                  onClick={() => setActiveTab('customercare')}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
                    activeTab === 'customercare'
                      ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
                      : 'text-[#C5B4A5] hover:bg-[#241311] hover:text-[#FAF7F2]'
                  }`}
                >
                  <Phone className="w-4 h-4 text-[#FFC700]" />
                  <span>Customer Support</span>
                </button>

                <button
                  onClick={() => setActiveTab('notifications')}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
                    activeTab === 'notifications'
                      ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
                      : 'text-[#C5B4A5] hover:bg-[#241311] hover:text-[#FAF7F2]'
                  }`}
                >
                  <Bell className="w-4 h-4 text-[#FFC700]" />
                  <span>Messages & Alerts</span>
                </button>
              </>
            ) : (
              <>
                {['super_admin', 'corporate_admin', 'admin', 'branch_manager', 'auditor'].includes(currentStaff?.role || '') && (
                  <button
                    onClick={() => setActiveTab('staff')}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
                      activeTab === 'staff'
                        ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
                        : 'text-[#C5B4A5] hover:bg-[#241311] hover:text-[#FAF7F2]'
                    }`}
                  >
                    <Users className="w-4 h-4 text-[#FFC700]" />
                    <span>Staff Directory & RBAC</span>
                  </button>
                )}

                {['super_admin', 'corporate_admin', 'admin', 'branch_manager', 'menu_manager'].includes(currentStaff?.role || '') && (
                  <button
                    onClick={() => setActiveTab('menu_catalog')}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
                      activeTab === 'menu_catalog'
                        ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
                        : 'text-[#C5B4A5] hover:bg-[#241311] hover:text-[#FAF7F2]'
                    }`}
                  >
                    <UtensilsCrossed className="w-4 h-4 text-[#FFC700]" />
                    <span>Menu & Catalogue</span>
                  </button>
                )}

                {['super_admin', 'corporate_admin', 'admin', 'branch_manager', 'content_editor'].includes(currentStaff?.role || '') && (
                  <button
                    onClick={() => setActiveTab('cms')}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
                      activeTab === 'cms'
                        ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
                        : 'text-[#C5B4A5] hover:bg-[#241311] hover:text-[#FAF7F2]'
                    }`}
                  >
                    <Globe className="w-4 h-4 text-[#FFC700]" />
                    <span>Website Content (CMS)</span>
                  </button>
                )}

                {['super_admin', 'corporate_admin', 'admin', 'store_manager', 'branch_manager', 'accountant', 'auditor'].includes(currentStaff?.role || '') && (
                  <button
                    onClick={() => setActiveTab('reports')}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
                      activeTab === 'reports'
                        ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
                        : 'text-[#C5B4A5] hover:bg-[#241311] hover:text-[#FAF7F2]'
                    }`}
                  >
                    <BarChart3 className="w-4 h-4 text-[#FFC700]" />
                    <span>Executive Reports & BI</span>
                  </button>
                )}

                {['super_admin', 'corporate_admin', 'admin', 'store_manager', 'storekeeper', 'branch_manager', 'auditor', 'accountant'].includes(currentStaff?.role || '') && (
                  <button
                    onClick={() => setActiveTab('inventory')}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
                      activeTab === 'inventory'
                        ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
                        : 'text-[#C5B4A5] hover:bg-[#241311] hover:text-[#FAF7F2]'
                    }`}
                  >
                    <Boxes className="w-4 h-4 text-[#FFC700]" />
                    <span>Inventory & Purchasing</span>
                  </button>
                )}

                {['super_admin', 'corporate_admin', 'admin', 'auditor', 'accountant', 'branch_manager'].includes(currentStaff?.role || '') && (
                  <button
                    onClick={() => setActiveTab('audit')}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
                      activeTab === 'audit'
                        ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
                        : 'text-[#C5B4A5] hover:bg-[#241311] hover:text-[#FAF7F2]'
                    }`}
                  >
                    <ShieldCheck className="w-4 h-4 text-[#FFC700]" />
                    <span>Audit Logs</span>
                  </button>
                )}

                {['super_admin', 'corporate_admin', 'admin', 'branch_manager', 'accountant'].includes(currentStaff?.role || '') && (
                  <button
                    onClick={() => setActiveTab('shifts')}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
                      activeTab === 'shifts'
                        ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
                        : 'text-[#C5B4A5] hover:bg-[#241311] hover:text-[#FAF7F2]'
                    }`}
                  >
                    <Clock className="w-4 h-4 text-[#FFC700]" />
                    <span>Shift Reconciliations</span>
                  </button>
                )}

                {['super_admin', 'corporate_admin', 'admin', 'branch_manager', 'accountant'].includes(currentStaff?.role || '') && (
                  <button
                    onClick={() => setActiveTab('loyalty_vip')}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
                      activeTab === 'loyalty_vip'
                        ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
                        : 'text-[#C5B4A5] hover:bg-[#241311] hover:text-[#FAF7F2]'
                    }`}
                  >
                    <Award className="w-4 h-4 text-[#FFC700]" />
                    <span>Loyalty & House Accounts</span>
                  </button>
                )}

                <button
                  onClick={() => setActiveTab('customercare')}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
                    activeTab === 'customercare'
                      ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
                      : 'text-[#C5B4A5] hover:bg-[#241311] hover:text-[#FAF7F2]'
                  }`}
                >
                  <Phone className="w-4 h-4 text-[#FFC700]" />
                  <span>Customer Support</span>
                </button>

                <button
                  onClick={() => setActiveTab('notifications')}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
                    activeTab === 'notifications'
                      ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
                      : 'text-[#C5B4A5] hover:bg-[#241311] hover:text-[#FAF7F2]'
                  }`}
                >
                  <Bell className="w-4 h-4 text-[#FFC700]" />
                  <span>Messages & Alerts</span>
                </button>

                <button
                  onClick={() => setActiveTab('catering')}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
                    activeTab === 'catering'
                      ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
                      : 'text-[#C5B4A5] hover:bg-[#241311] hover:text-[#FAF7F2]'
                  }`}
                >
                  <UtensilsCrossed className="w-4 h-4 text-[#FFC700]" />
                  <span>Catering Planner</span>
                </button>
              </>
            )}
          </div>

          {/* Quick Shortcuts */}
          <div className="bg-[#241311] border border-[#36221E] p-2.5 rounded-xl text-[11px] text-[#A89689] space-y-1.5 mt-4">
            <p className="font-bold text-[#FAF7F2]">Active Checks: {checks.filter((c) => c.status === 'open' || c.status === 'sent_to_kitchen').length}</p>
            <p className="text-[10px]">Database: <span className="text-[#22C55E] font-mono">PERSISTED (WAL)</span></p>
          </div>
        </aside>

        {/* Main Operational Stage */}
        <main className="flex-1 bg-[#1A100E] flex flex-col overflow-hidden relative">
          {/* =================================================================== */}
          {/* 1. POS & ACTIVE CHECKS VIEW */}
          {/* =================================================================== */}
          {activeTab === 'pos' && (
            <div className="flex-1 flex flex-col md:flex-row overflow-hidden relative">
              {/* Mobile View Toggle Bar (Only visible on mobile screens) */}
              <div className="md:hidden flex items-center justify-between p-2 bg-[#1C1210] border-b border-[#36221E] shrink-0">
                <div className="flex items-center gap-1.5 bg-[#241311] p-1 rounded-xl w-full">
                  <button
                    onClick={() => setMobilePosView('catalog')}
                    className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                      mobilePosView === 'catalog'
                        ? 'bg-[#FFC700] text-[#4D080F] shadow-sm'
                        : 'text-[#A89689] hover:text-[#FAF7F2]'
                    }`}
                  >
                    <span>🍽️ Catalog</span>
                    <span className="text-[10px] opacity-75">({filteredProducts.length})</span>
                  </button>
                  <button
                    onClick={() => setMobilePosView('check')}
                    className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                      mobilePosView === 'check'
                        ? 'bg-[#FFC700] text-[#4D080F] shadow-sm'
                        : 'text-[#A89689] hover:text-[#FAF7F2]'
                    }`}
                  >
                    <span>🧾 Current Check</span>
                    {activeCheck && (
                      <span className="px-1.5 py-0.2 bg-[#800D15] text-[#FFC700] rounded text-[10px] font-black">
                        {activeCheck.items.reduce((s: number, i: any) => s + (i.quantity || 1), 0)}
                      </span>
                    )}
                  </button>
                </div>
              </div>

              {/* Product Catalog & Category Filter */}
              <div className={`flex-1 flex flex-col overflow-hidden border-r border-[#36221E] ${
                mobilePosView === 'check' ? 'hidden md:flex' : 'flex'
              }`}>
                {/* Search & Categories Bar */}
                <div className="p-3 bg-[#1C1210] border-b border-[#36221E] space-y-2">
                  <div className="flex items-center gap-2">
                    <div className="relative flex-1">
                      <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#A89689]" />
                      <input
                        type="text"
                        placeholder="Search menu items, combos, bread, small chops..."
                        value={posSearch}
                        onChange={(e) => setPosSearch(e.target.value)}
                        className="w-full bg-[#241311] border border-[#4D2924] rounded-xl pl-9 pr-3 py-2 text-xs text-[#FAF7F2] placeholder-[#A89689] focus:outline-none focus:border-[#FFC700]"
                      />
                    </div>
                    <button
                      onClick={() => handleOpenNewCheck('Table ' + String(tables.filter((t) => t.status === 'available')[0]?.tableNumber || '01'))}
                      className="px-3 py-2 bg-[#800D15] hover:bg-[#600A10] text-[#FAF7F2] text-xs font-bold rounded-xl flex items-center gap-1.5 shrink-0 border border-[#FFC700]/30 transition-all shadow-sm"
                    >
                      <Plus className="w-4 h-4 text-[#FFC700]" /> New Check
                    </button>
                  </div>

                  {/* Category Pills */}
                  <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
                    <button
                      onClick={() => setPosCategory('all')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-all ${
                        posCategory === 'all'
                          ? 'bg-[#FFC700] text-[#4D080F]'
                          : 'bg-[#241311] text-[#C5B4A5] hover:bg-[#36221E] hover:text-[#FAF7F2]'
                      }`}
                    >
                      All Items
                    </button>
                    {MENU_CATEGORIES.map((cat) => (
                      <button
                        key={cat.id}
                        onClick={() => setPosCategory(cat.id)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                          posCategory === cat.id
                            ? 'bg-[#FFC700] text-[#4D080F]'
                            : 'bg-[#241311] text-[#C5B4A5] hover:bg-[#36221E] hover:text-[#FAF7F2]'
                        }`}
                      >
                        <span>{cat.icon}</span>
                        <span>{cat.name}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Product Grid */}
                <div className="flex-1 overflow-y-auto p-3 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2.5">
                  {filteredProducts.map((p) => {
                    const price = getProductPrice(p, activeBranchId);
                    const isAvailable = isProductAvailable(p.id, activeBranchId);
                    return (
                      <button
                        key={p.id}
                        onClick={() => isAvailable && handleAddItemToCheck(p)}
                        disabled={!isAvailable}
                        className={`p-2.5 rounded-xl border text-left flex flex-col justify-between transition-all group ${
                          isAvailable
                            ? 'bg-[#241311] border-[#36221E] hover:border-[#FFC700] hover:bg-[#301B17] cursor-pointer'
                            : 'bg-[#1C1210] border-[#2A1815] opacity-50 cursor-not-allowed'
                        }`}
                      >
                        <div className="space-y-1 w-full">
                          <div className="flex items-start justify-between gap-1">
                            <span className="font-bold text-xs text-[#FAF7F2] line-clamp-2 leading-tight group-hover:text-[#FFC700]">
                              {p.name}
                            </span>
                          </div>
                          <p className="text-[10px] text-[#A89689] line-clamp-1">{p.shortDescription}</p>
                        </div>

                        <div className="pt-2 mt-2 border-t border-[#36221E] flex items-center justify-between w-full">
                          <span className="font-mono font-extrabold text-xs text-[#FFC700]">
                            ₦{price.toLocaleString()}
                          </span>
                          {isAvailable ? (
                            <span className="w-5 h-5 rounded-md bg-[#800D15] text-[#FFC700] flex items-center justify-center text-xs font-black group-hover:scale-110 transition-transform">
                              +
                            </span>
                          ) : (
                            <span className="text-[9px] text-[#EF4444] font-bold uppercase">Sold Out</span>
                          )}
                        </div>
                      </button>
                    );
                  })}
                </div>

                {/* Mobile Floating Check Bar */}
                {activeCheck && activeCheck.items.length > 0 && (
                  <div className="md:hidden p-2.5 bg-[#1C1210] border-t border-[#36221E] shrink-0">
                    <button
                      onClick={() => setMobilePosView('check')}
                      className="w-full py-2.5 px-4 bg-[#FFC700] hover:bg-[#E6B400] text-[#4D080F] font-bold rounded-xl flex items-center justify-between shadow-lg active:scale-95 transition-all"
                    >
                      <div className="flex items-center gap-2">
                        <span className="bg-[#4D080F] text-[#FFC700] text-xs font-black px-2 py-0.5 rounded-full">
                          {activeCheck.items.reduce((s: number, i: any) => s + (i.quantity || 1), 0)}
                        </span>
                        <span className="text-xs">View Active Check</span>
                      </div>
                      <span className="font-mono font-extrabold text-sm">₦{activeCheck.total.toLocaleString()} →</span>
                    </button>
                  </div>
                )}
              </div>

              {/* Active Check Pane */}
              <div className={`w-full md:w-80 lg:w-96 bg-[#180F0D] flex flex-col shrink-0 ${
                mobilePosView === 'catalog' ? 'hidden md:flex' : 'flex'
              }`}>
                {/* Active Check Header */}
                <div className="p-3 bg-[#1C1210] border-b border-[#36221E] flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setMobilePosView('catalog')}
                      className="md:hidden px-2 py-1 bg-[#241311] text-[#FFC700] hover:bg-[#36221E] rounded-lg text-xs font-bold border border-[#4D2924] transition-colors"
                      title="Back to Catalog"
                    >
                      ← Menu
                    </button>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-[#FAF7F2]">
                          {activeCheck ? activeCheck.checkNumber : 'No Active Check'}
                        </span>
                        {activeCheck && (
                          <span
                            className={`px-1.5 py-0.5 rounded text-[10px] font-bold uppercase ${
                              activeCheck.status === 'open'
                                ? 'bg-[#EAB308]/20 text-[#EAB308]'
                                : activeCheck.status === 'sent_to_kitchen'
                                ? 'bg-[#3B82F6]/20 text-[#60A5FA]'
                                : 'bg-[#22C55E]/20 text-[#22C55E]'
                            }`}
                          >
                            {activeCheck.status.replace('_', ' ')}
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-[#A89689]">
                        {activeCheck?.tableNumber || 'Direct Takeaway'} • Guest: {activeCheck?.guestCount || 1}
                      </p>
                    </div>
                  </div>

                  {/* Open Checks Switcher Dropdown */}
                  <select
                    value={activeCheck?.id || ''}
                    onChange={(e) => {
                      const found = checks.find((c) => c.id === e.target.value);
                      if (found) setActiveCheck(found);
                    }}
                    className="bg-[#241311] border border-[#4D2924] text-xs text-[#FAF7F2] rounded-lg px-2 py-1 max-w-[130px] truncate"
                  >
                    <option value="">Switch Check</option>
                    {checks
                      .filter((c) => c.status === 'open' || c.status === 'sent_to_kitchen')
                      .map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.checkNumber} ({c.tableNumber || c.checkType})
                        </option>
                      ))}
                  </select>
                </div>

                {/* Items in Current Check */}
                <div className="flex-1 overflow-y-auto p-3 space-y-2">
                  {activeCheck && activeCheck.items.length > 0 ? (
                    activeCheck.items.map((it: any) => (
                      <div
                        key={it.id}
                        className="bg-[#241311] border border-[#36221E] p-2.5 rounded-xl flex items-center justify-between gap-2"
                      >
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-bold text-[#FAF7F2] truncate">{it.name}</p>
                          <p className="text-[10px] text-[#A89689] font-mono">
                            ₦{it.unitPrice.toLocaleString()} × {it.quantity} = ₦{it.totalPrice.toLocaleString()}
                          </p>
                          {it.status === 'sent_to_kitchen' && (
                            <span className="inline-block mt-0.5 text-[9px] px-1.5 py-0.2 rounded bg-[#3B82F6]/20 text-[#60A5FA] font-medium">
                              In Kitchen
                            </span>
                          )}
                        </div>

                        {/* Quantity Adjusters */}
                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            onClick={() => handleUpdateItemQty(it.id, -1)}
                            className="w-6 h-6 rounded-lg bg-[#36221E] hover:bg-[#800D15] text-[#FAF7F2] flex items-center justify-center text-xs"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="font-mono font-bold text-xs w-4 text-center">{it.quantity}</span>
                          <button
                            onClick={() => handleUpdateItemQty(it.id, 1)}
                            className="w-6 h-6 rounded-lg bg-[#36221E] hover:bg-[#800D15] text-[#FAF7F2] flex items-center justify-center text-xs"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="h-full flex flex-col items-center justify-center text-[#A89689] p-4 text-center">
                      <Receipt className="w-10 h-10 text-[#4D2924] mb-2" />
                      <p className="text-xs font-semibold">Check is currently empty</p>
                      <p className="text-[11px] text-[#7A695C]">Tap items on the left menu to add</p>
                    </div>
                  )}
                </div>

                {/* Check Summary & Operations Footer */}
                {activeCheck && (
                  <div className="p-3 bg-[#1C1210] border-t border-[#36221E] space-y-2.5">
                    {/* Financial Summary */}
                    <div className="space-y-1 text-xs text-[#C5B4A5]">
                      <div className="flex justify-between">
                        <span>Subtotal</span>
                        <span className="font-mono">₦{activeCheck.subtotal.toLocaleString()}</span>
                      </div>
                      {activeCheck.discountAmount > 0 && (
                        <div className="flex justify-between text-[#22C55E]">
                          <span>Discount ({activeCheck.discountPercent}%)</span>
                          <span className="font-mono">-₦{activeCheck.discountAmount.toLocaleString()}</span>
                        </div>
                      )}
                      <div className="flex justify-between font-bold text-sm text-[#FAF7F2] pt-1 border-t border-[#36221E]">
                        <span>Total Due</span>
                        <span className="font-mono text-[#FFC700]">₦{activeCheck.total.toLocaleString()}</span>
                      </div>
                    </div>

                    {/* Operational Action Buttons */}
                    <div className="grid grid-cols-4 gap-1.5">
                      <button
                        onClick={() => setIsDiscountModalOpen(true)}
                        className="px-2 py-1.5 bg-[#241311] hover:bg-[#36221E] text-[11px] font-semibold text-[#FAF7F2] rounded-lg border border-[#4D2924] flex items-center justify-center gap-1"
                        title="Apply Discount"
                      >
                        <Tag className="w-3 h-3 text-[#FFC700]" /> Disc.
                      </button>

                      <button
                        onClick={() => setIsSplitBillModalOpen(true)}
                        disabled={activeCheck.items.length === 0}
                        className="px-2 py-1.5 bg-[#241311] hover:bg-[#36221E] disabled:opacity-40 text-[11px] font-semibold text-[#FAF7F2] rounded-lg border border-[#4D2924] flex items-center justify-center gap-1"
                        title="Split Check between guests"
                      >
                        <Split className="w-3 h-3 text-[#FFC700]" /> Split
                      </button>

                      <button
                        onClick={() => setIsTableTransferModalOpen(true)}
                        disabled={!activeCheck.tableId}
                        className="px-2 py-1.5 bg-[#241311] hover:bg-[#36221E] disabled:opacity-40 text-[11px] font-semibold text-[#FAF7F2] rounded-lg border border-[#4D2924] flex items-center justify-center gap-1"
                        title="Transfer Check to Another Table"
                      >
                        <MoveRight className="w-3 h-3 text-[#FFC700]" /> Table
                      </button>

                      <button
                        onClick={handleSendToKitchen}
                        className="px-2 py-1.5 bg-[#1E3A8A] hover:bg-[#1D4ED8] text-[11px] font-bold text-white rounded-lg flex items-center justify-center gap-1 shadow-sm"
                        title="Send un-fired items to KDS"
                      >
                        <ChefHat className="w-3 h-3 text-[#FFC700]" /> KDS
                      </button>
                    </div>

                    {/* Settle Bill / Payment CTA */}
                    <button
                      onClick={() => setIsPaymentModalOpen(true)}
                      disabled={activeCheck.items.length === 0}
                      className="w-full py-2.5 bg-[#22C55E] hover:bg-[#16A34A] disabled:opacity-50 text-[#120B0A] text-sm font-black rounded-xl flex items-center justify-center gap-2 transition-all shadow-md active:scale-95"
                    >
                      <CreditCard className="w-4 h-4" />
                      <span>Settle & Pay (₦{activeCheck.total.toLocaleString()})</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* =================================================================== */}
          {/* 2. FLOOR & TABLES VIEW */}
          {/* =================================================================== */}
          {activeTab === 'tables' && (
            <div className="flex-1 p-4 overflow-y-auto space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-black text-[#FAF7F2]">Restaurant Floor & Table Map</h2>
                  <p className="text-xs text-[#A89689]">
                    Real-time status for {activeBranchId === 'gra' ? 'GRA Flagship' : activeBranchId === 'okabere' ? 'Okabere Hub' : 'Ugbowo Campus'}
                  </p>
                </div>

                {/* Table Status Legend */}
                <div className="flex items-center gap-3 text-xs">
                  <span className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#22C55E]" /> Available
                  </span>
                  <span className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#EAB308]" /> Seated / Ordering
                  </span>
                  <span className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#3B82F6]" /> In Kitchen
                  </span>
                  <span className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#A855F7]" /> Bill Requested
                  </span>
                </div>
              </div>

              {/* Floor Plan Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
                {tables.map((t) => (
                  <div
                    key={t.id}
                    onClick={() => {
                      if (t.currentCheckId) {
                        const chk = checks.find((c) => c.id === t.currentCheckId);
                        if (chk) setActiveCheck(chk);
                      } else {
                        handleOpenNewCheck(t.tableNumber);
                      }
                      setActiveTab('pos');
                    }}
                    className={`p-4 rounded-2xl border text-left cursor-pointer transition-all hover:scale-[1.02] flex flex-col justify-between h-36 ${
                      t.status === 'available'
                        ? 'bg-[#1C1210] border-[#22C55E]/40 hover:border-[#22C55E]'
                        : t.status === 'kitchen_prep'
                        ? 'bg-[#1E293B] border-[#3B82F6]/60'
                        : t.status === 'bill_requested'
                        ? 'bg-[#3B1A45] border-[#A855F7]/60'
                        : 'bg-[#241311] border-[#EAB308]/50'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="font-extrabold text-sm text-[#FAF7F2]">{t.tableNumber}</span>
                        <span
                          className={`w-2.5 h-2.5 rounded-full ${
                            t.status === 'available'
                              ? 'bg-[#22C55E]'
                              : t.status === 'kitchen_prep'
                              ? 'bg-[#3B82F6]'
                              : t.status === 'bill_requested'
                              ? 'bg-[#A855F7]'
                              : 'bg-[#EAB308]'
                          }`}
                        />
                      </div>
                      <p className="text-[10px] text-[#A89689] mt-0.5">{t.area} • Seats {t.capacity}</p>
                    </div>

                    <div className="pt-2 border-t border-[#36221E]/60 flex items-center justify-between text-[11px]">
                      <span className="capitalize text-[#C5B4A5]">{t.status.replace('_', ' ')}</span>
                      <span className="font-bold text-[#FFC700]">
                        {t.currentCheckId ? 'Open Check' : 'Empty'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* =================================================================== */}
          {/* 3. KITCHEN DISPLAY SYSTEM (KDS) */}
          {/* =================================================================== */}
          {activeTab === 'kds' && (
            <div className="flex-1 p-4 overflow-y-auto space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-[#1C1210] p-4 rounded-2xl border border-[#36221E]">
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-lg font-black text-[#FAF7F2]">Kitchen Display System (KDS)</h2>
                    <span className="bg-[#800D15] text-[#FFC700] text-[10px] font-titan uppercase px-2 py-0.5 rounded-full border border-[#FFC700]/30">
                      Live Expediting
                    </span>
                  </div>
                  <p className="text-xs text-[#A89689]">
                    Station preparation queues, elapsed cooking timers, single-touch Bump & Recall
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  {/* Channel Filter */}
                  <div className="bg-[#140C0B] p-1 rounded-xl border border-[#36221E] flex items-center">
                    <button
                      onClick={() => setKdsChannelFilter('all')}
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                        kdsChannelFilter === 'all'
                          ? 'bg-[#E62E00] text-white'
                          : 'text-[#A89689] hover:text-[#FAF7F2]'
                      }`}
                    >
                      All
                    </button>
                    <button
                      onClick={() => setKdsChannelFilter('dine_in')}
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                        kdsChannelFilter === 'dine_in'
                          ? 'bg-[#E62E00] text-white'
                          : 'text-[#A89689] hover:text-[#FAF7F2]'
                      }`}
                    >
                      Dine-in
                    </button>
                    <button
                      onClick={() => setKdsChannelFilter('takeaway')}
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                        kdsChannelFilter === 'takeaway'
                          ? 'bg-[#E62E00] text-white'
                          : 'text-[#A89689] hover:text-[#FAF7F2]'
                      }`}
                    >
                      Takeaway
                    </button>
                    <button
                      onClick={() => setKdsChannelFilter('delivery')}
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                        kdsChannelFilter === 'delivery'
                          ? 'bg-[#E62E00] text-white'
                          : 'text-[#A89689] hover:text-[#FAF7F2]'
                      }`}
                    >
                      Delivery
                    </button>
                  </div>

                  {/* Toggle Show Bumped */}
                  <button
                    onClick={() => setKdsShowBumped(!kdsShowBumped)}
                    className={`px-3 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition-all ${
                      kdsShowBumped
                        ? 'bg-emerald-950/60 border-emerald-800 text-emerald-400'
                        : 'bg-[#241311] border-[#36221E] text-[#A89689] hover:text-[#FAF7F2]'
                    }`}
                  >
                    <span>{kdsShowBumped ? '✓ Showing Bumped' : 'Show Bumped'}</span>
                  </button>

                  <button
                    onClick={fetchKds}
                    className="p-2 bg-[#241311] hover:bg-[#36221E] text-[#A89689] border border-[#36221E] rounded-xl transition-all"
                    title="Refresh Queue"
                  >
                    <RefreshCw className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Tickets Queue */}
              {(() => {
                const filteredTickets = kdsTickets.filter((ticket) => {
                  if (!kdsShowBumped && ticket.status === 'ready') return false;
                  if (kdsChannelFilter === 'all') return true;
                  const channel = (ticket.checkType || '').toLowerCase();
                  if (kdsChannelFilter === 'dine_in') return channel.includes('dine') || ticket.tableNumber;
                  if (kdsChannelFilter === 'takeaway') return channel.includes('takeaway');
                  if (kdsChannelFilter === 'delivery') return channel.includes('delivery');
                  return true;
                });

                if (filteredTickets.length === 0) {
                  return (
                    <div className="bg-[#1C1210] border border-[#36221E] rounded-2xl p-12 text-center text-[#A89689]">
                      <p className="text-base font-bold text-[#FAF7F2]">Kitchen queue is all caught up!</p>
                      <p className="text-xs mt-1">No active tickets waiting in preparation for this filter.</p>
                    </div>
                  );
                }

                return (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                    {filteredTickets.map((ticket) => {
                      const elapsedMinutes = Math.floor(
                        (Date.now() - new Date(ticket.openedAt).getTime()) / 60000
                      );
                      const isLate = elapsedMinutes > 15 && ticket.status !== 'ready';
                      const isReady = ticket.status === 'ready';

                      return (
                        <div
                          key={ticket.id}
                          className={`rounded-2xl border p-4 flex flex-col justify-between shadow-lg transition-all ${
                            isReady
                              ? 'bg-[#152319] border-[#22C55E]/40'
                              : isLate
                              ? 'bg-[#3A1412] border-[#EF4444]'
                              : 'bg-[#1C1210] border-[#36221E]'
                          }`}
                        >
                          <div className="space-y-3">
                            <div className="flex items-start justify-between">
                              <div>
                                <span className="font-black text-sm text-[#FFC700]">
                                  #{ticket.checkNumber}
                                </span>
                                <p className="text-xs font-bold text-[#FAF7F2]">
                                  {ticket.tableNumber || ticket.checkType || 'Order'}
                                </p>
                              </div>
                              <div className="flex flex-col items-end gap-1">
                                <span
                                  className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                                    isReady
                                      ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                                      : isLate
                                      ? 'bg-[#EF4444] text-white'
                                      : 'bg-[#241311] text-[#A89689]'
                                  }`}
                                >
                                  {isReady ? 'READY' : `${elapsedMinutes}m ago`}
                                </span>
                                {ticket.checkType && (
                                  <span className="text-[9px] uppercase font-bold text-[#A89689]">
                                    {ticket.checkType}
                                  </span>
                                )}
                              </div>
                            </div>

                            {/* Order Items */}
                            <div className="space-y-1.5 border-t border-[#36221E] pt-2">
                              {ticket.items.map((it: any) => (
                                <div
                                  key={it.id}
                                  onClick={() =>
                                    handleAdvanceKdsItem(
                                      ticket.id,
                                      it.id,
                                      it.status === 'ready' ? 'sent_to_kitchen' : 'ready'
                                    )
                                  }
                                  className={`p-2 rounded-xl text-xs flex items-center justify-between cursor-pointer border transition-all ${
                                    it.status === 'ready'
                                      ? 'bg-[#15803D]/20 border-[#22C55E]/40 text-[#4ADE80] line-through'
                                      : 'bg-[#241311] border-[#36221E] text-[#FAF7F2] hover:border-[#FFC700]'
                                  }`}
                                >
                                  <div className="flex items-center gap-2">
                                    <span className="font-mono font-black text-sm text-[#FFC700]">
                                      {it.quantity}x
                                    </span>
                                    <span className="font-bold truncate max-w-[140px]">
                                      {it.name}
                                    </span>
                                  </div>
                                  <span className="text-[10px] uppercase font-bold">
                                    {it.status === 'ready' ? '✓ Ready' : 'Prep'}
                                  </span>
                                </div>
                              ))}
                            </div>
                          </div>

                          {/* Ticket Footer & Bump/Recall Actions */}
                          <div className="pt-3 mt-3 border-t border-[#36221E] space-y-2">
                            <div className="flex justify-between items-center text-[11px] text-[#A89689]">
                              <span>Server: {ticket.openedByName || 'Counter'}</span>
                              <span className="font-bold text-[#FAF7F2]">
                                {ticket.items.length} Items
                              </span>
                            </div>

                            <div className="pt-1">
                              {isReady ? (
                                <button
                                  onClick={() => handleRecallKdsTicket(ticket.id)}
                                  className="w-full py-2 bg-[#241311] hover:bg-[#36221E] text-amber-400 border border-amber-800/40 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all"
                                >
                                  <RotateCcw className="w-3.5 h-3.5" />
                                  <span>Recall to Kitchen</span>
                                </button>
                              ) : (
                                <button
                                  onClick={() => handleBumpKdsTicket(ticket.id)}
                                  className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-md transition-all active:scale-95"
                                >
                                  <CheckCircle2 className="w-3.5 h-3.5" />
                                  <span>Bump Ticket (All Ready)</span>
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                );
              })()}
            </div>
          )}

          {/* =================================================================== */}
          {/* 4. DISPATCH & RIDER FLEET MANAGEMENT HUB */}
          {/* =================================================================== */}
          {activeTab === 'dispatch' && (
            <DispatchOperationsHub
              activeBranchId={activeBranchId}
              currentStaff={currentStaff as any}
              showToast={showToast}
            />
          )}

          {/* =================================================================== */}
          {/* 5. MASTER INVENTORY & PURCHASING */}
          {/* =================================================================== */}
          {activeTab === 'inventory' && (
            <div className="flex-1 overflow-y-auto p-4 md:p-6">
              <MasterInventoryManager
                selectedBranchId={activeBranchId}
                onSelectBranch={(bId) => setActiveBranchId(bId)}
              />
            </div>
          )}

          {/* =================================================================== */}
          {/* 6. SHIFTS & TILL RECONCILIATION */}
          {/* =================================================================== */}
          {activeTab === 'shifts' && (
            <div className="flex-1 p-4 overflow-y-auto space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-black text-[#FAF7F2]">Shift Management & Cash Drawer</h2>
                  <p className="text-xs text-[#A89689]">Live cash movements, X-Report snapshots, and closing Z-Reports</p>
                </div>
                <div className="flex items-center gap-2">
                  {currentShift ? (
                    <>
                      <button
                        onClick={() => setIsCashMovementModalOpen(true)}
                        className="px-3 py-1.5 bg-[#241311] hover:bg-[#36221E] text-xs font-bold rounded-lg border border-[#4D2924] flex items-center gap-1.5"
                      >
                        <Banknote className="w-3.5 h-3.5 text-[#FFC700]" /> Safe Drop / Paid Out
                      </button>
                      <button
                        onClick={() => setIsClosingShiftModalOpen(true)}
                        className="px-3 py-1.5 bg-[#EF4444] hover:bg-[#DC2626] text-xs font-bold text-white rounded-lg flex items-center gap-1.5"
                      >
                        <Lock className="w-3.5 h-3.5" /> Close Shift (Z-Report)
                      </button>
                    </>
                  ) : (
                    <button
                      onClick={() => setIsOpeningShiftModalOpen(true)}
                      className="px-3 py-1.5 bg-[#FFC700] hover:bg-[#E5B200] text-[#4D080F] text-xs font-bold rounded-lg flex items-center gap-1.5"
                    >
                      <Sparkles className="w-3.5 h-3.5" /> Open New Shift
                    </button>
                  )}
                </div>
              </div>

              {/* Active Shift Financial Card */}
              {currentShift ? (
                <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                  <div className="p-4 bg-[#1C1210] border border-[#36221E] rounded-2xl">
                    <span className="text-xs text-[#A89689]">Opening Float</span>
                    <p className="font-mono font-extrabold text-lg text-[#FAF7F2] mt-1">₦{currentShift.openingFloat.toLocaleString()}</p>
                  </div>
                  <div className="p-4 bg-[#1C1210] border border-[#36221E] rounded-2xl">
                    <span className="text-xs text-[#A89689]">Cash Sales</span>
                    <p className="font-mono font-extrabold text-lg text-[#22C55E] mt-1">₦{currentShift.totalCashSales.toLocaleString()}</p>
                  </div>
                  <div className="p-4 bg-[#1C1210] border border-[#36221E] rounded-2xl">
                    <span className="text-xs text-[#A89689]">POS Terminal Sales</span>
                    <p className="font-mono font-extrabold text-lg text-[#38BDF8] mt-1">₦{currentShift.totalPosSales.toLocaleString()}</p>
                  </div>
                  <div className="p-4 bg-[#1C1210] border border-[#36221E] rounded-2xl">
                    <span className="text-xs text-[#A89689]">Expected Cash in Till</span>
                    <p className="font-mono font-extrabold text-lg text-[#FFC700] mt-1">₦{currentShift.expectedCashInTill.toLocaleString()}</p>
                  </div>
                </div>
              ) : (
                <div className="p-8 bg-[#1C1210] border border-[#36221E] rounded-2xl text-center space-y-2">
                  <Clock className="w-10 h-10 text-[#4D2924] mx-auto" />
                  <h3 className="font-bold text-sm text-[#FAF7F2]">No Shift Currently Active</h3>
                  <p className="text-xs text-[#A89689]">Enter your opening cash float to begin processing sales.</p>
                </div>
              )}
            </div>
          )}

          {/* =================================================================== */}
          {/* 7. SALES & FINANCIAL REPORTS */}
          {/* =================================================================== */}
          {/* 7. EXECUTIVE ANALYTICS & BI DASHBOARD */}
          {/* =================================================================== */}
          {activeTab === 'reports' && (
            !canAccessBackend ? (
              <div className="flex-1 p-8 flex flex-col items-center justify-center text-center space-y-4">
                <div className="w-16 h-16 rounded-2xl bg-red-950/40 border border-red-800 text-red-500 flex items-center justify-center">
                  <Lock className="w-8 h-8" />
                </div>
                <h2 className="text-xl font-black text-[#FAF7F2]">Access Restricted — Interface C Required</h2>
                <p className="text-sm text-[#A89689] max-w-md">
                  Executive analytics, financial reports, and business intelligence are restricted to management and administrative personnel.
                </p>
                <button
                  onClick={() => setActiveTab('pos')}
                  className="px-5 py-2.5 bg-[#FFC700] text-[#4D080F] font-black text-xs uppercase rounded-xl hover:bg-[#E6B200] transition-colors"
                >
                  Return to POS Register
                </button>
              </div>
            ) : (
              <ExecutiveBIDashboard
                currentStaffRole={currentStaff?.role}
                currentStaffBranchId={currentStaff?.branchId}
                defaultBranchId={activeBranchId}
              />
            )
          )}

          {/* =================================================================== */}
          {/* 8. STAFF & ROLES (ChopLife RBAC & Directory) */}
          {/* =================================================================== */}
          {activeTab === 'staff' && (
            !canAccessBackend ? (
              <div className="flex-1 p-8 flex flex-col items-center justify-center text-center space-y-4">
                <div className="w-16 h-16 rounded-2xl bg-red-950/40 border border-red-800 text-red-500 flex items-center justify-center">
                  <Lock className="w-8 h-8" />
                </div>
                <h2 className="text-xl font-black text-[#FAF7F2]">Access Restricted — Interface C Required</h2>
                <p className="text-sm text-[#A89689] max-w-md">
                  Staff account administration and RBAC governance are restricted to authorized administrators and branch managers.
                </p>
                <button
                  onClick={() => setActiveTab('pos')}
                  className="px-5 py-2.5 bg-[#FFC700] text-[#4D080F] font-black text-xs uppercase rounded-xl hover:bg-[#E6B200] transition-colors"
                >
                  Return to POS Register
                </button>
              </div>
            ) : (
            <div className="flex-1 p-4 overflow-y-auto space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h2 className="text-lg font-black text-[#FAF7F2]">Staff Directory & RBAC Governance</h2>
                  <p className="text-xs text-[#A89689]">Configurable role matrices, granular privileges, reports, and staff credentials</p>
                </div>

                <div className="flex items-center gap-2">
                  {/* Sub-tab pills */}
                  <div className="flex bg-[#160E0C] p-1 rounded-xl border border-[#36221E]">
                    <button
                      onClick={() => setStaffSubTab('directory')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                        staffSubTab === 'directory'
                          ? 'bg-[#FFC700] text-[#4D080F] shadow-xs'
                          : 'text-[#A89689] hover:text-[#FAF7F2]'
                      }`}
                    >
                      Staff Directory
                    </button>
                    <button
                      onClick={() => setStaffSubTab('roles')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                        staffSubTab === 'roles'
                          ? 'bg-[#FFC700] text-[#4D080F] shadow-xs'
                          : 'text-[#A89689] hover:text-[#FAF7F2]'
                      }`}
                    >
                      Roles & Permissions (Master)
                    </button>
                  </div>

                  {staffSubTab === 'directory' && (
                    <button
                      onClick={handleOpenNewStaffModal}
                      className="px-4 py-2 bg-[#FFC700] hover:bg-[#E6B200] text-[#4D080F] rounded-xl text-xs font-black uppercase flex items-center gap-1.5 shadow-md transition-all active:scale-95"
                    >
                      <Plus className="w-4 h-4" /> Add Staff Account
                    </button>
                  )}
                </div>
              </div>

              {/* 🎂 Upcoming Staff Birthdays Alert Banner (CR-14) */}
              {upcomingBirthdays.length > 0 && staffSubTab === 'directory' && (
                <div className="bg-gradient-to-r from-[#800D15]/40 via-[#4D080F]/40 to-[#241311] border border-[#FFC700]/30 rounded-2xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-3 shadow-md">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-[#FFC700]/20 text-[#FFC700] flex items-center justify-center font-bold text-lg shrink-0">
                      🎂
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-[#FAF7F2] flex items-center gap-2">
                        Upcoming Staff Birthdays (Next 30 Days)
                        <span className="px-2 py-0.5 rounded-full bg-[#FFC700] text-[#4D080F] text-[10px] font-black">
                          {upcomingBirthdays.length}
                        </span>
                      </h4>
                      <p className="text-xs text-[#A89689]">
                        Recognize and celebrate our restaurant team members across all branches!
                      </p>
                    </div>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    {upcomingBirthdays.slice(0, 5).map((b: any) => (
                      <div
                        key={b.staffId}
                        className="bg-[#1C1210] border border-[#4D2924] px-3 py-1.5 rounded-xl text-xs flex items-center gap-2"
                      >
                        <span className="font-bold text-[#FAF7F2]">{b.name}</span>
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#FFC700]/15 text-[#FFC700] font-mono font-bold">
                          {b.birthdayThisYear} ({b.daysUntil === 0 ? 'Today!' : `${b.daysUntil}d`})
                        </span>
                        <span className="text-[10px] text-[#A89689]">Turns {b.turningAge}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {staffSubTab === 'directory' ? (
                <div className="bg-[#1C1210] border border-[#36221E] rounded-2xl overflow-hidden shadow-md">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-[#241311] border-b border-[#36221E] text-[#A89689] uppercase font-semibold">
                      <tr>
                        <th className="p-3">Staff ID</th>
                        <th className="p-3">Full Name</th>
                        <th className="p-3">Work Email</th>
                        <th className="p-3">Role</th>
                        <th className="p-3">Branch</th>
                        <th className="p-3">DOB</th>
                        <th className="p-3">Guarantor</th>
                        <th className="p-3">Status</th>
                        <th className="p-3 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#36221E]">
                      {staffAccountsList.map((s) => (
                        <tr key={s.id} className="hover:bg-[#241311] transition-colors">
                          <td className="p-3 font-mono font-bold text-[#FFC700]">{s.staffId}</td>
                          <td className="p-3 font-bold text-[#FAF7F2]">{s.name}</td>
                          <td className="p-3 text-[#A89689]">{s.workEmail}</td>
                          <td className="p-3 uppercase font-semibold text-[#C5B4A5]">
                            <span className="bg-[#241311] px-2 py-0.5 rounded border border-[#36221E] font-mono text-[11px]">
                              {s.role.replace(/_/g, ' ')}
                            </span>
                          </td>
                          <td className="p-3 uppercase font-semibold text-[#C5B4A5]">{s.branchId}</td>
                          <td className="p-3 text-[#FAF7F2] font-mono text-[11px]">
                            {s.dateOfBirth || <span className="text-[#6B5A4E] italic font-sans">Not set</span>}
                          </td>
                          <td className="p-3">
                            {s.guarantorName ? (
                              <div className="text-[11px] leading-tight">
                                <p className="font-semibold text-emerald-400 truncate max-w-[120px]">{s.guarantorName}</p>
                                <p className="text-[#A89689] text-[10px] truncate max-w-[120px]">{s.guarantorRelationship || s.guarantorPhone}</p>
                              </div>
                            ) : (
                              <span className="text-amber-500 text-[10px] font-medium bg-amber-950/40 px-1.5 py-0.5 rounded border border-amber-800/40">
                                Pending
                              </span>
                            )}
                          </td>
                          <td className="p-3">
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                                s.status === 'active' ? 'bg-[#15803D]/20 text-[#4ADE80]' : 'bg-[#EF4444]/20 text-[#EF4444]'
                              }`}
                            >
                              {s.status}
                            </span>
                          </td>
                          <td className="p-3 text-right space-x-1.5 whitespace-nowrap">
                            <button
                              onClick={() => {
                                setEffectiveAccessStaffId(s.staffId);
                                setIsEffectiveAccessOpen(true);
                              }}
                              className="px-2.5 py-1 bg-[#15803D]/20 hover:bg-[#15803D]/30 text-emerald-400 border border-emerald-800/40 rounded-lg text-[11px] font-bold transition-all"
                              title="Inspect resolved runtime permissions and reports"
                            >
                              View Access
                            </button>
                            <button
                              onClick={() => handleEditStaffModal(s)}
                              className="px-2.5 py-1 bg-[#36221E] hover:bg-[#4D2924] text-[#FAF7F2] rounded-lg text-[11px] font-bold"
                            >
                              Edit
                            </button>
                            <button
                              onClick={() => handleResetStaffPassword(s.id, s.name)}
                              className="px-2.5 py-1 bg-[#FFC700]/15 hover:bg-[#FFC700]/30 text-[#FFC700] rounded-lg text-[11px] font-bold"
                            >
                              Reset Password
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <RolePermissionManager
                  currentStaffRole={currentStaff?.role}
                  showToast={(msg) => showToast(msg, 'success')}
                />
              )}
            </div>
            )
          )}

          {/* =================================================================== */}
          {/* 9. SECURITY AUDIT LOGS */}
          {/* =================================================================== */}
          {activeTab === 'audit' && (
            !canAccessBackend ? (
              <div className="flex-1 p-8 flex flex-col items-center justify-center text-center space-y-4">
                <div className="w-16 h-16 rounded-2xl bg-red-950/40 border border-red-800 text-red-500 flex items-center justify-center">
                  <Lock className="w-8 h-8" />
                </div>
                <h2 className="text-xl font-black text-[#FAF7F2]">Access Restricted — Interface C Required</h2>
                <p className="text-sm text-[#A89689] max-w-md">
                  Immutable forensic audit logs are reserved for system auditors and corporate administration.
                </p>
                <button
                  onClick={() => setActiveTab('pos')}
                  className="px-5 py-2.5 bg-[#FFC700] text-[#4D080F] font-black text-xs uppercase rounded-xl hover:bg-[#E6B200] transition-colors"
                >
                  Return to POS Register
                </button>
              </div>
            ) : (
            <div className="flex-1 p-4 overflow-y-auto space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-black text-[#FAF7F2]">Immutable Security Audit Log</h2>
                  <p className="text-xs text-[#A89689]">Forensic operational logs for financial events, auth, inventory, and voids</p>
                </div>
              </div>

              <div className="bg-[#1C1210] border border-[#36221E] rounded-2xl overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#241311] border-b border-[#36221E] text-[#A89689] uppercase font-semibold">
                    <tr>
                      <th className="p-3">Timestamp</th>
                      <th className="p-3">Staff / Role</th>
                      <th className="p-3">Action Type</th>
                      <th className="p-3">Details</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#36221E]">
                    {auditLogsList.map((log) => (
                      <tr key={log.id} className="hover:bg-[#241311]">
                        <td className="p-3 font-mono text-[#A89689] whitespace-nowrap">
                          {new Date(log.timestamp).toLocaleString('en-GB', { timeZone: 'Africa/Lagos' })}
                        </td>
                        <td className="p-3">
                          <p className="font-bold text-[#FAF7F2]">{log.staffName}</p>
                          <span className="text-[10px] text-[#A89689] uppercase">{log.staffRole}</span>
                        </td>
                        <td className="p-3">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold font-mono bg-[#FFC700]/15 text-[#FFC700] border border-[#FFC700]/30">
                            {log.actionType}
                          </span>
                        </td>
                        <td className="p-3 text-[#C5B4A5]">{log.details}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
            )
          )}

          {/* =================================================================== */}
          {/* 10. CUSTOMER CARE & SUPPORT HUB */}
          {/* =================================================================== */}
          {activeTab === 'customercare' && (
            <CustomerCareHub
              activeBranchId={activeBranchId}
              currentStaff={currentStaff!}
              showToast={showToast}
            />
          )}

          {/* =================================================================== */}
          {/* 10.5 AUTOMATED MULTI-CHANNEL NOTIFICATION ENGINE (SMS & WHATSAPP) */}
          {/* =================================================================== */}
          {activeTab === 'notifications' && (
            <div className="flex-1 overflow-y-auto">
              <NotificationHub
                activeBranchId={activeBranchId}
                currentStaff={currentStaff!}
                showToast={showToast}
              />
            </div>
          )}

          {/* =================================================================== */}
          {/* 11. CATERING PRODUCTION PLANNER & EVENT DISPATCH */}
          {/* =================================================================== */}
          {activeTab === 'catering' && (
            <div className="flex-1 overflow-y-auto">
              <CateringProductionPlanner />
            </div>
          )}

          {/* =================================================================== */}
          {/* 12. VIP LOYALTY, DIGITAL WALLETS & CORPORATE HOUSE ACCOUNTS */}
          {/* =================================================================== */}
          {activeTab === 'loyalty_vip' && (
            <div className="flex-1 overflow-y-auto p-4 sm:p-6">
              <LoyaltyAndHouseAccountsHub
                activeBranchId={activeBranchId}
                currentStaff={currentStaff!}
                showToast={showToast}
              />
            </div>
          )}

          {/* =================================================================== */}
          {/* 13. MENU & CATALOGUE ADMINISTRATION */}
          {/* =================================================================== */}
          {activeTab === 'menu_catalog' && (
            <div className="flex-1 overflow-hidden flex flex-col">
              <MenuCatalogueManager />
            </div>
          )}

          {/* =================================================================== */}
          {/* 14. WEBSITE CONTENT MANAGEMENT (CMS) */}
          {/* =================================================================== */}
          {activeTab === 'cms' && (
            <div className="flex-1 overflow-hidden flex flex-col">
              <WebsiteCmsManager />
            </div>
          )}
        </main>
      </div>

      {/* ========================================================================= */}
      {/* MODALS: PAYMENT, DISCOUNT, OPEN SHIFT, CASH MOVEMENTS, RECEIPT */}
      {/* ========================================================================= */}

      {/* 1. Payment Modal */}
      {isPaymentModalOpen && activeCheck && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#1C1210] border border-[#36221E] rounded-2xl max-w-md w-full p-5 space-y-4 shadow-2xl animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-[#36221E] pb-3">
              <div>
                <h3 className="font-black text-base text-[#FAF7F2]">Settle Check #{activeCheck.checkNumber}</h3>
                <p className="text-xs text-[#A89689]">{activeCheck.tableNumber || activeCheck.checkType}</p>
              </div>
              <button onClick={() => setIsPaymentModalOpen(false)} className="text-[#A89689] hover:text-[#FAF7F2]">
                ✕
              </button>
            </div>

            {/* Total Amount Banner */}
            <div className="p-3.5 bg-[#241311] rounded-xl border border-[#4D2924] text-center">
              <span className="text-xs text-[#A89689]">Total Amount Payable</span>
              <p className="font-mono font-black text-2xl text-[#FFC700] mt-0.5">₦{activeCheck.total.toLocaleString()}</p>
            </div>

            {/* Payment Method Selector */}
            <div className="grid grid-cols-5 gap-1.5">
              <button
                onClick={() => setPaymentMethod('cash')}
                className={`p-2 rounded-xl border text-[11px] font-bold flex flex-col items-center gap-1 transition-all ${
                  paymentMethod === 'cash'
                    ? 'bg-[#800D15] border-[#FFC700] text-[#FFC700]'
                    : 'bg-[#241311] border-[#36221E] text-[#C5B4A5]'
                }`}
              >
                <Banknote className="w-4 h-4" /> Cash
              </button>
              <button
                onClick={() => setPaymentMethod('pos_terminal')}
                className={`p-2 rounded-xl border text-[11px] font-bold flex flex-col items-center gap-1 transition-all ${
                  paymentMethod === 'pos_terminal'
                    ? 'bg-[#800D15] border-[#FFC700] text-[#FFC700]'
                    : 'bg-[#241311] border-[#36221E] text-[#C5B4A5]'
                }`}
              >
                <CreditCard className="w-4 h-4" /> POS
              </button>
              <button
                onClick={() => setPaymentMethod('bank_transfer')}
                className={`p-2 rounded-xl border text-[11px] font-bold flex flex-col items-center gap-1 transition-all ${
                  paymentMethod === 'bank_transfer'
                    ? 'bg-[#800D15] border-[#FFC700] text-[#FFC700]'
                    : 'bg-[#241311] border-[#36221E] text-[#C5B4A5]'
                }`}
              >
                <Building className="w-4 h-4" /> Transfer
              </button>
              <button
                onClick={() => setPaymentMethod('wallet')}
                className={`p-2 rounded-xl border text-[11px] font-bold flex flex-col items-center gap-1 transition-all ${
                  paymentMethod === 'wallet'
                    ? 'bg-[#800D15] border-[#FFC700] text-[#FFC700]'
                    : 'bg-[#241311] border-[#36221E] text-[#C5B4A5]'
                }`}
              >
                <Wallet className="w-4 h-4" /> Wallet
              </button>
              <button
                onClick={() => setPaymentMethod('house_account')}
                className={`p-2 rounded-xl border text-[11px] font-bold flex flex-col items-center gap-1 transition-all ${
                  paymentMethod === 'house_account'
                    ? 'bg-[#800D15] border-[#FFC700] text-[#FFC700]'
                    : 'bg-[#241311] border-[#36221E] text-[#C5B4A5]'
                }`}
              >
                <Award className="w-4 h-4" /> Corp Acct
              </button>
            </div>

            {/* Payment Fields */}
            {paymentMethod === 'cash' && (
              <div className="space-y-2">
                <label className="text-xs text-[#A89689]">Cash Tendered (₦)</label>
                <input
                  type="number"
                  placeholder={String(activeCheck.total)}
                  value={cashTendered}
                  onChange={(e) => setCashTendered(e.target.value)}
                  className="w-full bg-[#241311] border border-[#4D2924] rounded-xl px-3 py-2 text-sm text-[#FAF7F2] font-mono focus:outline-none focus:border-[#FFC700]"
                />
                {Number(cashTendered) > activeCheck.total && (
                  <div className="p-2 bg-[#15803D]/20 text-[#4ADE80] rounded-lg text-xs font-mono font-bold flex justify-between">
                    <span>Change Due:</span>
                    <span>₦{(Number(cashTendered) - activeCheck.total).toLocaleString()}</span>
                  </div>
                )}
              </div>
            )}

            {paymentMethod === 'pos_terminal' && (
              <div className="space-y-2">
                <label className="text-xs text-[#A89689]">POS Terminal RRN / STAN Number</label>
                <input
                  type="text"
                  placeholder="e.g. 0048291038"
                  value={posRrn}
                  onChange={(e) => setPosRrn(e.target.value)}
                  className="w-full bg-[#241311] border border-[#4D2924] rounded-xl px-3 py-2 text-sm text-[#FAF7F2] font-mono focus:outline-none focus:border-[#FFC700]"
                />
              </div>
            )}

            {paymentMethod === 'bank_transfer' && (
              <div className="space-y-2">
                <label className="text-xs text-[#A89689]">Bank Transfer Session ID / Ref</label>
                <input
                  type="text"
                  placeholder="e.g. TRF-GTB-849102"
                  value={transferRef}
                  onChange={(e) => setTransferRef(e.target.value)}
                  className="w-full bg-[#241311] border border-[#4D2924] rounded-xl px-3 py-2 text-sm text-[#FAF7F2] font-mono focus:outline-none focus:border-[#FFC700]"
                />
              </div>
            )}

            {/* DIGITAL WALLET PAYMENT FORM */}
            {paymentMethod === 'wallet' && (
              <div className="space-y-3 bg-[#120B0A] p-3 rounded-xl border border-[#36221E]">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-[#FFC700] flex items-center gap-1.5">
                    <Wallet className="w-4 h-4" /> Patron Digital Wallet
                  </span>
                  <span className="text-[10px] text-[#A89689]">Pre-paid Stored Float</span>
                </div>

                <div>
                  <label className="text-[11px] text-[#A89689]">Select Registered Member *</label>
                  <select
                    value={selectedCustomerIdForPayment}
                    onChange={(e) => setSelectedCustomerIdForPayment(e.target.value)}
                    className="w-full bg-[#241311] border border-[#36221E] rounded-xl px-2.5 py-2 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
                  >
                    <option value="">-- Choose Member --</option>
                    {posCustomers.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} ({c.phone}) - Bal: ₦{Number(c.walletBalance).toLocaleString()} [{c.tier.toUpperCase()}]
                      </option>
                    ))}
                  </select>
                </div>

                {selectedCustomerIdForPayment && (
                  (() => {
                    const cust = posCustomers.find((c) => c.id === selectedCustomerIdForPayment);
                    if (!cust) return null;
                    const canAfford = cust.walletBalance >= activeCheck.total;
                    return (
                      <div className="space-y-2 pt-1 border-t border-[#36221E]">
                        <div className="flex justify-between text-xs">
                          <span className="text-[#A89689]">Available Balance:</span>
                          <span className={`font-mono font-bold ${canAfford ? 'text-emerald-400' : 'text-rose-400'}`}>
                            ₦{Number(cust.walletBalance).toLocaleString()}
                          </span>
                        </div>

                        {!canAfford && (
                          <div className="text-[11px] text-rose-400 bg-rose-950/40 p-2 rounded-lg border border-rose-800/40">
                            Insufficient balance. Patron needs ₦{(activeCheck.total - cust.walletBalance).toLocaleString()} top-up.
                          </div>
                        )}

                        <div>
                          <label className="text-[11px] text-[#A89689]">Customer 4-Digit Security PIN *</label>
                          <input
                            type="password"
                            maxLength={4}
                            placeholder="1234"
                            value={walletPinForPayment}
                            onChange={(e) => setWalletPinForPayment(e.target.value)}
                            className="w-full bg-[#241311] border border-[#36221E] rounded-xl px-3 py-2 text-xs text-[#FAF7F2] font-mono tracking-widest focus:outline-none focus:border-[#FFC700]"
                          />
                        </div>
                      </div>
                    );
                  })()
                )}
              </div>
            )}

            {/* CORPORATE HOUSE ACCOUNT PAYMENT FORM */}
            {paymentMethod === 'house_account' && (
              <div className="space-y-3 bg-[#120B0A] p-3 rounded-xl border border-[#36221E]">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-[#FFC700] flex items-center gap-1.5">
                    <Building className="w-4 h-4" /> Corporate House Account
                  </span>
                  <span className="text-[10px] text-[#A89689]">Direct Client Billing</span>
                </div>

                <div>
                  <label className="text-[11px] text-[#A89689]">Select Corporate Account *</label>
                  <select
                    value={selectedHouseAccountIdForPayment}
                    onChange={(e) => {
                      setSelectedHouseAccountIdForPayment(e.target.value);
                      const acc = posHouseAccounts.find((a) => a.id === e.target.value);
                      if (acc?.authorizedSigners?.[0]) {
                        setAuthorizedSignerForPayment(acc.authorizedSigners[0].name);
                      } else if (acc?.contactPerson) {
                        setAuthorizedSignerForPayment(acc.contactPerson);
                      }
                    }}
                    className="w-full bg-[#241311] border border-[#36221E] rounded-xl px-2.5 py-2 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
                  >
                    <option value="">-- Choose Corporate Account --</option>
                    {posHouseAccounts.map((a) => (
                      <option key={a.id} value={a.id}>
                        {a.companyName} ({a.accountCode}) - Avail: ₦{Math.max(0, a.creditLimit - a.currentBalance).toLocaleString()}
                      </option>
                    ))}
                  </select>
                </div>

                {selectedHouseAccountIdForPayment && (
                  (() => {
                    const acc = posHouseAccounts.find((a) => a.id === selectedHouseAccountIdForPayment);
                    if (!acc) return null;
                    const availCredit = Math.max(0, acc.creditLimit - acc.currentBalance);
                    const canCharge = availCredit >= activeCheck.total;
                    return (
                      <div className="space-y-2 pt-1 border-t border-[#36221E]">
                        <div className="flex justify-between text-xs">
                          <span className="text-[#A89689]">Remaining Credit Line:</span>
                          <span className={`font-mono font-bold ${canCharge ? 'text-emerald-400' : 'text-rose-400'}`}>
                            ₦{availCredit.toLocaleString()}
                          </span>
                        </div>

                        <div>
                          <label className="text-[11px] text-[#A89689]">Authorized Signer *</label>
                          <input
                            type="text"
                            required
                            placeholder="Signer Full Name"
                            value={authorizedSignerForPayment}
                            onChange={(e) => setAuthorizedSignerForPayment(e.target.value)}
                            className="w-full bg-[#241311] border border-[#36221E] rounded-xl px-3 py-2 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
                          />
                        </div>
                      </div>
                    );
                  })()
                )}
              </div>
            )}

            {/* Optional Loyalty Attaching for Cash / POS / Transfer */}
            {paymentMethod !== 'wallet' && (
              <div className="bg-[#241311]/60 p-2.5 rounded-xl border border-[#36221E]">
                <div className="flex items-center justify-between text-[11px] text-[#A89689]">
                  <span className="flex items-center gap-1 font-bold text-[#FFC700]">
                    <Sparkles className="w-3 h-3" /> VIP Patron Points & Stamps
                  </span>
                  <span>(Optional)</span>
                </div>
                <select
                  value={selectedCustomerIdForPayment}
                  onChange={(e) => setSelectedCustomerIdForPayment(e.target.value)}
                  className="mt-1.5 w-full bg-[#120B0A] border border-[#36221E] rounded-lg px-2 py-1.5 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
                >
                  <option value="">-- No Member Attached --</option>
                  {posCustomers.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.phone}) [{c.tier.toUpperCase()}]
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Confirm Payment CTA */}
            <button
              onClick={handleCompletePayment}
              className="w-full py-3 bg-[#22C55E] hover:bg-[#16A34A] text-[#120B0A] font-black text-sm rounded-xl transition-all shadow-md active:scale-95"
            >
              Confirm Settlement & Print Receipt
            </button>
          </div>
        </div>
      )}

      {/* 2. Open Shift Modal */}
      {isOpeningShiftModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#1C1210] border border-[#36221E] rounded-2xl max-w-sm w-full p-5 space-y-4 shadow-2xl animate-in zoom-in-95">
            <h3 className="font-black text-base text-[#FAF7F2]">Open New Shift</h3>
            <p className="text-xs text-[#A89689]">Enter the counted physical cash float placed into the register till.</p>

            <div className="space-y-1.5">
              <label className="text-xs text-[#A89689]">Opening Cash Float (₦)</label>
              <input
                type="number"
                placeholder="e.g. 10000"
                value={openingFloatInput}
                onChange={(e) => setOpeningFloatInput(e.target.value)}
                className="w-full bg-[#241311] border border-[#4D2924] rounded-xl px-3 py-2 text-sm text-[#FAF7F2] font-mono focus:outline-none focus:border-[#FFC700]"
              />
            </div>

            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setIsOpeningShiftModalOpen(false)}
                className="flex-1 py-2 bg-[#241311] text-[#A89689] text-xs font-bold rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={handleOpenShift}
                className="flex-1 py-2 bg-[#FFC700] text-[#4D080F] text-xs font-bold rounded-xl"
              >
                Open Shift
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 3. Discount Modal */}
      {isDiscountModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#1C1210] border border-[#36221E] rounded-2xl max-w-sm w-full p-5 space-y-4 shadow-2xl animate-in zoom-in-95">
            <h3 className="font-black text-base text-[#FAF7F2]">Apply Authorized Discount</h3>

            <div className="space-y-2">
              <label className="text-xs text-[#A89689]">Discount Percentage (%)</label>
              <div className="grid grid-cols-4 gap-2">
                {[5, 10, 15, 20].map((pct) => (
                  <button
                    key={pct}
                    onClick={() => setDiscountPercentInput(pct)}
                    className={`py-1.5 rounded-lg text-xs font-bold border ${
                      discountPercentInput === pct
                        ? 'bg-[#FFC700] text-[#4D080F] border-[#FFC700]'
                        : 'bg-[#241311] text-[#C5B4A5] border-[#36221E]'
                    }`}
                  >
                    {pct}%
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs text-[#A89689]">Authorized Reason</label>
              <select
                value={discountReasonInput}
                onChange={(e) => setDiscountReasonInput(e.target.value)}
                className="w-full bg-[#241311] border border-[#4D2924] rounded-xl px-3 py-2 text-xs text-[#FAF7F2]"
              >
                <option value="VIP Courtesy">VIP Courtesy</option>
                <option value="Staff Meal">Staff Meal</option>
                <option value="Management Approved">Management Approved</option>
                <option value="Customer Goodwill">Customer Goodwill</option>
              </select>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setIsDiscountModalOpen(false)}
                className="flex-1 py-2 bg-[#241311] text-[#A89689] text-xs font-bold rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={handleApplyDiscount}
                className="flex-1 py-2 bg-[#FFC700] text-[#4D080F] text-xs font-bold rounded-xl"
              >
                Apply
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 4. Thermal Receipt Modal (Connected to Editable Receipt Template) */}
      {isReceiptModalOpen && lastPaidCheck && (() => {
        const tpl = getCachedReceiptTemplate('customer_receipt');
        const branchDetails = resolveBranchDetails(lastPaidCheck.branchId);
        return (
          <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-[#FAF7F2] text-[#120B0A] rounded-2xl max-w-sm w-full p-6 space-y-4 shadow-2xl font-mono text-xs animate-in zoom-in-95">
              <div className="text-center space-y-1 border-b border-dashed border-[#120B0A]/30 pb-3">
                <h4 className="font-black text-sm uppercase">{tpl?.brandName || 'CHOPLIFE REPUBLIC'}</h4>
                {tpl?.tagline && (
                  <p className="text-[10px] text-gray-700 font-bold uppercase">{tpl.tagline}</p>
                )}
                <p className="text-[10px] text-gray-600 uppercase font-semibold">
                  {branchDetails.name}
                </p>
                {(tpl?.showBranchAddress !== false) && (
                  <p className="text-[10px] text-gray-600">{branchDetails.address}</p>
                )}
                {(tpl?.showBranchPhone !== false) && (
                  <p className="text-[10px] text-gray-500">Tel: {tpl?.phone || branchDetails.phone}</p>
                )}
                {tpl?.customHeaderMessage && (
                  <p className="text-[10px] text-[#800D15] font-bold pt-0.5">{tpl.customHeaderMessage}</p>
                )}
              </div>

              <div className="space-y-1 text-[11px] border-b border-dashed border-[#120B0A]/30 pb-2">
                <div className="flex justify-between">
                  <span>Receipt #:</span>
                  <span className="font-bold">{lastPaidCheck.checkNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span>Date:</span>
                  <span>{new Date(lastPaidCheck.closedAt).toLocaleString('en-GB', { timeZone: 'Africa/Lagos' })}</span>
                </div>
                <div className="flex justify-between">
                  <span>Table / Type:</span>
                  <span>{lastPaidCheck.tableNumber || lastPaidCheck.checkType}</span>
                </div>
                {(tpl?.showCashierName !== false) && (
                  <div className="flex justify-between">
                    <span>Cashier:</span>
                    <span>{lastPaidCheck.closedByName}</span>
                  </div>
                )}
              </div>

              {/* Items List */}
              <div className="space-y-1.5 border-b border-dashed border-[#120B0A]/30 pb-2">
                {lastPaidCheck.items.map((it: any) => (
                  <div key={it.id} className="flex justify-between text-[11px]">
                    <span>{it.quantity}x {it.name}</span>
                    <span className="font-bold">₦{it.totalPrice.toLocaleString()}</span>
                  </div>
                ))}
              </div>

              {/* Totals */}
              <div className="space-y-1 text-xs font-bold pt-1">
                <div className="flex justify-between">
                  <span>Subtotal:</span>
                  <span>₦{lastPaidCheck.subtotal.toLocaleString()}</span>
                </div>
                {lastPaidCheck.discountAmount > 0 && (
                  <div className="flex justify-between text-green-700">
                    <span>Discount:</span>
                    <span>-₦{lastPaidCheck.discountAmount.toLocaleString()}</span>
                  </div>
                )}
                <div className="flex justify-between text-sm font-black pt-1 border-t border-[#120B0A]">
                  <span>TOTAL PAID:</span>
                  <span>₦{lastPaidCheck.total.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-[10px] text-gray-600 uppercase pt-1">
                  <span>Payment Method:</span>
                  <span>{lastPaidCheck.paymentMethod}</span>
                </div>
              </div>

              <div className="text-[10px] text-center text-gray-500 pt-2 border-t border-dashed border-[#120B0A]/30 space-y-0.5">
                <p className="font-bold text-[#120B0A]">{tpl?.thankYouMessage || 'Thank you for dining at Choplife Republic!'}</p>
                {tpl?.customFooterMessage && <p>{tpl.customFooterMessage}</p>}
              </div>

              <div className="grid grid-cols-2 gap-2 pt-1">
                <button
                  onClick={() => {
                    dispatchCustomerReceipt(lastPaidCheck);
                  }}
                  className="w-full py-2 bg-[#800D15] hover:bg-[#4D080F] text-[#FFC700] font-sans font-bold text-xs rounded-xl flex items-center justify-center gap-1.5"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Print Thermal
                </button>
                <button
                  onClick={() => setIsReceiptModalOpen(false)}
                  className="w-full py-2 bg-[#120B0A] text-[#FAF7F2] font-sans font-bold text-xs rounded-xl"
                >
                  Close Receipt
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* 5. Safe Drop / Paid Out Cash Movement Modal */}
      <CashMovementModal
        isOpen={isCashMovementModalOpen}
        onClose={() => setIsCashMovementModalOpen(false)}
        currentShift={currentShift}
        cashMovementType={cashMovementType}
        setCashMovementType={setCashMovementType}
        cashMovementAmount={cashMovementAmount}
        setCashMovementAmount={setCashMovementAmount}
        cashMovementReason={cashMovementReason}
        setCashMovementReason={setCashMovementReason}
        onSave={handleLogCashMovement}
      />

      {/* 6. Close Shift & Blind Till Balancing Modal */}
      <CloseShiftModal
        isOpen={isClosingShiftModalOpen}
        onClose={() => setIsClosingShiftModalOpen(false)}
        currentShift={currentShift}
        countedCashInput={countedCashInput}
        setCountedCashInput={setCountedCashInput}
        closingNotesInput={closingNotesInput}
        setClosingNotesInput={setClosingNotesInput}
        onConfirmClose={handleCloseShift}
      />

      {/* 7. Shift Z-Report Modal */}
      <ShiftZReportModal
        isOpen={isShiftZReportModalOpen}
        onClose={() => setIsShiftZReportModalOpen(false)}
        shiftReport={closedShiftReport}
        branchName={
          closedShiftReport?.branchId === 'gra'
            ? 'GRA Flagship (8a Okogo St)'
            : closedShiftReport?.branchId === 'okabere'
            ? 'Okabere Hub'
            : 'Ugbowo Campus Hub'
        }
      />

      {/* 8. Split Bill Modal */}
      <PosBillSplitModal
        isOpen={isSplitBillModalOpen}
        onClose={() => setIsSplitBillModalOpen(false)}
        activeCheck={activeCheck}
        onSettleSplit={handleSettleSplitBill}
        showToast={showToast}
      />

      {/* 9. Table Transfer Modal */}
      <PosTableTransferModal
        isOpen={isTableTransferModalOpen}
        onClose={() => setIsTableTransferModalOpen(false)}
        activeCheck={activeCheck}
        tables={tables}
        onTransfer={handleTransferTable}
        showToast={showToast}
      />

      {/* 9b. Staff Account Creation & Editing Modal */}
      {isStaffModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleSaveStaffAccount}
            className="bg-[#1C1210] border border-[#36221E] rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl animate-in zoom-in-95 text-xs text-[#FAF7F2]"
          >
            <div className="flex items-center justify-between border-b border-[#36221E] pb-3">
              <h3 className="font-black text-base text-[#FAF7F2]">
                {editingStaffAccount ? 'Edit Staff Account' : 'Create New Staff Account'}
              </h3>
              <button
                type="button"
                onClick={() => setIsStaffModalOpen(false)}
                className="text-[#A89689] hover:text-[#FAF7F2]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-[#A89689] block mb-1">Staff ID *</label>
                <input
                  type="text"
                  required
                  value={staffFormId}
                  onChange={(e) => setStaffFormId(e.target.value)}
                  disabled={!!editingStaffAccount}
                  className="w-full bg-[#241311] border border-[#4D2924] rounded-xl px-3 py-2 text-xs text-[#FAF7F2] font-mono focus:outline-none focus:border-[#FFC700] disabled:opacity-50"
                />
              </div>

              <div>
                <label className="text-[#A89689] block mb-1">Full Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Osahon Enabulele"
                  value={staffFormName}
                  onChange={(e) => setStaffFormName(e.target.value)}
                  className="w-full bg-[#241311] border border-[#4D2924] rounded-xl px-3 py-2 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
                />
              </div>

              <div>
                <label className="text-[#A89689] block mb-1">Work Email *</label>
                <input
                  type="email"
                  required
                  placeholder="e.g. osahon@chopliferepublic.com"
                  value={staffFormEmail}
                  onChange={(e) => setStaffFormEmail(e.target.value)}
                  disabled={!!editingStaffAccount}
                  className="w-full bg-[#241311] border border-[#4D2924] rounded-xl px-3 py-2 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700] disabled:opacity-50"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div>
                  <label className="text-[#A89689] block mb-1">Phone Number</label>
                  <input
                    type="tel"
                    placeholder="08012345678"
                    value={staffFormPhone}
                    onChange={(e) => setStaffFormPhone(e.target.value)}
                    className="w-full bg-[#241311] border border-[#4D2924] rounded-xl px-3 py-2 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
                  />
                </div>
                <div>
                  <label className="text-[#A89689] block mb-1">Date of Birth</label>
                  <input
                    type="date"
                    value={staffFormDob}
                    onChange={(e) => setStaffFormDob(e.target.value)}
                    className="w-full bg-[#241311] border border-[#4D2924] rounded-xl px-3 py-2 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[#A89689] block mb-1">Assigned Role *</label>
                  <select
                    value={staffFormRole}
                    onChange={(e) => setStaffFormRole(e.target.value as StaffRole)}
                    className="w-full bg-[#241311] border border-[#4D2924] rounded-xl px-2.5 py-2 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
                  >
                    <option value="cashier">Cashier</option>
                    {currentStaff?.role !== 'branch_manager' && (
                      <>
                        <option value="branch_manager">Branch Manager</option>
                        <option value="corporate_admin">Corporate Admin</option>
                        <option value="super_admin">Super Administrator</option>
                      </>
                    )}
                    <option value="kitchen_lead">Kitchen Lead</option>
                    <option value="storekeeper">Storekeeper</option>
                    <option value="customer_care">Customer Care</option>
                    <option value="rider">Dispatch Rider</option>
                    {currentStaff?.role !== 'branch_manager' && (
                      <>
                        <option value="auditor">Auditor</option>
                        <option value="accountant">Accountant / Finance</option>
                      </>
                    )}
                  </select>
                </div>

                <div>
                  <label className="text-[#A89689] block mb-1">Primary Home Branch *</label>
                  <select
                    value={staffFormBranch}
                    onChange={(e) => setStaffFormBranch(e.target.value as BranchId)}
                    disabled={currentStaff?.role === 'branch_manager'}
                    className="w-full bg-[#241311] border border-[#4D2924] rounded-xl px-2.5 py-2 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700] disabled:opacity-60"
                  >
                    {branches
                      .filter((b) => currentStaff?.role !== 'branch_manager' || b.id === currentStaff?.branchId)
                      .map((b) => (
                        <option key={b.id} value={b.id}>
                          {b.shortName || b.name}
                        </option>
                      ))}
                  </select>
                </div>
              </div>

              {/* Multi-Branch Operational Privileges */}
              <div className="bg-[#1C1210] p-3 rounded-xl border border-[#4D2924]">
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-[#FFC700]">
                    Permitted Operational Branches
                  </label>
                  <span className="text-[10px] text-[#A89689]">
                    {currentStaff?.role === 'branch_manager' ? 'Branch Manager Scoped' : 'Multi-branch access'}
                  </span>
                </div>
                <p className="text-[11px] text-[#A89689] mb-2.5">
                  {currentStaff?.role === 'branch_manager'
                    ? 'Branch managers can only manage staff assigned to their home branch.'
                    : 'Select all restaurant locations this staff member can access and manage:'}
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  {branches.map((b) => {
                    const isBranchMgr = currentStaff?.role === 'branch_manager';
                    const isSelfBranch = b.id === currentStaff?.branchId;
                    const isChecked = staffFormAllowedBranches.includes(b.id) || staffFormBranch === b.id;
                    return (
                      <label
                        key={b.id}
                        className={`flex items-center gap-2 p-2 rounded-lg border text-xs cursor-pointer transition-colors ${
                          isChecked
                            ? 'bg-[#800D15]/40 border-[#FFC700] text-[#FAF7F2]'
                            : 'bg-[#241311] border-[#36221E] text-[#A89689]'
                        } ${isBranchMgr && !isSelfBranch ? 'opacity-40 cursor-not-allowed' : ''}`}
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          disabled={staffFormBranch === b.id || (isBranchMgr && !isSelfBranch)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setStaffFormAllowedBranches((prev) => Array.from(new Set([...prev, b.id])));
                            } else {
                              if (staffFormAllowedBranches.length > 1) {
                                setStaffFormAllowedBranches((prev) => prev.filter((id) => id !== b.id));
                              }
                            }
                          }}
                          className="accent-[#FFC700] rounded"
                        />
                        <span className="truncate">{b.shortName || b.name}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* Guarantor & Compliance Details (CR-13) */}
              <div className="bg-[#1C1210] p-3 rounded-xl border border-[#4D2924] space-y-2.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-[#FFC700]">Guarantor & Compliance Verification</label>
                  <span className="text-[10px] text-[#A89689]">Operational Due Diligence</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <div>
                    <label className="text-[10px] text-[#A89689] block mb-0.5">Guarantor Full Name</label>
                    <input
                      type="text"
                      placeholder="e.g. Chief Osasere Igbinedion"
                      value={staffFormGuarantorName}
                      onChange={(e) => setStaffFormGuarantorName(e.target.value)}
                      className="w-full bg-[#241311] border border-[#36221E] rounded-lg px-2.5 py-1.5 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-[#A89689] block mb-0.5">Guarantor Phone</label>
                    <input
                      type="tel"
                      placeholder="e.g. 08033001122"
                      value={staffFormGuarantorPhone}
                      onChange={(e) => setStaffFormGuarantorPhone(e.target.value)}
                      className="w-full bg-[#241311] border border-[#36221E] rounded-lg px-2.5 py-1.5 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <div>
                    <label className="text-[10px] text-[#A89689] block mb-0.5">Relationship</label>
                    <input
                      type="text"
                      placeholder="e.g. Uncle / Civil Servant"
                      value={staffFormGuarantorRel}
                      onChange={(e) => setStaffFormGuarantorRel(e.target.value)}
                      className="w-full bg-[#241311] border border-[#36221E] rounded-lg px-2.5 py-1.5 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-[#A89689] block mb-0.5">Guarantor Workplace</label>
                    <input
                      type="text"
                      placeholder="e.g. Edo State Ministry of Health"
                      value={staffFormGuarantorWorkplace}
                      onChange={(e) => setStaffFormGuarantorWorkplace(e.target.value)}
                      className="w-full bg-[#241311] border border-[#36221E] rounded-lg px-2.5 py-1.5 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-[10px] text-[#A89689] block mb-0.5">Guarantor Residential Address</label>
                  <input
                    type="text"
                    placeholder="e.g. 14 Boundary Road, GRA, Benin City"
                    value={staffFormGuarantorAddress}
                    onChange={(e) => setStaffFormGuarantorAddress(e.target.value)}
                    className="w-full bg-[#241311] border border-[#36221E] rounded-lg px-2.5 py-1.5 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
                  />
                </div>
              </div>

              {!editingStaffAccount && (
                <div>
                  <PasswordInput
                    label="Initial Password *"
                    required
                    value={staffFormPassword}
                    onChange={(e) => setStaffFormPassword(e.target.value)}
                    className="bg-[#241311] border-[#4D2924] text-[#FAF7F2]"
                    autoComplete="new-password"
                    minLength={8}
                  />
                </div>
              )}

              {editingStaffAccount && (
                <div>
                  <label className="text-[#A89689] block mb-1">Account Status</label>
                  <select
                    value={staffFormStatus}
                    onChange={(e) => setStaffFormStatus(e.target.value as any)}
                    className="w-full bg-[#241311] border border-[#4D2924] rounded-xl px-2.5 py-2 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
                  >
                    <option value="active">Active</option>
                    <option value="suspended">Suspended</option>
                    <option value="deactivated">Deactivated</option>
                  </select>
                </div>
              )}
            </div>

            <div className="flex gap-2 pt-3 border-t border-[#36221E]">
              <button
                type="button"
                onClick={() => setIsStaffModalOpen(false)}
                className="flex-1 py-2.5 bg-[#241311] text-[#A89689] font-bold rounded-xl"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 py-2.5 bg-[#FFC700] hover:bg-[#E6B200] text-[#4D080F] font-black rounded-xl"
              >
                {editingStaffAccount ? 'Update Staff' : 'Save Staff Account'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* 10. Fleet & Network Hardware Thermal Printer Manager (TCP 9100 / ESC POS) */}
      <HardwarePrinterModal
        isOpen={isHardwarePrinterOpen}
        onClose={() => setIsHardwarePrinterOpen(false)}
      />

      {/* 11. Optical Camera & Hardware USB/Bluetooth Barcode Dispatch Scanner */}
      <BarcodeDispatchScanner
        isOpen={isBarcodeScannerOpen}
        onClose={() => setIsBarcodeScannerOpen(false)}
        activeBranchId={activeBranchId}
        onScanSuccess={(result) => {
          showToast(result.message || 'Barcode scan action completed successfully!');
          fetchDispatch();
          fetchTablesAndChecks();
        }}
      />

      {/* 12. Effective Access Viewer Modal (ChopLife RBAC Inspector) */}
      <EffectiveAccessModal
        staffId={effectiveAccessStaffId}
        isOpen={isEffectiveAccessOpen}
        onClose={() => {
          setIsEffectiveAccessOpen(false);
          setEffectiveAccessStaffId(null);
        }}
        showToast={(msg) => showToast(msg, 'success')}
      />

      {/* 13. Change Password & Generate Recovery PIN Modal (Part D Section 16) */}
      {resetCredentialsModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#1C1210] border-2 border-[#FFC700] rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4 animate-in zoom-in-95 text-xs text-[#FAF7F2]">
            <div className="flex items-center justify-between border-b border-[#36221E] pb-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-[#FFC700]/20 text-[#FFC700] flex items-center justify-center font-bold text-lg">
                  🔑
                </div>
                <div>
                  <h3 className="font-titan text-base text-[#FAF7F2]">Change Password & Recovery PIN</h3>
                  <p className="text-[11px] text-[#A89689]">
                    Account: <strong className="text-[#FFC700]">{resetCredentialsModal.name}</strong> ({resetCredentialsModal.staffId})
                  </p>
                </div>
              </div>
              <button
                onClick={() => setResetCredentialsModal(null)}
                className="text-[#A89689] hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Direct Password Set with Live Policy Checklist */}
            <div className="bg-[#160E0C] p-4 rounded-2xl border border-[#36221E] space-y-3">
              <PasswordInput
                label="Set New Password"
                value={adminNewPasswordInput}
                onChange={(e) => setAdminNewPasswordInput(e.target.value)}
                className="bg-[#241311] border-[#4D2924] text-[#FAF7F2]"
                placeholder="Enter new password..."
              />
              <div className="space-y-1 text-[11px]">
                <div className="flex items-center gap-1.5">
                  <span className={adminNewPasswordInput.length >= 8 ? 'text-emerald-400' : 'text-[#A89689]'}>
                    {adminNewPasswordInput.length >= 8 ? '✓' : '○'}
                  </span>
                  <span>At least 8 characters long</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className={/[A-Za-z]/.test(adminNewPasswordInput) ? 'text-emerald-400' : 'text-[#A89689]'}>
                    {/[A-Za-z]/.test(adminNewPasswordInput) ? '✓' : '○'}
                  </span>
                  <span>Contains at least one letter (A–Z)</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span
                    className={
                      /[0-9!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(adminNewPasswordInput)
                        ? 'text-emerald-400'
                        : 'text-[#A89689]'
                    }
                  >
                    {/[0-9!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(adminNewPasswordInput) ? '✓' : '○'}
                  </span>
                  <span>Contains at least one number or symbol</span>
                </div>
              </div>

              <div className="flex gap-2 pt-1">
                <button
                  type="button"
                  disabled={
                    isResetSubmitting ||
                    adminNewPasswordInput.length < 8 ||
                    !/[A-Za-z]/.test(adminNewPasswordInput) ||
                    !/[0-9!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(adminNewPasswordInput)
                  }
                  onClick={handleSaveAdminPasswordReset}
                  className="flex-1 py-2.5 bg-[#FFC700] hover:bg-[#E6B200] disabled:opacity-40 text-[#4D080F] font-black rounded-xl transition-colors"
                >
                  Save New Password
                </button>
                <button
                  type="button"
                  disabled={isResetSubmitting}
                  onClick={handleGenerateStaffRecoveryPin}
                  className="px-3.5 py-2.5 bg-[#241311] hover:bg-[#36221E] border border-[#FFC700]/50 text-[#FFC700] font-bold rounded-xl transition-colors"
                >
                  Generate PIN
                </button>
              </div>
            </div>

            {resetCredentialsModal.tempPass && (
              <div className="bg-emerald-950/40 p-3.5 rounded-2xl border border-emerald-500/40 space-y-1.5">
                <span className="text-[10px] font-bold text-emerald-300 uppercase tracking-wider block">
                  One-Time Temporary Password (Bcrypt Hashed):
                </span>
                <div className="flex items-center justify-between bg-[#120B0A] px-3 py-2 rounded-xl font-mono text-sm font-bold text-[#FFC700]">
                  <span>{resetCredentialsModal.tempPass}</span>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(resetCredentialsModal.tempPass || '');
                      showToast('Password copied to clipboard!', 'success');
                    }}
                    className="text-xs font-montserrat font-bold bg-[#FFC700] text-[#4D080F] px-2.5 py-1 rounded-lg"
                  >
                    Copy
                  </button>
                </div>
              </div>
            )}

            {resetCredentialsModal.recoveryPin && (
              <div className="bg-[#241311] p-3.5 rounded-2xl border border-[#FFC700]/60 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-[#FFC700] uppercase tracking-wider">
                    Single-Use Recovery PIN (15-Min Expiry):
                  </span>
                  <span className="text-[10px] text-[#A89689]">Invalidates prior PINs</span>
                </div>
                <div className="flex items-center justify-between bg-[#120B0A] px-3 py-2 rounded-xl font-mono text-base font-bold text-[#FFC700] tracking-widest">
                  <span>{resetCredentialsModal.recoveryPin}</span>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(resetCredentialsModal.recoveryPin || '');
                      showToast('Recovery PIN copied to clipboard!', 'success');
                    }}
                    className="text-xs font-montserrat font-bold bg-[#FFC700] text-[#4D080F] px-2.5 py-1 rounded-lg"
                  >
                    Copy PIN
                  </button>
                </div>
                <p className="text-[10px] text-[#A89689]">
                  Staff member can enter this PIN on the Staff Login &rarr; Forgot Password screen to set their own password.
                </p>
              </div>
            )}

            <button
              onClick={() => setResetCredentialsModal(null)}
              className="w-full py-2.5 bg-[#241311] hover:bg-[#36221E] text-[#FAF7F2] font-bold text-xs rounded-xl transition-colors border border-[#36221E]"
            >
              Close Window
            </button>
          </div>
        </div>
      )}

      {/* Mobile Bottom Navigation Bar (Screens < md) */}
      <nav className="md:hidden bg-[#160E0C] border-t border-[#36221E] px-2 py-1 flex items-center justify-around z-30 shrink-0">
        <button
          onClick={() => { setActiveTab('pos'); setIsMobileNavOpen(false); }}
          className={`flex flex-col items-center justify-center p-1.5 min-w-[56px] min-h-[44px] rounded-xl transition-all ${
            activeTab === 'pos' ? 'text-[#FFC700] bg-[#800D15]/40' : 'text-[#A89689]'
          }`}
        >
          <Store className="w-5 h-5" />
          <span className="text-[10px] font-bold mt-0.5">Register</span>
        </button>
        <button
          onClick={() => { setActiveTab('tables'); setIsMobileNavOpen(false); }}
          className={`flex flex-col items-center justify-center p-1.5 min-w-[56px] min-h-[44px] rounded-xl transition-all ${
            activeTab === 'tables' ? 'text-[#FFC700] bg-[#800D15]/40' : 'text-[#A89689]'
          }`}
        >
          <LayoutGrid className="w-5 h-5" />
          <span className="text-[10px] font-bold mt-0.5">Tables</span>
        </button>
        <button
          onClick={() => { setActiveTab('kds'); setIsMobileNavOpen(false); }}
          className={`flex flex-col items-center justify-center p-1.5 min-w-[56px] min-h-[44px] rounded-xl relative transition-all ${
            activeTab === 'kds' ? 'text-[#FFC700] bg-[#800D15]/40' : 'text-[#A89689]'
          }`}
        >
          <ChefHat className="w-5 h-5" />
          {kdsTickets.length > 0 && (
            <span className="absolute top-1 right-2 px-1 bg-[#EF4444] text-white text-[9px] font-extrabold rounded-full">
              {kdsTickets.length}
            </span>
          )}
          <span className="text-[10px] font-bold mt-0.5">Kitchen</span>
        </button>
        <button
          onClick={() => { setActiveTab('dispatch'); setIsMobileNavOpen(false); }}
          className={`flex flex-col items-center justify-center p-1.5 min-w-[56px] min-h-[44px] rounded-xl transition-all ${
            activeTab === 'dispatch' ? 'text-[#FFC700] bg-[#800D15]/40' : 'text-[#A89689]'
          }`}
        >
          <Truck className="w-5 h-5" />
          <span className="text-[10px] font-bold mt-0.5">Delivery</span>
        </button>
        <button
          onClick={() => setIsMobileNavOpen(true)}
          className="flex flex-col items-center justify-center p-1.5 min-w-[56px] min-h-[44px] rounded-xl text-[#A89689] hover:text-[#FAF7F2] active:scale-95 transition-all"
        >
          <Menu className="w-5 h-5" />
          <span className="text-[10px] font-bold mt-0.5">More</span>
        </button>
      </nav>
    </div>
  );
};
