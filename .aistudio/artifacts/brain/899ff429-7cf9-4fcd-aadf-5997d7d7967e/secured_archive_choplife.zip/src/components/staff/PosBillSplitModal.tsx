import React, { useState } from 'react';
import {
  Split,
  X,
  CreditCard,
  Banknote,
  Users,
  CheckCircle2,
  ArrowRight,
  MoveRight,
  UtensilsCrossed,
} from 'lucide-react';

interface PosBillSplitModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeCheck: any;
  onSettleSplit: (splitDetails: any) => void;
  showToast: (msg: string, type?: 'success' | 'error') => void;
}

export const PosBillSplitModal: React.FC<PosBillSplitModalProps> = ({
  isOpen,
  onClose,
  activeCheck,
  onSettleSplit,
  showToast,
}) => {
  const [splitWays, setSplitWays] = useState<number>(2);
  const [splitMethod, setSplitMethod] = useState<'cash' | 'pos_terminal' | 'split'>('cash');
  const [splitCashAmount, setSplitCashAmount] = useState<string>('');
  const [splitPosAmount, setSplitPosAmount] = useState<string>('');

  if (!isOpen || !activeCheck) return null;

  const total = activeCheck.total || 0;
  const perPersonShare = Math.round(total / splitWays);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (splitMethod === 'split') {
      const cashNum = Number(splitCashAmount) || 0;
      const posNum = Number(splitPosAmount) || 0;
      if (cashNum + posNum < total) {
        showToast(`Total tendered (₦${(cashNum + posNum).toLocaleString()}) is less than total due (₦${total.toLocaleString()})`, 'error');
        return;
      }
      onSettleSplit({
        paymentMethod: 'split',
        paymentDetails: {
          splitWays,
          splitCashAmount: cashNum,
          splitPosAmount: posNum,
          note: `Split ₦${cashNum.toLocaleString()} Cash + ₦${posNum.toLocaleString()} POS Card`,
        },
      });
    } else {
      onSettleSplit({
        paymentMethod: splitMethod,
        paymentDetails: {
          splitWays,
          splitCashAmount: splitMethod === 'cash' ? total : 0,
          splitPosAmount: splitMethod === 'pos_terminal' ? total : 0,
          note: `Equal ${splitWays}-way split (₦${perPersonShare.toLocaleString()} each)`,
        },
      });
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#1C1210] border border-[#36221E] rounded-2xl max-w-md w-full p-5 space-y-4 shadow-2xl animate-in zoom-in-95">
        <div className="flex items-center justify-between border-b border-[#36221E] pb-3">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-[#800D15] rounded-xl text-[#FFC700]">
              <Split className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-base text-[#FAF7F2]">Split Check #{activeCheck.checkNumber}</h3>
              <p className="text-xs text-[#A89689]">
                {activeCheck.tableNumber || 'Direct Table'} • Total: ₦{total.toLocaleString()}
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-[#A89689] hover:text-[#FAF7F2]">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          {/* Split Count Selector */}
          <div className="space-y-1.5">
            <label className="text-[#A89689] font-semibold">Number of Ways to Split</label>
            <div className="grid grid-cols-5 gap-2">
              {[2, 3, 4, 5, 6].map((num) => (
                <button
                  type="button"
                  key={num}
                  onClick={() => setSplitWays(num)}
                  className={`py-2 rounded-xl font-mono font-bold text-xs border transition-all ${
                    splitWays === num
                      ? 'bg-[#FFC700] text-[#4D080F] border-[#FFC700] shadow'
                      : 'bg-[#241311] text-[#FAF7F2] border-[#36221E] hover:border-[#4D2924]'
                  }`}
                >
                  {num} Ways
                </button>
              ))}
            </div>
          </div>

          {/* Equal Share Breakdown Box */}
          <div className="p-3.5 bg-[#241311] border border-[#36221E] rounded-xl space-y-2 text-center">
            <span className="text-[10px] uppercase font-bold text-[#A89689] tracking-wider">
              Each Guest Pays
            </span>
            <div className="font-mono font-black text-2xl text-[#FFC700]">
              ₦{perPersonShare.toLocaleString()}
            </div>
            <p className="text-[11px] text-[#A89689]">
              {splitWays} equal shares of ₦{perPersonShare.toLocaleString()} = ₦{(perPersonShare * splitWays).toLocaleString()}
            </p>
          </div>

          {/* Settle Mode */}
          <div className="space-y-1.5">
            <label className="text-[#A89689] font-semibold">Payment Settlement Method</label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setSplitMethod('cash')}
                className={`p-2.5 rounded-xl border flex flex-col items-center gap-1 transition-all ${
                  splitMethod === 'cash'
                    ? 'bg-[#800D15] border-[#FFC700] text-white'
                    : 'bg-[#241311] border-[#36221E] text-[#A89689]'
                }`}
              >
                <Banknote className="w-4 h-4 text-[#FFC700]" />
                <span className="font-bold text-[11px] text-[#FAF7F2]">All Cash</span>
              </button>

              <button
                type="button"
                onClick={() => setSplitMethod('pos_terminal')}
                className={`p-2.5 rounded-xl border flex flex-col items-center gap-1 transition-all ${
                  splitMethod === 'pos_terminal'
                    ? 'bg-[#800D15] border-[#FFC700] text-white'
                    : 'bg-[#241311] border-[#36221E] text-[#A89689]'
                }`}
              >
                <CreditCard className="w-4 h-4 text-[#FFC700]" />
                <span className="font-bold text-[11px] text-[#FAF7F2]">All POS Card</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setSplitMethod('split');
                  setSplitCashAmount(String(perPersonShare));
                  setSplitPosAmount(String(total - perPersonShare));
                }}
                className={`p-2.5 rounded-xl border flex flex-col items-center gap-1 transition-all ${
                  splitMethod === 'split'
                    ? 'bg-[#800D15] border-[#FFC700] text-white'
                    : 'bg-[#241311] border-[#36221E] text-[#A89689]'
                }`}
              >
                <Split className="w-4 h-4 text-[#FFC700]" />
                <span className="font-bold text-[11px] text-[#FAF7F2]">Mixed Tender</span>
              </button>
            </div>
          </div>

          {/* Mixed Tender Breakdown Inputs */}
          {splitMethod === 'split' && (
            <div className="p-3 bg-[#241311] border border-[#36221E] rounded-xl space-y-2.5">
              <span className="text-[10px] uppercase font-bold text-[#A89689]">Mixed Tender Breakdown</span>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] text-[#A89689]">Cash Tendered (₦)</label>
                  <input
                    type="number"
                    value={splitCashAmount}
                    onChange={(e) => setSplitCashAmount(e.target.value)}
                    className="w-full bg-[#1C1210] border border-[#4D2924] rounded-lg px-2.5 py-1.5 text-xs font-mono text-[#FAF7F2]"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-[#A89689]">POS Card Tendered (₦)</label>
                  <input
                    type="number"
                    value={splitPosAmount}
                    onChange={(e) => setSplitPosAmount(e.target.value)}
                    className="w-full bg-[#1C1210] border border-[#4D2924] rounded-lg px-2.5 py-1.5 text-xs font-mono text-[#FAF7F2]"
                  />
                </div>
              </div>
            </div>
          )}

          <div className="flex gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 bg-[#241311] hover:bg-[#36221E] text-[#A89689] font-bold text-xs rounded-xl"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 py-2.5 bg-[#22C55E] hover:bg-[#16A34A] text-[#120B0A] font-black text-xs rounded-xl shadow-md transition-all"
            >
              Settle Split Bill (₦{total.toLocaleString()})
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

interface PosTableTransferModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeCheck: any;
  tables: any[];
  onTransfer: (newTableId: string, newTableNumber: string) => void;
  showToast: (msg: string, type?: 'success' | 'error') => void;
}

export const PosTableTransferModal: React.FC<PosTableTransferModalProps> = ({
  isOpen,
  onClose,
  activeCheck,
  tables,
  onTransfer,
  showToast,
}) => {
  const [selectedTableId, setSelectedTableId] = useState<string>('');

  if (!isOpen || !activeCheck) return null;

  const currentTableId = activeCheck.tableId;
  const availableTables = tables.filter((t) => t.id !== currentTableId && t.status === 'available');

  const handleConfirm = () => {
    if (!selectedTableId) {
      showToast('Please select a destination table', 'error');
      return;
    }
    const target = tables.find((t) => t.id === selectedTableId);
    onTransfer(selectedTableId, target?.tableNumber || selectedTableId);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#1C1210] border border-[#36221E] rounded-2xl max-w-md w-full p-5 space-y-4 shadow-2xl animate-in zoom-in-95">
        <div className="flex items-center justify-between border-b border-[#36221E] pb-3">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-[#800D15] rounded-xl text-[#FFC700]">
              <MoveRight className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-base text-[#FAF7F2]">Transfer Table</h3>
              <p className="text-xs text-[#A89689]">
                Move Check #{activeCheck.checkNumber} ({activeCheck.tableNumber || 'Current Table'})
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-[#A89689] hover:text-[#FAF7F2]">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-3 text-xs">
          <p className="text-[#A89689]">
            Select an available table to transfer this guest check. The current table will be automatically marked available.
          </p>

          <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 max-h-56 overflow-y-auto p-1">
            {availableTables.map((t) => {
              const isSelected = selectedTableId === t.id;
              return (
                <button
                  type="button"
                  key={t.id}
                  onClick={() => setSelectedTableId(t.id)}
                  className={`p-3 rounded-xl border flex flex-col items-center gap-1 transition-all ${
                    isSelected
                      ? 'bg-[#800D15] border-[#FFC700] text-white shadow-md'
                      : 'bg-[#241311] border-[#36221E] text-[#FAF7F2] hover:border-[#4D2924]'
                  }`}
                >
                  <UtensilsCrossed className={`w-4 h-4 ${isSelected ? 'text-[#FFC700]' : 'text-[#A89689]'}`} />
                  <span className="font-bold text-xs">Table {t.tableNumber}</span>
                  <span className="text-[10px] opacity-75">{t.capacity} Seats</span>
                </button>
              );
            })}
          </div>

          {availableTables.length === 0 && (
            <div className="p-4 bg-[#241311] rounded-xl text-center text-[#A89689]">
              No other tables are currently available for transfer.
            </div>
          )}
        </div>

        <div className="flex gap-2 pt-2">
          <button
            type="button"
            onClick={onClose}
            className="flex-1 py-2.5 bg-[#241311] hover:bg-[#36221E] text-[#A89689] font-bold text-xs rounded-xl"
          >
            Cancel
          </button>
          <button
            type="button"
            disabled={!selectedTableId}
            onClick={handleConfirm}
            className="flex-1 py-2.5 bg-[#FFC700] hover:bg-[#E5B200] disabled:opacity-50 text-[#4D080F] font-black text-xs rounded-xl shadow-md transition-all"
          >
            Confirm Transfer
          </button>
        </div>
      </div>
    </div>
  );
};
