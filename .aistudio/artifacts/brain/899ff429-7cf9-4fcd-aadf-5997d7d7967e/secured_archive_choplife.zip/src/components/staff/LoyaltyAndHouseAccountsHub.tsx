import React, { useState, useEffect } from 'react';
import { BranchId, StaffUser, CustomerAccount, CorporateHouseAccount, WalletTransaction, HouseAccountCharge, HouseAccountPayment, CustomerTier } from '../../types';
import {
  Award,
  Wallet,
  Building,
  CreditCard,
  Search,
  Plus,
  ArrowUpRight,
  ArrowDownLeft,
  CheckCircle2,
  Clock,
  User,
  Phone,
  Mail,
  Shield,
  FileText,
  DollarSign,
  Gift,
  RefreshCw,
  X,
  AlertCircle,
  Calendar,
  Sparkles,
  Printer,
  ChevronRight,
  TrendingUp,
} from 'lucide-react';

interface LoyaltyAndHouseAccountsHubProps {
  activeBranchId: BranchId;
  currentStaff: StaffUser;
  showToast: (msg: string, type?: 'success' | 'error') => void;
}

export const LoyaltyAndHouseAccountsHub: React.FC<LoyaltyAndHouseAccountsHubProps> = ({
  activeBranchId,
  currentStaff,
  showToast,
}) => {
  const [activeTab, setActiveTab] = useState<'loyalty' | 'house_accounts'>('loyalty');
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // Customer Loyalty State
  const [customers, setCustomers] = useState<CustomerAccount[]>([]);
  const [customerSearch, setCustomerSearch] = useState<string>('');
  const [tierFilter, setTierFilter] = useState<string>('all');
  const [branchFilter, setBranchFilter] = useState<string>('all');
  const [loyaltyStats, setLoyaltyStats] = useState({
    totalMembers: 0,
    totalWalletLiability: 0,
    totalPointsOutstanding: 0,
    totalLifetimeSpend: 0,
  });

  // Selected Customer for Ledger / Details
  const [selectedCustomer, setSelectedCustomer] = useState<CustomerAccount | null>(null);
  const [customerTransactions, setCustomerTransactions] = useState<WalletTransaction[]>([]);
  const [isCustomerModalOpen, setIsCustomerModalOpen] = useState<boolean>(false);
  const [isRegisterModalOpen, setIsRegisterModalOpen] = useState<boolean>(false);
  const [isTopupModalOpen, setIsTopupModalOpen] = useState<boolean>(false);
  const [isRedeemPointsModalOpen, setIsRedeemPointsModalOpen] = useState<boolean>(false);

  // Topup form
  const [topupAmount, setTopupAmount] = useState<string>('10000');
  const [topupMethod, setTopupMethod] = useState<'pos_terminal' | 'cash' | 'bank_transfer'>('pos_terminal');
  const [topupReference, setTopupReference] = useState<string>('');
  const [topupNote, setTopupNote] = useState<string>('');

  // Redeem points form
  const [pointsToRedeemInput, setPointsToRedeemInput] = useState<string>('100');

  // Customer Register form
  const [newCustName, setNewCustName] = useState<string>('');
  const [newCustPhone, setNewCustPhone] = useState<string>('+234 ');
  const [newCustEmail, setNewCustEmail] = useState<string>('');
  const [newCustBranch, setNewCustBranch] = useState<BranchId>('gra');
  const [newCustPin, setNewCustPin] = useState<string>('1234');
  const [newCustBirthday, setNewCustBirthday] = useState<string>('');
  const [newCustNotes, setNewCustNotes] = useState<string>('');

  // Corporate House Accounts State
  const [houseAccounts, setHouseAccounts] = useState<CorporateHouseAccount[]>([]);
  const [houseAccountStats, setHouseAccountStats] = useState({
    totalAccounts: 0,
    totalCreditLimit: 0,
    totalOutstanding: 0,
    totalAvailableCredit: 0,
  });
  const [selectedHouseAccount, setSelectedHouseAccount] = useState<CorporateHouseAccount | null>(null);
  const [accountCharges, setAccountCharges] = useState<HouseAccountCharge[]>([]);
  const [accountPayments, setAccountPayments] = useState<HouseAccountPayment[]>([]);

  // Modals for Corporate Accounts
  const [isCreateAccountModalOpen, setIsCreateAccountModalOpen] = useState<boolean>(false);
  const [isDirectChargeModalOpen, setIsDirectChargeModalOpen] = useState<boolean>(false);
  const [isRecordPaymentModalOpen, setIsRecordPaymentModalOpen] = useState<boolean>(false);
  const [isStatementModalOpen, setIsStatementModalOpen] = useState<boolean>(false);

  // New Corporate Account form
  const [newCorpName, setNewCorpName] = useState<string>('');
  const [newCorpCode, setNewCorpCode] = useState<string>('');
  const [newCorpContact, setNewCorpContact] = useState<string>('');
  const [newCorpPhone, setNewCorpPhone] = useState<string>('+234 ');
  const [newCorpEmail, setNewCorpEmail] = useState<string>('');
  const [newCorpAddress, setNewCorpAddress] = useState<string>('Benin City, Edo State');
  const [newCorpCreditLimit, setNewCorpCreditLimit] = useState<string>('1000000');
  const [newCorpTerms, setNewCorpTerms] = useState<'net_7' | 'net_15' | 'net_30'>('net_30');
  const [newCorpBranch, setNewCorpBranch] = useState<BranchId | 'all'>('all');
  const [newCorpSignerName, setNewCorpSignerName] = useState<string>('');
  const [newCorpSignerRole, setNewCorpSignerRole] = useState<string>('Director');
  const [newCorpSignerPhone, setNewCorpSignerPhone] = useState<string>('');
  const [newCorpBillingNotes, setNewCorpBillingNotes] = useState<string>('');

  // Direct Charge form
  const [chargeAmount, setChargeAmount] = useState<string>('');
  const [chargeSigner, setChargeSigner] = useState<string>('');
  const [chargeDept, setChargeDept] = useState<string>('Executive Luncheon');
  const [chargeCheckNo, setChargeCheckNo] = useState<string>('');
  const [chargeNotes, setChargeNotes] = useState<string>('');

  // Record Payment form
  const [paymentAmount, setPaymentAmount] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<'bank_transfer' | 'cheque' | 'pos_terminal' | 'cash'>('bank_transfer');
  const [paymentRef, setPaymentRef] = useState<string>('');
  const [paymentNotes, setPaymentNotes] = useState<string>('');

  const getAuthHeaders = (extra: Record<string, string> = {}) => {
    const token = localStorage.getItem('choplife_staff_token') || '';
    return {
      Authorization: `Bearer ${token}`,
      ...extra,
    };
  };

  // Fetch Customers
  const fetchCustomers = async () => {
    try {
      setIsLoading(true);
      const params = new URLSearchParams();
      if (customerSearch) params.append('search', customerSearch);
      if (tierFilter !== 'all') params.append('tier', tierFilter);
      if (branchFilter !== 'all') params.append('branchId', branchFilter);

      const res = await fetch(`/api/customers?${params.toString()}`, {
        headers: getAuthHeaders(),
      });
      if (res.ok) {
        const data = await res.json();
        setCustomers(data.customers || []);
        if (data.stats) setLoyaltyStats(data.stats);
      }
    } catch (err) {
      console.error('Failed to load customers:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Fetch House Accounts
  const fetchHouseAccounts = async () => {
    try {
      setIsLoading(true);
      const res = await fetch('/api/house-accounts', {
        headers: getAuthHeaders(),
      });
      if (res.ok) {
        const data = await res.json();
        setHouseAccounts(data.accounts || []);
        if (data.stats) setHouseAccountStats(data.stats);
      }
    } catch (err) {
      console.error('Failed to load corporate house accounts:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (activeTab === 'loyalty') {
      fetchCustomers();
    } else {
      fetchHouseAccounts();
    }
  }, [activeTab, customerSearch, tierFilter, branchFilter]);

  // Load single customer details
  const viewCustomerDetails = async (cust: CustomerAccount) => {
    setSelectedCustomer(cust);
    try {
      const res = await fetch(`/api/customers/${cust.id}`, {
        headers: getAuthHeaders(),
      });
      if (res.ok) {
        const data = await res.json();
        setSelectedCustomer(data.customer);
        setCustomerTransactions(data.transactions || []);
        setIsCustomerModalOpen(true);
      }
    } catch (err) {
      console.error(err);
      setIsCustomerModalOpen(true);
    }
  };

  // Load single corporate account details
  const viewHouseAccountDetails = async (acc: CorporateHouseAccount) => {
    setSelectedHouseAccount(acc);
    try {
      const res = await fetch(`/api/house-accounts/${acc.id}`, {
        headers: getAuthHeaders(),
      });
      if (res.ok) {
        const data = await res.json();
        setSelectedHouseAccount(data.account);
        setAccountCharges(data.charges || []);
        setAccountPayments(data.payments || []);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Register Customer Handler
  const handleRegisterCustomer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCustName.trim() || !newCustPhone.trim()) {
      showToast('Please enter customer name and phone number.', 'error');
      return;
    }

    try {
      const res = await fetch('/api/customers', {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          name: newCustName,
          phone: newCustPhone,
          email: newCustEmail || undefined,
          preferredBranchId: newCustBranch,
          walletPin: newCustPin || '1234',
          birthday: newCustBirthday,
          notes: newCustNotes,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to register customer');

      showToast(`VIP Member ${data.customer.name} registered with 50 bonus points!`, 'success');
      setIsRegisterModalOpen(false);
      setNewCustName('');
      setNewCustPhone('+234 ');
      setNewCustEmail('');
      setNewCustNotes('');
      fetchCustomers();
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  // Top-Up Wallet Handler
  const handleTopupWallet = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCustomer) return;
    const amt = Number(topupAmount);
    if (isNaN(amt) || amt <= 0) {
      showToast('Please enter a valid top-up amount.', 'error');
      return;
    }

    try {
      const res = await fetch(`/api/customers/${selectedCustomer.id}/topup`, {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          amount: amt,
          paymentMethod: topupMethod,
          reference: topupReference || undefined,
          note: topupNote || undefined,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to credit wallet');

      showToast(`Successfully credited ₦${amt.toLocaleString()} to ${data.customer.name}'s wallet!`, 'success');
      setSelectedCustomer(data.customer);
      setIsTopupModalOpen(false);
      setTopupReference('');
      setTopupNote('');
      fetchCustomers();
      // Refresh transactions
      viewCustomerDetails(data.customer);
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  // Redeem Points Handler
  const handleRedeemPoints = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCustomer) return;
    const pts = Number(pointsToRedeemInput);
    if (isNaN(pts) || pts <= 0) {
      showToast('Please specify positive points to redeem.', 'error');
      return;
    }

    try {
      const res = await fetch(`/api/customers/${selectedCustomer.id}/redeem-points`, {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({ pointsToRedeem: pts }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Redemption failed');

      showToast(`Redeemed ${pts} points for ₦${data.creditValue.toLocaleString()} wallet stored credit!`, 'success');
      setSelectedCustomer(data.customer);
      setIsRedeemPointsModalOpen(false);
      fetchCustomers();
      viewCustomerDetails(data.customer);
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  // Claim 10-Stamp Card Reward
  const handleClaimStampReward = async (cust: CustomerAccount) => {
    if (cust.stampCount < 10) {
      showToast(`Customer currently has ${cust.stampCount}/10 stamps. 10 stamps are required for complimentary meal.`, 'error');
      return;
    }

    try {
      const res = await fetch(`/api/customers/${cust.id}/redeem-stamp`, {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to claim reward');

      showToast(`🎉 10-Stamp Milestone Reached! ₦${data.rewardCredit.toLocaleString()} meal reward credited to wallet!`, 'success');
      fetchCustomers();
      if (selectedCustomer && selectedCustomer.id === cust.id) {
        setSelectedCustomer(data.customer);
      }
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  // Create Corporate Account Handler
  const handleCreateCorporateAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCorpName.trim() || !newCorpContact.trim() || !newCorpPhone.trim()) {
      showToast('Company name, contact person, and phone are required.', 'error');
      return;
    }

    const signers = [];
    if (newCorpSignerName.trim()) {
      signers.push({
        name: newCorpSignerName.trim(),
        designation: newCorpSignerRole.trim(),
        phone: newCorpSignerPhone.trim() || newCorpPhone.trim(),
      });
    }

    try {
      const res = await fetch('/api/house-accounts', {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          companyName: newCorpName,
          accountCode: newCorpCode ? newCorpCode.toUpperCase() : undefined,
          contactPerson: newCorpContact,
          phone: newCorpPhone,
          email: newCorpEmail,
          address: newCorpAddress,
          creditLimit: Number(newCorpCreditLimit) || 1000000,
          paymentTerms: newCorpTerms,
          authorizedSigners: signers,
          preferredBranchId: newCorpBranch,
          billingNotes: newCorpBillingNotes,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to create corporate account');

      showToast(`Corporate House Account ${data.account.companyName} created!`, 'success');
      setIsCreateAccountModalOpen(false);
      setNewCorpName('');
      setNewCorpCode('');
      setNewCorpContact('');
      setNewCorpPhone('+234 ');
      setNewCorpEmail('');
      setNewCorpSignerName('');
      fetchHouseAccounts();
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  // Direct Charge Handler
  const handleDirectCharge = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedHouseAccount) return;
    const amt = Number(chargeAmount);
    if (isNaN(amt) || amt <= 0) {
      showToast('Please enter a valid charge amount.', 'error');
      return;
    }

    try {
      const res = await fetch(`/api/house-accounts/${selectedHouseAccount.id}/charge`, {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          amount: amt,
          authorizedSigner: chargeSigner || selectedHouseAccount.contactPerson,
          department: chargeDept,
          checkNumber: chargeCheckNo || undefined,
          notes: chargeNotes,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to post charge');

      showToast(`Charged ₦${amt.toLocaleString()} to ${data.account.companyName}!`, 'success');
      setSelectedHouseAccount(data.account);
      setIsDirectChargeModalOpen(false);
      setChargeAmount('');
      setChargeCheckNo('');
      setChargeNotes('');
      fetchHouseAccounts();
      viewHouseAccountDetails(data.account);
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  // Record Corporate Remittance Payment Handler
  const handleRecordPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedHouseAccount) return;
    const amt = Number(paymentAmount);
    if (isNaN(amt) || amt <= 0) {
      showToast('Please enter a valid remittance amount.', 'error');
      return;
    }

    try {
      const res = await fetch(`/api/house-accounts/${selectedHouseAccount.id}/payments`, {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          amount: amt,
          paymentMethod,
          bankReference: paymentRef,
          notes: paymentNotes,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to record payment');

      showToast(`Recorded remittance of ₦${amt.toLocaleString()} from ${data.account.companyName}. Receipt: ${data.payment.receiptNumber}`, 'success');
      setSelectedHouseAccount(data.account);
      setIsRecordPaymentModalOpen(false);
      setPaymentAmount('');
      setPaymentRef('');
      setPaymentNotes('');
      fetchHouseAccounts();
      viewHouseAccountDetails(data.account);
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  const getTierColor = (tier: CustomerTier) => {
    switch (tier) {
      case 'platinum':
        return 'bg-gradient-to-r from-purple-900 to-indigo-900 border-purple-400 text-purple-200';
      case 'gold':
        return 'bg-gradient-to-r from-[#800D15] to-[#B3121E] border-[#FFC700] text-[#FFC700]';
      case 'silver':
        return 'bg-[#2A2A2A] border-gray-400 text-gray-200';
      default:
        return 'bg-[#38201C] border-[#8D5B4C] text-[#E0B8A8]';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header & Sub-Tab Switcher */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-[#1C0F0D] p-5 rounded-2xl border border-[#36221E]">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-[#800D15] border border-[#FFC700]/40 flex items-center justify-center text-[#FFC700] shadow-lg">
            <Award className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold font-serif text-[#FAF7F2] tracking-wide">
              VIP Loyalty, Digital Wallets & Corporate House Accounts
            </h1>
            <p className="text-xs text-[#A89689]">
              Manage patron loyalty tiers, stored-value digital wallets, 10-stamp meal cards, and corporate credit accounts.
            </p>
          </div>
        </div>

        {/* Tab Controls */}
        <div className="flex bg-[#120B0A] p-1 rounded-xl border border-[#36221E] self-stretch sm:self-auto">
          <button
            onClick={() => setActiveTab('loyalty')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'loyalty'
                ? 'bg-[#800D15] text-[#FFC700] shadow-md border border-[#FFC700]/30'
                : 'text-[#C5B4A5] hover:text-[#FAF7F2]'
            }`}
          >
            <Wallet className="w-4 h-4" />
            <span>VIP Loyalty & Wallets</span>
          </button>
          <button
            onClick={() => setActiveTab('house_accounts')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'house_accounts'
                ? 'bg-[#800D15] text-[#FFC700] shadow-md border border-[#FFC700]/30'
                : 'text-[#C5B4A5] hover:text-[#FAF7F2]'
            }`}
          >
            <Building className="w-4 h-4" />
            <span>Corporate House Accounts</span>
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* TAB 1: VIP CUSTOMER LOYALTY & DIGITAL WALLETS */}
      {/* ========================================================================= */}
      {activeTab === 'loyalty' && (
        <div className="space-y-6">
          {/* Top Metrics Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-[#1C0F0D] border border-[#36221E] p-4 rounded-xl">
              <div className="flex items-center justify-between text-xs text-[#A89689] mb-1">
                <span>Enrolled VIP Patrons</span>
                <User className="w-4 h-4 text-[#FFC700]" />
              </div>
              <div className="text-2xl font-bold font-mono text-[#FAF7F2]">
                {loyaltyStats.totalMembers}
              </div>
              <div className="text-[10px] text-emerald-400 mt-1 flex items-center gap-1">
                <Sparkles className="w-3 h-3" /> Active loyalty network
              </div>
            </div>

            <div className="bg-[#1C0F0D] border border-[#36221E] p-4 rounded-xl">
              <div className="flex items-center justify-between text-xs text-[#A89689] mb-1">
                <span>Stored Wallet Deposits</span>
                <Wallet className="w-4 h-4 text-amber-400" />
              </div>
              <div className="text-2xl font-bold font-mono text-[#FFC700]">
                ₦{loyaltyStats.totalWalletLiability.toLocaleString()}
              </div>
              <div className="text-[10px] text-[#A89689] mt-1">Pre-paid diner float</div>
            </div>

            <div className="bg-[#1C0F0D] border border-[#36221E] p-4 rounded-xl">
              <div className="flex items-center justify-between text-xs text-[#A89689] mb-1">
                <span>Points Outstanding</span>
                <Award className="w-4 h-4 text-[#FFC700]" />
              </div>
              <div className="text-2xl font-bold font-mono text-purple-300">
                {loyaltyStats.totalPointsOutstanding.toLocaleString()} pts
              </div>
              <div className="text-[10px] text-purple-400 mt-1">
                ≈ ₦{(loyaltyStats.totalPointsOutstanding * 10).toLocaleString()} redeemable value
              </div>
            </div>

            <div className="bg-[#1C0F0D] border border-[#36221E] p-4 rounded-xl">
              <div className="flex items-center justify-between text-xs text-[#A89689] mb-1">
                <span>Lifetime Patron Spend</span>
                <TrendingUp className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="text-2xl font-bold font-mono text-emerald-400">
                ₦{loyaltyStats.totalLifetimeSpend.toLocaleString()}
              </div>
              <div className="text-[10px] text-[#A89689] mt-1">Across all 3 branches</div>
            </div>
          </div>

          {/* Search, Filters & Action Bar */}
          <div className="bg-[#1C0F0D] p-4 rounded-xl border border-[#36221E] flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
              <div className="relative flex-1 sm:w-64">
                <Search className="w-4 h-4 text-[#A89689] absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Search by name or phone..."
                  value={customerSearch}
                  onChange={(e) => setCustomerSearch(e.target.value)}
                  className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl pl-9 pr-3 py-1.5 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
                />
              </div>

              <select
                value={tierFilter}
                onChange={(e) => setTierFilter(e.target.value)}
                className="bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-1.5 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
              >
                <option value="all">All VIP Tiers</option>
                <option value="platinum">Platinum VIP</option>
                <option value="gold">Gold VIP</option>
                <option value="silver">Silver Tier</option>
                <option value="bronze">Bronze Tier</option>
              </select>

              <select
                value={branchFilter}
                onChange={(e) => setBranchFilter(e.target.value)}
                className="bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-1.5 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
              >
                <option value="all">All Branches</option>
                <option value="gra">GRA Flagship</option>
                <option value="ugbowo">Ugbowo Campus</option>
                <option value="okabere">Okabere Express</option>
              </select>
            </div>

            <button
              onClick={() => setIsRegisterModalOpen(true)}
              className="w-full sm:w-auto px-4 py-2 bg-[#800D15] hover:bg-[#96121B] text-[#FAF7F2] font-bold text-xs rounded-xl flex items-center justify-center gap-2 border border-[#FFC700]/30 transition-all shadow-md"
            >
              <Plus className="w-4 h-4 text-[#FFC700]" />
              <span>Enroll New Patron</span>
            </button>
          </div>

          {/* Customers Table / Grid */}
          <div className="bg-[#1C0F0D] rounded-xl border border-[#36221E] overflow-hidden">
            <div className="p-4 border-b border-[#36221E] flex items-center justify-between">
              <h2 className="text-sm font-bold text-[#FAF7F2] flex items-center gap-2">
                <span>VIP Patrons Registry</span>
                <span className="text-xs font-mono text-[#A89689]">({customers.length})</span>
              </h2>
              <button
                onClick={fetchCustomers}
                className="p-1.5 text-[#A89689] hover:text-[#FAF7F2] rounded-lg hover:bg-[#241311] transition-all"
                title="Refresh customer database"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-[#36221E] bg-[#120B0A] text-[11px] font-bold uppercase tracking-wider text-[#A89689]">
                    <th className="py-3 px-4">Patron & Contact</th>
                    <th className="py-3 px-4">Tier Status</th>
                    <th className="py-3 px-4">Digital Wallet Balance</th>
                    <th className="py-3 px-4">Loyalty Points</th>
                    <th className="py-3 px-4">10-Stamp Card</th>
                    <th className="py-3 px-4">Lifetime Spend</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#36221E] text-xs">
                  {customers.map((c) => (
                    <tr key={c.id} className="hover:bg-[#241311]/60 transition-colors">
                      <td className="py-3.5 px-4">
                        <div className="font-bold text-[#FAF7F2]">{c.name}</div>
                        <div className="text-[11px] text-[#A89689] flex items-center gap-2 mt-0.5">
                          <span className="font-mono">{c.phone}</span>
                          {c.preferredBranchId && (
                            <span className="uppercase text-[9px] bg-[#241311] px-1.5 py-0.5 rounded border border-[#36221E]">
                              {c.preferredBranchId}
                            </span>
                          )}
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        <span
                          className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wide border ${getTierColor(
                            c.tier
                          )}`}
                        >
                          <Sparkles className="w-3 h-3" />
                          {c.tier}
                        </span>
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="font-mono font-bold text-sm text-[#FFC700]">
                          ₦{c.walletBalance.toLocaleString()}
                        </div>
                        <div className="text-[10px] text-[#A89689]">PIN: ••••</div>
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="font-mono font-bold text-purple-300">
                          {c.loyaltyPoints} pts
                        </div>
                        <div className="text-[10px] text-purple-400/80">
                          = ₦{(c.loyaltyPoints * 10).toLocaleString()} credit
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-1">
                          {[...Array(10)].map((_, idx) => (
                            <div
                              key={idx}
                              className={`w-3 h-3 rounded-full border ${
                                idx < c.stampCount
                                  ? 'bg-[#FFC700] border-[#FFC700]'
                                  : 'bg-[#120B0A] border-[#4D2924]'
                              }`}
                              title={`Stamp ${idx + 1}`}
                            />
                          ))}
                          <span className="text-[10px] font-mono text-[#A89689] ml-1">
                            {c.stampCount}/10
                          </span>
                        </div>
                        {c.stampCount >= 10 && (
                          <button
                            onClick={() => handleClaimStampReward(c)}
                            className="mt-1 px-2 py-0.5 bg-emerald-700 hover:bg-emerald-600 text-white text-[10px] font-bold rounded flex items-center gap-1 animate-pulse"
                          >
                            <Gift className="w-2.5 h-2.5" /> Claim Free Meal (₦4,000)
                          </button>
                        )}
                      </td>

                      <td className="py-3.5 px-4 font-mono text-[#FAF7F2]">
                        <div>₦{c.lifetimeSpend.toLocaleString()}</div>
                        <div className="text-[10px] text-[#A89689]">{c.visitCount} visits</div>
                      </td>

                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => {
                              setSelectedCustomer(c);
                              setIsTopupModalOpen(true);
                            }}
                            className="px-2 py-1 bg-[#241311] hover:bg-[#36221E] text-amber-400 border border-amber-500/30 rounded text-[11px] font-bold flex items-center gap-1"
                            title="Top-up digital wallet balance"
                          >
                            <ArrowUpRight className="w-3 h-3" /> Top-Up
                          </button>
                          <button
                            onClick={() => viewCustomerDetails(c)}
                            className="px-2.5 py-1 bg-[#800D15] hover:bg-[#96121B] text-[#FAF7F2] rounded text-[11px] font-bold"
                          >
                            Profile & Ledger
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                  {customers.length === 0 && (
                    <tr>
                      <td colSpan={7} className="py-8 text-center text-sm text-[#A89689]">
                        No patrons found matching your search filter.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: CORPORATE VIP HOUSE ACCOUNTS & CREDIT LEDGER */}
      {/* ========================================================================= */}
      {activeTab === 'house_accounts' && (
        <div className="space-y-6">
          {/* Corporate Metrics */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-[#1C0F0D] border border-[#36221E] p-4 rounded-xl">
              <div className="flex items-center justify-between text-xs text-[#A89689] mb-1">
                <span>Active Corporate Clients</span>
                <Building className="w-4 h-4 text-[#FFC700]" />
              </div>
              <div className="text-2xl font-bold font-mono text-[#FAF7F2]">
                {houseAccountStats.totalAccounts}
              </div>
              <div className="text-[10px] text-blue-400 mt-1">Institutions & firms</div>
            </div>

            <div className="bg-[#1C0F0D] border border-[#36221E] p-4 rounded-xl">
              <div className="flex items-center justify-between text-xs text-[#A89689] mb-1">
                <span>Extended Credit Facility</span>
                <CreditCard className="w-4 h-4 text-blue-400" />
              </div>
              <div className="text-2xl font-bold font-mono text-[#FAF7F2]">
                ₦{houseAccountStats.totalCreditLimit.toLocaleString()}
              </div>
              <div className="text-[10px] text-[#A89689] mt-1">Approved credit lines</div>
            </div>

            <div className="bg-[#1C0F0D] border border-[#36221E] p-4 rounded-xl">
              <div className="flex items-center justify-between text-xs text-[#A89689] mb-1">
                <span>Outstanding Receivables</span>
                <DollarSign className="w-4 h-4 text-[#FFC700]" />
              </div>
              <div className="text-2xl font-bold font-mono text-[#FFC700]">
                ₦{houseAccountStats.totalOutstanding.toLocaleString()}
              </div>
              <div className="text-[10px] text-amber-400 mt-1">Pending monthly billing</div>
            </div>

            <div className="bg-[#1C0F0D] border border-[#36221E] p-4 rounded-xl">
              <div className="flex items-center justify-between text-xs text-[#A89689] mb-1">
                <span>Available Headroom</span>
                <Shield className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="text-2xl font-bold font-mono text-emerald-400">
                ₦{houseAccountStats.totalAvailableCredit.toLocaleString()}
              </div>
              <div className="text-[10px] text-emerald-400 mt-1">Low risk utilization</div>
            </div>
          </div>

          {/* Action Bar */}
          <div className="bg-[#1C0F0D] p-4 rounded-xl border border-[#36221E] flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold text-[#FAF7F2]">Corporate House Accounts Ledger</h2>
              <p className="text-xs text-[#A89689]">
                Authorized institutional billing for ministries, corporate banks, multinationals & medical societies.
              </p>
            </div>
            <button
              onClick={() => setIsCreateAccountModalOpen(true)}
              className="px-4 py-2 bg-[#800D15] hover:bg-[#96121B] text-[#FAF7F2] font-bold text-xs rounded-xl flex items-center gap-2 border border-[#FFC700]/30 transition-all shadow-md"
            >
              <Plus className="w-4 h-4 text-[#FFC700]" />
              <span>New Corporate Account</span>
            </button>
          </div>

          {/* Corporate Accounts Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {houseAccounts.map((acc) => {
              const utilPct = Math.min(100, Math.round((acc.currentBalance / acc.creditLimit) * 100));
              return (
                <div
                  key={acc.id}
                  className="bg-[#1C0F0D] border border-[#36221E] rounded-xl p-5 space-y-4 hover:border-[#800D15] transition-all"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-bold text-sm text-[#FAF7F2]">{acc.companyName}</h3>
                        <span className="text-[10px] font-mono bg-[#800D15]/30 text-[#FFC700] border border-[#FFC700]/30 px-1.5 py-0.5 rounded">
                          {acc.accountCode}
                        </span>
                      </div>
                      <p className="text-xs text-[#A89689] mt-0.5">
                        Attn: {acc.contactPerson} • {acc.phone}
                      </p>
                    </div>
                    <span
                      className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded border ${
                        acc.status === 'active'
                          ? 'bg-emerald-950 text-emerald-300 border-emerald-500/30'
                          : 'bg-amber-950 text-amber-300 border-amber-500/30'
                      }`}
                    >
                      {acc.status}
                    </span>
                  </div>

                  {/* Credit Utilization Bar */}
                  <div className="space-y-1.5 bg-[#120B0A] p-3 rounded-lg border border-[#36221E]">
                    <div className="flex justify-between text-xs">
                      <span className="text-[#A89689]">Current Outstanding:</span>
                      <span className="font-bold font-mono text-[#FFC700]">
                        ₦{acc.currentBalance.toLocaleString()}
                      </span>
                    </div>
                    <div className="w-full bg-[#241311] h-2 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all ${
                          utilPct > 80 ? 'bg-rose-600' : utilPct > 50 ? 'bg-amber-500' : 'bg-emerald-500'
                        }`}
                        style={{ width: `${utilPct}%` }}
                      />
                    </div>
                    <div className="flex justify-between text-[10px] text-[#A89689]">
                      <span>Limit: ₦{acc.creditLimit.toLocaleString()}</span>
                      <span>
                        {utilPct}% used • Terms: {acc.paymentTerms.replace('_', ' ').toUpperCase()}
                      </span>
                    </div>
                  </div>

                  {/* Authorized Signers */}
                  <div className="text-[11px] text-[#A89689]">
                    <span className="font-bold text-[#FAF7F2]">Authorized Signers: </span>
                    {acc.authorizedSigners && acc.authorizedSigners.length > 0 ? (
                      acc.authorizedSigners.map((s) => `${s.name} (${s.designation})`).join(', ')
                    ) : (
                      <span>Primary contact only</span>
                    )}
                  </div>

                  {/* Action Buttons */}
                  <div className="pt-2 border-t border-[#36221E] flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          setSelectedHouseAccount(acc);
                          setChargeSigner(acc.authorizedSigners?.[0]?.name || acc.contactPerson);
                          setIsDirectChargeModalOpen(true);
                        }}
                        className="px-2.5 py-1.5 bg-[#241311] hover:bg-[#36221E] text-[#FFC700] border border-[#FFC700]/30 rounded-lg text-xs font-bold flex items-center gap-1"
                      >
                        <Plus className="w-3.5 h-3.5" /> Post Charge
                      </button>
                      <button
                        onClick={() => {
                          setSelectedHouseAccount(acc);
                          setPaymentAmount(String(acc.currentBalance));
                          setIsRecordPaymentModalOpen(true);
                        }}
                        className="px-2.5 py-1.5 bg-[#241311] hover:bg-[#36221E] text-emerald-400 border border-emerald-500/30 rounded-lg text-xs font-bold flex items-center gap-1"
                      >
                        <DollarSign className="w-3.5 h-3.5" /> Record Payment
                      </button>
                    </div>

                    <button
                      onClick={() => {
                        viewHouseAccountDetails(acc);
                        setIsStatementModalOpen(true);
                      }}
                      className="px-3 py-1.5 bg-[#800D15] hover:bg-[#96121B] text-[#FAF7F2] rounded-lg text-xs font-bold flex items-center gap-1"
                    >
                      <FileText className="w-3.5 h-3.5" /> Statement
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: ENROLL NEW PATRON */}
      {/* ========================================================================= */}
      {isRegisterModalOpen && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#1C0F0D] border border-[#36221E] rounded-2xl w-full max-w-md p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#36221E] pb-3">
              <h3 className="font-serif font-bold text-[#FAF7F2] text-base flex items-center gap-2">
                <Award className="w-5 h-5 text-[#FFC700]" />
                <span>Enroll VIP Patron</span>
              </h3>
              <button
                onClick={() => setIsRegisterModalOpen(false)}
                className="text-[#A89689] hover:text-[#FAF7F2]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleRegisterCustomer} className="space-y-3">
              <div>
                <label className="text-xs text-[#A89689]">Customer Full Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Chief Osarumen Igbinedion"
                  value={newCustName}
                  onChange={(e) => setNewCustName(e.target.value)}
                  className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
                />
              </div>

              <div>
                <label className="text-xs text-[#A89689]">Phone Number (Mobile) *</label>
                <input
                  type="text"
                  required
                  placeholder="+234 803 123 4567"
                  value={newCustPhone}
                  onChange={(e) => setNewCustPhone(e.target.value)}
                  className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-xs text-[#FAF7F2] font-mono focus:outline-none focus:border-[#FFC700]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-[#A89689]">Email Address</label>
                  <input
                    type="email"
                    placeholder="patron@gmail.com"
                    value={newCustEmail}
                    onChange={(e) => setNewCustEmail(e.target.value)}
                    className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
                  />
                </div>
                <div>
                  <label className="text-xs text-[#A89689]">Preferred Branch</label>
                  <select
                    value={newCustBranch}
                    onChange={(e) => setNewCustBranch(e.target.value as BranchId)}
                    className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
                  >
                    <option value="gra">GRA Flagship</option>
                    <option value="ugbowo">Ugbowo Campus</option>
                    <option value="okabere">Okabere Express</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-[#A89689]">Wallet Security PIN</label>
                  <input
                    type="password"
                    maxLength={4}
                    placeholder="1234"
                    value={newCustPin}
                    onChange={(e) => setNewCustPin(e.target.value)}
                    className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-xs text-[#FAF7F2] font-mono tracking-widest focus:outline-none focus:border-[#FFC700]"
                  />
                </div>
                <div>
                  <label className="text-xs text-[#A89689]">Birthday (MM-DD)</label>
                  <input
                    type="text"
                    placeholder="e.g. 08-25"
                    value={newCustBirthday}
                    onChange={(e) => setNewCustBirthday(e.target.value)}
                    className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs text-[#A89689]">Preferences / Table Notes</label>
                <textarea
                  rows={2}
                  placeholder="e.g. Likes VIP booth 4, prefers spicy catfish, Heineken zero ice."
                  value={newCustNotes}
                  onChange={(e) => setNewCustNotes(e.target.value)}
                  className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
                />
              </div>

              <div className="bg-[#241311] p-3 rounded-xl border border-[#36221E] text-[11px] text-amber-300 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-[#FFC700] shrink-0" />
                <span>New VIP members receive 50 complimentary welcome loyalty points upon registration!</span>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsRegisterModalOpen(false)}
                  className="px-4 py-2 bg-[#241311] text-[#A89689] hover:text-[#FAF7F2] rounded-xl text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#800D15] hover:bg-[#96121B] text-[#FAF7F2] font-bold text-xs rounded-xl shadow-md"
                >
                  Complete Enrollment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: TOP-UP DIGITAL WALLET */}
      {/* ========================================================================= */}
      {isTopupModalOpen && selectedCustomer && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#1C0F0D] border border-[#36221E] rounded-2xl w-full max-w-md p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#36221E] pb-3">
              <div>
                <h3 className="font-serif font-bold text-[#FAF7F2] text-base">Top-Up Digital Wallet</h3>
                <p className="text-xs text-[#A89689]">
                  {selectedCustomer.name} • Current Balance: ₦{selectedCustomer.walletBalance.toLocaleString()}
                </p>
              </div>
              <button
                onClick={() => setIsTopupModalOpen(false)}
                className="text-[#A89689] hover:text-[#FAF7F2]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleTopupWallet} className="space-y-3">
              <div>
                <label className="text-xs text-[#A89689]">Top-Up Amount (₦) *</label>
                <input
                  type="number"
                  required
                  min={1000}
                  step={500}
                  value={topupAmount}
                  onChange={(e) => setTopupAmount(e.target.value)}
                  className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-sm font-mono text-[#FFC700] focus:outline-none focus:border-[#FFC700]"
                />
              </div>

              {/* Quick Preset Buttons */}
              <div className="grid grid-cols-4 gap-2">
                {[5000, 10000, 20000, 50000].map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => setTopupAmount(String(preset))}
                    className="py-1.5 bg-[#241311] hover:bg-[#36221E] text-xs font-mono text-[#FAF7F2] rounded-lg border border-[#36221E]"
                  >
                    ₦{(preset / 1000).toFixed(0)}k
                  </button>
                ))}
              </div>

              {Number(topupAmount) >= 20000 && (
                <div className="bg-emerald-950/60 border border-emerald-600/40 p-2.5 rounded-xl text-xs text-emerald-300 flex items-center justify-between">
                  <span>✨ 5% Reload Bonus Qualified!</span>
                  <span className="font-bold font-mono">
                    +₦{Math.floor(Number(topupAmount) * 0.05).toLocaleString()}
                  </span>
                </div>
              )}

              <div>
                <label className="text-xs text-[#A89689]">Payment Method</label>
                <div className="grid grid-cols-3 gap-2 mt-1">
                  {[
                    { id: 'pos_terminal', label: 'POS Terminal' },
                    { id: 'bank_transfer', label: 'Transfer' },
                    { id: 'cash', label: 'Cash' },
                  ].map((m) => (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => setTopupMethod(m.id as any)}
                      className={`py-2 text-xs font-bold rounded-lg border transition-all ${
                        topupMethod === m.id
                          ? 'bg-[#800D15] text-[#FFC700] border-[#FFC700]/40'
                          : 'bg-[#241311] text-[#A89689] border-[#36221E]'
                      }`}
                    >
                      {m.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-xs text-[#A89689]">Payment Reference / POS STAN</label>
                <input
                  type="text"
                  placeholder="e.g. STAN-009182 / TRF-GTB-8812"
                  value={topupReference}
                  onChange={(e) => setTopupReference(e.target.value)}
                  className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-xs text-[#FAF7F2] font-mono focus:outline-none focus:border-[#FFC700]"
                />
              </div>

              <div>
                <label className="text-xs text-[#A89689]">Staff Notes</label>
                <input
                  type="text"
                  placeholder="Optional top-up memo"
                  value={topupNote}
                  onChange={(e) => setTopupNote(e.target.value)}
                  className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsTopupModalOpen(false)}
                  className="px-4 py-2 bg-[#241311] text-[#A89689] rounded-xl text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#800D15] hover:bg-[#96121B] text-[#FAF7F2] font-bold text-xs rounded-xl shadow-md"
                >
                  Confirm Credit (₦{Number(topupAmount).toLocaleString()})
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: CUSTOMER PROFILE & TRANSACTION LEDGER */}
      {/* ========================================================================= */}
      {isCustomerModalOpen && selectedCustomer && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#1C0F0D] border border-[#36221E] rounded-2xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
            {/* Modal Header */}
            <div className="p-5 border-b border-[#36221E] flex items-center justify-between bg-[#120B0A]">
              <div>
                <div className="flex items-center gap-3">
                  <h3 className="font-serif font-bold text-lg text-[#FAF7F2]">
                    {selectedCustomer.name}
                  </h3>
                  <span
                    className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full border ${getTierColor(
                      selectedCustomer.tier
                    )}`}
                  >
                    {selectedCustomer.tier} VIP
                  </span>
                </div>
                <p className="text-xs text-[#A89689] mt-0.5">
                  {selectedCustomer.phone} • Member since{' '}
                  {new Date(selectedCustomer.createdAt).toLocaleDateString()}
                </p>
              </div>
              <button
                onClick={() => setIsCustomerModalOpen(false)}
                className="text-[#A89689] hover:text-[#FAF7F2]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5 overflow-y-auto space-y-5 flex-1">
              {/* Account Quick Cards */}
              <div className="grid grid-cols-3 gap-3">
                <div className="bg-[#241311] p-3 rounded-xl border border-[#36221E]">
                  <div className="text-[10px] text-[#A89689]">Wallet Stored Credit</div>
                  <div className="text-lg font-bold font-mono text-[#FFC700]">
                    ₦{selectedCustomer.walletBalance.toLocaleString()}
                  </div>
                  <button
                    onClick={() => {
                      setIsTopupModalOpen(true);
                    }}
                    className="mt-1 text-[10px] text-amber-400 font-bold hover:underline"
                  >
                    + Add Funds
                  </button>
                </div>

                <div className="bg-[#241311] p-3 rounded-xl border border-[#36221E]">
                  <div className="text-[10px] text-[#A89689]">Loyalty Points</div>
                  <div className="text-lg font-bold font-mono text-purple-300">
                    {selectedCustomer.loyaltyPoints} pts
                  </div>
                  <button
                    onClick={() => setIsRedeemPointsModalOpen(true)}
                    className="mt-1 text-[10px] text-purple-400 font-bold hover:underline"
                  >
                    Convert to Credit
                  </button>
                </div>

                <div className="bg-[#241311] p-3 rounded-xl border border-[#36221E]">
                  <div className="text-[10px] text-[#A89689]">10-Stamp Milestone</div>
                  <div className="text-lg font-bold font-mono text-[#FAF7F2]">
                    {selectedCustomer.stampCount} / 10
                  </div>
                  <div className="text-[10px] text-[#A89689]">
                    {selectedCustomer.stampsRedeemedTotal} meals claimed
                  </div>
                </div>
              </div>

              {/* Stamp Visual Card */}
              <div className="bg-[#120B0A] p-4 rounded-xl border border-[#36221E] space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-[#FAF7F2] flex items-center gap-1.5">
                    <Gift className="w-4 h-4 text-[#FFC700]" />
                    <span>Digital Loyalty Stamp Card</span>
                  </span>
                  <span className="text-[11px] text-[#A89689]">
                    Earn 1 stamp on every visit over ₦3,000
                  </span>
                </div>

                <div className="grid grid-cols-10 gap-2 pt-2">
                  {[...Array(10)].map((_, i) => (
                    <div
                      key={i}
                      className={`aspect-square rounded-xl border flex flex-col items-center justify-center transition-all ${
                        i < selectedCustomer.stampCount
                          ? 'bg-[#800D15] border-[#FFC700] text-[#FFC700] shadow-md scale-105'
                          : 'bg-[#241311] border-[#36221E] text-gray-600'
                      }`}
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span className="text-[9px] font-mono mt-0.5">#{i + 1}</span>
                    </div>
                  ))}
                </div>

                {selectedCustomer.stampCount >= 10 && (
                  <div className="pt-2 flex justify-end">
                    <button
                      onClick={() => handleClaimStampReward(selectedCustomer)}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-lg animate-pulse"
                    >
                      <Gift className="w-4 h-4" /> Claim Complimentary ₦4,000 Meal Reward
                    </button>
                  </div>
                )}
              </div>

              {/* Transactions Ledger */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-[#A89689] flex items-center gap-2">
                  <Clock className="w-3.5 h-3.5" />
                  <span>Wallet Transaction History</span>
                </h4>

                <div className="bg-[#120B0A] rounded-xl border border-[#36221E] overflow-hidden">
                  <div className="max-h-60 overflow-y-auto divide-y divide-[#36221E]">
                    {customerTransactions.map((tx) => (
                      <div key={tx.id} className="p-3 text-xs flex items-center justify-between">
                        <div>
                          <div className="flex items-center gap-2">
                            <span
                              className={`px-1.5 py-0.5 rounded text-[10px] font-bold uppercase ${
                                tx.type === 'top_up' || tx.type === 'bonus' || tx.type === 'points_conversion'
                                  ? 'bg-emerald-950 text-emerald-300 border border-emerald-600/30'
                                  : 'bg-rose-950 text-rose-300 border border-rose-600/30'
                              }`}
                            >
                              {tx.type.replace('_', ' ')}
                            </span>
                            <span className="text-[#FAF7F2] font-mono font-bold">
                              {tx.type === 'debit_order' ? '-' : '+'}₦{tx.amount.toLocaleString()}
                            </span>
                          </div>
                          <div className="text-[11px] text-[#A89689] mt-0.5">
                            {tx.note || tx.reference} • Staff: {tx.staffName}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-[10px] text-[#A89689]">
                            {new Date(tx.timestamp).toLocaleString()}
                          </div>
                          <div className="text-[10px] font-mono text-[#FAF7F2]">
                            Bal: ₦{tx.newBalance.toLocaleString()}
                          </div>
                        </div>
                      </div>
                    ))}
                    {customerTransactions.length === 0 && (
                      <div className="p-6 text-center text-xs text-[#A89689]">
                        No wallet transactions logged yet for this member.
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-[#36221E] bg-[#120B0A] flex justify-end">
              <button
                onClick={() => setIsCustomerModalOpen(false)}
                className="px-5 py-2 bg-[#241311] text-[#FAF7F2] hover:bg-[#36221E] text-xs font-bold rounded-xl"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: REDEEM POINTS */}
      {/* ========================================================================= */}
      {isRedeemPointsModalOpen && selectedCustomer && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#1C0F0D] border border-[#36221E] rounded-2xl w-full max-w-sm p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#36221E] pb-3">
              <h3 className="font-serif font-bold text-[#FAF7F2] text-base">Redeem Points</h3>
              <button
                onClick={() => setIsRedeemPointsModalOpen(false)}
                className="text-[#A89689] hover:text-[#FAF7F2]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleRedeemPoints} className="space-y-3">
              <div className="text-xs text-[#A89689]">
                Available Points: <span className="font-bold text-[#FAF7F2]">{selectedCustomer.loyaltyPoints}</span>
              </div>

              <div>
                <label className="text-xs text-[#A89689]">Points to Convert</label>
                <input
                  type="number"
                  min={10}
                  max={selectedCustomer.loyaltyPoints}
                  step={10}
                  value={pointsToRedeemInput}
                  onChange={(e) => setPointsToRedeemInput(e.target.value)}
                  className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-sm font-mono text-[#FFC700] focus:outline-none focus:border-[#FFC700]"
                />
              </div>

              <div className="bg-[#241311] p-3 rounded-xl border border-[#36221E] text-xs text-[#FAF7F2] flex items-center justify-between">
                <span>Wallet Credit Yield:</span>
                <span className="font-bold font-mono text-emerald-400">
                  ₦{(Number(pointsToRedeemInput || 0) * 10).toLocaleString()}
                </span>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsRedeemPointsModalOpen(false)}
                  className="px-4 py-2 bg-[#241311] text-[#A89689] rounded-xl text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#800D15] hover:bg-[#96121B] text-[#FAF7F2] font-bold text-xs rounded-xl shadow-md"
                >
                  Convert Now
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: CREATE CORPORATE HOUSE ACCOUNT */}
      {/* ========================================================================= */}
      {isCreateAccountModalOpen && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#1C0F0D] border border-[#36221E] rounded-2xl w-full max-w-lg p-6 space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-[#36221E] pb-3">
              <h3 className="font-serif font-bold text-[#FAF7F2] text-base flex items-center gap-2">
                <Building className="w-5 h-5 text-[#FFC700]" />
                <span>Create Corporate House Account</span>
              </h3>
              <button
                onClick={() => setIsCreateAccountModalOpen(false)}
                className="text-[#A89689] hover:text-[#FAF7F2]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateCorporateAccount} className="space-y-3">
              <div>
                <label className="text-xs text-[#A89689]">Company / Organization Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Zenith Bank Regional Operations Hub"
                  value={newCorpName}
                  onChange={(e) => setNewCorpName(e.target.value)}
                  className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-[#A89689]">Account Code (Optional)</label>
                  <input
                    type="text"
                    placeholder="e.g. CHOP-CORP-0104"
                    value={newCorpCode}
                    onChange={(e) => setNewCorpCode(e.target.value)}
                    className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-xs font-mono text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
                  />
                </div>
                <div>
                  <label className="text-xs text-[#A89689]">Credit Limit (₦) *</label>
                  <input
                    type="number"
                    required
                    min={100000}
                    step={50000}
                    placeholder="1000000"
                    value={newCorpCreditLimit}
                    onChange={(e) => setNewCorpCreditLimit(e.target.value)}
                    className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-xs font-mono text-[#FFC700] focus:outline-none focus:border-[#FFC700]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-[#A89689]">Primary Contact Person *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Mrs. Ngozi Adeleke"
                    value={newCorpContact}
                    onChange={(e) => setNewCorpContact(e.target.value)}
                    className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
                  />
                </div>
                <div>
                  <label className="text-xs text-[#A89689]">Contact Phone *</label>
                  <input
                    type="text"
                    required
                    placeholder="+234 803 123 4567"
                    value={newCorpPhone}
                    onChange={(e) => setNewCorpPhone(e.target.value)}
                    className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-xs font-mono text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-[#A89689]">Billing Email</label>
                  <input
                    type="email"
                    placeholder="accounts@zenithbank.com"
                    value={newCorpEmail}
                    onChange={(e) => setNewCorpEmail(e.target.value)}
                    className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
                  />
                </div>
                <div>
                  <label className="text-xs text-[#A89689]">Payment Terms</label>
                  <select
                    value={newCorpTerms}
                    onChange={(e) => setNewCorpTerms(e.target.value as any)}
                    className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
                  >
                    <option value="net_7">Net 7 Days</option>
                    <option value="net_15">Net 15 Days</option>
                    <option value="net_30">Net 30 Days (Standard)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs text-[#A89689]">Office / Delivery Address</label>
                <input
                  type="text"
                  placeholder="Plot 18 Sapele Road Commercial Zone, Benin City"
                  value={newCorpAddress}
                  onChange={(e) => setNewCorpAddress(e.target.value)}
                  className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
                />
              </div>

              {/* Initial Signer */}
              <div className="border border-[#36221E] p-3 rounded-xl bg-[#120B0A] space-y-2">
                <div className="text-[11px] font-bold text-[#FFC700]">Initial Authorized Signer</div>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    placeholder="Signer Full Name"
                    value={newCorpSignerName}
                    onChange={(e) => setNewCorpSignerName(e.target.value)}
                    className="bg-[#241311] border border-[#36221E] rounded-lg px-2.5 py-1.5 text-xs text-[#FAF7F2]"
                  />
                  <input
                    type="text"
                    placeholder="Designation / Role"
                    value={newCorpSignerRole}
                    onChange={(e) => setNewCorpSignerRole(e.target.value)}
                    className="bg-[#241311] border border-[#36221E] rounded-lg px-2.5 py-1.5 text-xs text-[#FAF7F2]"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs text-[#A89689]">Billing & Invoicing Instructions</label>
                <textarea
                  rows={2}
                  placeholder="e.g. Invoices to be sent to Accounts Payable Division on 25th of each month."
                  value={newCorpBillingNotes}
                  onChange={(e) => setNewCorpBillingNotes(e.target.value)}
                  className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsCreateAccountModalOpen(false)}
                  className="px-4 py-2 bg-[#241311] text-[#A89689] rounded-xl text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#800D15] hover:bg-[#96121B] text-[#FAF7F2] font-bold text-xs rounded-xl shadow-md"
                >
                  Establish Account
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: POST DIRECT CHARGE TO CORPORATE HOUSE ACCOUNT */}
      {/* ========================================================================= */}
      {isDirectChargeModalOpen && selectedHouseAccount && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#1C0F0D] border border-[#36221E] rounded-2xl w-full max-w-md p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#36221E] pb-3">
              <div>
                <h3 className="font-serif font-bold text-[#FAF7F2] text-base">Post House Account Charge</h3>
                <p className="text-xs text-[#A89689]">
                  {selectedHouseAccount.companyName} ({selectedHouseAccount.accountCode})
                </p>
              </div>
              <button
                onClick={() => setIsDirectChargeModalOpen(false)}
                className="text-[#A89689] hover:text-[#FAF7F2]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleDirectCharge} className="space-y-3">
              <div>
                <label className="text-xs text-[#A89689]">Charge Amount (₦) *</label>
                <input
                  type="number"
                  required
                  min={500}
                  step={100}
                  placeholder="e.g. 85000"
                  value={chargeAmount}
                  onChange={(e) => setChargeAmount(e.target.value)}
                  className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-sm font-mono text-[#FFC700] focus:outline-none focus:border-[#FFC700]"
                />
              </div>

              <div>
                <label className="text-xs text-[#A89689]">Authorized Signer *</label>
                <input
                  type="text"
                  required
                  value={chargeSigner}
                  onChange={(e) => setChargeSigner(e.target.value)}
                  className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-[#A89689]">Department / Event</label>
                  <input
                    type="text"
                    value={chargeDept}
                    onChange={(e) => setChargeDept(e.target.value)}
                    className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
                  />
                </div>
                <div>
                  <label className="text-xs text-[#A89689]">Check / Invoice Ref</label>
                  <input
                    type="text"
                    placeholder="CHK-GRA-942"
                    value={chargeCheckNo}
                    onChange={(e) => setChargeCheckNo(e.target.value)}
                    className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-xs text-[#FAF7F2] font-mono focus:outline-none focus:border-[#FFC700]"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs text-[#A89689]">Description / Catering Notes</label>
                <textarea
                  rows={2}
                  placeholder="e.g. Buffet lunch service for visiting audit committee."
                  value={chargeNotes}
                  onChange={(e) => setChargeNotes(e.target.value)}
                  className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsDirectChargeModalOpen(false)}
                  className="px-4 py-2 bg-[#241311] text-[#A89689] rounded-xl text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#800D15] hover:bg-[#96121B] text-[#FAF7F2] font-bold text-xs rounded-xl shadow-md"
                >
                  Post ₦{Number(chargeAmount || 0).toLocaleString()} Charge
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: RECORD CORPORATE REMITTANCE PAYMENT */}
      {/* ========================================================================= */}
      {isRecordPaymentModalOpen && selectedHouseAccount && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#1C0F0D] border border-[#36221E] rounded-2xl w-full max-w-md p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#36221E] pb-3">
              <div>
                <h3 className="font-serif font-bold text-[#FAF7F2] text-base">Record Corporate Remittance</h3>
                <p className="text-xs text-[#A89689]">
                  {selectedHouseAccount.companyName} • Balance Owed: ₦{selectedHouseAccount.currentBalance.toLocaleString()}
                </p>
              </div>
              <button
                onClick={() => setIsRecordPaymentModalOpen(false)}
                className="text-[#A89689] hover:text-[#FAF7F2]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleRecordPayment} className="space-y-3">
              <div>
                <label className="text-xs text-[#A89689]">Remittance Amount (₦) *</label>
                <input
                  type="number"
                  required
                  min={1000}
                  step={500}
                  value={paymentAmount}
                  onChange={(e) => setPaymentAmount(e.target.value)}
                  className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-sm font-mono text-emerald-400 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="text-xs text-[#A89689]">Payment Instrument</label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value as any)}
                  className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
                >
                  <option value="bank_transfer">Direct Bank Transfer (NIP)</option>
                  <option value="cheque">Bankers Cheque / Draft</option>
                  <option value="pos_terminal">POS Terminal Settlement</option>
                  <option value="cash">Cash In Office</option>
                </select>
              </div>

              <div>
                <label className="text-xs text-[#A89689]">Bank Transfer Session ID / Cheque # *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. ZEN-NIP-20260902-8812"
                  value={paymentRef}
                  onChange={(e) => setPaymentRef(e.target.value)}
                  className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-xs font-mono text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
                />
              </div>

              <div>
                <label className="text-xs text-[#A89689]">Settlement Notes</label>
                <input
                  type="text"
                  placeholder="e.g. Full settlement for August judicial lunches"
                  value={paymentNotes}
                  onChange={(e) => setPaymentNotes(e.target.value)}
                  className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsRecordPaymentModalOpen(false)}
                  className="px-4 py-2 bg-[#241311] text-[#A89689] rounded-xl text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs rounded-xl shadow-md"
                >
                  Record Remittance
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: CORPORATE STATEMENT / INVOICE VIEW */}
      {/* ========================================================================= */}
      {isStatementModalOpen && selectedHouseAccount && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#1C0F0D] border border-[#36221E] rounded-2xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
            <div className="p-5 border-b border-[#36221E] flex items-center justify-between bg-[#120B0A]">
              <div>
                <h3 className="font-serif font-bold text-lg text-[#FAF7F2]">
                  Corporate Billing Statement & Ledger
                </h3>
                <p className="text-xs text-[#A89689]">
                  {selectedHouseAccount.companyName} • Code: {selectedHouseAccount.accountCode}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="px-3 py-1.5 bg-[#241311] hover:bg-[#36221E] text-[#FAF7F2] rounded-lg text-xs font-bold flex items-center gap-1.5 border border-[#36221E]"
                >
                  <Printer className="w-3.5 h-3.5" /> Print Statement
                </button>
                <button
                  onClick={() => setIsStatementModalOpen(false)}
                  className="text-[#A89689] hover:text-[#FAF7F2]"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="p-6 overflow-y-auto space-y-6 flex-1 bg-[#120B0A]">
              {/* Statement Header Card */}
              <div className="bg-[#1C0F0D] p-5 rounded-xl border border-[#36221E] flex flex-col sm:flex-row justify-between gap-4">
                <div>
                  <div className="text-[10px] uppercase font-bold text-[#FFC700] tracking-wider">
                    Choplife Republic Hospitality Group
                  </div>
                  <div className="text-xs text-[#A89689] mt-1">
                    Head Office: 8a Okogo Street, Opposite Wesley Hotel, Off Akhionbare, G.R.A., Benin City, Edo
                  </div>
                  <div className="text-xs text-[#A89689]">Phone: +234 815 817 7897 • finance@choplife.ng</div>
                </div>

                <div className="text-right">
                  <div className="text-xs text-[#A89689]">Statement Date:</div>
                  <div className="font-bold text-sm text-[#FAF7F2]">
                    {new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })}
                  </div>
                  <div className="text-xs text-amber-400 mt-1 font-mono">
                    Terms: {selectedHouseAccount.paymentTerms.replace('_', ' ').toUpperCase()}
                  </div>
                </div>
              </div>

              {/* Balance Summary */}
              <div className="grid grid-cols-3 gap-3">
                <div className="bg-[#1C0F0D] p-3.5 rounded-xl border border-[#36221E]">
                  <div className="text-[10px] text-[#A89689]">Approved Credit Limit</div>
                  <div className="text-lg font-bold font-mono text-[#FAF7F2]">
                    ₦{selectedHouseAccount.creditLimit.toLocaleString()}
                  </div>
                </div>
                <div className="bg-[#1C0F0D] p-3.5 rounded-xl border border-[#36221E]">
                  <div className="text-[10px] text-[#A89689]">Current Net Outstanding</div>
                  <div className="text-lg font-bold font-mono text-[#FFC700]">
                    ₦{selectedHouseAccount.currentBalance.toLocaleString()}
                  </div>
                </div>
                <div className="bg-[#1C0F0D] p-3.5 rounded-xl border border-[#36221E]">
                  <div className="text-[10px] text-[#A89689]">Remaining Credit Line</div>
                  <div className="text-lg font-bold font-mono text-emerald-400">
                    ₦{Math.max(0, selectedHouseAccount.creditLimit - selectedHouseAccount.currentBalance).toLocaleString()}
                  </div>
                </div>
              </div>

              {/* Charges Section */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-[#FAF7F2] flex items-center justify-between">
                  <span>Dining & Banquet Charges Incurred</span>
                  <span className="text-xs font-mono text-[#A89689]">({accountCharges.length} entries)</span>
                </h4>
                <div className="bg-[#1C0F0D] rounded-xl border border-[#36221E] overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-[#241311] text-[10px] font-bold uppercase text-[#A89689] border-b border-[#36221E]">
                      <tr>
                        <th className="p-3">Date</th>
                        <th className="p-3">Check / Inv #</th>
                        <th className="p-3">Signer & Dept</th>
                        <th className="p-3">Notes</th>
                        <th className="p-3 text-right">Amount</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#36221E]">
                      {accountCharges.map((c) => (
                        <tr key={c.id}>
                          <td className="p-3 text-[#A89689] font-mono">
                            {new Date(c.timestamp).toLocaleDateString()}
                          </td>
                          <td className="p-3 font-mono font-bold text-[#FFC700]">{c.checkNumber}</td>
                          <td className="p-3 text-[#FAF7F2]">
                            <div>{c.authorizedSigner}</div>
                            <div className="text-[10px] text-[#A89689]">{c.department}</div>
                          </td>
                          <td className="p-3 text-xs text-[#A89689]">{c.notes}</td>
                          <td className="p-3 text-right font-mono font-bold text-[#FAF7F2]">
                            ₦{c.amount.toLocaleString()}
                          </td>
                        </tr>
                      ))}
                      {accountCharges.length === 0 && (
                        <tr>
                          <td colSpan={5} className="p-4 text-center text-[#A89689]">
                            No charges logged to this corporate account.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Payments Section */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-[#FAF7F2] flex items-center justify-between">
                  <span>Remittances & Settlement Payments</span>
                  <span className="text-xs font-mono text-emerald-400">({accountPayments.length} entries)</span>
                </h4>
                <div className="bg-[#1C0F0D] rounded-xl border border-[#36221E] overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-[#241311] text-[10px] font-bold uppercase text-[#A89689] border-b border-[#36221E]">
                      <tr>
                        <th className="p-3">Date</th>
                        <th className="p-3">Receipt #</th>
                        <th className="p-3">Method & Reference</th>
                        <th className="p-3">Received By</th>
                        <th className="p-3 text-right">Credit Amount</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#36221E]">
                      {accountPayments.map((p) => (
                        <tr key={p.id}>
                          <td className="p-3 text-[#A89689] font-mono">
                            {new Date(p.timestamp).toLocaleDateString()}
                          </td>
                          <td className="p-3 font-mono font-bold text-emerald-400">{p.receiptNumber}</td>
                          <td className="p-3 text-[#FAF7F2]">
                            <div className="capitalize">{p.paymentMethod.replace('_', ' ')}</div>
                            <div className="text-[10px] font-mono text-[#A89689]">{p.bankReference}</div>
                          </td>
                          <td className="p-3 text-[#A89689]">{p.receivedByStaffName}</td>
                          <td className="p-3 text-right font-mono font-bold text-emerald-400">
                            -₦{p.amount.toLocaleString()}
                          </td>
                        </tr>
                      ))}
                      {accountPayments.length === 0 && (
                        <tr>
                          <td colSpan={5} className="p-4 text-center text-[#A89689]">
                            No remittance records found yet.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            <div className="p-4 border-t border-[#36221E] bg-[#120B0A] flex justify-end">
              <button
                onClick={() => setIsStatementModalOpen(false)}
                className="px-5 py-2 bg-[#241311] text-[#FAF7F2] hover:bg-[#36221E] text-xs font-bold rounded-xl"
              >
                Close Statement
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
