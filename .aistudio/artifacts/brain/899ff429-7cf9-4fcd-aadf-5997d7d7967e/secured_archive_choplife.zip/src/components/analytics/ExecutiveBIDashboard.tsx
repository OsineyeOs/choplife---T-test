import React, { useState, useEffect } from 'react';
import {
  TrendingUp,
  TrendingDown,
  Building2,
  Clock,
  PieChart,
  BarChart3,
  Flame,
  ShieldAlert,
  Zap,
  Download,
  Printer,
  RefreshCw,
  Users,
  Award,
  Sparkles,
  Filter,
  Layers,
  UtensilsCrossed,
  AlertTriangle,
  CheckCircle2,
  Bike,
  Calendar,
  ChevronDown,
  Percent,
} from 'lucide-react';
import {
  BranchId,
  ExecutivePeriod,
  ExecutiveBIDashboardData,
  StaffRole,
} from '../../types';

interface ExecutiveBIDashboardProps {
  currentStaffRole?: StaffRole;
  currentStaffBranchId?: string;
  defaultBranchId?: string;
}

export const ExecutiveBIDashboard: React.FC<ExecutiveBIDashboardProps> = ({
  currentStaffRole,
  currentStaffBranchId,
  defaultBranchId = 'all',
}) => {
  const [selectedBranch, setSelectedBranch] = useState<string>(
    currentStaffBranchId && currentStaffBranchId !== 'all' ? currentStaffBranchId : defaultBranchId
  );
  const [selectedPeriod, setSelectedPeriod] = useState<ExecutivePeriod>('7days');
  const [activeSubTab, setActiveSubTab] = useState<'pnl' | 'branches' | 'hourly' | 'bcg' | 'labor'>('pnl');
  const [selectedBcgFilter, setSelectedBcgFilter] = useState<'ALL' | 'STAR' | 'PLOWHORSE' | 'PUZZLE' | 'DOG'>('ALL');
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [data, setData] = useState<ExecutiveBIDashboardData | null>(null);
  const [fetchError, setFetchError] = useState<string | null>(null);
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [exportMessage, setExportMessage] = useState<string | null>(null);

  const getAuthHeaders = (): Record<string, string> => {
    const token = localStorage.getItem('choplife_staff_token') || '';
    return {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    };
  };

  const [dataFreshnessTimestamp, setDataFreshnessTimestamp] = useState<string | null>(null);

  const fetchDashboardData = async () => {
    setIsLoading(true);
    setFetchError(null);
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 8000);

    try {
      const query = new URLSearchParams({
        branchId: selectedBranch,
        period: selectedPeriod,
      });
      const res = await fetch(`/api/reports/executive-dashboard?${query.toString()}`, {
        headers: getAuthHeaders(),
        signal: controller.signal,
      });
      clearTimeout(timeoutId);

      if (res.ok) {
        const json = await res.json();
        setData(json);
        setFetchError(null);
        setDataFreshnessTimestamp(
          new Date().toLocaleTimeString('en-NG', { timeZone: 'Africa/Lagos' })
        );
      } else if (res.status === 401) {
        setFetchError('Staff authentication required. Please sign in with active credentials to view executive reports.');
      } else if (res.status === 403) {
        const errJson = await res.json().catch(() => ({}));
        setFetchError(errJson.error || 'Access denied: Executive BI is restricted to authorized supervisors and administrators.');
      } else {
        const errJson = await res.json().catch(() => ({}));
        setFetchError(errJson.error || 'Executive analytics could not be retrieved from the reporting engine.');
      }
    } catch (err: any) {
      clearTimeout(timeoutId);
      if (err.name === 'AbortError') {
        setFetchError('Request timed out after 8 seconds. Please check server status and click below to retry.');
      } else {
        setFetchError('Unable to connect to executive analytics service. Please verify your connection.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, [selectedBranch, selectedPeriod]);

  const handleExportCsv = async (exportType: 'pnl' | 'menu' | 'branches' | 'quickbooks') => {
    setIsExporting(true);
    try {
      const res = await fetch('/api/reports/export-csv', {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({
          exportType,
          branchId: selectedBranch,
          period: selectedPeriod,
        }),
      });

      if (res.ok) {
        const blob = await res.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `choplife-${exportType}-${selectedBranch}-${selectedPeriod}-${Date.now()}.csv`;
        document.body.appendChild(a);
        a.click();
        a.remove();
        setExportMessage(`Exported ${exportType.toUpperCase()} report successfully.`);
        setTimeout(() => setExportMessage(null), 3500);
      }
    } catch (err) {
      console.error('Export error:', err);
    } finally {
      setIsExporting(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  if (isLoading && !data) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-12 space-y-4">
        <RefreshCw className="w-8 h-8 text-[#FFC700] animate-spin" />
        <p className="text-sm font-semibold text-[#FAF7F2]">
          Aggregating Multi-Branch Financial & Operational Metrics...
        </p>
        <p className="text-xs text-[#A89689]">
          Querying ledger, till shifts, and consolidated P&L (WAT / Benin City timezone)
        </p>
        <button
          onClick={() => {
            setIsLoading(false);
            setFetchError('Loading cancelled by user.');
          }}
          className="mt-2 text-xs text-[#FFC700] hover:underline"
        >
          Cancel Request
        </button>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="flex-1 p-8 text-center text-[#A89689] flex flex-col items-center justify-center space-y-3">
        <p className="text-sm font-medium text-[#FAF7F2]">
          {fetchError || 'No operational data available for the selected filters.'}
        </p>
        <button
          onClick={fetchDashboardData}
          className="mt-2 px-5 py-2.5 bg-[#FFC700] hover:bg-[#E6B400] text-[#4D080F] font-bold rounded-xl text-xs flex items-center gap-2 shadow-md transition-all active:scale-95"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Reload Executive Analytics</span>
        </button>
      </div>
    );
  }

  const { pnl, branchBenchmarks, hourlySales, menuMatrix, wastageAudit, laborProductivity, aiInsights } = data;

  const filteredMenuMatrix =
    selectedBcgFilter === 'ALL'
      ? menuMatrix
      : menuMatrix.filter((item) => item.quadrant === selectedBcgFilter);

  const starCount = menuMatrix.filter((i) => i.quadrant === 'STAR').length;
  const plowhorseCount = menuMatrix.filter((i) => i.quadrant === 'PLOWHORSE').length;
  const puzzleCount = menuMatrix.filter((i) => i.quadrant === 'PUZZLE').length;
  const dogCount = menuMatrix.filter((i) => i.quadrant === 'DOG').length;

  const maxHourlyRev = Math.max(...hourlySales.map((s) => s.revenue), 1);

  return (
    <div className="flex-1 p-4 md:p-6 overflow-y-auto space-y-6 bg-[#140A09] text-[#FAF7F2]">
      {/* Top Header & Filter Controls */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-[#36221E]">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider bg-[#FFC700]/10 text-[#FFC700] border border-[#FFC700]/20 uppercase">
              Choplife Intelligence BI
            </span>
            {dataFreshnessTimestamp && (
              <span className="text-[11px] text-[#A89689]">
                • Fresh as of {dataFreshnessTimestamp} WAT
              </span>
            )}
          </div>
          <h1 className="text-xl md:text-2xl font-black text-[#FAF7F2] mt-1 font-titan">
            Multi-Branch Executive Analytics & BI
          </h1>
          <p className="text-xs text-[#A89689]">
            Consolidated cross-branch P&L, BCG menu matrix, hourly rush curves & labor throughput
          </p>
        </div>

        {/* Global Filter Bar */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Branch Selector */}
          <div className="flex items-center bg-[#1C1210] border border-[#36221E] rounded-xl px-3 py-1.5">
            <Building2 className="w-3.5 h-3.5 text-[#FFC700] mr-2" />
            <select
              value={selectedBranch}
              onChange={(e) => setSelectedBranch(e.target.value)}
              className="bg-transparent text-xs font-bold text-[#FAF7F2] focus:outline-none cursor-pointer"
            >
              <option value="all" className="bg-[#1C1210] text-[#FAF7F2]">
                All Branches (Consolidated)
              </option>
              <option value="gra" className="bg-[#1C1210] text-[#FAF7F2]">
                GRA Flagship (Okogo St)
              </option>
              <option value="okabere" className="bg-[#1C1210] text-[#FAF7F2]">
                Okabere (Sapele Rd)
              </option>
              <option value="ugbowo" className="bg-[#1C1210] text-[#FAF7F2]">
                Ugbowo (Campus & UBTH)
              </option>
            </select>
          </div>

          {/* Period Selector */}
          <div className="flex items-center bg-[#1C1210] border border-[#36221E] rounded-xl px-3 py-1.5">
            <Calendar className="w-3.5 h-3.5 text-[#38BDF8] mr-2" />
            <select
              value={selectedPeriod}
              onChange={(e) => setSelectedPeriod(e.target.value as ExecutivePeriod)}
              className="bg-transparent text-xs font-bold text-[#FAF7F2] focus:outline-none cursor-pointer"
            >
              <option value="today" className="bg-[#1C1210] text-[#FAF7F2]">
                Today
              </option>
              <option value="yesterday" className="bg-[#1C1210] text-[#FAF7F2]">
                Yesterday
              </option>
              <option value="7days" className="bg-[#1C1210] text-[#FAF7F2]">
                Last 7 Days
              </option>
              <option value="30days" className="bg-[#1C1210] text-[#FAF7F2]">
                Month to Date (30D)
              </option>
              <option value="all" className="bg-[#1C1210] text-[#FAF7F2]">
                All Time (Lifetime)
              </option>
            </select>
          </div>

          {/* Actions: Refresh */}
          <button
            onClick={fetchDashboardData}
            disabled={isLoading}
            className="p-2 bg-[#1C1210] hover:bg-[#2A1B18] border border-[#36221E] rounded-xl text-[#A89689] hover:text-[#FAF7F2] transition-colors"
            title="Refresh Metrics"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin text-[#FFC700]' : ''}`} />
          </button>

          {/* Export Dropdown / Action */}
          <button
            onClick={() => handleExportCsv('pnl')}
            disabled={isExporting}
            className="flex items-center gap-1.5 px-3 py-2 bg-[#241311] hover:bg-[#36221E] border border-[#4D2924] rounded-xl text-xs font-bold text-[#FAF7F2] transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-[#FFC700]" />
            <span className="hidden sm:inline">Export P&L CSV</span>
          </button>

          <button
            onClick={() => handleExportCsv('quickbooks')}
            disabled={isExporting}
            id="btn-export-quickbooks-journal"
            className="flex items-center gap-1.5 px-3 py-2 bg-[#241311] hover:bg-[#36221E] border border-[#22C55E]/40 rounded-xl text-xs font-bold text-[#22C55E] transition-colors"
            title="Export Double-Entry General Ledger Journal CSV (QuickBooks / IFRS)"
          >
            <Download className="w-3.5 h-3.5 text-[#22C55E]" />
            <span className="hidden sm:inline">QuickBooks GL CSV</span>
          </button>

          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3 py-2 bg-[#241311] hover:bg-[#36221E] border border-[#4D2924] rounded-xl text-xs font-bold text-[#FAF7F2] transition-colors"
          >
            <Printer className="w-3.5 h-3.5 text-[#38BDF8]" />
            <span className="hidden sm:inline">Print Report</span>
          </button>
        </div>
      </div>

      {exportMessage && (
        <div className="p-3 bg-[#22C55E]/10 border border-[#22C55E]/30 rounded-xl text-xs text-[#22C55E] flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{exportMessage}</span>
        </div>
      )}

      {/* Top Level Financial KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Net Sales Revenue */}
        <div className="p-4 bg-[#1C1210] border border-[#36221E] rounded-2xl relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#A89689]">Net Sales Revenue</span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#22C55E]/10 text-[#22C55E] border border-[#22C55E]/20 flex items-center gap-1">
              <TrendingUp className="w-2.5 h-2.5" /> +14.2%
            </span>
          </div>
          <p className="text-2xl font-black font-mono text-[#FFC700] mt-2">
            ₦{pnl.netRevenue.toLocaleString()}
          </p>
          <div className="flex items-center justify-between text-[11px] text-[#A89689] mt-2 pt-2 border-t border-[#2A1B18]">
            <span>Gross: ₦{pnl.grossRevenue.toLocaleString()}</span>
            <span className="text-[#EF4444]">Discounts: -₦{pnl.discounts.toLocaleString()}</span>
          </div>
        </div>

        {/* Gross Profit & Margin */}
        <div className="p-4 bg-[#1C1210] border border-[#36221E] rounded-2xl relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#A89689]">Gross Profit (After Food Cost)</span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#FFC700]/10 text-[#FFC700] border border-[#FFC700]/20">
              {pnl.grossMarginPct}% Margin
            </span>
          </div>
          <p className="text-2xl font-black font-mono text-[#FAF7F2] mt-2">
            ₦{pnl.grossProfit.toLocaleString()}
          </p>
          <div className="flex items-center justify-between text-[11px] text-[#A89689] mt-2 pt-2 border-t border-[#2A1B18]">
            <span>COGS: ₦{pnl.cogs.toLocaleString()}</span>
            <span>Target: &gt;62%</span>
          </div>
        </div>

        {/* Net Operating Profit (EBITDA) */}
        <div className="p-4 bg-[#1C1210] border border-[#36221E] rounded-2xl relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#A89689]">Net Operating Profit (EBITDA)</span>
            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
              pnl.netMarginPct >= 25
                ? 'bg-[#22C55E]/10 text-[#22C55E] border border-[#22C55E]/20'
                : 'bg-[#F59E0B]/10 text-[#F59E0B] border border-[#F59E0B]/20'
            }`}>
              {pnl.netMarginPct}% Net
            </span>
          </div>
          <p className="text-2xl font-black font-mono text-[#22C55E] mt-2">
            ₦{pnl.netProfit.toLocaleString()}
          </p>
          <div className="flex items-center justify-between text-[11px] text-[#A89689] mt-2 pt-2 border-t border-[#2A1B18]">
            <span>Total OPEX: ₦{pnl.operatingExpenses.totalOpex.toLocaleString()}</span>
            <span>Healthy QSR Standard</span>
          </div>
        </div>

        {/* Operating Shrinkage & Fuel Factor */}
        <div className="p-4 bg-[#1C1210] border border-[#36221E] rounded-2xl relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#A89689]">Diesel Gen & Wastage Loss</span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#EF4444]/10 text-[#EF4444] border border-[#EF4444]/20">
              Shrinkage & Energy
            </span>
          </div>
          <p className="text-2xl font-black font-mono text-[#EF4444] mt-2">
            ₦{(pnl.operatingExpenses.generatorAndPower + pnl.operatingExpenses.wastageShrinkage).toLocaleString()}
          </p>
          <div className="flex items-center justify-between text-[11px] text-[#A89689] mt-2 pt-2 border-t border-[#2A1B18]">
            <span>Gen Fuel: ₦{pnl.operatingExpenses.generatorAndPower.toLocaleString()}</span>
            <span>Waste: ₦{pnl.operatingExpenses.wastageShrinkage.toLocaleString()}</span>
          </div>
        </div>
      </div>

      {/* AI Strategic Intelligence & Anomaly Alerts */}
      <div className="p-4 bg-gradient-to-r from-[#241311] via-[#1C1210] to-[#1C1210] border border-[#800D15]/40 rounded-2xl space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#FFC700]" />
            <h2 className="text-sm font-bold text-[#FAF7F2]">
              AI Strategic Intelligence & Operational Anomalies
            </h2>
          </div>
          <span className="text-[11px] text-[#A89689]">Real-time margin alerts</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
          {aiInsights.map((insight) => (
            <div
              key={insight.id}
              className="p-3 bg-[#170E0D] border border-[#36221E] rounded-xl flex flex-col justify-between space-y-2 hover:border-[#FFC700]/30 transition-all"
            >
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <span
                    className={`px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider ${
                      insight.type === 'positive'
                        ? 'bg-[#22C55E]/10 text-[#22C55E] border border-[#22C55E]/20'
                        : insight.type === 'strategy'
                        ? 'bg-[#38BDF8]/10 text-[#38BDF8] border border-[#38BDF8]/20'
                        : 'bg-[#EF4444]/10 text-[#EF4444] border border-[#EF4444]/20'
                    }`}
                  >
                    {insight.type}
                  </span>
                  {insight.branchTarget && (
                    <span className="text-[10px] text-[#A89689]">{insight.branchTarget}</span>
                  )}
                </div>
                <h4 className="text-xs font-bold text-[#FAF7F2] line-clamp-1">{insight.title}</h4>
                <p className="text-[11px] text-[#C5B4A5] leading-relaxed line-clamp-3">
                  {insight.detail}
                </p>
              </div>
              {insight.metric && (
                <div className="pt-2 border-t border-[#2A1B18] flex items-center justify-between">
                  <span className="text-[10px] text-[#A89689]">Impact</span>
                  <span className="text-xs font-mono font-bold text-[#FFC700]">
                    {insight.metric}
                  </span>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Sub-Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-[#36221E] pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveSubTab('pnl')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
            activeSubTab === 'pnl'
              ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
              : 'text-[#C5B4A5] hover:bg-[#1C1210] hover:text-[#FAF7F2]'
          }`}
        >
          <BarChart3 className="w-4 h-4 text-[#FFC700]" />
          <span>P&L Statement & Waterfall</span>
        </button>

        <button
          onClick={() => setActiveSubTab('branches')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
            activeSubTab === 'branches'
              ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
              : 'text-[#C5B4A5] hover:bg-[#1C1210] hover:text-[#FAF7F2]'
          }`}
        >
          <Building2 className="w-4 h-4 text-[#38BDF8]" />
          <span>Branch Benchmarks ({branchBenchmarks.length})</span>
        </button>

        <button
          onClick={() => setActiveSubTab('hourly')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
            activeSubTab === 'hourly'
              ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
              : 'text-[#C5B4A5] hover:bg-[#1C1210] hover:text-[#FAF7F2]'
          }`}
        >
          <Clock className="w-4 h-4 text-[#F59E0B]" />
          <span>Hourly Rush & Kitchen Heatmap</span>
        </button>

        <button
          onClick={() => setActiveSubTab('bcg')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
            activeSubTab === 'bcg'
              ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
              : 'text-[#C5B4A5] hover:bg-[#1C1210] hover:text-[#FAF7F2]'
          }`}
        >
          <UtensilsCrossed className="w-4 h-4 text-[#22C55E]" />
          <span>BCG Menu Matrix ({menuMatrix.length})</span>
        </button>

        <button
          onClick={() => setActiveSubTab('labor')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
            activeSubTab === 'labor'
              ? 'bg-[#800D15] text-[#FAF7F2] shadow-md border border-[#FFC700]/30'
              : 'text-[#C5B4A5] hover:bg-[#1C1210] hover:text-[#FAF7F2]'
          }`}
        >
          <Users className="w-4 h-4 text-[#A855F7]" />
          <span>Wastage & Labor Productivity</span>
        </button>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* TAB 1: P&L STATEMENT & REVENUE WATERFALL                      */}
      {/* ------------------------------------------------------------- */}
      {activeSubTab === 'pnl' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Visual Waterfall / Cost Distribution */}
            <div className="p-5 bg-[#1C1210] border border-[#36221E] rounded-2xl space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-[#FAF7F2] flex items-center gap-2">
                  <PieChart className="w-4 h-4 text-[#FFC700]" /> Revenue Waterfall Breakdown
                </h3>
                <span className="text-[10px] text-[#A89689]">% of Net Sales</span>
              </div>

              <div className="space-y-3 text-xs">
                <div>
                  <div className="flex justify-between text-[#C5B4A5] mb-1">
                    <span>Gross Profit (After COGS)</span>
                    <span className="font-mono font-bold text-[#22C55E]">
                      {pnl.grossMarginPct}% (₦{pnl.grossProfit.toLocaleString()})
                    </span>
                  </div>
                  <div className="w-full h-3 bg-[#2A1B18] rounded-full overflow-hidden">
                    <div
                      className="h-full bg-[#22C55E] rounded-full transition-all"
                      style={{ width: `${Math.min(100, pnl.grossMarginPct)}%` }}
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-[#C5B4A5] mb-1">
                    <span>Cost of Goods Sold (Food Cost)</span>
                    <span className="font-mono font-bold text-[#F59E0B]">
                      {pnl.cogsPct}% (₦{pnl.cogs.toLocaleString()})
                    </span>
                  </div>
                  <div className="w-full h-3 bg-[#2A1B18] rounded-full overflow-hidden">
                    <div
                      className="h-full bg-[#F59E0B] rounded-full transition-all"
                      style={{ width: `${Math.min(100, pnl.cogsPct)}%` }}
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-[#C5B4A5] mb-1">
                    <span>Labor & Payroll Expense</span>
                    <span className="font-mono font-bold text-[#38BDF8]">
                      {pnl.netRevenue > 0
                        ? ((pnl.operatingExpenses.labor / pnl.netRevenue) * 100).toFixed(1)
                        : 0}% (₦{pnl.operatingExpenses.labor.toLocaleString()})
                    </span>
                  </div>
                  <div className="w-full h-3 bg-[#2A1B18] rounded-full overflow-hidden">
                    <div
                      className="h-full bg-[#38BDF8] rounded-full transition-all"
                      style={{
                        width: `${Math.min(
                          100,
                          pnl.netRevenue > 0 ? (pnl.operatingExpenses.labor / pnl.netRevenue) * 100 : 0
                        )}%`,
                      }}
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-[#C5B4A5] mb-1">
                    <span>Generator Diesel & Electricity</span>
                    <span className="font-mono font-bold text-[#EF4444]">
                      {pnl.netRevenue > 0
                        ? ((pnl.operatingExpenses.generatorAndPower / pnl.netRevenue) * 100).toFixed(1)
                        : 0}% (₦{pnl.operatingExpenses.generatorAndPower.toLocaleString()})
                    </span>
                  </div>
                  <div className="w-full h-3 bg-[#2A1B18] rounded-full overflow-hidden">
                    <div
                      className="h-full bg-[#EF4444] rounded-full transition-all"
                      style={{
                        width: `${Math.min(
                          100,
                          pnl.netRevenue > 0
                            ? (pnl.operatingExpenses.generatorAndPower / pnl.netRevenue) * 100
                            : 0
                        )}%`,
                      }}
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-[#C5B4A5] mb-1">
                    <span>Wastage & Spoilage Loss</span>
                    <span className="font-mono font-bold text-[#A855F7]">
                      {pnl.netRevenue > 0
                        ? ((pnl.operatingExpenses.wastageShrinkage / pnl.netRevenue) * 100).toFixed(1)
                        : 0}% (₦{pnl.operatingExpenses.wastageShrinkage.toLocaleString()})
                    </span>
                  </div>
                  <div className="w-full h-3 bg-[#2A1B18] rounded-full overflow-hidden">
                    <div
                      className="h-full bg-[#A855F7] rounded-full transition-all"
                      style={{
                        width: `${Math.min(
                          100,
                          pnl.netRevenue > 0
                            ? (pnl.operatingExpenses.wastageShrinkage / pnl.netRevenue) * 100
                            : 0
                        )}%`,
                      }}
                    />
                  </div>
                </div>

                <div className="pt-3 border-t border-[#2A1B18]">
                  <div className="flex justify-between text-xs font-bold text-[#FAF7F2] mb-1">
                    <span>Net Operating EBITDA Margin</span>
                    <span className="font-mono text-[#22C55E]">
                      {pnl.netMarginPct}% (₦{pnl.netProfit.toLocaleString()})
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Detailed Line-Item Executive P&L Table */}
            <div className="lg:col-span-2 p-5 bg-[#1C1210] border border-[#36221E] rounded-2xl space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-[#FAF7F2]">
                    Executive P&L Statement
                  </h3>
                  <p className="text-xs text-[#A89689]">
                    Standardized restaurant accounting framework
                  </p>
                </div>
                <button
                  onClick={() => handleExportCsv('pnl')}
                  className="px-2.5 py-1 bg-[#241311] hover:bg-[#36221E] border border-[#4D2924] rounded-lg text-xs font-semibold text-[#FFC700] flex items-center gap-1.5"
                >
                  <Download className="w-3 h-3" /> Export CSV
                </button>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left">
                  <thead>
                    <tr className="border-b border-[#36221E] text-[#A89689]">
                      <th className="pb-2 font-semibold">Account Category</th>
                      <th className="pb-2 font-semibold text-right">Amount (NGN)</th>
                      <th className="pb-2 font-semibold text-right">% of Net Sales</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#2A1B18]">
                    <tr className="hover:bg-[#241311]">
                      <td className="py-2.5 font-bold text-[#FAF7F2]">Gross Sales Collections</td>
                      <td className="py-2.5 font-mono font-bold text-right text-[#FAF7F2]">
                        ₦{pnl.grossRevenue.toLocaleString()}
                      </td>
                      <td className="py-2.5 font-mono text-right text-[#A89689]">
                        {pnl.netRevenue > 0
                          ? ((pnl.grossRevenue / pnl.netRevenue) * 100).toFixed(1)
                          : 100}%
                      </td>
                    </tr>
                    <tr className="hover:bg-[#241311]">
                      <td className="py-2.5 pl-4 text-[#C5B4A5]">Less: Discounts & Vouchers</td>
                      <td className="py-2.5 font-mono text-right text-[#EF4444]">
                        -₦{pnl.discounts.toLocaleString()}
                      </td>
                      <td className="py-2.5 font-mono text-right text-[#EF4444]">
                        {pnl.netRevenue > 0
                          ? ((pnl.discounts / pnl.netRevenue) * 100).toFixed(1)
                          : 0}%
                      </td>
                    </tr>
                    <tr className="bg-[#241311]/60 font-bold">
                      <td className="py-2.5 text-[#FFC700]">Net Sales Revenue</td>
                      <td className="py-2.5 font-mono text-right text-[#FFC700]">
                        ₦{pnl.netRevenue.toLocaleString()}
                      </td>
                      <td className="py-2.5 font-mono text-right text-[#FFC700]">100.0%</td>
                    </tr>
                    <tr className="hover:bg-[#241311]">
                      <td className="py-2.5 pl-4 text-[#C5B4A5]">
                        Less: Cost of Goods Sold (Food & Drink Cost)
                      </td>
                      <td className="py-2.5 font-mono text-right text-[#F59E0B]">
                        -₦{pnl.cogs.toLocaleString()}
                      </td>
                      <td className="py-2.5 font-mono text-right text-[#F59E0B]">
                        {pnl.cogsPct}%
                      </td>
                    </tr>
                    <tr className="bg-[#241311]/60 font-bold">
                      <td className="py-2.5 text-[#22C55E]">Gross Operating Profit</td>
                      <td className="py-2.5 font-mono text-right text-[#22C55E]">
                        ₦{pnl.grossProfit.toLocaleString()}
                      </td>
                      <td className="py-2.5 font-mono text-right text-[#22C55E]">
                        {pnl.grossMarginPct}%
                      </td>
                    </tr>

                    {/* Operating Expenses */}
                    <tr className="hover:bg-[#241311]">
                      <td className="py-2.5 pl-4 text-[#C5B4A5]">
                        Staff Labor & Shift Wages (Front & Kitchen)
                      </td>
                      <td className="py-2.5 font-mono text-right text-[#C5B4A5]">
                        -₦{pnl.operatingExpenses.labor.toLocaleString()}
                      </td>
                      <td className="py-2.5 font-mono text-right text-[#A89689]">
                        {pnl.netRevenue > 0
                          ? ((pnl.operatingExpenses.labor / pnl.netRevenue) * 100).toFixed(1)
                          : 0}%
                      </td>
                    </tr>
                    <tr className="hover:bg-[#241311]">
                      <td className="py-2.5 pl-4 text-[#C5B4A5]">
                        Generator Diesel Fuel & Power Utility
                      </td>
                      <td className="py-2.5 font-mono text-right text-[#C5B4A5]">
                        -₦{pnl.operatingExpenses.generatorAndPower.toLocaleString()}
                      </td>
                      <td className="py-2.5 font-mono text-right text-[#A89689]">
                        {pnl.netRevenue > 0
                          ? ((pnl.operatingExpenses.generatorAndPower / pnl.netRevenue) * 100).toFixed(1)
                          : 0}%
                      </td>
                    </tr>
                    <tr className="hover:bg-[#241311]">
                      <td className="py-2.5 pl-4 text-[#C5B4A5]">
                        Wastage, Spoilage & Kitchen Shrinkage
                      </td>
                      <td className="py-2.5 font-mono text-right text-[#C5B4A5]">
                        -₦{pnl.operatingExpenses.wastageShrinkage.toLocaleString()}
                      </td>
                      <td className="py-2.5 font-mono text-right text-[#A89689]">
                        {pnl.netRevenue > 0
                          ? ((pnl.operatingExpenses.wastageShrinkage / pnl.netRevenue) * 100).toFixed(1)
                          : 0}%
                      </td>
                    </tr>
                    <tr className="hover:bg-[#241311]">
                      <td className="py-2.5 pl-4 text-[#C5B4A5]">
                        Delivery Rider Fleet Logistics & Bike Fuel
                      </td>
                      <td className="py-2.5 font-mono text-right text-[#C5B4A5]">
                        -₦{pnl.operatingExpenses.deliveryFleet.toLocaleString()}
                      </td>
                      <td className="py-2.5 font-mono text-right text-[#A89689]">
                        {pnl.netRevenue > 0
                          ? ((pnl.operatingExpenses.deliveryFleet / pnl.netRevenue) * 100).toFixed(1)
                          : 0}%
                      </td>
                    </tr>
                    <tr className="bg-[#800D15]/20 font-black text-sm border-t-2 border-[#800D15]">
                      <td className="py-3 text-[#FAF7F2]">
                        Net Operating Profit (EBITDA)
                      </td>
                      <td className="py-3 font-mono text-right text-[#22C55E]">
                        ₦{pnl.netProfit.toLocaleString()}
                      </td>
                      <td className="py-3 font-mono text-right text-[#22C55E]">
                        {pnl.netMarginPct}%
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* TAB 2: MULTI-BRANCH COMPARATIVE BENCHMARKS                   */}
      {/* ------------------------------------------------------------- */}
      {activeSubTab === 'branches' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-[#FAF7F2]">
                Cross-Branch Performance & Benchmarks
              </h3>
              <p className="text-xs text-[#A89689]">
                Comparative unit economics for GRA, Okabere, and Ugbowo
              </p>
            </div>
            <button
              onClick={() => handleExportCsv('branches')}
              className="px-3 py-1.5 bg-[#241311] hover:bg-[#36221E] border border-[#4D2924] rounded-lg text-xs font-semibold text-[#38BDF8] flex items-center gap-1.5"
            >
              <Download className="w-3 h-3" /> Export Branch Benchmarks
            </button>
          </div>

          {/* Branch Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {branchBenchmarks.map((branch) => (
              <div
                key={branch.branchId}
                className={`p-5 bg-[#1C1210] border rounded-2xl space-y-4 transition-all ${
                  selectedBranch === branch.branchId
                    ? 'border-[#FFC700] ring-1 ring-[#FFC700]/30'
                    : 'border-[#36221E] hover:border-[#4D2924]'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] font-mono uppercase tracking-wider text-[#A89689]">
                      {branch.branchId.toUpperCase()} BRANCH
                    </span>
                    <h4 className="font-bold text-sm text-[#FAF7F2] mt-0.5">
                      {branch.branchName}
                    </h4>
                    <p className="text-[11px] text-[#C5B4A5]">{branch.tagline}</p>
                  </div>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#FFC700]/10 text-[#FFC700] border border-[#FFC700]/20">
                    {branch.revenueSharePct}% Share
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3 py-3 border-y border-[#2A1B18] text-xs">
                  <div>
                    <span className="text-[#A89689] text-[10px]">Gross Sales</span>
                    <p className="font-mono font-bold text-[#FFC700] text-base mt-0.5">
                      ₦{branch.grossSales.toLocaleString()}
                    </p>
                  </div>
                  <div>
                    <span className="text-[#A89689] text-[10px]">Net Profit</span>
                    <p className="font-mono font-bold text-[#22C55E] text-base mt-0.5">
                      ₦{branch.netProfitNaira.toLocaleString()}
                    </p>
                  </div>
                  <div>
                    <span className="text-[#A89689] text-[10px]">Average Check (AOV)</span>
                    <p className="font-mono font-bold text-[#FAF7F2] mt-0.5">
                      ₦{branch.aov.toLocaleString()}
                    </p>
                  </div>
                  <div>
                    <span className="text-[#A89689] text-[10px]">Orders Count</span>
                    <p className="font-mono font-bold text-[#38BDF8] mt-0.5">
                      {branch.orderCount} orders
                    </p>
                  </div>
                </div>

                {/* Branch Unit Economics */}
                <div className="space-y-2 text-xs">
                  <div className="flex justify-between items-center text-[#C5B4A5]">
                    <span>Food Cost (COGS)</span>
                    <span className="font-mono text-[#F59E0B] font-bold">{branch.cogsPct}%</span>
                  </div>
                  <div className="flex justify-between items-center text-[#C5B4A5]">
                    <span>Net Profit Margin</span>
                    <span className="font-mono text-[#22C55E] font-bold">{branch.netMarginPct}%</span>
                  </div>
                  <div className="flex justify-between items-center text-[#C5B4A5]">
                    <span>Table Turn Time</span>
                    <span className="font-mono text-[#FAF7F2]">{branch.avgTableTurnMinutes} mins</span>
                  </div>
                  <div className="flex justify-between items-center text-[#C5B4A5]">
                    <span>Delivery SLA Fulfillment</span>
                    <span className="font-mono text-[#38BDF8] font-bold">{branch.deliverySlaCompliancePct}%</span>
                  </div>
                  <div className="flex justify-between items-center text-[#C5B4A5]">
                    <span>Top Selling Anchor</span>
                    <span className="font-semibold text-[#FFC700] truncate max-w-[140px]">
                      {branch.topItemName}
                    </span>
                  </div>
                </div>

                {/* Channel Split Badges */}
                <div className="pt-2 border-t border-[#2A1B18] flex items-center justify-between text-[10px] text-[#A89689]">
                  <span>Dine-In: {branch.channelSplit.dineIn}</span>
                  <span>Takeaway: {branch.channelSplit.takeaway}</span>
                  <span>Delivery: {branch.channelSplit.delivery}</span>
                </div>
              </div>
            ))}
          </div>

          {/* Side by Side Comparative Benchmark Table */}
          <div className="p-5 bg-[#1C1210] border border-[#36221E] rounded-2xl space-y-4">
            <h3 className="text-sm font-bold text-[#FAF7F2]">
              Unit Economics Comparison Matrix
            </h3>
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead>
                  <tr className="border-b border-[#36221E] text-[#A89689]">
                    <th className="pb-2 font-semibold">Metric</th>
                    <th className="pb-2 font-semibold text-right">GRA Flagship</th>
                    <th className="pb-2 font-semibold text-right">Okabere (Sapele Rd)</th>
                    <th className="pb-2 font-semibold text-right">Ugbowo Campus</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#2A1B18]">
                  <tr className="hover:bg-[#241311]">
                    <td className="py-2.5 text-[#FAF7F2] font-semibold">Revenue Contribution</td>
                    {branchBenchmarks.map((b) => (
                      <td key={b.branchId} className="py-2.5 font-mono text-right text-[#FFC700] font-bold">
                        ₦{b.grossSales.toLocaleString()} ({b.revenueSharePct}%)
                      </td>
                    ))}
                  </tr>
                  <tr className="hover:bg-[#241311]">
                    <td className="py-2.5 text-[#C5B4A5]">Average Order Value (AOV)</td>
                    {branchBenchmarks.map((b) => (
                      <td key={b.branchId} className="py-2.5 font-mono text-right text-[#FAF7F2]">
                        ₦{b.aov.toLocaleString()}
                      </td>
                    ))}
                  </tr>
                  <tr className="hover:bg-[#241311]">
                    <td className="py-2.5 text-[#C5B4A5]">COGS Food Cost %</td>
                    {branchBenchmarks.map((b) => (
                      <td key={b.branchId} className="py-2.5 font-mono text-right text-[#F59E0B] font-bold">
                        {b.cogsPct}%
                      </td>
                    ))}
                  </tr>
                  <tr className="hover:bg-[#241311]">
                    <td className="py-2.5 text-[#C5B4A5]">Generator Fuel & Energy Burn</td>
                    {branchBenchmarks.map((b) => (
                      <td key={b.branchId} className="py-2.5 font-mono text-right text-[#EF4444]">
                        ₦{b.utilitiesFuelCostNaira.toLocaleString()}
                      </td>
                    ))}
                  </tr>
                  <tr className="hover:bg-[#241311]">
                    <td className="py-2.5 text-[#C5B4A5]">Wastage & Spoilage Loss</td>
                    {branchBenchmarks.map((b) => (
                      <td key={b.branchId} className="py-2.5 font-mono text-right text-[#A855F7]">
                        ₦{b.wastageLossNaira.toLocaleString()}
                      </td>
                    ))}
                  </tr>
                  <tr className="hover:bg-[#241311]">
                    <td className="py-2.5 text-[#C5B4A5]">Table Turnaround Velocity</td>
                    {branchBenchmarks.map((b) => (
                      <td key={b.branchId} className="py-2.5 font-mono text-right text-[#38BDF8]">
                        {b.avgTableTurnMinutes} minutes
                      </td>
                    ))}
                  </tr>
                  <tr className="bg-[#241311]/70 font-bold">
                    <td className="py-2.5 text-[#22C55E]">Net Operating Profit (EBITDA)</td>
                    {branchBenchmarks.map((b) => (
                      <td key={b.branchId} className="py-2.5 font-mono text-right text-[#22C55E]">
                        ₦{b.netProfitNaira.toLocaleString()} ({b.netMarginPct}%)
                      </td>
                    ))}
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* TAB 3: HOURLY SALES HEATMAP & KITCHEN LOAD                    */}
      {/* ------------------------------------------------------------- */}
      {activeSubTab === 'hourly' && (
        <div className="space-y-6">
          <div className="p-5 bg-[#1C1210] border border-[#36221E] rounded-2xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h3 className="text-sm font-bold text-[#FAF7F2] flex items-center gap-2">
                  <Flame className="w-4 h-4 text-[#EF4444]" /> Hourly Sales Flow & Rush Curve (08:00 – 21:00)
                </h3>
                <p className="text-xs text-[#A89689]">
                  Analyzes peak rush windows for kitchen prep staffing and delivery rider dispatch
                </p>
              </div>
              <div className="flex items-center gap-3 text-xs">
                <span className="flex items-center gap-1.5 text-[#A89689]">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#2A1B18] border border-[#4D2924]" /> Normal
                </span>
                <span className="flex items-center gap-1.5 text-[#FFC700]">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#FFC700]" /> Rush (Prep)
                </span>
                <span className="flex items-center gap-1.5 text-[#EF4444]">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#EF4444]" /> Peak (Kitchen Rush)
                </span>
              </div>
            </div>

            {/* Visual Column / Bar Curve */}
            <div className="grid grid-cols-7 sm:grid-cols-14 gap-2 items-end h-44 pt-6 pb-2 border-b border-[#2A1B18]">
              {hourlySales.map((slot) => {
                const heightPct = Math.max(12, Math.round((slot.revenue / maxHourlyRev) * 100));
                const barColor =
                  slot.rushLevel === 'peak'
                    ? 'bg-[#EF4444]'
                    : slot.rushLevel === 'rush'
                    ? 'bg-[#FFC700]'
                    : 'bg-[#4D2924] hover:bg-[#800D15]';

                return (
                  <div key={slot.hour} className="flex flex-col items-center h-full justify-end group relative">
                    {/* Tooltip on Hover */}
                    <div className="absolute -top-12 bg-[#241311] border border-[#4D2924] rounded-lg px-2 py-1 text-[10px] text-center font-mono opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-10 shadow-xl whitespace-nowrap">
                      <span className="font-bold text-[#FFC700]">₦{slot.revenue.toLocaleString()}</span>
                      <div className="text-[#A89689]">{slot.orderCount} orders</div>
                    </div>

                    <div
                      className={`w-full rounded-t-lg transition-all duration-300 ${barColor}`}
                      style={{ height: `${heightPct}%` }}
                    />
                    <span className="text-[9px] font-mono text-[#A89689] mt-2 group-hover:text-[#FAF7F2]">
                      {slot.hour.slice(0, 2)}h
                    </span>
                  </div>
                );
              })}
            </div>

            {/* Hourly Rush Highlights */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2">
              <div className="p-3 bg-[#241311] border border-[#36221E] rounded-xl space-y-1">
                <span className="text-[10px] font-bold text-[#38BDF8] uppercase tracking-wider">
                  Morning Breakfast & Bakery
                </span>
                <p className="text-xs font-bold text-[#FAF7F2]">08:00 AM – 11:00 AM</p>
                <p className="text-[11px] text-[#A89689]">
                  Fresh bread loaves, meat pies, and breakfast takeaways. Heavy bakery deck oven utilization.
                </p>
              </div>

              <div className="p-3 bg-[#241311] border border-[#36221E] rounded-xl space-y-1">
                <span className="text-[10px] font-bold text-[#FFC700] uppercase tracking-wider">
                  Midday Lunch Peak
                </span>
                <p className="text-xs font-bold text-[#FAF7F2]">12:00 PM – 02:30 PM</p>
                <p className="text-[11px] text-[#A89689]">
                  Asun Jollof rice, student combos, burger orders, and corporate delivery fleet departure.
                </p>
              </div>

              <div className="p-3 bg-[#241311] border border-[#36221E] rounded-xl space-y-1">
                <span className="text-[10px] font-bold text-[#EF4444] uppercase tracking-wider">
                  Evening Suya & Grills Peak
                </span>
                <p className="text-xs font-bold text-[#FAF7F2]">06:00 PM – 09:00 PM</p>
                <p className="text-[11px] text-[#A89689]">
                  Grilled catfish, signature suya platters, VIP lounge dining, and cold drink orders.
                </p>
              </div>
            </div>
          </div>

          {/* Kitchen Station Load & Throughput */}
          <div className="p-5 bg-[#1C1210] border border-[#36221E] rounded-2xl space-y-4">
            <h3 className="text-sm font-bold text-[#FAF7F2] flex items-center gap-2">
              <UtensilsCrossed className="w-4 h-4 text-[#FFC700]" /> Kitchen Station Load & SLA Compliance
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
              {laborProductivity.kitchenStations.map((station) => (
                <div
                  key={station.stationName}
                  className="p-3 bg-[#241311] border border-[#36221E] rounded-xl space-y-2"
                >
                  <span className="text-xs font-bold text-[#FAF7F2] block line-clamp-1">
                    {station.stationName}
                  </span>
                  <div className="space-y-1 text-xs">
                    <div className="flex justify-between text-[#A89689]">
                      <span>Completed</span>
                      <span className="font-mono font-bold text-[#FAF7F2]">{station.ordersCompleted}</span>
                    </div>
                    <div className="flex justify-between text-[#A89689]">
                      <span>Avg Prep Time</span>
                      <span className="font-mono font-bold text-[#38BDF8]">{station.avgPrepTimeMins} mins</span>
                    </div>
                    <div className="flex justify-between text-[#A89689]">
                      <span>On-Time SLA</span>
                      <span className="font-mono font-bold text-[#22C55E]">{station.onTimePct}%</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* TAB 4: BCG MENU ENGINEERING MATRIX                            */}
      {/* ------------------------------------------------------------- */}
      {activeSubTab === 'bcg' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-bold text-[#FAF7F2]">
                Menu Engineering Matrix (BCG Product Quadrants)
              </h3>
              <p className="text-xs text-[#A89689]">
                Optimizes profitability by plotting sales volume against gross profit margin
              </p>
            </div>
            <button
              onClick={() => handleExportCsv('menu')}
              className="px-3 py-1.5 bg-[#241311] hover:bg-[#36221E] border border-[#4D2924] rounded-lg text-xs font-semibold text-[#22C55E] flex items-center gap-1.5"
            >
              <Download className="w-3 h-3" /> Export Menu Matrix CSV
            </button>
          </div>

          {/* 4-Quadrant Filter Summary Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {/* Stars */}
            <button
              onClick={() => setSelectedBcgFilter(selectedBcgFilter === 'STAR' ? 'ALL' : 'STAR')}
              className={`p-3.5 rounded-2xl border text-left transition-all ${
                selectedBcgFilter === 'STAR'
                  ? 'bg-[#22C55E]/20 border-[#22C55E] ring-1 ring-[#22C55E]'
                  : 'bg-[#1C1210] border-[#36221E] hover:border-[#22C55E]/40'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold text-[#22C55E] uppercase tracking-wider">
                  ⭐ Stars ({starCount})
                </span>
                <span className="text-[10px] text-[#A89689]">High Vol • High Margin</span>
              </div>
              <p className="text-xs font-semibold text-[#FAF7F2] mt-1.5">
                Core Profit Drivers
              </p>
              <p className="text-[11px] text-[#A89689] mt-0.5">
                Protect recipe quality & maintain inventory stability.
              </p>
            </button>

            {/* Plowhorses */}
            <button
              onClick={() => setSelectedBcgFilter(selectedBcgFilter === 'PLOWHORSE' ? 'ALL' : 'PLOWHORSE')}
              className={`p-3.5 rounded-2xl border text-left transition-all ${
                selectedBcgFilter === 'PLOWHORSE'
                  ? 'bg-[#38BDF8]/20 border-[#38BDF8] ring-1 ring-[#38BDF8]'
                  : 'bg-[#1C1210] border-[#36221E] hover:border-[#38BDF8]/40'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold text-[#38BDF8] uppercase tracking-wider">
                  🐴 Plowhorses ({plowhorseCount})
                </span>
                <span className="text-[10px] text-[#A89689]">High Vol • Low Margin</span>
              </div>
              <p className="text-xs font-semibold text-[#FAF7F2] mt-1.5">
                High Volume Staples
              </p>
              <p className="text-[11px] text-[#A89689] mt-0.5">
                Re-engineer portion sizes or apply +5% price adjustment.
              </p>
            </button>

            {/* Puzzles */}
            <button
              onClick={() => setSelectedBcgFilter(selectedBcgFilter === 'PUZZLE' ? 'ALL' : 'PUZZLE')}
              className={`p-3.5 rounded-2xl border text-left transition-all ${
                selectedBcgFilter === 'PUZZLE'
                  ? 'bg-[#F59E0B]/20 border-[#F59E0B] ring-1 ring-[#F59E0B]'
                  : 'bg-[#1C1210] border-[#36221E] hover:border-[#F59E0B]/40'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold text-[#F59E0B] uppercase tracking-wider">
                  🧩 Puzzles ({puzzleCount})
                </span>
                <span className="text-[10px] text-[#A89689]">Low Vol • High Margin</span>
              </div>
              <p className="text-xs font-semibold text-[#FAF7F2] mt-1.5">
                Untapped Profit Margins
              </p>
              <p className="text-[11px] text-[#A89689] mt-0.5">
                Incentivize server table upselling or create combos.
              </p>
            </button>

            {/* Dogs */}
            <button
              onClick={() => setSelectedBcgFilter(selectedBcgFilter === 'DOG' ? 'ALL' : 'DOG')}
              className={`p-3.5 rounded-2xl border text-left transition-all ${
                selectedBcgFilter === 'DOG'
                  ? 'bg-[#EF4444]/20 border-[#EF4444] ring-1 ring-[#EF4444]'
                  : 'bg-[#1C1210] border-[#36221E] hover:border-[#EF4444]/40'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold text-[#EF4444] uppercase tracking-wider">
                  🦴 Dogs ({dogCount})
                </span>
                <span className="text-[10px] text-[#A89689]">Low Vol • Low Margin</span>
              </div>
              <p className="text-xs font-semibold text-[#FAF7F2] mt-1.5">
                Underperformers
              </p>
              <p className="text-[11px] text-[#A89689] mt-0.5">
                Reformulate ingredients, renegotiate raw costs, or retire.
              </p>
            </button>
          </div>

          {/* Interactive Menu Matrix Table */}
          <div className="p-5 bg-[#1C1210] border border-[#36221E] rounded-2xl space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[#FAF7F2]">
                Showing {filteredMenuMatrix.length} Items ({selectedBcgFilter} Filter)
              </span>
              {selectedBcgFilter !== 'ALL' && (
                <button
                  onClick={() => setSelectedBcgFilter('ALL')}
                  className="text-xs text-[#FFC700] hover:underline"
                >
                  Clear Filter
                </button>
              )}
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead>
                  <tr className="border-b border-[#36221E] text-[#A89689]">
                    <th className="pb-2 font-semibold">Item & Category</th>
                    <th className="pb-2 font-semibold text-center">Quadrant</th>
                    <th className="pb-2 font-semibold text-right">Volume</th>
                    <th className="pb-2 font-semibold text-right">Price</th>
                    <th className="pb-2 font-semibold text-right">Food Cost</th>
                    <th className="pb-2 font-semibold text-right">Margin %</th>
                    <th className="pb-2 font-semibold text-right">Total Profit</th>
                    <th className="pb-2 font-semibold pl-4">Strategic Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#2A1B18]">
                  {filteredMenuMatrix.map((item) => {
                    const badgeStyle =
                      item.quadrant === 'STAR'
                        ? 'bg-[#22C55E]/10 text-[#22C55E] border-[#22C55E]/30'
                        : item.quadrant === 'PLOWHORSE'
                        ? 'bg-[#38BDF8]/10 text-[#38BDF8] border-[#38BDF8]/30'
                        : item.quadrant === 'PUZZLE'
                        ? 'bg-[#F59E0B]/10 text-[#F59E0B] border-[#F59E0B]/30'
                        : 'bg-[#EF4444]/10 text-[#EF4444] border-[#EF4444]/30';

                    return (
                      <tr key={item.id} className="hover:bg-[#241311] transition-colors">
                        <td className="py-2.5">
                          <span className="font-bold text-[#FAF7F2] block">{item.name}</span>
                          <span className="text-[10px] text-[#A89689]">{item.category}</span>
                        </td>
                        <td className="py-2.5 text-center">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${badgeStyle}`}>
                            {item.quadrant}
                          </span>
                        </td>
                        <td className="py-2.5 font-mono text-right text-[#FAF7F2] font-semibold">
                          {item.volume}
                        </td>
                        <td className="py-2.5 font-mono text-right text-[#A89689]">
                          ₦{item.sellingPrice.toLocaleString()}
                        </td>
                        <td className="py-2.5 font-mono text-right text-[#A89689]">
                          ₦{item.foodCost.toLocaleString()}
                        </td>
                        <td className="py-2.5 font-mono text-right font-bold text-[#FFC700]">
                          {item.grossMarginPct}%
                        </td>
                        <td className="py-2.5 font-mono text-right font-bold text-[#22C55E]">
                          ₦{item.grossProfit.toLocaleString()}
                        </td>
                        <td className="py-2.5 pl-4 text-[11px] text-[#C5B4A5] max-w-xs">
                          {item.strategicRecommendation}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* TAB 5: WASTAGE & LABOR PRODUCTIVITY                          */}
      {/* ------------------------------------------------------------- */}
      {activeSubTab === 'labor' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Cashier Speed & Checkout Leaderboard */}
            <div className="p-5 bg-[#1C1210] border border-[#36221E] rounded-2xl space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-[#FAF7F2] flex items-center gap-2">
                  <Award className="w-4 h-4 text-[#FFC700]" /> Cashier Checkout & Velocity Leaderboard
                </h3>
                <span className="text-[10px] text-[#A89689]">Front of House Productivity</span>
              </div>

              <div className="space-y-2 text-xs">
                {laborProductivity.cashierLeaderboard.map((c, idx) => (
                  <div
                    key={c.staffId}
                    className="p-3 bg-[#241311] border border-[#36221E] rounded-xl flex items-center justify-between"
                  >
                    <div className="flex items-center gap-2.5">
                      <span className="w-6 h-6 rounded-full bg-[#800D15] text-[#FFC700] text-xs font-mono font-bold flex items-center justify-center">
                        #{idx + 1}
                      </span>
                      <div>
                        <span className="font-bold text-[#FAF7F2] block">{c.name}</span>
                        <span className="text-[10px] text-[#A89689] uppercase">
                          {c.branchId.toUpperCase()} BRANCH
                        </span>
                      </div>
                    </div>
                    <div className="text-right space-y-0.5">
                      <div className="font-mono font-bold text-[#FFC700]">
                        ₦{c.totalRevenue.toLocaleString()}
                      </div>
                      <div className="text-[11px] text-[#A89689]">
                        {c.ordersProcessed} orders • {c.avgProcessingSecs}s avg check
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Rider Delivery SLA & Transit Velocity */}
            <div className="p-5 bg-[#1C1210] border border-[#36221E] rounded-2xl space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-[#FAF7F2] flex items-center gap-2">
                  <Bike className="w-4 h-4 text-[#38BDF8]" /> Fleet Rider Fulfillment SLA
                </h3>
                <span className="text-[10px] text-[#A89689]">Last-Mile Logistics</span>
              </div>

              <div className="space-y-2 text-xs">
                {laborProductivity.riderLogistics.map((r, idx) => (
                  <div
                    key={r.riderId}
                    className="p-3 bg-[#241311] border border-[#36221E] rounded-xl flex items-center justify-between"
                  >
                    <div className="flex items-center gap-2.5">
                      <span className="w-6 h-6 rounded-full bg-[#1C1210] border border-[#38BDF8]/40 text-[#38BDF8] text-xs font-mono font-bold flex items-center justify-center">
                        #{idx + 1}
                      </span>
                      <div>
                        <span className="font-bold text-[#FAF7F2] block">{r.name}</span>
                        <span className="text-[10px] text-[#22C55E] font-bold">
                          {r.onTimeRate}% On-Time SLA
                        </span>
                      </div>
                    </div>
                    <div className="text-right space-y-0.5">
                      <div className="font-mono font-bold text-[#FAF7F2]">
                        {r.completedDrops} drops
                      </div>
                      <div className="text-[11px] text-[#A89689]">
                        {r.avgTransitMins} mins avg transit
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Wastage Forensic Shrinkage Audit */}
          <div className="p-5 bg-[#1C1210] border border-[#36221E] rounded-2xl space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-[#FAF7F2] flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 text-[#EF4444]" /> Wastage & Shrinkage Forensic Breakdown
                </h3>
                <p className="text-xs text-[#A89689]">
                  Total Recorded Loss: ₦{wastageAudit.totalLossNaira.toLocaleString()}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* By Category */}
              <div className="space-y-2 text-xs">
                <span className="text-[11px] font-bold text-[#A89689] uppercase tracking-wider block">
                  Shrinkage by Ingredient Category
                </span>
                {wastageAudit.byCategory.map((cat) => (
                  <div key={cat.category} className="space-y-1">
                    <div className="flex justify-between text-[#C5B4A5]">
                      <span>{cat.category}</span>
                      <span className="font-mono font-bold text-[#FAF7F2]">
                        ₦{cat.amount.toLocaleString()} ({cat.pct}%)
                      </span>
                    </div>
                    <div className="w-full h-2 bg-[#2A1B18] rounded-full overflow-hidden">
                      <div
                        className="h-full bg-[#EF4444] rounded-full"
                        style={{ width: `${Math.min(100, cat.pct)}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>

              {/* By Reason */}
              <div className="space-y-2 text-xs">
                <span className="text-[11px] font-bold text-[#A89689] uppercase tracking-wider block">
                  Losses by Incident Reason
                </span>
                <div className="space-y-2">
                  {wastageAudit.byReason.map((r) => (
                    <div
                      key={r.reason}
                      className="flex justify-between items-center p-2.5 bg-[#241311] rounded-xl"
                    >
                      <div>
                        <span className="font-semibold text-[#FAF7F2] block">{r.reason}</span>
                        <span className="text-[10px] text-[#A89689]">{r.count} incidents logged</span>
                      </div>
                      <span className="font-mono font-bold text-[#EF4444]">
                        ₦{r.lossNaira.toLocaleString()}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
