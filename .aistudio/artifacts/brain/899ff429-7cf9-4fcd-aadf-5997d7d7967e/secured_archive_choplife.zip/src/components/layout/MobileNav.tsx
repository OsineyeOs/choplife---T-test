import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  Home,
  UtensilsCrossed,
  Search,
  ShoppingBag,
  User,
  Clock,
} from 'lucide-react';

export const MobileNav: React.FC = () => {
  const {
    cartCount,
    cartSubtotal,
    setIsCartOpen,
    setIsAccountModalOpen,
    activeTrackingOrder,
    setActiveTrackingOrder,
    formatNaira,
    searchQuery,
    setSearchQuery,
  } = useApp();

  const handleSearchClick = () => {
    const searchInput = document.getElementById('desktop-search-input') || document.getElementById('mobile-search-input');
    const menuEl = document.getElementById('menu-explorer-section');
    if (menuEl) {
      menuEl.scrollIntoView({ behavior: 'smooth' });
    }
    if (searchInput) {
      searchInput.focus();
    }
  };

  const handleMenuClick = () => {
    const menuEl = document.getElementById('menu-explorer-section');
    if (menuEl) {
      menuEl.scrollIntoView({ behavior: 'smooth' });
    } else {
      window.scrollTo({ top: 400, behavior: 'smooth' });
    }
  };

  return (
    <nav
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-lg border-t border-[#E5DEC9] px-2 py-1.5 shadow-2xl safe-area-inset-bottom"
      id="mobile-bottom-nav"
      aria-label="Mobile Navigation"
    >
      <div className="grid grid-cols-5 gap-1 items-center max-w-md mx-auto">
        {/* Home */}
        <button
          onClick={() => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="flex flex-col items-center justify-center py-1.5 text-[#4D080F] hover:text-[#E62E00] active:scale-95 transition-all"
          id="mobile-nav-home"
          aria-label="Home"
        >
          <Home className="w-5 h-5" />
          <span className="text-[10px] font-montserrat font-bold mt-0.5">Home</span>
        </button>

        {/* Menu */}
        <button
          onClick={handleMenuClick}
          className="flex flex-col items-center justify-center py-1.5 text-[#4D080F] hover:text-[#E62E00] active:scale-95 transition-all"
          id="mobile-nav-menu"
          aria-label="Full Menu"
        >
          <UtensilsCrossed className="w-5 h-5" />
          <span className="text-[10px] font-montserrat font-bold mt-0.5">Menu</span>
        </button>

        {/* Floating Cart Button in Center */}
        <button
          onClick={() => setIsCartOpen(true)}
          className="flex flex-col items-center justify-center -mt-6 relative group active:scale-95 transition-transform"
          id="mobile-nav-cart"
          aria-label="View Cart"
        >
          <div className="w-13 h-13 rounded-full bg-[#E62E00] text-white flex items-center justify-center shadow-lg border-3 border-white">
            <ShoppingBag className="w-6 h-6 text-[#FFC700]" />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-[#FFC700] text-[#4D080F] font-titan text-[10px] w-5 h-5 rounded-full flex items-center justify-center border-2 border-[#4D080F] animate-bounce">
                {cartCount}
              </span>
            )}
          </div>
          <span className="text-[10px] font-montserrat font-extrabold text-[#E62E00] mt-0.5 whitespace-nowrap">
            {cartCount > 0 ? formatNaira(cartSubtotal) : 'Cart'}
          </span>
        </button>

        {/* Search */}
        <button
          onClick={handleSearchClick}
          className={`flex flex-col items-center justify-center py-1.5 transition-all active:scale-95 ${
            searchQuery ? 'text-[#E62E00]' : 'text-[#4D080F] hover:text-[#E62E00]'
          }`}
          id="mobile-nav-search"
          aria-label="Search Dishes"
        >
          <Search className="w-5 h-5" />
          <span className="text-[10px] font-montserrat font-bold mt-0.5">Search</span>
        </button>

        {/* Account / Orders */}
        <button
          onClick={() => {
            if (activeTrackingOrder) {
              setActiveTrackingOrder(activeTrackingOrder);
            } else {
              setIsAccountModalOpen(true);
            }
          }}
          className={`flex flex-col items-center justify-center py-1.5 transition-all active:scale-95 ${
            activeTrackingOrder ? 'text-emerald-700 font-bold' : 'text-[#4D080F] hover:text-[#E62E00]'
          }`}
          id="mobile-nav-account"
          aria-label="Orders and Account"
        >
          {activeTrackingOrder ? (
            <Clock className="w-5 h-5 animate-pulse text-emerald-600" />
          ) : (
            <User className="w-5 h-5" />
          )}
          <span className="text-[10px] font-montserrat font-bold mt-0.5">
            {activeTrackingOrder ? 'Tracking' : 'Account'}
          </span>
        </button>
      </div>
    </nav>
  );
};
