import React from 'react';
import { BrandLogo } from '../ui/BrandLogo';
import { useApp } from '../../context/AppContext';
import {
  MapPin,
  Phone,
  MessageCircle,
  Clock,
  ExternalLink,
  Sparkles,
  Lock,
  Heart,
  Award,
  Flame,
  Store,
  ShieldCheck,
} from 'lucide-react';

export interface FooterProps {
  onNavigateRoute?: (route: 'storefront' | 'pos' | 'admin') => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigateRoute }) => {
  const {
    branches,
    setSelectedBranchId,
    setIsLocationsModalOpen,
    setIsCateringModalOpen,
    setIsStaffLoginModalOpen,
    setIsAccountModalOpen,
    setActiveCategory,
    currentStaff,
    navigateToOperations,
  } = useApp();

  return (
    <footer className="bg-[#3D0007] text-[#FAF7F2] pt-16 pb-36 sm:pb-24 border-t-4 border-[#E62E00]" id="main-footer">
      {/* Upper Slogan Banner */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-12">
        <div className="bg-[#4D080F] border border-[#FFC700]/30 rounded-3xl p-6 sm:p-10 flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl">
          <div className="text-center md:text-left">
            <span className="text-[#FFC700] text-xs font-titan tracking-widest uppercase mb-1 block">
              THE CHOPLIFE REPUBLIC CREED
            </span>
            <h2 className="font-titan text-2xl sm:text-3xl lg:text-4xl text-white tracking-tight leading-tight">
              ENJOY YOURSELF, <br className="hidden sm:inline" />
              <span className="text-[#FFC700]">IS THAT TOO MUCH TO ASK?</span>
            </h2>
            <p className="text-white/80 font-montserrat text-sm mt-2 max-w-xl">
              From our famous Benin City small chops to flame-grilled suya chicken, loaded double shawarmas, and smoky party jollof. Maximum enjoyment guaranteed.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row items-center gap-3 shrink-0">
            <button
              onClick={() => {
                window.scrollTo({ top: 500, behavior: 'smooth' });
              }}
              className="bg-[#E62E00] hover:bg-[#FF3E1D] text-white font-titan text-sm px-6 py-3.5 rounded-2xl shadow-lg transition-transform active:scale-95"
              id="footer-order-now-cta"
            >
              START YOUR ORDER
            </button>
            <button
              onClick={() => setIsCateringModalOpen(true)}
              className="bg-[#FFC700] hover:bg-[#FFD733] text-[#4D080F] font-titan text-sm px-6 py-3.5 rounded-2xl shadow-lg transition-transform active:scale-95 flex items-center gap-1.5"
              id="footer-catering-cta"
            >
              <Sparkles className="w-4 h-4 text-[#4D080F]" />
              PLAN EVENT CATERING
            </button>
          </div>
        </div>
      </div>

      {/* Main Footer Links & Branch Cards */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 lg:gap-10 pb-12 border-b border-white/10">
          
          {/* Col 1: Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <BrandLogo variant="full" theme="white" size="lg" />
            <p className="text-white/70 font-montserrat text-xs sm:text-sm leading-relaxed max-w-sm">
              Choplife Republic is Benin City’s premier Nigerian QSR and food lifestyle brand. Founded in 2022, we operate 3 flagship kitchens in Okabere, GRA, and Ugbowo serving thousands of happy food lovers every day.
            </p>
            <div className="flex items-center gap-3 pt-2">
              <div className="bg-white/10 px-3 py-1.5 rounded-xl border border-white/10 flex items-center gap-2">
                <Award className="w-4 h-4 text-[#FFC700]" />
                <span className="text-xs font-montserrat font-bold text-white">4.8★ Benin City Rating</span>
              </div>
              <div className="bg-white/10 px-3 py-1.5 rounded-xl border border-white/10 flex items-center gap-2">
                <Flame className="w-4 h-4 text-[#E62E00]" />
                <span className="text-xs font-montserrat font-bold text-white">100% Fresh Daily</span>
              </div>
            </div>
          </div>

          {/* Col 2: Fast Ordering Categories */}
          <div>
            <h3 className="font-titan text-sm text-[#FFC700] tracking-wider uppercase mb-4">
              Explore Menu
            </h3>
            <ul className="space-y-2.5 text-xs font-montserrat font-semibold text-white/80">
              <li>
                <button
                  onClick={() => {
                    setActiveCategory('small-chops');
                    document.getElementById('menu-explorer-section')?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="hover:text-[#FFC700] transition-colors"
                >
                  🥟 Small Chops & Box Builder
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setActiveCategory('bakery');
                    document.getElementById('menu-explorer-section')?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="hover:text-[#FFC700] transition-colors"
                >
                  🍞 Choplife Bakery & Bread
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setActiveCategory('snacks');
                    document.getElementById('menu-explorer-section')?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="hover:text-[#FFC700] transition-colors"
                >
                  🌯 Chicken Shawarma & Snacks
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setActiveCategory('protein');
                    document.getElementById('menu-explorer-section')?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="hover:text-[#FFC700] transition-colors"
                >
                  🍗 Flame Grills & Whole Fish
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setActiveCategory('food');
                    document.getElementById('menu-explorer-section')?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="hover:text-[#FFC700] transition-colors"
                >
                  🍲 Smoky Party Jollof & QSR Food
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setActiveCategory('drinks');
                    document.getElementById('menu-explorer-section')?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="hover:text-[#FFC700] transition-colors"
                >
                  🥤 Chilled Drinks, Zobo & Parfaits
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Customer Services */}
          <div>
            <h3 className="font-titan text-sm text-[#FFC700] tracking-wider uppercase mb-4">
              Services & Help
            </h3>
            <ul className="space-y-2.5 text-xs font-montserrat font-semibold text-white/80">
              <li>
                <button
                  onClick={() => setIsLocationsModalOpen(true)}
                  className="hover:text-[#FFC700] transition-colors flex items-center gap-1.5"
                >
                  <MapPin className="w-3.5 h-3.5 text-[#E62E00]" />
                  Branch Locations & Map
                </button>
              </li>
              <li>
                <button
                  onClick={() => setIsCateringModalOpen(true)}
                  className="hover:text-[#FFC700] transition-colors flex items-center gap-1.5"
                >
                  <Sparkles className="w-3.5 h-3.5 text-[#FFC700]" />
                  Bulk Orders & Party Quote
                </button>
              </li>
              <li>
                <button
                  onClick={() => setIsAccountModalOpen(true)}
                  className="hover:text-[#FFC700] transition-colors"
                >
                  My Order History & Reorder
                </button>
              </li>
              <li>
                <a
                  href="mailto:orders@choplife.ng"
                  className="hover:text-white transition-colors flex items-center gap-1.5 text-left text-xs"
                  id="footer-email-support"
                >
                  <span>orders@choplife.ng</span>
                </a>
              </li>
              <li>
                <a
                  href="tel:+2348158177897"
                  className="hover:text-white transition-colors flex items-center gap-1.5 text-left text-xs font-mono"
                  id="footer-phone-support"
                >
                  <span>+234 815 817 7897</span>
                </a>
              </li>
            </ul>
          </div>

          {/* Col 4: Branch WhatsApp Catalogues */}
          <div>
            <h3 className="font-titan text-sm text-[#FFC700] tracking-wider uppercase mb-4">
              WhatsApp Catalogues
            </h3>
            <p className="text-[11px] text-white/60 font-montserrat mb-3">
              Alternative ordering channels via official WhatsApp catalogues:
            </p>
            <div className="space-y-2 text-xs font-montserrat">
              {branches.map((b) => (
                <a
                  key={b.id}
                  href={b.whatsappCatalogueUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-between p-2 rounded-xl bg-white/5 hover:bg-[#25D366]/20 border border-white/10 hover:border-[#25D366] transition-all group"
                  id={`footer-whatsapp-link-${b.id}`}
                >
                  <div className="flex items-center gap-2">
                    <MessageCircle className="w-3.5 h-3.5 text-[#25D366]" />
                    <span className="font-bold text-white group-hover:text-[#25D366]">{b.shortName}</span>
                  </div>
                  <ExternalLink className="w-3 h-3 text-white/40 group-hover:text-white" />
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* 3 Physical Branches Strip */}
        <div className="py-8 grid grid-cols-1 md:grid-cols-3 gap-4 border-b border-white/10">
          {branches.map((b) => (
            <div
              key={b.id}
              className="bg-white/5 rounded-2xl p-4 border border-white/10 space-y-2"
              id={`footer-branch-card-${b.id}`}
            >
              <div className="flex items-center justify-between">
                <h4 className="font-titan text-sm text-[#FFC700]">{b.name}</h4>
                {b.id === 'ugbowo' && new Date().getDay() === 0 ? (
                  <span className="text-[10px] font-bold text-amber-400 bg-amber-950/60 px-2 py-0.5 rounded-full border border-amber-800">
                    Closed Sundays (Opens Mon 8 AM)
                  </span>
                ) : (
                  <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded-full border border-emerald-800">
                    Open Today
                  </span>
                )}
              </div>
              <p className="text-xs text-white/80 font-montserrat flex items-start gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-[#E62E00] shrink-0 mt-0.5" />
                <span>{b.address}, {b.city}</span>
              </p>
              <div className="flex items-center justify-between text-xs text-white/70 pt-1 font-montserrat">
                <span className="flex items-center gap-1">
                  <Phone className="w-3 h-3 text-[#FFC700]" />
                  {b.phone}
                </span>
                <span className="flex items-center gap-1 text-[11px]">
                  <Clock className="w-3 h-3 text-white/50" />
                  {b.openingHours}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom copyright & Slogans */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs font-montserrat text-white/60 gap-4">
          <p className="flex items-center gap-1.5 flex-wrap">
            <span>© {new Date().getFullYear()} Choplife Republic Ltd. All rights reserved. Registered in Nigeria.</span>
            {currentStaff && (
              <button
                onClick={() => navigateToOperations()}
                className="inline-flex items-center gap-1 text-[11px] font-bold text-[#FFC700] hover:underline ml-2 px-2 py-0.5 rounded bg-white/10"
                id="footer-back-to-ops-btn"
                title="Return to Staff Operations Workspace"
              >
                <Lock className="w-3 h-3" />
                <span>Return to Staff Operations ({currentStaff.name.split(' ')[0]})</span>
              </button>
            )}
          </p>
          <div className="flex items-center gap-4 text-xs font-montserrat">
            <span className="text-[#FFC700] font-titan tracking-wider">EAT, ENJOY, REPEAT.</span>
            <span>•</span>
            <span className="text-emerald-400 font-bold">100% Maximum Enjoyment</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
