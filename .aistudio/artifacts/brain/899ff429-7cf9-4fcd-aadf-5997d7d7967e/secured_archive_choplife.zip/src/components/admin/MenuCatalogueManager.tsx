import React, { useState, useEffect, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  UtensilsCrossed,
  Search,
  Plus,
  Edit2,
  Trash2,
  CheckCircle2,
  AlertCircle,
  Eye,
  Filter,
  Layers,
  Sparkles,
  RefreshCw,
  Sliders,
  DollarSign,
  Tag,
  Store,
  Globe,
  ArrowUpDown,
  Flame,
  Clock,
} from 'lucide-react';

export interface MenuCategoryItem {
  id: string;
  name: string;
  tag: string;
  description: string;
  icon: string;
  badge?: string;
  sortOrder: number;
  channels: ('website' | 'pos')[];
  isActive: boolean;
  updatedAt: string;
}

export interface MenuProductItem {
  id: string;
  name: string;
  shortDescription: string;
  longDescription: string;
  category: string;
  subcategory?: string;
  image: string;
  basePrice: number;
  branchPrices?: Record<string, number>;
  branchAvailability: Record<string, boolean>;
  prepTimeMinutes: number;
  isPopular?: boolean;
  isFeatured?: boolean;
  isNewProduct?: boolean;
  isSpicy?: boolean;
  isVegetarian?: boolean;
  packagingCharge?: number;
  channels: ('website' | 'pos')[];
  status: 'published' | 'draft' | 'archived';
  updatedAt: string;
}

export const MenuCatalogueManager: React.FC = () => {
  const { formatNaira, branches } = useApp();
  const [activeTab, setActiveTab] = useState<'products' | 'categories'>('products');
  const [products, setProducts] = useState<MenuProductItem[]>([]);
  const [categories, setCategories] = useState<MenuCategoryItem[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [channelFilter, setChannelFilter] = useState<'all' | 'website' | 'pos'>('all');

  // Edit / Create Modals
  const [editingCategory, setEditingCategory] = useState<MenuCategoryItem | null>(null);
  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState<boolean>(false);

  const [editingProduct, setEditingProduct] = useState<MenuProductItem | null>(null);
  const [isProductModalOpen, setIsProductModalOpen] = useState<boolean>(false);

  const [isUploadingImage, setIsUploadingImage] = useState<boolean>(false);

  const getAuthHeaders = () => {
    const sessionToken = localStorage.getItem('choplife_staff_token') || sessionStorage.getItem('choplife_staff_token');
    return {
      'Content-Type': 'application/json',
      ...(sessionToken ? { Authorization: `Bearer ${sessionToken}` } : {}),
    };
  };

  const handleProductImageUpload = async (file: File) => {
    if (!editingProduct) return;
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
      setFeedback({ type: 'error', message: 'Only JPEG, PNG, and WebP images are permitted.' });
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setFeedback({ type: 'error', message: 'Image file size must be 5 MB or less.' });
      return;
    }
    setIsUploadingImage(true);
    try {
      const dataBase64 = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result || ''));
        reader.onerror = () => reject(new Error('File read error'));
        reader.readAsDataURL(file);
      });
      const res = await fetch('/api/uploads/image', {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({
          fileName: file.name,
          mimeType: file.type,
          dataBase64,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        setEditingProduct({ ...editingProduct, image: data.url });
        setFeedback({ type: 'success', message: `Uploaded image '${data.filename}' (${Math.round(data.sizeBytes / 1024)} KB).` });
      } else {
        const err = await res.json().catch(() => ({}));
        setFeedback({ type: 'error', message: err.error || 'Image upload failed.' });
      }
    } catch {
      setFeedback({ type: 'error', message: 'Network error uploading product image.' });
    } finally {
      setIsUploadingImage(false);
    }
  };

  const fetchData = async () => {
    setIsLoading(true);
    try {
      const [resCats, resProds] = await Promise.all([
        fetch('/api/categories'),
        fetch('/api/menu/products'),
      ]);
      if (resCats.ok) setCategories(await resCats.json());
      if (resProds.ok) setProducts(await resProds.json());
    } catch {
      setFeedback({ type: 'error', message: 'Failed to load menu data from server.' });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Filtered Products
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      const matchQuery =
        !searchQuery ||
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (p.shortDescription && p.shortDescription.toLowerCase().includes(searchQuery.toLowerCase()));

      const matchCategory = categoryFilter === 'all' || p.category === categoryFilter;

      const matchChannel =
        channelFilter === 'all' || (p.channels && p.channels.includes(channelFilter));

      return matchQuery && matchCategory && matchChannel;
    });
  }, [products, searchQuery, categoryFilter, channelFilter]);

  // Toggle Category Status
  const handleToggleCategoryActive = async (cat: MenuCategoryItem) => {
    try {
      const res = await fetch(`/api/categories/${cat.id}`, {
        method: 'PUT',
        headers: getAuthHeaders(),
        body: JSON.stringify({ isActive: !cat.isActive }),
      });
      if (res.ok) {
        const data = await res.json();
        setCategories((prev) => prev.map((c) => (c.id === cat.id ? data.category : c)));
        setFeedback({
          type: 'success',
          message: `Category '${cat.name}' is now ${!cat.isActive ? 'active' : 'hidden'}.`,
        });
      }
    } catch {
      setFeedback({ type: 'error', message: 'Failed to update category.' });
    }
  };

  // Save Category Modal
  const handleSaveCategory = async () => {
    if (!editingCategory || !editingCategory.name.trim()) return;
    const isNew = !categories.some((c) => c.id === editingCategory.id);
    const endpoint = isNew ? '/api/categories' : `/api/categories/${editingCategory.id}`;
    const method = isNew ? 'POST' : 'PUT';

    try {
      const res = await fetch(endpoint, {
        method,
        headers: getAuthHeaders(),
        body: JSON.stringify(editingCategory),
      });

      if (res.ok) {
        const data = await res.json();
        if (isNew) {
          setCategories((prev) => [...prev, data.category]);
        } else {
          setCategories((prev) => prev.map((c) => (c.id === editingCategory.id ? data.category : c)));
        }
        setIsCategoryModalOpen(false);
        setEditingCategory(null);
        setFeedback({
          type: 'success',
          message: `Category '${data.category.name}' saved successfully!`,
        });
      } else {
        const err = await res.json().catch(() => ({}));
        setFeedback({ type: 'error', message: err.error || 'Failed to save category.' });
      }
    } catch {
      setFeedback({ type: 'error', message: 'Network error saving category.' });
    }
  };

  // Toggle Product Availability for Branch
  const handleToggleProductAvailability = async (productId: string, branchId: string) => {
    const p = products.find((item) => item.id === productId);
    if (!p) return;

    const currentBranchAvail = p.branchAvailability || { gra: true, okabere: true, ugbowo: true };
    const updatedAvail = {
      ...currentBranchAvail,
      [branchId]: !currentBranchAvail[branchId],
    };

    try {
      const res = await fetch(`/api/menu/products/${productId}`, {
        method: 'PUT',
        headers: getAuthHeaders(),
        body: JSON.stringify({ branchAvailability: updatedAvail }),
      });

      if (res.ok) {
        const data = await res.json();
        setProducts((prev) => prev.map((item) => (item.id === productId ? data.product : item)));
        setFeedback({
          type: 'success',
          message: `${p.name} at ${branchId.toUpperCase()} is now ${updatedAvail[branchId] ? 'IN STOCK' : 'SOLD OUT (86)'}.`,
        });
      }
    } catch {
      setFeedback({ type: 'error', message: 'Failed to update branch stock status.' });
    }
  };

  // Save Product Modal
  const handleSaveProduct = async () => {
    if (!editingProduct || !editingProduct.name.trim() || !editingProduct.basePrice) return;
    const isNew = !products.some((p) => p.id === editingProduct.id);
    const endpoint = isNew ? '/api/menu/products' : `/api/menu/products/${editingProduct.id}`;
    const method = isNew ? 'POST' : 'PUT';

    try {
      const res = await fetch(endpoint, {
        method,
        headers: getAuthHeaders(),
        body: JSON.stringify(editingProduct),
      });

      if (res.ok) {
        const data = await res.json();
        if (isNew) {
          setProducts((prev) => [...prev, data.product]);
        } else {
          setProducts((prev) => prev.map((p) => (p.id === editingProduct.id ? data.product : p)));
        }
        setIsProductModalOpen(false);
        setEditingProduct(null);
        setFeedback({
          type: 'success',
          message: `Product '${data.product.name}' saved successfully!`,
        });
      } else {
        const err = await res.json().catch(() => ({}));
        setFeedback({ type: 'error', message: err.error || 'Failed to save product.' });
      }
    } catch {
      setFeedback({ type: 'error', message: 'Network error saving product.' });
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-[#120B0A] text-[#FAF7F2] overflow-hidden">
      {/* Header Bar */}
      <div className="h-16 px-6 bg-[#1C1210] border-b border-[#36221E] flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-[#800D15]/40 border border-[#FFC700]/30 flex items-center justify-center text-[#FFC700]">
            <UtensilsCrossed className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-black uppercase tracking-wider text-[#FAF7F2]">
                Menu & Catalogue Administration
              </h2>
              <span className="px-2 py-0.5 rounded-md bg-[#FFC700]/15 text-[#FFC700] text-[10px] font-bold tracking-wider uppercase border border-[#FFC700]/30">
                Centralized Master
              </span>
            </div>
            <p className="text-[11px] text-[#A89689]">
              Manage categories, products, pricing, branch availability overrides, and sales channel visibility
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={fetchData}
            className="p-2 rounded-xl bg-[#241311] hover:bg-[#36221E] text-[#A89689] hover:text-[#FAF7F2] border border-[#36221E] transition-all"
            title="Reload from Database"
          >
            <RefreshCw className="w-4 h-4" />
          </button>

          {activeTab === 'categories' ? (
            <button
              onClick={() => {
                setEditingCategory({
                  id: '',
                  name: '',
                  tag: '',
                  description: '',
                  icon: '🍲',
                  badge: '',
                  sortOrder: categories.length + 1,
                  channels: ['website', 'pos'],
                  isActive: true,
                  updatedAt: new Date().toISOString(),
                });
                setIsCategoryModalOpen(true);
              }}
              className="px-4 py-1.5 rounded-xl bg-[#800D15] hover:bg-[#991B1B] text-white text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>New Category</span>
            </button>
          ) : (
            <button
              onClick={() => {
                setEditingProduct({
                  id: '',
                  name: '',
                  shortDescription: '',
                  longDescription: '',
                  category: categories[0]?.id || 'small-chops',
                  basePrice: 2000,
                  branchPrices: {},
                  branchAvailability: { gra: true, okabere: true, ugbowo: true },
                  prepTimeMinutes: 20,
                  image: 'https://images.unsplash.com/photo-1541592106381-b31e9677c0e5?auto=format&fit=crop&w=800&q=80',
                  channels: ['website', 'pos'],
                  status: 'published',
                  updatedAt: new Date().toISOString(),
                });
                setIsProductModalOpen(true);
              }}
              className="px-4 py-1.5 rounded-xl bg-[#800D15] hover:bg-[#991B1B] text-white text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>New Product</span>
            </button>
          )}
        </div>
      </div>

      {/* Feedback Banner */}
      {feedback && (
        <div
          className={`px-4 py-2.5 text-xs font-semibold flex items-center justify-between border-b ${
            feedback.type === 'success'
              ? 'bg-[#15803D]/25 border-[#15803D]/50 text-[#4ADE80]'
              : 'bg-[#991B1B]/25 border-[#991B1B]/50 text-[#FCA5A5]'
          }`}
        >
          <div className="flex items-center gap-2">
            {feedback.type === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
            <span>{feedback.message}</span>
          </div>
          <button onClick={() => setFeedback(null)} className="text-white/60 hover:text-white text-xs">
            ✕
          </button>
        </div>
      )}

      {/* Tabs Switcher: Products vs Categories */}
      <div className="bg-[#160E0C] border-b border-[#36221E] px-6 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('products')}
            className={`py-3 px-4 text-xs font-extrabold tracking-wide uppercase border-b-2 transition-all flex items-center gap-2 ${
              activeTab === 'products'
                ? 'border-[#FFC700] text-[#FFC700]'
                : 'border-transparent text-[#A89689] hover:text-[#FAF7F2]'
            }`}
          >
            <UtensilsCrossed className="w-3.5 h-3.5" />
            <span>Products Master ({products.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('categories')}
            className={`py-3 px-4 text-xs font-extrabold tracking-wide uppercase border-b-2 transition-all flex items-center gap-2 ${
              activeTab === 'categories'
                ? 'border-[#FFC700] text-[#FFC700]'
                : 'border-transparent text-[#A89689] hover:text-[#FAF7F2]'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Categories Tree ({categories.length})</span>
          </button>
        </div>

        {activeTab === 'products' && (
          <div className="flex items-center gap-2 py-2">
            {/* Search Input */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-[#A89689]" />
              <input
                type="text"
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8 pr-3 py-1.5 bg-[#120B0A] border border-[#36221E] rounded-xl text-xs text-[#FAF7F2] placeholder-[#A89689] focus:outline-none focus:border-[#FFC700] w-48 sm:w-60"
              />
            </div>

            {/* Category Filter */}
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="bg-[#120B0A] border border-[#36221E] text-xs font-semibold rounded-xl px-2.5 py-1.5 text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
            >
              <option value="all">All Categories</option>
              {categories.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.icon} {c.name}
                </option>
              ))}
            </select>

            {/* Channel Filter */}
            <select
              value={channelFilter}
              onChange={(e) => setChannelFilter(e.target.value as any)}
              className="bg-[#120B0A] border border-[#36221E] text-xs font-semibold rounded-xl px-2.5 py-1.5 text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
            >
              <option value="all">All Channels</option>
              <option value="website">Website Storefront</option>
              <option value="pos">POS Registers</option>
            </select>
          </div>
        )}
      </div>

      {/* Main Body */}
      <div className="flex-1 overflow-y-auto p-6">
        {isLoading ? (
          <div className="flex flex-col items-center justify-center h-64 gap-3 text-[#A89689]">
            <RefreshCw className="w-6 h-6 animate-spin text-[#FFC700]" />
            <p className="text-xs">Loading catalogue records...</p>
          </div>
        ) : activeTab === 'categories' ? (
          /* CATEGORIES TABLE */
          <div className="bg-[#1C1210] border border-[#36221E] rounded-2xl overflow-hidden shadow-lg">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#160E0C] border-b border-[#36221E] text-[#A89689] uppercase tracking-wider font-bold">
                  <tr>
                    <th className="py-3 px-4">Order</th>
                    <th className="py-3 px-4">Icon & Name</th>
                    <th className="py-3 px-4">Tagline & Description</th>
                    <th className="py-3 px-4">Channels</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#36221E]">
                  {categories.map((cat) => (
                    <tr key={cat.id} className="hover:bg-[#241311] transition-colors">
                      <td className="py-3.5 px-4 font-mono font-bold text-[#FFC700]">#{cat.sortOrder}</td>
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-2.5">
                          <span className="text-lg">{cat.icon}</span>
                          <div>
                            <span className="font-extrabold text-[#FAF7F2] text-xs block">{cat.name}</span>
                            <span className="text-[10px] text-[#A89689] font-mono">{cat.id}</span>
                          </div>
                          {cat.badge && (
                            <span className="px-2 py-0.5 rounded bg-[#FFC700]/20 text-[#FFC700] text-[10px] font-bold">
                              {cat.badge}
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="py-3.5 px-4 max-w-xs">
                        <p className="font-semibold text-xs text-[#FAF7F2]">{cat.tag}</p>
                        <p className="text-[11px] text-[#A89689] truncate">{cat.description}</p>
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-1.5">
                          {cat.channels?.includes('website') && (
                            <span className="px-2 py-0.5 rounded bg-[#3B82F6]/20 text-[#60A5FA] border border-[#3B82F6]/30 text-[10px] font-bold flex items-center gap-1">
                              <Globe className="w-3 h-3" /> Web
                            </span>
                          )}
                          {cat.channels?.includes('pos') && (
                            <span className="px-2 py-0.5 rounded bg-[#10B981]/20 text-[#34D399] border border-[#10B981]/30 text-[10px] font-bold flex items-center gap-1">
                              <Store className="w-3 h-3" /> POS
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="py-3.5 px-4">
                        <button
                          onClick={() => handleToggleCategoryActive(cat)}
                          className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition-all ${
                            cat.isActive
                              ? 'bg-[#15803D]/25 text-[#4ADE80] border border-[#15803D]/50 hover:bg-[#15803D]/40'
                              : 'bg-[#241311] text-[#A89689] border border-[#36221E] hover:text-white'
                          }`}
                        >
                          {cat.isActive ? 'Active' : 'Hidden'}
                        </button>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <button
                          onClick={() => {
                            setEditingCategory(cat);
                            setIsCategoryModalOpen(true);
                          }}
                          className="p-1.5 rounded-lg text-[#FFC700] hover:bg-[#FFC700]/10 transition-colors mr-1"
                          title="Edit Category"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : (
          /* PRODUCTS TABLE */
          <div className="bg-[#1C1210] border border-[#36221E] rounded-2xl overflow-hidden shadow-lg">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#160E0C] border-b border-[#36221E] text-[#A89689] uppercase tracking-wider font-bold">
                  <tr>
                    <th className="py-3 px-4">Product Details</th>
                    <th className="py-3 px-4">Category</th>
                    <th className="py-3 px-4">Base Price</th>
                    <th className="py-3 px-4">Branch Stock (86 Switch)</th>
                    <th className="py-3 px-4">Channels</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4 text-right">Edit</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#36221E]">
                  {filteredProducts.map((p) => (
                    <tr key={p.id} className="hover:bg-[#241311] transition-colors">
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-3">
                          <img
                            src={p.image}
                            alt={p.name}
                            className="w-12 h-12 rounded-xl object-cover border border-[#36221E] shrink-0"
                          />
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-extrabold text-[#FAF7F2] text-xs">{p.name}</span>
                              {p.isPopular && (
                                <span className="px-1.5 py-0.2 rounded bg-[#EF4444]/20 text-[#EF4444] text-[9px] font-bold">
                                  🔥 HOT
                                </span>
                              )}
                              {p.isFeatured && (
                                <span className="px-1.5 py-0.2 rounded bg-[#FFC700]/20 text-[#FFC700] text-[9px] font-bold">
                                  FEATURED
                                </span>
                              )}
                            </div>
                            <span className="text-[10px] text-[#A89689] font-mono block">{p.id}</span>
                            <span className="text-[11px] text-[#A89689] line-clamp-1">{p.shortDescription}</span>
                          </div>
                        </div>
                      </td>
                      <td className="py-3.5 px-4 font-semibold text-xs text-[#FAF7F2] uppercase">
                        {p.category}
                      </td>
                      <td className="py-3.5 px-4 font-mono font-bold text-xs text-[#FFC700]">
                        ₦{p.basePrice.toLocaleString()}
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-1.5">
                          {['gra', 'okabere', 'ugbowo'].map((bId) => {
                            const isAvail = p.branchAvailability?.[bId] !== false;
                            return (
                              <button
                                key={bId}
                                onClick={() => handleToggleProductAvailability(p.id, bId)}
                                title={`Click to toggle availability at ${bId.toUpperCase()}`}
                                className={`px-2 py-0.5 rounded text-[10px] font-bold transition-all border ${
                                  isAvail
                                    ? 'bg-[#15803D]/20 text-[#4ADE80] border-[#15803D]/40 hover:bg-[#991B1B]/30 hover:text-[#F87171]'
                                    : 'bg-[#991B1B]/20 text-[#EF4444] border-[#991B1B]/40 hover:bg-[#15803D]/30 hover:text-[#4ADE80]'
                                }`}
                              >
                                {bId.toUpperCase()}: {isAvail ? 'IN' : '86'}
                              </button>
                            );
                          })}
                        </div>
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-1">
                          {p.channels?.includes('website') && (
                            <span className="px-1.5 py-0.5 rounded bg-[#3B82F6]/20 text-[#60A5FA] text-[9px] font-bold">
                              Web
                            </span>
                          )}
                          {p.channels?.includes('pos') && (
                            <span className="px-1.5 py-0.5 rounded bg-[#10B981]/20 text-[#34D399] text-[9px] font-bold">
                              POS
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="py-3.5 px-4">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            p.status === 'published'
                              ? 'bg-[#15803D]/20 text-[#4ADE80]'
                              : 'bg-[#FFC700]/20 text-[#FFC700]'
                          }`}
                        >
                          {p.status || 'published'}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <button
                          onClick={() => {
                            setEditingProduct(p);
                            setIsProductModalOpen(true);
                          }}
                          className="p-1.5 rounded-lg text-[#FFC700] hover:bg-[#FFC700]/10 transition-colors"
                          title="Edit Product"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* CATEGORY EDIT/CREATE MODAL */}
      {isCategoryModalOpen && editingCategory && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#1C1210] border border-[#36221E] rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl">
            <div className="p-4 border-b border-[#36221E] flex items-center justify-between">
              <h3 className="text-sm font-bold text-[#FFC700] uppercase tracking-wider">
                {editingCategory.id ? 'Edit Category' : 'Create New Category'}
              </h3>
              <button onClick={() => setIsCategoryModalOpen(false)} className="text-xs text-[#A89689] hover:text-white">
                ✕
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs">
              <div className="grid grid-cols-3 gap-3">
                <div className="col-span-2">
                  <label className="block text-xs font-semibold text-[#A89689] mb-1">Category Name</label>
                  <input
                    type="text"
                    value={editingCategory.name}
                    onChange={(e) => setEditingCategory({ ...editingCategory, name: e.target.value })}
                    className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
                    placeholder="e.g. Small Chops & Platters"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-[#A89689] mb-1">Emoji Icon</label>
                  <input
                    type="text"
                    value={editingCategory.icon}
                    onChange={(e) => setEditingCategory({ ...editingCategory, icon: e.target.value })}
                    className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-xs text-[#FAF7F2] text-center"
                    placeholder="🥟"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#A89689] mb-1">Tagline</label>
                <input
                  type="text"
                  value={editingCategory.tag}
                  onChange={(e) => setEditingCategory({ ...editingCategory, tag: e.target.value })}
                  className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-xs text-[#FAF7F2]"
                  placeholder="e.g. Benin City #1 Ranked"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#A89689] mb-1">Description</label>
                <textarea
                  rows={2}
                  value={editingCategory.description}
                  onChange={(e) => setEditingCategory({ ...editingCategory, description: e.target.value })}
                  className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-xs text-[#FAF7F2]"
                  placeholder="e.g. Mini Packs, Munch Boxes, Samosas, Spring Rolls..."
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#A89689] mb-1">Badge (Optional)</label>
                  <input
                    type="text"
                    value={editingCategory.badge || ''}
                    onChange={(e) => setEditingCategory({ ...editingCategory, badge: e.target.value })}
                    className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-xs text-[#FAF7F2]"
                    placeholder="e.g. Signature"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-[#A89689] mb-1">Display Sort Order</label>
                  <input
                    type="number"
                    value={editingCategory.sortOrder}
                    onChange={(e) => setEditingCategory({ ...editingCategory, sortOrder: Number(e.target.value) })}
                    className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-xs text-[#FAF7F2]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#A89689] mb-2">Sales Channel Visibility</label>
                <div className="flex items-center gap-4">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={editingCategory.channels?.includes('website')}
                      onChange={(e) => {
                        const channels = editingCategory.channels || [];
                        const updated = e.target.checked
                          ? [...channels, 'website']
                          : channels.filter((c) => c !== 'website');
                        setEditingCategory({ ...editingCategory, channels: updated as any });
                      }}
                      className="rounded text-[#800D15]"
                    />
                    <span>Website Storefront</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={editingCategory.channels?.includes('pos')}
                      onChange={(e) => {
                        const channels = editingCategory.channels || [];
                        const updated = e.target.checked
                          ? [...channels, 'pos']
                          : channels.filter((c) => c !== 'pos');
                        setEditingCategory({ ...editingCategory, channels: updated as any });
                      }}
                      className="rounded text-[#800D15]"
                    />
                    <span>POS Terminal Registers</span>
                  </label>
                </div>
              </div>
            </div>

            <div className="p-4 border-t border-[#36221E] flex justify-end gap-2">
              <button
                onClick={() => setIsCategoryModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-[#241311] text-xs font-bold text-[#A89689]"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveCategory}
                className="px-4 py-2 rounded-xl bg-[#FFC700] text-[#4D080F] text-xs font-bold"
              >
                Save Category
              </button>
            </div>
          </div>
        </div>
      )}

      {/* PRODUCT EDIT/CREATE MODAL */}
      {isProductModalOpen && editingProduct && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#1C1210] border border-[#36221E] rounded-2xl w-full max-w-2xl max-h-[90vh] flex flex-col overflow-hidden shadow-2xl">
            <div className="p-4 border-b border-[#36221E] flex items-center justify-between">
              <h3 className="text-sm font-bold text-[#FFC700] uppercase tracking-wider">
                {editingProduct.id ? 'Edit Menu Product' : 'Create New Menu Product'}
              </h3>
              <button onClick={() => setIsProductModalOpen(false)} className="text-xs text-[#A89689] hover:text-white">
                ✕
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-5 space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#A89689] mb-1">Product Name</label>
                  <input
                    type="text"
                    value={editingProduct.name}
                    onChange={(e) => setEditingProduct({ ...editingProduct, name: e.target.value })}
                    className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#A89689] mb-1">Category</label>
                  <select
                    value={editingProduct.category}
                    onChange={(e) => setEditingProduct({ ...editingProduct, category: e.target.value })}
                    className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-xs text-[#FAF7F2] focus:outline-none focus:border-[#FFC700]"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.icon} {c.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#A89689] mb-1">Base Price (₦)</label>
                  <input
                    type="number"
                    value={editingProduct.basePrice}
                    onChange={(e) => setEditingProduct({ ...editingProduct, basePrice: Number(e.target.value) })}
                    className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-xs text-[#FAF7F2] font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#A89689] mb-1">Prep Time (Mins)</label>
                  <input
                    type="number"
                    value={editingProduct.prepTimeMinutes}
                    onChange={(e) => setEditingProduct({ ...editingProduct, prepTimeMinutes: Number(e.target.value) })}
                    className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-xs text-[#FAF7F2]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#A89689] mb-1">Status</label>
                  <select
                    value={editingProduct.status}
                    onChange={(e) => setEditingProduct({ ...editingProduct, status: e.target.value as any })}
                    className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-xs text-[#FAF7F2]"
                  >
                    <option value="published">Published</option>
                    <option value="draft">Draft</option>
                    <option value="archived">Archived</option>
                  </select>
                </div>
              </div>

              <div className="space-y-2">
                <label className="block text-xs font-semibold text-[#A89689]">Product Image (Upload File or Paste URL)</label>
                <div className="flex flex-col sm:flex-row gap-2">
                  <input
                    type="text"
                    value={editingProduct.image}
                    onChange={(e) => setEditingProduct({ ...editingProduct, image: e.target.value })}
                    placeholder="https://... or /uploads/..."
                    className="flex-1 bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-xs text-[#FAF7F2]"
                  />
                  <label className="px-3 py-2 rounded-xl bg-[#241311] hover:bg-[#36221E] border border-[#FFC700]/40 text-[#FFC700] text-xs font-bold cursor-pointer flex items-center justify-center gap-1.5 shrink-0">
                    <span>{isUploadingImage ? 'Uploading...' : 'Upload JPEG/PNG/WebP'}</span>
                    <input
                      type="file"
                      accept="image/jpeg,image/png,image/webp"
                      className="hidden"
                      disabled={isUploadingImage}
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) handleProductImageUpload(file);
                      }}
                    />
                  </label>
                </div>
                {editingProduct.image && (
                  <div className="flex items-center gap-3 bg-[#120B0A] p-2 rounded-xl border border-[#36221E]">
                    <img
                      src={editingProduct.image}
                      alt={editingProduct.name}
                      className="w-12 h-12 rounded-lg object-cover border border-[#36221E]"
                    />
                    <span className="text-[11px] text-[#A89689] truncate flex-1">{editingProduct.image}</span>
                  </div>
                )}
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#A89689] mb-1">Short Description</label>
                <input
                  type="text"
                  value={editingProduct.shortDescription}
                  onChange={(e) => setEditingProduct({ ...editingProduct, shortDescription: e.target.value })}
                  className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-xs text-[#FAF7F2]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#A89689] mb-1">Long Description / Ingredients</label>
                <textarea
                  rows={2}
                  value={editingProduct.longDescription}
                  onChange={(e) => setEditingProduct({ ...editingProduct, longDescription: e.target.value })}
                  className="w-full bg-[#120B0A] border border-[#36221E] rounded-xl px-3 py-2 text-xs text-[#FAF7F2]"
                />
              </div>

              {/* Branch Specific Price Overrides */}
              <div className="bg-[#160E0C] p-3 rounded-xl border border-[#36221E] space-y-2">
                <span className="font-bold text-xs text-[#FFC700] block">Branch Price Overrides (Optional)</span>
                <div className="grid grid-cols-3 gap-2">
                  {['gra', 'okabere', 'ugbowo'].map((bId) => (
                    <div key={bId}>
                      <label className="block text-[10px] text-[#A89689] uppercase font-bold">{bId}</label>
                      <input
                        type="number"
                        placeholder={`Base (₦${editingProduct.basePrice})`}
                        value={editingProduct.branchPrices?.[bId] || ''}
                        onChange={(e) => {
                          const val = e.target.value ? Number(e.target.value) : undefined;
                          const updated = { ...editingProduct.branchPrices };
                          if (val) updated[bId] = val;
                          else delete updated[bId];
                          setEditingProduct({ ...editingProduct, branchPrices: updated });
                        }}
                        className="w-full bg-[#120B0A] border border-[#36221E] rounded-lg px-2.5 py-1 text-xs text-[#FAF7F2] font-mono"
                      />
                    </div>
                  ))}
                </div>
              </div>

              {/* Badges & Dietary Tags */}
              <div className="flex flex-wrap items-center gap-4 pt-1">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editingProduct.isPopular}
                    onChange={(e) => setEditingProduct({ ...editingProduct, isPopular: e.target.checked })}
                    className="rounded text-[#800D15]"
                  />
                  <span>Popular / Top Rated</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editingProduct.isFeatured}
                    onChange={(e) => setEditingProduct({ ...editingProduct, isFeatured: e.target.checked })}
                    className="rounded text-[#800D15]"
                  />
                  <span>Featured Hero Deal</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editingProduct.isSpicy}
                    onChange={(e) => setEditingProduct({ ...editingProduct, isSpicy: e.target.checked })}
                    className="rounded text-[#800D15]"
                  />
                  <span>Spicy</span>
                </label>
              </div>

              {/* Channels */}
              <div>
                <label className="block text-xs font-semibold text-[#A89689] mb-1">Sales Channels</label>
                <div className="flex items-center gap-4">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={editingProduct.channels?.includes('website')}
                      onChange={(e) => {
                        const channels = editingProduct.channels || [];
                        const updated = e.target.checked
                          ? [...channels, 'website']
                          : channels.filter((c) => c !== 'website');
                        setEditingProduct({ ...editingProduct, channels: updated as any });
                      }}
                      className="rounded text-[#800D15]"
                    />
                    <span>Website Storefront</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={editingProduct.channels?.includes('pos')}
                      onChange={(e) => {
                        const channels = editingProduct.channels || [];
                        const updated = e.target.checked
                          ? [...channels, 'pos']
                          : channels.filter((c) => c !== 'pos');
                        setEditingProduct({ ...editingProduct, channels: updated as any });
                      }}
                      className="rounded text-[#800D15]"
                    />
                    <span>POS Registers</span>
                  </label>
                </div>
              </div>
            </div>

            <div className="p-4 border-t border-[#36221E] flex justify-end gap-2">
              <button
                onClick={() => setIsProductModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-[#241311] text-xs font-bold text-[#A89689]"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveProduct}
                className="px-4 py-2 rounded-xl bg-[#FFC700] text-[#4D080F] text-xs font-bold"
              >
                Save Product
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
