import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { CateringProductionPlanner } from './CateringProductionPlanner';
import {
  X,
  Sparkles,
  Calculator,
  Users,
  CheckCircle2,
  Phone,
  MessageCircle,
  ShoppingBag,
  Flame,
  Calendar,
  Layers,
} from 'lucide-react';

export const CateringModal: React.FC = () => {
  const {
    isCateringModalOpen,
    setIsCateringModalOpen,
    formatNaira,
    currentBranch,
    selectedBranchId,
    getBranchWhatsAppUrl,
    addToCart,
    products,
  } = useApp();

  const [activeView, setActiveView] = useState<'calculator' | 'production_planner'>('calculator');
  const [guestCount, setGuestCount] = useState(30);
  const [cateringStyle, setCateringStyle] = useState<'chops_heavy' | 'party_jollof_grills' | 'shawarma_bar' | 'mixed_executive'>('chops_heavy');
  const [includeDrinks, setIncludeDrinks] = useState(true);
  const [includeDeliverySetup, setIncludeDeliverySetup] = useState(true);
  const [isSubmitted, setIsSubmitted] = useState(false);

  if (!isCateringModalOpen) return null;

  // Pricing math per head
  const getCostPerGuest = () => {
    let base = 2500;
    if (cateringStyle === 'party_jollof_grills') base = 4200;
    if (cateringStyle === 'shawarma_bar') base = 3800;
    if (cateringStyle === 'mixed_executive') base = 6500;

    if (includeDrinks) base += 800;
    return base;
  };

  const costPerGuest = getCostPerGuest();
  const totalEstimatedCost = (costPerGuest * guestCount) + (includeDeliverySetup ? 10000 : 0);

  const getStyleBreakdown = () => {
    switch (cateringStyle) {
      case 'party_jollof_grills':
        return `${guestCount} Portions Firewood Party Jollof + Smoky Peppered Chicken / BBQ Turkey + Plantain Dodo + Coleslaw`;
      case 'shawarma_bar':
        return `${guestCount} Double Chicken/Beef Shawarma Wraps + Fresh Loaded Fries Platters + Signature Dips`;
      case 'mixed_executive':
        return `${guestCount} Executive Platters with Custom Small Chops + Jollof/Fried Rice + Peppered Gizzard + Charcoal Grills + Chapman`;
      default:
        return `${guestCount * 4} Spring Rolls + ${guestCount * 4} Samosas + ${guestCount * 6} Puff-Puffs + ${guestCount} Peppered Chicken Skewers`;
    }
  };

  const handle1ClickBook = () => {
    const baseProduct = products.find((p) => p.id === 'prod-sc-box-custom') || products[0];
    const cateringProduct = {
      ...baseProduct,
      id: `catering-${Date.now()}`,
      name: `Catering Package (${guestCount} Guests - ${cateringStyle.replace('_', ' ').toUpperCase()})`,
      shortDescription: getStyleBreakdown(),
      basePrice: totalEstimatedCost,
    };

    addToCart(cateringProduct, 1, {
      selectedOptions: [],
      selectedAddOns: [],
      specialInstructions: `Event Catering for ${guestCount} people. Breakdown: ${getStyleBreakdown()}`,
    });

    setIsCateringModalOpen(false);
  };

  const inquiryWhatsAppText = `Hello Choplife Republic (${currentBranch.shortName}), I would like to book Event Catering for ${guestCount} guests. Style: ${cateringStyle}. Estimated Cost: ${formatNaira(totalEstimatedCost)}.`;

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200"
      id="catering-modal"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          setIsCateringModalOpen(false);
        }
      }}
    >
      <div className={`bg-white rounded-3xl w-full ${activeView === 'production_planner' ? 'max-w-5xl' : 'max-w-2xl'} max-h-[92vh] overflow-y-auto shadow-2xl border-2 border-[#FFC700] flex flex-col justify-between transition-all`}>
        
        {/* Header */}
        <div className="bg-[#4D080F] text-white p-4 sm:p-5 rounded-t-3xl flex items-center justify-between sticky top-0 z-20 shadow-md">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#FFC700] text-[#4D080F] flex items-center justify-center font-titan text-xl">
              🎉
            </div>
            <div>
              <span className="text-[10px] font-titan uppercase tracking-widest text-[#FFC700] block">
                CHOPLIFE CATERING & COMMISSARY
              </span>
              <h2 className="font-titan text-lg sm:text-xl text-white">
                BULK ORDERS & EVENT PRODUCTION
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* View Switcher */}
            <div className="flex bg-black/30 p-1 rounded-xl border border-white/20">
              <button
                onClick={() => setActiveView('calculator')}
                className={`px-3 py-1 text-xs font-montserrat font-bold rounded-lg transition-all ${
                  activeView === 'calculator'
                    ? 'bg-[#FFC700] text-[#4D080F]'
                    : 'text-white/80 hover:text-white'
                }`}
              >
                Party Calculator
              </button>
              <button
                onClick={() => setActiveView('production_planner')}
                className={`px-3 py-1 text-xs font-montserrat font-bold rounded-lg transition-all flex items-center gap-1 ${
                  activeView === 'production_planner'
                    ? 'bg-[#FFC700] text-[#4D080F]'
                    : 'text-white/80 hover:text-white'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                Production BOM
              </button>
            </div>

            <button
              onClick={() => setIsCateringModalOpen(false)}
              className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
              id="close-catering-modal-btn"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        {activeView === 'production_planner' ? (
          <div className="p-4 sm:p-6 overflow-y-auto">
            <CateringProductionPlanner />
          </div>
        ) : (
          <>
            {/* Calculator Body */}
            <div className="p-5 sm:p-6 space-y-6 flex-1">
          
          {/* Guest slider */}
          <div className="bg-[#FAF7F2] p-5 rounded-3xl border border-[#E5DEC9] space-y-3">
            <div className="flex items-center justify-between">
              <label className="font-titan text-xs text-[#4D080F] uppercase tracking-wider flex items-center gap-1.5">
                <Users className="w-4 h-4 text-[#E62E00]" />
                NUMBER OF GUESTS: <span className="text-xl text-[#E62E00] font-titan ml-1">{guestCount} GUESTS</span>
              </label>
              <span className="text-xs font-montserrat text-[#7A6A65] font-bold">10 to 500+</span>
            </div>

            <input
              type="range"
              min={10}
              max={250}
              step={5}
              value={guestCount}
              onChange={(e) => setGuestCount(Number(e.target.value))}
              className="w-full h-2.5 bg-[#E5DEC9] rounded-lg appearance-none cursor-pointer accent-[#E62E00]"
              id="catering-guest-slider"
            />

            <div className="flex justify-between text-[11px] font-montserrat font-bold text-[#7A6A65]">
              <span>Small Gathering (10)</span>
              <span>Birthday / Office (50)</span>
              <span>Mega Wedding / Concert (200+)</span>
            </div>
          </div>

          {/* Catering Style Selector */}
          <div className="space-y-3">
            <label className="font-titan text-xs text-[#4D080F] uppercase tracking-wider block">
              CHOOSE FOOD & FEAST FORMAT
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {[
                { id: 'chops_heavy', title: 'Small Chops Mega Platters', desc: 'Spring rolls, samosas, puff puff & peppered cuts', badge: 'Most Popular' },
                { id: 'party_jollof_grills', title: 'Party Jollof & Charcoal Grills', desc: 'Smoky firewood jollof, plantain, chicken & turkey', badge: 'Full Meal' },
                { id: 'shawarma_bar', title: 'Live Shawarma Station', desc: 'Freshly rolled chicken/beef wraps & loaded fries', badge: 'Party Hit' },
                { id: 'mixed_executive', title: 'Executive Complete Experience', desc: 'All-inclusive feast with small chops, grills, sides & Chapman', badge: 'Luxury' },
              ].map((style) => (
                <button
                  key={style.id}
                  onClick={() => setCateringStyle(style.id as any)}
                  className={`p-4 rounded-2xl border-2 text-left transition-all flex flex-col justify-between ${
                    cateringStyle === style.id
                      ? 'border-[#E62E00] bg-[#FFF8E7] shadow-xs ring-1 ring-[#E62E00]'
                      : 'border-[#E5DEC9] bg-[#FAF7F2] hover:bg-white'
                  }`}
                  id={`catering-style-${style.id}`}
                >
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <p className="font-titan text-xs sm:text-sm text-[#241311]">{style.title}</p>
                      <span className="text-[9px] font-titan text-[#E62E00] bg-white px-2 py-0.5 rounded-full border border-[#E5DEC9]">
                        {style.badge}
                      </span>
                    </div>
                    <p className="text-[11px] text-[#5C4D49] font-montserrat">{style.desc}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Add-on toggles */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            <button
              onClick={() => setIncludeDrinks(!includeDrinks)}
              className={`p-3 rounded-2xl border text-left flex items-center justify-between transition-all ${
                includeDrinks ? 'bg-[#FFF8E7] border-[#E62E00]' : 'bg-[#FAF7F2] border-[#E5DEC9]'
              }`}
            >
              <div className="flex items-center gap-2">
                <span className="text-xl">🍹</span>
                <div>
                  <p className="font-titan text-xs text-[#241311]">Include Chapman & Zobo</p>
                  <p className="text-[10px] text-[#7A6A65] font-montserrat">+₦800 per guest</p>
                </div>
              </div>
              <div className={`w-4 h-4 rounded-md border flex items-center justify-center ${
                includeDrinks ? 'bg-[#E62E00] border-[#E62E00]' : 'border-gray-400'
              }`}>
                {includeDrinks && <CheckCircle2 className="w-3 h-3 text-white" />}
              </div>
            </button>

            <button
              onClick={() => setIncludeDeliverySetup(!includeDeliverySetup)}
              className={`p-3 rounded-2xl border text-left flex items-center justify-between transition-all ${
                includeDeliverySetup ? 'bg-[#FFF8E7] border-[#E62E00]' : 'bg-[#FAF7F2] border-[#E5DEC9]'
              }`}
            >
              <div className="flex items-center gap-2">
                <span className="text-xl">🚚</span>
                <div>
                  <p className="font-titan text-xs text-[#241311]">Chafing Dish & Setup</p>
                  <p className="text-[10px] text-[#7A6A65] font-montserrat">Thermal buffet service (₦10k)</p>
                </div>
              </div>
              <div className={`w-4 h-4 rounded-md border flex items-center justify-center ${
                includeDeliverySetup ? 'bg-[#E62E00] border-[#E62E00]' : 'border-gray-400'
              }`}>
                {includeDeliverySetup && <CheckCircle2 className="w-3 h-3 text-white" />}
              </div>
            </button>
          </div>

          {/* Package Breakdown Box */}
          <div className="bg-[#FFF8E7] p-4 rounded-2xl border border-[#FFC700] space-y-2">
            <h4 className="font-titan text-xs text-[#4D080F] uppercase tracking-wider">
              RECOMMENDED PACKAGE BREAKDOWN:
            </h4>
            <p className="text-xs font-montserrat font-bold text-[#241311]">
              {getStyleBreakdown()}
            </p>
            <div className="pt-2 flex items-center justify-between text-xs font-montserrat text-[#7A6A65] border-t border-[#FFC700]/40">
              <span>Estimated Cost / Head: <strong className="text-[#241311]">{formatNaira(costPerGuest)}</strong></span>
              <span>Kitchen: <strong className="text-[#4D080F]">{currentBranch.name}</strong></span>
            </div>
          </div>

        </div>

        {/* Footer with 1-Click Order or WhatsApp Inquiry */}
        <div className="bg-[#FAF7F2] p-4 sm:p-5 rounded-b-3xl border-t border-[#E5DEC9] flex flex-col sm:flex-row items-center justify-between gap-3 sticky bottom-0">
          <div>
            <span className="text-[10px] text-[#7A6A65] font-montserrat uppercase font-bold block">
              ESTIMATED EVENT TOTAL
            </span>
            <span className="font-titan text-2xl text-[#E62E00]">
              {formatNaira(totalEstimatedCost)}
            </span>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <a
              href={getBranchWhatsAppUrl(selectedBranchId, inquiryWhatsAppText)}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 sm:flex-initial bg-white border border-[#25D366] text-[#006039] hover:bg-emerald-50 font-montserrat font-bold text-xs py-3 px-4 rounded-xl flex items-center justify-center gap-1.5 shadow-2xs"
            >
              <MessageCircle className="w-4 h-4 text-[#25D366] fill-[#25D366]" />
              <span>Inquire via WhatsApp</span>
            </a>

            <button
              onClick={handle1ClickBook}
              className="flex-1 sm:flex-initial bg-[#E62E00] hover:bg-[#C92200] text-white font-titan text-xs sm:text-sm py-3 px-5 rounded-xl shadow-md transition-transform active:scale-95 flex items-center justify-center gap-1.5"
              id="add-catering-to-cart-btn"
            >
              <ShoppingBag className="w-4 h-4 text-[#FFC700]" />
              <span>ADD PACKAGE TO CART</span>
            </button>
          </div>
        </div>
        </>
      )}

      </div>
    </div>
  );
};
