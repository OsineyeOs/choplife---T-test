import React, { useState, useEffect, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  InventoryItem,
  StockLedgerTransaction,
  StockRequest,
  PurchaseOrder,
  GoodsReceiptNote,
  WastageRecord,
  StockCountSession,
  RecipeBOM,
  Supplier,
  InventoryLocationId,
} from '../../types';
import {
  INVENTORY_LOCATIONS,
  INITIAL_CANONICAL_INVENTORY,
  INITIAL_SUPPLIERS,
  INITIAL_PURCHASE_ORDERS,
  INITIAL_GOODS_RECEIPT_NOTES,
  INITIAL_STOCK_LEDGER,
  INITIAL_WASTAGE_RECORDS,
  INITIAL_RECIPES_BOM,
  INITIAL_STOCK_REQUESTS,
} from '../../data/inventoryMaster';
import {
  Package,
  Layers,
  History,
  Truck,
  FileCheck,
  TrendingDown,
  ClipboardList,
  Utensils,
  BarChart3,
  Plus,
  Search,
  Filter,
  CheckCircle2,
  AlertTriangle,
  AlertCircle,
  RotateCcw,
  ArrowRight,
  ArrowDownLeft,
  ArrowUpRight,
  DollarSign,
  Building2,
  ShieldCheck,
  FileText,
  Calendar,
  Clock,
  User,
  Check,
  X,
  RefreshCw,
  Printer,
  ChevronDown,
  ChevronRight,
  Sparkles,
  Info,
  Edit,
  Trash2,
  Archive,
  Eye,
  Database,
} from 'lucide-react';

interface MasterInventoryManagerProps {
  selectedBranchId: string;
  onSelectBranch: (branchId: any) => void;
}

export const MasterInventoryManager: React.FC<MasterInventoryManagerProps> = ({
  selectedBranchId,
  onSelectBranch,
}) => {
  const { currentStaff, formatNaira, products } = useApp();

  type InventorySubTab =
    | 'balances'
    | 'ledger'
    | 'transfers'
    | 'purchasing'
    | 'wastage'
    | 'stocktake'
    | 'recipes'
    | 'analytics';

  const [activeSubTab, setActiveSubTab] = useState<InventorySubTab>('balances');
  const [activeLocationFilter, setActiveLocationFilter] = useState<string>(selectedBranchId || 'all');
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'archived'>('all');
  const [originFilter, setOriginFilter] = useState<'all' | 'operational' | 'demo'>('all');
  const [stockLevelFilter, setStockLevelFilter] = useState<'all' | 'low_stock' | 'out_of_stock' | 'in_stock'>('all');
  const [isLoading, setIsLoading] = useState(false);
  const [toastMessage, setToastMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Master Data States initialized with canonical defaults and updated via API
  const [inventoryItems, setInventoryItems] = useState<InventoryItem[]>(INITIAL_CANONICAL_INVENTORY);
  const [ledgerTransactions, setLedgerTransactions] = useState<StockLedgerTransaction[]>(INITIAL_STOCK_LEDGER);
  const [stockRequests, setStockRequests] = useState<StockRequest[]>(INITIAL_STOCK_REQUESTS);
  const [suppliers, setSuppliers] = useState<Supplier[]>(INITIAL_SUPPLIERS);
  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>(INITIAL_PURCHASE_ORDERS);
  const [grnList, setGrnList] = useState<GoodsReceiptNote[]>(INITIAL_GOODS_RECEIPT_NOTES);
  const [wastageRecords, setWastageRecords] = useState<WastageRecord[]>(INITIAL_WASTAGE_RECORDS);
  const [stockCounts, setStockCounts] = useState<StockCountSession[]>([]);
  const [recipes, setRecipes] = useState<RecipeBOM[]>(INITIAL_RECIPES_BOM);
  const [varianceData, setVarianceData] = useState<any[]>([]);

  // Modal / Form States
  const [isAddItemOpen, setIsAddItemOpen] = useState(false);
  const [editItemTarget, setEditItemTarget] = useState<InventoryItem | null>(null);
  const [viewLedgerItem, setViewLedgerItem] = useState<InventoryItem | null>(null);
  const [itemLedgerHistory, setItemLedgerHistory] = useState<StockLedgerTransaction[]>([]);
  const [isHistoryLoading, setIsHistoryLoading] = useState(false);
  const [deleteItemTarget, setDeleteItemTarget] = useState<InventoryItem | null>(null);
  const [deleteAuditInfo, setDeleteAuditInfo] = useState<any | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isDemoWorking, setIsDemoWorking] = useState(false);
  const [isNewRequestOpen, setIsNewRequestOpen] = useState(false);
  const [isNewPOOpen, setIsNewPOOpen] = useState(false);
  const [isNewGRNOpen, setIsNewGRNOpen] = useState(false);
  const [isLogWastageOpen, setIsLogWastageOpen] = useState(false);
  const [isNewStocktakeOpen, setIsNewStocktakeOpen] = useState(false);
  const [isNewRecipeOpen, setIsNewRecipeOpen] = useState(false);
  const [isQuickAdjustOpen, setIsQuickAdjustOpen] = useState<InventoryItem | null>(null);

  // Add Stock Item Form state
  const [addName, setAddName] = useState('');
  const [addSku, setAddSku] = useState('');
  const [addBarcode, setAddBarcode] = useState('');
  const [addDescription, setAddDescription] = useState('');
  const [addCategory, setAddCategory] = useState('ingredients');
  const [addSubcategory, setAddSubcategory] = useState('');
  const [addInventoryType, setAddInventoryType] = useState('raw_material');
  const [addStorageArea, setAddStorageArea] = useState('dry_store');
  const [addBaseUnit, setAddBaseUnit] = useState('kg');
  const [addUnit, setAddUnit] = useState('kg');
  const [addPurchaseUnit, setAddPurchaseUnit] = useState('bag');
  const [addPurchaseUnitFactor, setAddPurchaseUnitFactor] = useState(1);
  const [addCostPerUnit, setAddCostPerUnit] = useState<string>('0');
  const [addSellingPrice, setAddSellingPrice] = useState<string>('0');
  const [addIsSellable, setAddIsSellable] = useState(false);
  const [addIsPurchasable, setAddIsPurchasable] = useState(true);
  const [addIsDemo, setAddIsDemo] = useState(false);
  const [addMinThreshold, setAddMinThreshold] = useState<string>('10');
  const [addParLevel, setAddParLevel] = useState<string>('50');
  const [addReorderLevel, setAddReorderLevel] = useState<string>('20');
  const [addReorderQuantity, setAddReorderQuantity] = useState<string>('30');
  const [addInitialStock, setAddInitialStock] = useState<string>('0');
  const [addInitialLocation, setAddInitialLocation] = useState<string>('general_store');
  const [addInitialNotes, setAddInitialNotes] = useState('Opening stock balance upon master item creation');
  const [addNotes, setAddNotes] = useState('');

  // Edit Stock Item Form state
  const [editName, setEditName] = useState('');
  const [editSku, setEditSku] = useState('');
  const [editBarcode, setEditBarcode] = useState('');
  const [editDescription, setEditDescription] = useState('');
  const [editCategory, setEditCategory] = useState('');
  const [editSubcategory, setEditSubcategory] = useState('');
  const [editInventoryType, setEditInventoryType] = useState('raw_material');
  const [editStorageArea, setEditStorageArea] = useState('dry_store');
  const [editBaseUnit, setEditBaseUnit] = useState('kg');
  const [editUnit, setEditUnit] = useState('kg');
  const [editPurchaseUnit, setEditPurchaseUnit] = useState('');
  const [editPurchaseUnitFactor, setEditPurchaseUnitFactor] = useState(1);
  const [editCostPerUnit, setEditCostPerUnit] = useState<string>('0');
  const [editSellingPrice, setEditSellingPrice] = useState<string>('0');
  const [editIsSellable, setEditIsSellable] = useState(false);
  const [editIsPurchasable, setEditIsPurchasable] = useState(true);
  const [editIsActive, setEditIsActive] = useState(true);
  const [editMinThreshold, setEditMinThreshold] = useState<string>('10');
  const [editParLevel, setEditParLevel] = useState<string>('50');
  const [editReorderLevel, setEditReorderLevel] = useState<string>('20');
  const [editReorderQuantity, setEditReorderQuantity] = useState<string>('30');
  const [editNotes, setEditNotes] = useState('');

  // Quick Adjustment Form state
  const [adjustLocation, setAdjustLocation] = useState<string>(selectedBranchId || 'gra');
  const [adjustQuantity, setAdjustQuantity] = useState<string>('');
  const [adjustReason, setAdjustReason] = useState<string>('Cycle Count Correction');

  // Wastage Form state
  const [wasteItem, setWasteItem] = useState<string>('');
  const [wasteLocation, setWasteLocation] = useState<string>(selectedBranchId || 'gra');
  const [wasteQty, setWasteQty] = useState<string>('');
  const [wasteReason, setWasteReason] = useState<string>('expired_spoilage');
  const [wasteNote, setWasteNote] = useState<string>('');

  // Stocktake Form state
  const [stocktakeLocation, setStocktakeLocation] = useState<string>('gra');
  const [stocktakeCounts, setStocktakeCounts] = useState<Record<string, number>>({});
  const [stocktakeNotes, setStocktakeNotes] = useState<Record<string, string>>({});

  // Transfer Indent Form state
  const [indentBranch, setIndentBranch] = useState<string>('gra');
  const [indentPriority, setIndentPriority] = useState<'low' | 'normal' | 'high' | 'urgent'>('normal');
  const [indentItems, setIndentItems] = useState<{ itemId: string; requestedQty: number }[]>([]);
  const [indentNotes, setIndentNotes] = useState<string>('');

  // Purchase Order Form state
  const [poSupplierId, setPoSupplierId] = useState<string>('');
  const [poDestLoc, setPoDestLoc] = useState<string>('general_store');
  const [poItems, setPoItems] = useState<{ itemId: string; orderQuantity: number; purchaseUnit: string; unitPrice: number }[]>([]);

  // Goods Receipt (GRN) Form state
  const [grnPoId, setGrnPoId] = useState<string>('');
  const [grnSupplierName, setGrnSupplierName] = useState<string>('');
  const [grnInvoiceNo, setGrnInvoiceNo] = useState<string>('');
  const [grnReceivingLoc, setGrnReceivingLoc] = useState<string>('general_store');
  const [grnLines, setGrnLines] = useState<{ itemId: string; itemName: string; acceptedQty: number; unitPrice: number; batchNumber: string; expiryDate: string }[]>([]);

  const getAuthHeaders = (extra: Record<string, string> = {}) => {
    const token = localStorage.getItem('choplife_staff_token') || '';
    return {
      Authorization: `Bearer ${token}`,
      ...extra,
    };
  };

  // Fetch all initial data from API with safe error boundaries
  const fetchAllData = async () => {
    setIsLoading(true);
    try {
      const headers = getAuthHeaders();
      const [invRes, ledRes, reqRes, supRes, poRes, grnRes, wstRes, cntRes, rcpRes, varRes] = await Promise.all([
        fetch('/api/inventory/items', { headers })
          .then((r) => (r.ok ? r.json() : INITIAL_CANONICAL_INVENTORY))
          .catch(() => INITIAL_CANONICAL_INVENTORY),
        fetch('/api/inventory/ledger', { headers })
          .then((r) => (r.ok ? r.json() : INITIAL_STOCK_LEDGER))
          .catch(() => INITIAL_STOCK_LEDGER),
        fetch('/api/inventory/requests', { headers })
          .then((r) => (r.ok ? r.json() : INITIAL_STOCK_REQUESTS))
          .catch(() => INITIAL_STOCK_REQUESTS),
        fetch('/api/inventory/purchasing/suppliers', { headers })
          .then((r) => (r.ok ? r.json() : INITIAL_SUPPLIERS))
          .catch(() => INITIAL_SUPPLIERS),
        fetch('/api/inventory/purchasing/orders', { headers })
          .then((r) => (r.ok ? r.json() : INITIAL_PURCHASE_ORDERS))
          .catch(() => INITIAL_PURCHASE_ORDERS),
        fetch('/api/inventory/purchasing/grn', { headers })
          .then((r) => (r.ok ? r.json() : INITIAL_GOODS_RECEIPT_NOTES))
          .catch(() => INITIAL_GOODS_RECEIPT_NOTES),
        fetch('/api/inventory/wastage', { headers })
          .then((r) => (r.ok ? r.json() : INITIAL_WASTAGE_RECORDS))
          .catch(() => INITIAL_WASTAGE_RECORDS),
        fetch('/api/inventory/stock-counts', { headers })
          .then((r) => (r.ok ? r.json() : []))
          .catch(() => []),
        fetch('/api/inventory/recipes', { headers })
          .then((r) => (r.ok ? r.json() : INITIAL_RECIPES_BOM))
          .catch(() => INITIAL_RECIPES_BOM),
        fetch(`/api/inventory/analytics/variance?locationId=${selectedBranchId || 'gra'}`, { headers })
          .then((r) => (r.ok ? r.json() : []))
          .catch(() => []),
      ]);

      setInventoryItems(Array.isArray(invRes) ? invRes : INITIAL_CANONICAL_INVENTORY);
      setLedgerTransactions(Array.isArray(ledRes) ? ledRes : INITIAL_STOCK_LEDGER);
      setStockRequests(Array.isArray(reqRes) ? reqRes : INITIAL_STOCK_REQUESTS);
      setSuppliers(Array.isArray(supRes) ? supRes : INITIAL_SUPPLIERS);
      setPurchaseOrders(Array.isArray(poRes) ? poRes : INITIAL_PURCHASE_ORDERS);
      setGrnList(Array.isArray(grnRes) ? grnRes : INITIAL_GOODS_RECEIPT_NOTES);
      setWastageRecords(Array.isArray(wstRes) ? wstRes : INITIAL_WASTAGE_RECORDS);
      setStockCounts(Array.isArray(cntRes) ? cntRes : []);
      setRecipes(Array.isArray(rcpRes) ? rcpRes : INITIAL_RECIPES_BOM);
      setVarianceData(Array.isArray(varRes) ? varRes : []);
    } catch (err) {
      console.error('Failed to load inventory data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (selectedBranchId) {
      setActiveLocationFilter(selectedBranchId);
    }
    fetchAllData();
  }, [selectedBranchId]);

  const showToast = (type: 'success' | 'error', text: string) => {
    setToastMessage({ type, text });
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Helper: Location Name
  const getLocationName = (locId: string) => {
    const found = INVENTORY_LOCATIONS.find((l) => l.id === locId);
    return found ? found.name : locId.toUpperCase();
  };

  // Permissions
  const isSuperOrAdmin = ['super_admin', 'corporate_admin', 'inventory_manager'].includes(currentStaff?.role || '');
  const canDeleteOrArchive = ['super_admin', 'corporate_admin'].includes(currentStaff?.role || '');

  // Filtered inventory list
  const filteredInventory = useMemo(() => {
    let list = Array.isArray(inventoryItems) ? [...inventoryItems] : [];

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter((item) =>
        (item.name || '').toLowerCase().includes(q) ||
        (item.sku || '').toLowerCase().includes(q) ||
        (item.barcode || '').toLowerCase().includes(q) ||
        (item.description || '').toLowerCase().includes(q) ||
        (item.notes || '').toLowerCase().includes(q) ||
        (item.category || '').toLowerCase().includes(q)
      );
    }

    // Category filter
    if (categoryFilter !== 'all') {
      const catLower = categoryFilter.toLowerCase();
      list = list.filter((item) => (item.category || '').toLowerCase() === catLower);
    }

    // Status filter (active vs archived)
    if (statusFilter === 'active') {
      list = list.filter((it) => it.isActive !== false && !it.isArchived);
    } else if (statusFilter === 'archived') {
      list = list.filter((it) => it.isActive === false || it.isArchived === true);
    }

    // Origin filter (operational vs demo)
    if (originFilter === 'operational') {
      list = list.filter((it) => !it.isDemo && it.dataOrigin !== 'demo');
    } else if (originFilter === 'demo') {
      list = list.filter((it) => it.isDemo === true || it.dataOrigin === 'demo');
    }

    // Stock Level filter
    if (stockLevelFilter !== 'all') {
      const isSpecificLocation = Boolean(activeLocationFilter && activeLocationFilter !== 'all');
      const canonicalLocations = ['general_store', 'gra', 'okabere', 'ugbowo'];

      list = list.filter((it) => {
        if (isSpecificLocation) {
          // Specific location stock calculation: reflects this branch only
          const onHand = Number(it.locationStock?.[activeLocationFilter]?.stockOnHand ?? it.currentStock?.[activeLocationFilter] ?? 0);
          const min = Number(it.locationStock?.[activeLocationFilter]?.minThreshold ?? it.minThreshold?.[activeLocationFilter] ?? 10);

          if (stockLevelFilter === 'out_of_stock') return onHand <= 0;
          if (stockLevelFilter === 'low_stock') return onHand > 0 && onHand <= min;
          if (stockLevelFilter === 'in_stock') return onHand > 0;
          return true;
        } else {
          // Network-wide stock calculation: items in stock at one location are not excluded because another is 0
          let networkStock = 0;
          let networkMin = 0;
          for (const loc of canonicalLocations) {
            const onHand = Number(it.locationStock?.[loc]?.stockOnHand ?? it.currentStock?.[loc] ?? 0);
            const min = Number(it.locationStock?.[loc]?.minThreshold ?? it.minThreshold?.[loc] ?? 10);
            networkStock += onHand;
            networkMin += min;
          }

          if (stockLevelFilter === 'out_of_stock') return networkStock <= 0;
          if (stockLevelFilter === 'low_stock') return networkStock > 0 && networkStock <= networkMin;
          if (stockLevelFilter === 'in_stock') return networkStock > 0;
          return true;
        }
      });
    }

    return list;
  }, [inventoryItems, searchQuery, categoryFilter, statusFilter, originFilter, stockLevelFilter, activeLocationFilter]);

  // Overall Inventory Stats (Separating operational from demo valuation)
  const inventoryStats = useMemo(() => {
    let totalStockValue = 0;
    let operationalStockValue = 0;
    let demoStockValue = 0;
    let lowStockCount = 0;
    let outOfStockCount = 0;

    const safeItems = Array.isArray(inventoryItems) ? inventoryItems : [];
    const safeWastage = Array.isArray(wastageRecords) ? wastageRecords : [];
    const safeRequests = Array.isArray(stockRequests) ? stockRequests : [];

    safeItems.forEach((it) => {
      const isDemoItem = it.isDemo === true || it.dataOrigin === 'demo';
      const locKeys = activeLocationFilter === 'all'
        ? ['general_store', 'gra', 'okabere', 'ugbowo']
        : [activeLocationFilter];
      locKeys.forEach((loc) => {
        const stock = it.locationStock?.[loc]?.stockOnHand ?? it.currentStock?.[loc] ?? 0;
        const min = it.locationStock?.[loc]?.minThreshold ?? it.minThreshold?.[loc] ?? 10;
        const val = stock * (it.costPerUnit || 0);
        totalStockValue += val;
        if (isDemoItem) {
          demoStockValue += val;
        } else {
          operationalStockValue += val;
        }

        if (stock <= 0) outOfStockCount++;
        else if (stock <= min) lowStockCount++;
      });
    });

    const filteredWastage = activeLocationFilter === 'all'
      ? safeWastage
      : safeWastage.filter((w) => (w.locationId || (w as any).branchId) === activeLocationFilter);
    const totalWastageLoss = filteredWastage.reduce((sum, w) => sum + (w.totalLossValue || 0), 0);
    const pendingRequests = safeRequests.filter((r) => {
      const matchesLoc = activeLocationFilter === 'all' || r.destinationLocation === activeLocationFilter || r.sourceLocation === activeLocationFilter;
      return matchesLoc && (r.status === 'requested' || r.status === 'in_transit');
    }).length;

    return {
      totalStockValue,
      operationalStockValue,
      demoStockValue,
      lowStockCount,
      outOfStockCount,
      totalWastageLoss,
      pendingRequests,
    };
  }, [inventoryItems, wastageRecords, stockRequests, activeLocationFilter]);

  // Create Stock Item
  const handleCreateStockItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!addName.trim()) {
      showToast('error', 'Item name is required.');
      return;
    }
    try {
      const res = await fetch('/api/inventory/items', {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          name: addName.trim(),
          sku: addSku.trim() || undefined,
          barcode: addBarcode.trim() || undefined,
          description: addDescription.trim() || undefined,
          category: addCategory,
          subcategory: addSubcategory.trim() || undefined,
          inventoryType: addInventoryType,
          storageArea: addStorageArea,
          baseUnit: addBaseUnit,
          unit: addUnit,
          purchaseUnit: addPurchaseUnit,
          purchaseUnitFactor: Number(addPurchaseUnitFactor) || 1,
          costPerUnit: Number(addCostPerUnit) || 0,
          sellingPrice: Number(addSellingPrice) || 0,
          isSellable: addIsSellable,
          isPurchasable: addIsPurchasable,
          isDemo: addIsDemo,
          minThreshold: Number(addMinThreshold) || 10,
          parLevel: Number(addParLevel) || 50,
          reorderLevel: Number(addReorderLevel) || 20,
          reorderQuantity: Number(addReorderQuantity) || 30,
          initialStock: Number(addInitialStock) || 0,
          initialLocationId: addInitialLocation,
          openingStockNotes: addInitialNotes,
          notes: addNotes,
        }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        showToast('success', `Created stock item ${data.item.name}!`);
        setIsAddItemOpen(false);
        // Reset form
        setAddName('');
        setAddSku('');
        setAddBarcode('');
        setAddDescription('');
        setAddCategory('ingredients');
        setAddSubcategory('');
        setAddInitialStock('0');
        setAddCostPerUnit('0');
        setAddSellingPrice('0');
        setAddNotes('');
        setAddIsDemo(false);
        fetchAllData();
      } else {
        showToast('error', data.error || 'Failed to create item.');
      }
    } catch (err) {
      showToast('error', 'Network error creating stock item.');
    }
  };

  // Open Edit Item Modal
  const handleOpenEditItem = (item: InventoryItem) => {
    setEditItemTarget(item);
    setEditName(item.name || '');
    setEditSku(item.sku || '');
    setEditBarcode(item.barcode || '');
    setEditDescription(item.description || '');
    setEditCategory(item.category || 'ingredients');
    setEditSubcategory(item.subcategory || '');
    setEditInventoryType(item.inventoryType || 'raw_material');
    setEditStorageArea(item.storageArea || 'dry_store');
    setEditBaseUnit(item.baseUnit || item.unit || 'kg');
    setEditUnit(item.unit || 'kg');
    setEditPurchaseUnit(item.purchaseUnit || item.unit || 'kg');
    setEditPurchaseUnitFactor(item.purchaseUnitFactor || 1);
    setEditCostPerUnit(String(item.costPerUnit || 0));
    setEditSellingPrice(String(item.sellingPrice || 0));
    setEditIsSellable(Boolean(item.isSellable));
    setEditIsPurchasable(item.isPurchasable !== false);
    setEditIsActive(item.isActive !== false && !item.isArchived);
    const locKey = selectedBranchId && selectedBranchId !== 'all' ? selectedBranchId : 'gra';
    setEditMinThreshold(String(item.locationStock?.[locKey]?.minThreshold ?? item.minThreshold?.[locKey] ?? 10));
    setEditParLevel(String(item.locationStock?.[locKey]?.parLevel ?? 50));
    setEditReorderLevel(String(item.locationStock?.[locKey]?.reorderLevel ?? 20));
    setEditReorderQuantity(String(item.locationStock?.[locKey]?.reorderQuantity ?? 30));
    setEditNotes(item.notes || '');
  };

  // Submit Edit Item (Metadata only, stock preserved)
  const handleSaveEditItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editItemTarget) return;

    try {
      const res = await fetch(`/api/inventory/items/${editItemTarget.id}`, {
        method: 'PUT',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          name: editName.trim(),
          sku: editSku.trim() || undefined,
          barcode: editBarcode.trim() || undefined,
          description: editDescription.trim(),
          category: editCategory,
          subcategory: editSubcategory.trim() || undefined,
          inventoryType: editInventoryType,
          storageArea: editStorageArea,
          baseUnit: editBaseUnit,
          unit: editUnit,
          purchaseUnit: editPurchaseUnit,
          purchaseUnitFactor: Number(editPurchaseUnitFactor) || 1,
          costPerUnit: Number(editCostPerUnit) || 0,
          sellingPrice: Number(editSellingPrice) || 0,
          isSellable: editIsSellable,
          isPurchasable: editIsPurchasable,
          isActive: editIsActive,
          isArchived: !editIsActive,
          minThreshold: Number(editMinThreshold) || 10,
          parLevel: Number(editParLevel) || 50,
          reorderLevel: Number(editReorderLevel) || 20,
          reorderQuantity: Number(editReorderQuantity) || 30,
          notes: editNotes,
        }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        showToast('success', `Updated details for ${data.item.name}!`);
        setEditItemTarget(null);
        fetchAllData();
      } else {
        showToast('error', data.error || 'Failed to update item details.');
      }
    } catch (err) {
      showToast('error', 'Network error updating item details.');
    }
  };

  // Open Safe Delete / Archive Confirmation Modal
  const handleOpenDeleteModal = async (item: InventoryItem) => {
    setDeleteItemTarget(item);
    setDeleteAuditInfo(null);
    try {
      const res = await fetch(`/api/inventory/items/${item.id}`, {
        headers: getAuthHeaders(),
      });
      if (res.ok) {
        const data = await res.json();
        setDeleteAuditInfo(data.referenceAudit);
      }
    } catch (err) {
      console.error('Failed to load item audit details:', err);
    }
  };

  // Confirm Delete / Archive
  const handleConfirmDelete = async () => {
    if (!deleteItemTarget) return;
    setIsDeleting(true);
    try {
      const res = await fetch(`/api/inventory/items/${deleteItemTarget.id}`, {
        method: 'DELETE',
        headers: getAuthHeaders(),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        if (data.action === 'archived') {
          showToast('success', `Safely archived ${deleteItemTarget.name}.`);
        } else {
          showToast('success', `Permanently deleted draft item ${deleteItemTarget.name}.`);
        }
        setDeleteItemTarget(null);
        setDeleteAuditInfo(null);
        fetchAllData();
      } else {
        showToast('error', data.error || 'Failed to remove or archive item.');
      }
    } catch (err) {
      showToast('error', 'Network error during delete operation.');
    } finally {
      setIsDeleting(false);
    }
  };

  // Open Item Movement History Modal
  const handleOpenLedgerHistory = async (item: InventoryItem) => {
    setViewLedgerItem(item);
    setItemLedgerHistory([]);
    setIsHistoryLoading(true);
    try {
      const res = await fetch(`/api/inventory/items/${item.id}/ledger`, {
        headers: getAuthHeaders(),
      });
      if (res.ok) {
        const data = await res.json();
        setItemLedgerHistory(Array.isArray(data) ? data : []);
      }
    } catch (err) {
      console.error('Failed to load ledger history for item:', err);
    } finally {
      setIsHistoryLoading(false);
    }
  };

  // Seed Demo Items
  const handleSeedDemoCatalogue = async () => {
    setIsDemoWorking(true);
    try {
      const res = await fetch('/api/inventory/demo/seed', {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        showToast('success', data.message || `Seeded ${data.count} demo inventory items!`);
        fetchAllData();
      } else {
        showToast('error', data.error || 'Failed to seed demo items.');
      }
    } catch (err) {
      showToast('error', 'Network error seeding demo catalogue.');
    } finally {
      setIsDemoWorking(false);
    }
  };

  // Purge Demo Items
  const handleResetDemoCatalogue = async () => {
    if (!window.confirm('Reset all demo items? This will safely remove demo inventory items and demo ledger transactions without touching operational stock.')) {
      return;
    }
    setIsDemoWorking(true);
    try {
      const res = await fetch('/api/inventory/demo/reset', {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        showToast('success', data.message || `Purged ${data.removedItemsCount} demo items.`);
        fetchAllData();
      } else {
        showToast('error', data.error || 'Failed to reset demo items.');
      }
    } catch (err) {
      showToast('error', 'Network error resetting demo catalogue.');
    } finally {
      setIsDemoWorking(false);
    }
  };

  // Handle Quick Adjust Submit
  const handleQuickAdjust = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isQuickAdjustOpen || !adjustQuantity) return;

    try {
      const res = await fetch(`/api/inventory/${isQuickAdjustOpen.id}/stock`, {
        method: 'PUT',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          branchId: adjustLocation,
          quantity: Number(adjustQuantity),
        }),
      });
      const data = await res.json();
      if (data.success) {
        showToast('success', `Updated stock for ${isQuickAdjustOpen.name} at ${adjustLocation.toUpperCase()}!`);
        setIsQuickAdjustOpen(null);
        setAdjustQuantity('');
        fetchAllData();
      } else {
        showToast('error', data.error || 'Failed to update stock.');
      }
    } catch (err) {
      showToast('error', 'Network error updating stock.');
    }
  };

  // Handle Log Wastage Submit
  const handleLogWastage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!wasteItem || !wasteQty) return;

    try {
      const res = await fetch('/api/inventory/wastage', {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          itemId: wasteItem,
          locationId: wasteLocation,
          quantity: Number(wasteQty),
          reason: wasteReason,
          customNote: wasteNote,
        }),
      });
      const data = await res.json();
      if (data.success) {
        showToast('success', `Logged wastage of ${wasteQty} units successfully.`);
        setIsLogWastageOpen(false);
        setWasteQty('');
        setWasteNote('');
        fetchAllData();
      } else {
        showToast('error', data.error || 'Failed to log wastage.');
      }
    } catch (err) {
      showToast('error', 'Network error logging wastage.');
    }
  };

  // Handle Create Stock Requisition
  const handleCreateRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (indentItems.length === 0) {
      showToast('error', 'Please add at least one item to request.');
      return;
    }

    try {
      const res = await fetch('/api/inventory/requests', {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          destinationLocation: indentBranch,
          priority: indentPriority,
          items: indentItems,
          notes: indentNotes,
        }),
      });
      const data = await res.json();
      if (data.success) {
        showToast('success', `Created stock indent ${data.request.requestNumber}!`);
        setIsNewRequestOpen(false);
        setIndentItems([]);
        setIndentNotes('');
        fetchAllData();
      } else {
        showToast('error', data.error || 'Failed to submit indent.');
      }
    } catch (err) {
      showToast('error', 'Network error submitting indent.');
    }
  };

  // Handle Review Request (Approve / Reject)
  const handleReviewRequest = async (id: string, status: 'approved' | 'rejected') => {
    try {
      const res = await fetch(`/api/inventory/requests/${id}/review`, {
        method: 'PUT',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({ status }),
      });
      const data = await res.json();
      if (data.success) {
        showToast('success', `Indent marked as ${status.toUpperCase()}!`);
        fetchAllData();
      }
    } catch (err) {
      showToast('error', 'Action failed.');
    }
  };

  // Handle Dispatch Request
  const handleDispatchRequest = async (req: StockRequest) => {
    const issuedItems = req.items.map((it) => ({
      itemId: it.itemId,
      issuedQty: it.approvedQty || it.requestedQty || (it as any).quantityRequested || 1,
    }));

    try {
      const res = await fetch(`/api/inventory/requests/${req.id}/dispatch`, {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          issuedItems,
          dispatchNote: 'Dispatched via Central Commissary Dispatch Van',
        }),
      });
      const data = await res.json();
      if (data.success) {
        showToast('success', `Indent ${req.requestNumber} dispatched! Stock deducted from Commissary.`);
        fetchAllData();
      } else {
        showToast('error', data.error || 'Dispatch failed.');
      }
    } catch (err) {
      showToast('error', 'Dispatch failed.');
    }
  };

  // Handle Receive Request
  const handleReceiveRequest = async (req: StockRequest) => {
    const receivedItems = req.items.map((it) => ({
      itemId: it.itemId,
      receivedQty: it.issuedQty || it.requestedQty || (it as any).quantityRequested || 1,
    }));

    try {
      const res = await fetch(`/api/inventory/requests/${req.id}/receive`, {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          receivedItems,
          receivingNotes: 'Confirmed and verified upon arrival',
        }),
      });
      const data = await res.json();
      if (data.success) {
        showToast('success', `Indent ${req.requestNumber} received and credited to branch inventory!`);
        fetchAllData();
      } else {
        showToast('error', data.error || 'Receiving failed.');
      }
    } catch (err) {
      showToast('error', 'Receiving failed.');
    }
  };

  // Handle Submit Stocktake Count
  const handleSubmitStocktake = async (autoReconcile: boolean) => {
    const lines = Object.entries(stocktakeCounts).map(([itemId, count]) => ({
      itemId,
      physicalCountedQty: Number(count),
      notes: stocktakeNotes[itemId] || '',
    }));

    if (lines.length === 0) {
      showToast('error', 'Please enter counts for at least one item.');
      return;
    }

    try {
      const res = await fetch('/api/inventory/stock-counts', {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          locationId: stocktakeLocation,
          lines,
          autoReconcile,
        }),
      });
      const data = await res.json();
      if (data.success) {
        showToast('success', `Stocktake ${data.session.referenceNo} recorded & reconciled!`);
        setIsNewStocktakeOpen(false);
        setStocktakeCounts({});
        fetchAllData();
      } else {
        showToast('error', data.error || 'Stocktake submission failed.');
      }
    } catch (err) {
      showToast('error', 'Network error.');
    }
  };

  // Handle Create Purchase Order
  const handleCreatePO = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!poSupplierId) {
      showToast('error', 'Please select a verified supplier.');
      return;
    }
    if (poItems.length === 0) {
      showToast('error', 'Please add at least one line item to the Purchase Order.');
      return;
    }

    try {
      const res = await fetch('/api/inventory/purchasing/orders', {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          supplierId: poSupplierId,
          destinationLocation: poDestLoc,
          items: poItems,
          paymentTerms: 'Net 14 Days',
        }),
      });
      const data = await res.json();
      if (data.success) {
        showToast('success', `Purchase Order ${data.purchaseOrder.poNumber} generated and sent to ${data.purchaseOrder.supplierName}!`);
        setIsNewPOOpen(false);
        setPoItems([]);
        fetchAllData();
      } else {
        showToast('error', data.error || 'Failed to create Purchase Order.');
      }
    } catch (err) {
      showToast('error', 'Network error creating Purchase Order.');
    }
  };

  // Handle Create Goods Receipt Note (GRN)
  const handleCreateGRN = async (e: React.FormEvent) => {
    e.preventDefault();
    if (grnLines.length === 0) {
      showToast('error', 'Please add at least one received item line to the GRN.');
      return;
    }

    try {
      const res = await fetch('/api/inventory/purchasing/grn', {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          purchaseOrderId: grnPoId || undefined,
          supplierName: grnSupplierName || 'Verified Vendor',
          supplierInvoiceNumber: grnInvoiceNo || `INV-${Date.now().toString().slice(-6)}`,
          receivingLocation: grnReceivingLoc,
          lines: grnLines,
        }),
      });
      const data = await res.json();
      if (data.success) {
        showToast('success', `Verified GRN ${data.grn.grnNumber} accepted and stocked into ${getLocationName(grnReceivingLoc)}!`);
        setIsNewGRNOpen(false);
        setGrnLines([]);
        setGrnInvoiceNo('');
        fetchAllData();
      } else {
        showToast('error', data.error || 'Failed to record GRN.');
      }
    } catch (err) {
      showToast('error', 'Network error recording GRN.');
    }
  };

  return (
    <div className="space-y-5">
      {/* Toast Notification */}
      {toastMessage && (
        <div
          className={`fixed top-5 right-5 z-70 px-4 py-3 rounded-2xl shadow-xl flex items-center gap-2 text-xs font-montserrat font-bold text-white transition-all transform animate-bounce ${
            toastMessage.type === 'success' ? 'bg-emerald-700' : 'bg-red-600'
          }`}
        >
          {toastMessage.type === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
          {toastMessage.text}
        </div>
      )}

      {/* Top Header & Fast Navigation Tabs */}
      <div className="bg-white p-4 sm:p-5 rounded-3xl border border-[#E5DEC9] space-y-4 shadow-2xs">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 bg-[#FFC700]/20 text-[#4D080F] font-titan text-[10px] rounded-full uppercase tracking-wider">
                COMMISSARY & MULTI-BRANCH ERP
              </span>
              <span className="flex items-center gap-1 text-[11px] font-montserrat font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse" />
                Ledger Live & Synchronized
              </span>
            </div>
            <h2 className="font-titan text-xl sm:text-2xl text-[#4D080F] mt-1">
              Choplife Republic Inventory Management
            </h2>
            <p className="text-xs text-[#7A6A65] font-montserrat">
              Double-entry perpetual stock ledger, Central Store commissary indents, automated recipe BOM depletions & variance analytics.
            </p>
          </div>

          {/* Location Focus Filter */}
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs font-titan text-[#4D080F] uppercase">Stock Location:</span>
            <div className="flex items-center bg-[#FAF7F2] p-1 rounded-2xl border border-[#E5DEC9] overflow-x-auto">
              <button
                onClick={() => {
                  setActiveLocationFilter('all');
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-montserrat font-bold transition-all whitespace-nowrap ${
                  activeLocationFilter === 'all'
                    ? 'bg-[#4D080F] text-[#FFC700] shadow-xs'
                    : 'text-[#4D080F] hover:bg-white'
                }`}
              >
                All Stock Locations
              </button>
              {INVENTORY_LOCATIONS.map((loc) => (
                <button
                  key={loc.id}
                  onClick={() => {
                    setActiveLocationFilter(loc.id);
                    onSelectBranch(loc.id === 'general_store' ? 'gra' : loc.id);
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-montserrat font-bold transition-all whitespace-nowrap flex items-center gap-1.5 ${
                    activeLocationFilter === loc.id
                      ? 'bg-[#4D080F] text-[#FFC700] shadow-xs'
                      : 'text-[#4D080F] hover:bg-white'
                  }`}
                >
                  <Building2 className="w-3.5 h-3.5" />
                  {loc.name}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* 4-KPI Overview Bar */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-2 border-t border-[#FAF7F2]">
          <div className="bg-[#FAF7F2] p-3 rounded-2xl border border-[#E5DEC9]">
            <span className="text-[10px] text-gray-500 font-montserrat uppercase font-bold block">Operational Valuation</span>
            <strong className="text-base sm:text-lg font-titan text-[#4D080F]">
              {formatNaira(inventoryStats.operationalStockValue)}
            </strong>
            {inventoryStats.demoStockValue > 0 && (
              <span className="text-[9px] text-purple-700 block font-montserrat font-bold">
                + {formatNaira(inventoryStats.demoStockValue)} (Demo Stock)
              </span>
            )}
            <span className="text-[10px] text-gray-400 block font-montserrat">Active operational inventory</span>
          </div>

          <div className="bg-[#FAF7F2] p-3 rounded-2xl border border-[#E5DEC9]">
            <span className="text-[10px] text-gray-500 font-montserrat uppercase font-bold block">Low Stock / Alerts</span>
            <div className="flex items-center gap-1.5">
              <strong className="text-base sm:text-lg font-titan text-amber-600">
                {inventoryStats.lowStockCount} items
              </strong>
              {inventoryStats.outOfStockCount > 0 && (
                <span className="text-[10px] font-titan px-1.5 py-0.2 bg-red-100 text-red-700 rounded-full">
                  {inventoryStats.outOfStockCount} Out
                </span>
              )}
            </div>
            <span className="text-[10px] text-gray-400 block font-montserrat">Below safety par level</span>
          </div>

          <div className="bg-[#FAF7F2] p-3 rounded-2xl border border-[#E5DEC9]">
            <span className="text-[10px] text-gray-500 font-montserrat uppercase font-bold block">Wastage / Loss (Logged)</span>
            <strong className="text-base sm:text-lg font-titan text-[#E62E00]">
              {formatNaira(inventoryStats.totalWastageLoss)}
            </strong>
            <span className="text-[10px] text-gray-400 block font-montserrat">{wastageRecords.length} incidents recorded</span>
          </div>

          <div className="bg-[#FAF7F2] p-3 rounded-2xl border border-[#E5DEC9]">
            <span className="text-[10px] text-gray-500 font-montserrat uppercase font-bold block">Branch Indents Pending</span>
            <strong className="text-base sm:text-lg font-titan text-[#0284C7]">
              {inventoryStats.pendingRequests} Requisitions
            </strong>
            <span className="text-[10px] text-gray-400 block font-montserrat">Requires Commissary Action</span>
          </div>
        </div>

        {/* Sub-Tabs Bar */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pt-2 border-t border-[#FAF7F2]">
          {[
            { id: 'balances', label: 'Stock Balances & 86', icon: Layers },
            { id: 'ledger', label: 'Transaction Ledger', icon: History },
            { id: 'transfers', label: 'Branch Transfers & Indents', icon: Truck },
            { id: 'purchasing', label: 'Purchasing & GRN', icon: FileCheck },
            { id: 'wastage', label: 'Wastage & Spoilage', icon: TrendingDown },
            { id: 'stocktake', label: 'Stocktake & Variance', icon: ClipboardList },
            { id: 'recipes', label: 'Recipe BOM & Costing', icon: Utensils },
            { id: 'analytics', label: 'Actual vs Theoretical', icon: BarChart3 },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeSubTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveSubTab(tab.id as InventorySubTab)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-2xl text-xs font-montserrat font-bold whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-[#4D080F] text-[#FFC700] shadow-sm ring-2 ring-[#FFC700]/30'
                    : 'bg-[#FAF7F2] text-[#4D080F] hover:bg-[#FFF8E7] border border-[#E5DEC9]'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-[#FFC700]' : 'text-[#4D080F]'}`} />
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* ==========================================
          SUB-TAB 1: STOCK BALANCES & LIVE 86 STATUS
          ========================================== */}
      {activeSubTab === 'balances' && (
        <div className="space-y-4">
          {/* Controls & Filter Bar */}
          <div className="flex flex-col gap-3 bg-white p-3 sm:p-4 rounded-2xl border border-[#E5DEC9]">
            <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-2 w-full lg:w-auto">
                {/* Search */}
                <div className="relative flex-1 sm:w-64 min-w-[200px]">
                  <Search className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    placeholder="Search item, SKU, barcode..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl pl-9 pr-3 py-2 text-xs font-montserrat text-[#241311] focus:outline-none focus:border-[#4D080F]"
                  />
                </div>

                {/* Category Filter */}
                <select
                  value={categoryFilter}
                  onChange={(e) => setCategoryFilter(e.target.value)}
                  className="bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-2.5 py-2 text-xs font-montserrat font-bold text-[#4D080F] focus:outline-none focus:border-[#4D080F]"
                >
                  <option value="all">All Categories</option>
                  <option value="proteins">Proteins</option>
                  <option value="ingredients">Raw Ingredients</option>
                  <option value="bakery">Bakery & Flour</option>
                  <option value="beverages">Beverages</option>
                  <option value="packaging">Packaging</option>
                  <option value="cleaning">Cleaning</option>
                </select>

                {/* Status Filter */}
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value as any)}
                  className="bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-2.5 py-2 text-xs font-montserrat font-bold text-[#4D080F] focus:outline-none focus:border-[#4D080F]"
                >
                  <option value="all">All Statuses</option>
                  <option value="active">Active Only</option>
                  <option value="archived">Archived Only</option>
                </select>

                {/* Classification / Origin Filter */}
                <select
                  value={originFilter}
                  onChange={(e) => setOriginFilter(e.target.value as any)}
                  className="bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-2.5 py-2 text-xs font-montserrat font-bold text-[#4D080F] focus:outline-none focus:border-[#4D080F]"
                >
                  <option value="all">All Origins</option>
                  <option value="operational">Operational Stock</option>
                  <option value="demo">Demo / Placeholders</option>
                </select>

                {/* Stock Level Filter */}
                <select
                  value={stockLevelFilter}
                  onChange={(e) => setStockLevelFilter(e.target.value as any)}
                  className="bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-2.5 py-2 text-xs font-montserrat font-bold text-[#4D080F] focus:outline-none focus:border-[#4D080F]"
                >
                  <option value="all">All Stock Levels</option>
                  <option value="in_stock">In Stock (&gt; Min)</option>
                  <option value="low_stock">Low Stock (≤ Min)</option>
                  <option value="out_of_stock">Out of Stock (0)</option>
                </select>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 w-full lg:w-auto justify-start sm:justify-end flex-wrap">
                {isSuperOrAdmin && (
                  <button
                    onClick={() => setIsAddItemOpen(true)}
                    id="btn-add-stock-item"
                    className="px-3.5 py-2 bg-[#4D080F] hover:bg-[#38050A] text-[#FFC700] rounded-xl text-xs font-montserrat font-bold flex items-center gap-1.5 shadow-xs transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    Add Stock Item
                  </button>
                )}

                {isSuperOrAdmin && (
                  <button
                    onClick={handleSeedDemoCatalogue}
                    disabled={isDemoWorking}
                    id="btn-seed-demo-items"
                    className="px-3 py-2 bg-purple-50 hover:bg-purple-100 text-purple-700 rounded-xl text-xs font-montserrat font-bold border border-purple-200 flex items-center gap-1.5 transition-colors"
                    title="Seed canonical demonstration stock items across all categories"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-purple-600" />
                    Seed Demo Items
                  </button>
                )}

                {canDeleteOrArchive && (
                  <button
                    onClick={handleResetDemoCatalogue}
                    disabled={isDemoWorking}
                    id="btn-reset-demo-items"
                    className="px-3 py-2 bg-amber-50 hover:bg-amber-100 text-amber-800 rounded-xl text-xs font-montserrat font-bold border border-amber-300 flex items-center gap-1.5 transition-colors"
                    title="Safely purge all demo items and demo ledger transactions without touching operational stock"
                  >
                    <RotateCcw className="w-3.5 h-3.5 text-amber-700" />
                    Purge Demo Items
                  </button>
                )}

                <button
                  onClick={() => setIsLogWastageOpen(true)}
                  className="px-3 py-2 bg-red-50 hover:bg-red-100 text-red-700 rounded-xl text-xs font-montserrat font-bold border border-red-200 flex items-center gap-1.5 transition-colors"
                >
                  <TrendingDown className="w-3.5 h-3.5" />
                  Log Wastage
                </button>

                <button
                  onClick={() => setIsNewRequestOpen(true)}
                  className="px-3 py-2 bg-[#FAF7F2] hover:bg-[#FFF8E7] text-[#4D080F] rounded-xl text-xs font-montserrat font-bold border border-[#E5DEC9] flex items-center gap-1.5 shadow-2xs transition-colors"
                >
                  <Truck className="w-3.5 h-3.5" />
                  Raise Indent
                </button>
              </div>
            </div>
          </div>

          {/* Master Table of Stock Balances */}
          <div className="bg-white rounded-3xl border border-[#E5DEC9] overflow-hidden shadow-2xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-montserrat">
                <thead className="bg-[#FAF7F2] text-[#4D080F] font-titan uppercase text-[10px] border-b border-[#E5DEC9]">
                  <tr>
                    <th className="p-3.5">SKU & Item Name</th>
                    <th className="p-3.5">Category</th>
                    <th className="p-3.5 text-center">General Store (Commissary)</th>
                    <th className="p-3.5 text-center">GRA Branch</th>
                    <th className="p-3.5 text-center">Okabere Branch</th>
                    <th className="p-3.5 text-center">Ugbowo Branch</th>
                    <th className="p-3.5">Unit Cost</th>
                    <th className="p-3.5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E5DEC9]">
                  {filteredInventory.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="p-8 text-center text-gray-500 font-montserrat">
                        No inventory items match the current filters.
                      </td>
                    </tr>
                  ) : (
                    filteredInventory.map((item) => {
                      const genStock = item.locationStock?.general_store?.stockOnHand ?? item.currentStock?.general_store ?? 0;
                      const graStock = item.locationStock?.gra?.stockOnHand ?? item.currentStock?.gra ?? 0;
                      const okaStock = item.locationStock?.okabere?.stockOnHand ?? item.currentStock?.okabere ?? 0;
                      const ugbStock = item.locationStock?.ugbowo?.stockOnHand ?? item.currentStock?.ugbowo ?? 0;

                      const graMin = item.locationStock?.gra?.minThreshold ?? item.minThreshold?.gra ?? 10;
                      const okaMin = item.locationStock?.okabere?.minThreshold ?? item.minThreshold?.okabere ?? 10;
                      const ugbMin = item.locationStock?.ugbowo?.minThreshold ?? item.minThreshold?.ugbowo ?? 10;

                      return (
                        <tr key={item.id} className="hover:bg-[#FFF8E7]/40 transition-colors">
                          <td className="p-3.5">
                            <div className="flex items-center gap-2">
                              <span className="font-mono text-[10px] font-bold text-gray-500 bg-gray-100 px-1.5 py-0.5 rounded">
                                {item.sku}
                              </span>
                              <div>
                                <div className="flex items-center gap-1.5 flex-wrap">
                                  <strong className="text-[#241311] text-xs font-bold">{item.name}</strong>
                                  {item.isDemo && (
                                    <span className="px-1.5 py-0.2 bg-purple-100 text-purple-800 text-[9px] font-titan rounded uppercase border border-purple-200">
                                      DEMO
                                    </span>
                                  )}
                                  {(item.isArchived || item.isActive === false) && (
                                    <span className="px-1.5 py-0.2 bg-gray-200 text-gray-700 text-[9px] font-titan rounded uppercase border border-gray-300">
                                      ARCHIVED
                                    </span>
                                  )}
                                </div>
                                <span className="text-[10px] text-gray-500 block">
                                  Unit: {item.baseUnit || item.unit} | Storage: {item.storageArea || 'dry_store'}
                                </span>
                              </div>
                            </div>
                          </td>

                          <td className="p-3.5">
                            <span className="px-2 py-0.5 bg-[#FAF7F2] border border-[#E5DEC9] text-[#4D080F] text-[10px] font-titan rounded-md uppercase">
                              {item.category}
                            </span>
                          </td>

                          {/* General Store */}
                          <td className="p-3.5 text-center bg-gray-50/50">
                            <span className="font-titan text-sm text-[#4D080F]">{genStock}</span>
                            <span className="text-[10px] text-gray-500 ml-1">{item.unit}</span>
                          </td>

                          {/* GRA Branch */}
                          <td className="p-3.5 text-center">
                            <span
                              className={`font-titan text-sm ${
                                graStock <= 0
                                  ? 'text-red-600 font-black'
                                  : graStock <= graMin
                                  ? 'text-amber-600'
                                  : 'text-emerald-700'
                              }`}
                            >
                              {graStock}
                            </span>
                            <span className="text-[10px] text-gray-500 ml-1">{item.unit}</span>
                            {graStock <= graMin && (
                              <span className="block text-[9px] text-amber-600 font-bold">Min: {graMin}</span>
                            )}
                          </td>

                          {/* Okabere Branch */}
                          <td className="p-3.5 text-center">
                            <span
                              className={`font-titan text-sm ${
                                okaStock <= 0
                                  ? 'text-red-600 font-black'
                                  : okaStock <= okaMin
                                  ? 'text-amber-600'
                                  : 'text-emerald-700'
                              }`}
                            >
                              {okaStock}
                            </span>
                            <span className="text-[10px] text-gray-500 ml-1">{item.unit}</span>
                            {okaStock <= okaMin && (
                              <span className="block text-[9px] text-amber-600 font-bold">Min: {okaMin}</span>
                            )}
                          </td>

                          {/* Ugbowo Branch */}
                          <td className="p-3.5 text-center">
                            <span
                              className={`font-titan text-sm ${
                                ugbStock <= 0
                                  ? 'text-red-600 font-black'
                                  : ugbStock <= ugbMin
                                  ? 'text-amber-600'
                                  : 'text-emerald-700'
                              }`}
                            >
                              {ugbStock}
                            </span>
                            <span className="text-[10px] text-gray-500 ml-1">{item.unit}</span>
                            {ugbStock <= ugbMin && (
                              <span className="block text-[9px] text-amber-600 font-bold">Min: {ugbMin}</span>
                            )}
                          </td>

                          <td className="p-3.5 font-titan text-[#4D080F]">
                            {formatNaira(item.costPerUnit || 0)}
                          </td>

                          <td className="p-3.5 text-right">
                            <div className="flex items-center justify-end gap-1 flex-wrap">
                              {/* Quick Count Button */}
                              <button
                                onClick={() => {
                                  setIsQuickAdjustOpen(item);
                                  setAdjustLocation(selectedBranchId || 'gra');
                                  setAdjustQuantity(
                                    String(
                                      item.locationStock?.[selectedBranchId || 'gra']?.stockOnHand ??
                                        item.currentStock?.[selectedBranchId || 'gra'] ??
                                        0
                                    )
                                  );
                                }}
                                className="px-2 py-1 bg-[#FAF7F2] hover:bg-[#FFC700] text-[#4D080F] font-bold rounded-lg border border-[#E5DEC9] text-[10px] transition-colors"
                                title="Adjust stock on hand for selected branch"
                              >
                                Quick Count
                              </button>

                              {/* Edit Master Details Button */}
                              {isSuperOrAdmin && (
                                <button
                                  onClick={() => handleOpenEditItem(item)}
                                  className="px-2 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold rounded-lg border border-blue-200 text-[10px] flex items-center gap-1 transition-colors"
                                  title="Edit item specifications, reorder levels, and units"
                                >
                                  <Edit className="w-3 h-3" />
                                  Edit
                                </button>
                              )}

                              {/* Movement History Button */}
                              <button
                                onClick={() => handleOpenLedgerHistory(item)}
                                className="px-2 py-1 bg-gray-50 hover:bg-gray-100 text-gray-700 font-bold rounded-lg border border-gray-200 text-[10px] flex items-center gap-1 transition-colors"
                                title="View chronological movement audit ledger for this item"
                              >
                                <History className="w-3 h-3" />
                                History
                              </button>

                              {/* Safe Archive / Delete Button */}
                              {canDeleteOrArchive && (
                                <button
                                  onClick={() => handleOpenDeleteModal(item)}
                                  className="px-2 py-1 bg-red-50 hover:bg-red-100 text-red-700 font-bold rounded-lg border border-red-200 text-[10px] flex items-center gap-1 transition-colors"
                                  title="Retire/archive item or hard-delete if unreferenced"
                                >
                                  <Trash2 className="w-3 h-3" />
                                  Archive
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ==========================================
          SUB-TAB 2: IMMUTABLE TRANSACTION LEDGER
          ========================================== */}
      {activeSubTab === 'ledger' && (
        <div className="space-y-4">
          <div className="bg-white p-4 rounded-2xl border border-[#E5DEC9] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <h3 className="font-titan text-sm text-[#4D080F] uppercase flex items-center gap-1.5">
                <History className="w-4 h-4 text-emerald-700" />
                Immutable Stock Ledger (Single Source of Truth)
              </h3>
              <p className="text-xs text-gray-500 font-montserrat">
                Every deduction, transfer, GRN receipt, and wastage creates a non-destructive audit row.
              </p>
            </div>

            <button
              onClick={fetchAllData}
              className="px-3 py-1.5 bg-[#FAF7F2] hover:bg-[#FFC700] text-[#4D080F] font-bold text-xs rounded-xl border border-[#E5DEC9] flex items-center gap-1.5 transition-colors"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
              Refresh Ledger
            </button>
          </div>

          <div className="bg-white rounded-3xl border border-[#E5DEC9] overflow-hidden shadow-2xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-montserrat">
                <thead className="bg-[#FAF7F2] text-[#4D080F] font-titan uppercase text-[10px] border-b border-[#E5DEC9]">
                  <tr>
                    <th className="p-3.5">Ref # & Time</th>
                    <th className="p-3.5">Item & SKU</th>
                    <th className="p-3.5">Location</th>
                    <th className="p-3.5">Transaction Type</th>
                    <th className="p-3.5 text-right">Delta Qty</th>
                    <th className="p-3.5 text-center">Balance Before → After</th>
                    <th className="p-3.5">Performed By</th>
                    <th className="p-3.5">Reason / Notes</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E5DEC9]">
                  {ledgerTransactions
                    .filter((tx) => activeLocationFilter === 'all' || tx.locationId === activeLocationFilter || tx.sourceLocation === activeLocationFilter || tx.destinationLocation === activeLocationFilter)
                    .map((tx) => {
                      const isPositive = tx.quantityDelta > 0;
                      return (
                        <tr key={tx.id} className="hover:bg-[#FFF8E7]/40 transition-colors">
                          <td className="p-3.5">
                            <span className="font-titan text-xs text-[#4D080F] block">{tx.referenceNo}</span>
                            <span className="text-[10px] text-gray-400">
                              {new Date(tx.timestamp).toLocaleString()}
                            </span>
                          </td>

                          <td className="p-3.5">
                            <strong className="block text-[#241311]">{tx.itemName}</strong>
                            <span className="text-[10px] font-mono text-gray-500">{tx.sku}</span>
                          </td>

                          <td className="p-3.5">
                            <span className="font-titan text-[10px] text-[#4D080F] uppercase bg-gray-100 px-2 py-0.5 rounded">
                              {getLocationName(tx.locationId)}
                            </span>
                            {tx.sourceLocation && tx.destinationLocation && (
                              <span className="block text-[9px] text-gray-500 mt-0.5">
                                {tx.sourceLocation.toUpperCase()} → {tx.destinationLocation.toUpperCase()}
                              </span>
                            )}
                          </td>

                          <td className="p-3.5">
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-titan uppercase ${
                                tx.transactionType === 'PURCHASE_RECEIPT'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : tx.transactionType === 'TRANSFER_IN'
                                  ? 'bg-blue-100 text-blue-800'
                                  : tx.transactionType === 'TRANSFER_OUT'
                                  ? 'bg-amber-100 text-amber-800'
                                  : tx.transactionType === 'POS_DEPLETION' || tx.transactionType === 'ONLINE_ORDER_DEPLETION'
                                  ? 'bg-purple-100 text-purple-800'
                                  : tx.transactionType === 'WASTAGE'
                                  ? 'bg-red-100 text-red-800'
                                  : 'bg-gray-100 text-gray-800'
                              }`}
                            >
                              {tx.transactionType.replace(/_/g, ' ')}
                            </span>
                          </td>

                          <td className="p-3.5 text-right font-titan">
                            <span className={isPositive ? 'text-emerald-700' : 'text-[#E62E00]'}>
                              {isPositive ? `+${tx.quantityDelta}` : tx.quantityDelta} {tx.unit}
                            </span>
                          </td>

                          <td className="p-3.5 text-center text-gray-600 font-mono text-[11px]">
                            {tx.balanceBefore} → <strong className="text-[#241311]">{tx.balanceAfter}</strong> {tx.unit}
                          </td>

                          <td className="p-3.5">
                            <strong className="block text-[#241311]">{tx.performedByName}</strong>
                            <span className="text-[10px] text-gray-500 uppercase">{tx.performedByRole}</span>
                          </td>

                          <td className="p-3.5 text-gray-600 text-[11px] max-w-xs truncate">
                            {tx.reasonCategory || tx.notes || '—'}
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ==========================================
          SUB-TAB 3: TRANSFERS & BRANCH INDENTS
          ========================================== */}
      {activeSubTab === 'transfers' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-[#E5DEC9]">
            <div>
              <h3 className="font-titan text-sm text-[#4D080F] uppercase flex items-center gap-1.5">
                <Truck className="w-4 h-4 text-[#0284C7]" />
                Internal Stock Requisitions & Transfer Indents
              </h3>
              <p className="text-xs text-gray-500 font-montserrat">
                Hub-and-Spoke distribution from Central Commissary to GRA, Okabere, and Ugbowo.
              </p>
            </div>

            <button
              onClick={() => setIsNewRequestOpen(true)}
              className="px-4 py-2 bg-[#4D080F] hover:bg-[#38050A] text-[#FFC700] rounded-xl text-xs font-montserrat font-bold flex items-center gap-1.5 shadow-xs transition-colors"
            >
              <Plus className="w-4 h-4" />
              New Branch Requisition
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {stockRequests.map((req) => (
              <div
                key={req.id}
                className="bg-white rounded-3xl p-5 border border-[#E5DEC9] space-y-3 shadow-2xs relative"
              >
                <div className="flex items-center justify-between border-b pb-2.5">
                  <div>
                    <span className="font-titan text-sm text-[#4D080F]">{req.requestNumber}</span>
                    <span className="text-[10px] text-gray-400 block">
                      Requested {new Date(req.requestedAt).toLocaleString()} by {req.requestedByName}
                    </span>
                  </div>

                  <span
                    className={`px-2.5 py-1 rounded-full text-[10px] font-titan uppercase ${
                      req.status === 'completed'
                        ? 'bg-emerald-100 text-emerald-800'
                        : req.status === 'in_transit'
                        ? 'bg-amber-100 text-amber-800 animate-pulse'
                        : req.status === 'approved'
                        ? 'bg-blue-100 text-blue-800'
                        : req.status === 'rejected'
                        ? 'bg-red-100 text-red-800'
                        : 'bg-purple-100 text-purple-800'
                    }`}
                  >
                    {req.status.replace('_', ' ')}
                  </span>
                </div>

                <div className="flex items-center justify-between text-xs font-montserrat bg-[#FAF7F2] p-2.5 rounded-xl">
                  <div>
                    <span className="text-[10px] text-gray-400 block uppercase font-bold">Source Location</span>
                    <strong className="text-[#4D080F]">{getLocationName(req.sourceLocation)}</strong>
                  </div>
                  <ArrowRight className="w-4 h-4 text-gray-400" />
                  <div>
                    <span className="text-[10px] text-gray-400 block uppercase font-bold">Destination Location</span>
                    <strong className="text-[#4D080F]">{getLocationName(req.destinationLocation)}</strong>
                  </div>
                </div>

                {/* Items List in Indent */}
                <div className="space-y-1.5 max-h-36 overflow-y-auto">
                  {req.items.map((it, idx) => (
                    <div
                      key={idx}
                      className="flex items-center justify-between text-xs font-montserrat bg-white p-2 rounded-lg border border-gray-100"
                    >
                      <div>
                        <strong className="block text-[#241311]">{it.itemName}</strong>
                        <span className="text-[10px] text-gray-500 font-mono">{it.sku}</span>
                      </div>
                      <div className="text-right">
                        <span className="font-titan text-[#4D080F]">
                          Req: {it.requestedQty} {it.unit}
                        </span>
                        {it.issuedQty > 0 && (
                          <span className="block text-[10px] text-emerald-700 font-bold">
                            Issued: {it.issuedQty} {it.unit}
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Actions depending on role & status */}
                <div className="pt-2 border-t flex items-center justify-between gap-2">
                  {req.status === 'requested' && (
                    <>
                      <button
                        onClick={() => handleReviewRequest(req.id, 'rejected')}
                        className="px-3 py-1.5 bg-red-50 hover:bg-red-100 text-red-700 text-xs font-montserrat font-bold rounded-xl border border-red-200"
                      >
                        Reject
                      </button>
                      <button
                        onClick={() => handleReviewRequest(req.id, 'approved')}
                        className="px-4 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-montserrat font-bold rounded-xl shadow-xs"
                      >
                        Approve Indent
                      </button>
                    </>
                  )}

                  {req.status === 'approved' && (
                    <button
                      onClick={() => handleDispatchRequest(req)}
                      className="w-full px-4 py-2 bg-[#0284C7] hover:bg-[#0369A1] text-white text-xs font-montserrat font-bold rounded-xl flex items-center justify-center gap-1.5 shadow-xs"
                    >
                      <Truck className="w-3.5 h-3.5" />
                      Dispatch & Deduct from Commissary
                    </button>
                  )}

                  {req.status === 'in_transit' && (
                    <button
                      onClick={() => handleReceiveRequest(req)}
                      className="w-full px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-montserrat font-bold rounded-xl flex items-center justify-center gap-1.5 shadow-xs"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Acknowledge & Credit {getLocationName(req.destinationLocation)}
                    </button>
                  )}

                  {req.status === 'completed' && (
                    <span className="text-[11px] text-emerald-700 font-montserrat font-bold flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" /> Completed & Reconciled
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ==========================================
          SUB-TAB 4: PURCHASING & GOODS RECEIPT (GRN)
          ========================================== */}
      {activeSubTab === 'purchasing' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-[#E5DEC9]">
            <div>
              <h3 className="font-titan text-sm text-[#4D080F] uppercase flex items-center gap-1.5">
                <FileCheck className="w-4 h-4 text-emerald-700" />
                Procurement, PO Generation & Verified Goods Receipts (GRN)
              </h3>
              <p className="text-xs text-gray-500 font-montserrat">
                Prevent leakage with receiving verification, temperature checks & price discrepancy flags.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                id="btn-draft-po"
                onClick={() => {
                  if (!poSupplierId && suppliers.length > 0) setPoSupplierId(suppliers[0].id);
                  if (poItems.length === 0 && inventoryItems.length > 0) {
                    setPoItems([{
                      itemId: inventoryItems[0].id,
                      orderQuantity: 25,
                      purchaseUnit: inventoryItems[0].unit || 'kg',
                      unitPrice: inventoryItems[0].costPerUnit || 1500,
                    }]);
                  }
                  setIsNewPOOpen(true);
                }}
                className="px-3.5 py-2 bg-[#FAF7F2] hover:bg-[#FFC700] text-[#4D080F] rounded-xl text-xs font-montserrat font-bold border border-[#E5DEC9] flex items-center gap-1.5 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                Draft Purchase Order
              </button>

              <button
                id="btn-receive-grn"
                onClick={() => {
                  if (grnLines.length === 0 && inventoryItems.length > 0) {
                    setGrnLines([{
                      itemId: inventoryItems[0].id,
                      itemName: inventoryItems[0].name,
                      acceptedQty: 25,
                      unitPrice: inventoryItems[0].costPerUnit || 1500,
                      batchNumber: `BCH-${Date.now().toString().slice(-4)}`,
                      expiryDate: new Date(Date.now() + 86400000 * 30).toISOString().split('T')[0],
                    }]);
                  }
                  if (!grnSupplierName && suppliers.length > 0) setGrnSupplierName(suppliers[0].name);
                  setIsNewGRNOpen(true);
                }}
                className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-montserrat font-bold flex items-center gap-1.5 shadow-xs transition-colors"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                Receive Delivery (GRN)
              </button>
            </div>
          </div>

          {/* Active Purchase Orders List */}
          {purchaseOrders.length > 0 && (
            <div className="bg-white rounded-3xl border border-[#E5DEC9] overflow-hidden shadow-2xs">
              <div className="p-4 bg-[#FAF7F2] border-b border-[#E5DEC9] flex items-center justify-between">
                <h4 className="font-titan text-xs text-[#4D080F] uppercase">Purchase Orders (PO Register)</h4>
                <span className="text-[11px] font-montserrat text-gray-500">{purchaseOrders.length} Purchase Orders</span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs font-montserrat">
                  <thead className="bg-[#FAF7F2] text-[#4D080F] font-titan uppercase text-[10px] border-b border-[#E5DEC9]">
                    <tr>
                      <th className="p-3.5">PO #</th>
                      <th className="p-3.5">Supplier</th>
                      <th className="p-3.5">Destination Stock Location</th>
                      <th className="p-3.5">Line Items</th>
                      <th className="p-3.5">PO Total</th>
                      <th className="p-3.5">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#E5DEC9]">
                    {purchaseOrders.map((po) => (
                      <tr key={po.id} className="hover:bg-[#FFF8E7]/40 transition-colors">
                        <td className="p-3.5 font-titan text-[#4D080F]">{po.poNumber}</td>
                        <td className="p-3.5 font-bold text-[#241311]">{po.supplierName}</td>
                        <td className="p-3.5">
                          <span className="font-titan text-[10px] uppercase text-[#4D080F] bg-gray-100 px-2 py-0.5 rounded">
                            {getLocationName(po.destinationLocation)}
                          </span>
                        </td>
                        <td className="p-3.5">
                          {(po.items || []).map((it: any, idx: number) => (
                            <span key={idx} className="block text-[11px] text-gray-700">
                              {it.orderQuantity ?? it.orderedQty} {it.purchaseUnit || it.unit} × {it.itemName}
                            </span>
                          ))}
                        </td>
                        <td className="p-3.5 font-titan text-[#4D080F]">{formatNaira(po.totalAmount || 0)}</td>
                        <td className="p-3.5">
                          <span className="px-2 py-0.5 bg-blue-50 text-blue-700 text-[10px] font-titan rounded-md uppercase">
                            {(po.status || 'sent_to_supplier').replace(/_/g, ' ')}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Goods Receipt Notes List */}
          <div className="bg-white rounded-3xl border border-[#E5DEC9] overflow-hidden shadow-2xs">
            <div className="p-4 bg-[#FAF7F2] border-b border-[#E5DEC9]">
              <h4 className="font-titan text-xs text-[#4D080F] uppercase">Recent Verified Goods Receipt Notes (GRN)</h4>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-montserrat">
                <thead className="bg-[#FAF7F2] text-[#4D080F] font-titan uppercase text-[10px] border-b border-[#E5DEC9]">
                  <tr>
                    <th className="p-3.5">GRN #</th>
                    <th className="p-3.5">Supplier</th>
                    <th className="p-3.5">Receiving Stock Location</th>
                    <th className="p-3.5">Items Accepted</th>
                    <th className="p-3.5">Invoice Amount</th>
                    <th className="p-3.5">Received By</th>
                    <th className="p-3.5">Quality / Inspection</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E5DEC9]">
                  {grnList.map((grn) => {
                    const grnItems = Array.isArray(grn.items) ? grn.items : Array.isArray((grn as any).lines) ? (grn as any).lines : [];
                    const invoiceAmt = grn.actualAcceptedValue ?? (grn as any).totalValue ?? 0;
                    return (
                      <tr key={grn.id} className="hover:bg-[#FFF8E7]/40 transition-colors">
                        <td className="p-3.5 font-titan text-[#4D080F]">
                          {grn.grnNumber}
                          <span className="block text-[10px] font-normal text-gray-400">
                            {new Date(grn.receivedAt).toLocaleDateString()}
                          </span>
                        </td>

                        <td className="p-3.5">
                          <strong className="block text-[#241311]">{grn.supplierName}</strong>
                          <span className="text-[10px] text-gray-500">Inv: {grn.supplierInvoiceNumber || 'N/A'}</span>
                        </td>

                        <td className="p-3.5">
                          <span className="font-titan text-[10px] uppercase text-[#4D080F] bg-gray-100 px-2 py-0.5 rounded">
                            {getLocationName(grn.receivingLocation)}
                          </span>
                        </td>

                        <td className="p-3.5">
                          <div className="space-y-0.5">
                            {grnItems.map((it: any, i: number) => (
                              <span key={i} className="block text-[11px] text-gray-700">
                                {it.acceptedQty}x {it.itemName || 'Stock Item'} @ {formatNaira(it.unitPrice || 0)}
                              </span>
                            ))}
                          </div>
                        </td>

                        <td className="p-3.5 font-titan text-emerald-700">
                          {formatNaira(invoiceAmt)}
                        </td>

                        <td className="p-3.5">
                          <strong className="block text-[#241311]">{grn.receivedByName}</strong>
                          <span className="text-[10px] text-gray-400">Verified & Stocked</span>
                        </td>

                        <td className="p-3.5">
                          <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 text-[10px] font-titan rounded-md uppercase flex items-center gap-1 w-fit">
                            <Check className="w-3 h-3" /> Passed Inspection
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ==========================================
          SUB-TAB 5: WASTAGE & SPOILAGE LOG
          ========================================== */}
      {activeSubTab === 'wastage' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-[#E5DEC9]">
            <div>
              <h3 className="font-titan text-sm text-[#4D080F] uppercase flex items-center gap-1.5">
                <TrendingDown className="w-4 h-4 text-red-600" />
                Kitchen Wastage, Spoilage & Prep Loss Tracking
              </h3>
              <p className="text-xs text-gray-500 font-montserrat">
                Quantify shrink loss and identify root operational causes across cold-chain and kitchen lines.
              </p>
            </div>

            <button
              onClick={() => setIsLogWastageOpen(true)}
              className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-montserrat font-bold flex items-center gap-1.5 shadow-xs transition-colors"
            >
              <Plus className="w-4 h-4" />
              Log Waste Incident
            </button>
          </div>

          <div className="bg-white rounded-3xl border border-[#E5DEC9] overflow-hidden shadow-2xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-montserrat">
                <thead className="bg-[#FAF7F2] text-[#4D080F] font-titan uppercase text-[10px] border-b border-[#E5DEC9]">
                  <tr>
                    <th className="p-3.5">Ref # & Date</th>
                    <th className="p-3.5">Item & SKU</th>
                    <th className="p-3.5">Location</th>
                    <th className="p-3.5 text-right">Quantity Lost</th>
                    <th className="p-3.5">Reason Code</th>
                    <th className="p-3.5">Total Financial Loss</th>
                    <th className="p-3.5">Logged By</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E5DEC9]">
                  {wastageRecords.map((w) => (
                    <tr key={w.id} className="hover:bg-[#FFF8E7]/40 transition-colors">
                      <td className="p-3.5 font-titan text-[#4D080F]">
                        {w.referenceNo}
                        <span className="block text-[10px] font-normal text-gray-400">
                          {new Date(w.timestamp).toLocaleString()}
                        </span>
                      </td>

                      <td className="p-3.5">
                        <strong className="block text-[#241311]">{w.itemName}</strong>
                        <span className="text-[10px] font-mono text-gray-500">{w.sku}</span>
                      </td>

                      <td className="p-3.5">
                        <span className="font-titan text-[10px] uppercase text-[#4D080F] bg-gray-100 px-2 py-0.5 rounded">
                          {getLocationName(w.locationId)}
                        </span>
                      </td>

                      <td className="p-3.5 text-right font-titan text-red-600">
                        -{w.quantity} {w.unit}
                      </td>

                      <td className="p-3.5">
                        <span className="px-2 py-0.5 bg-red-100 text-red-800 text-[10px] font-titan rounded-md uppercase">
                          {w.reason.replace(/_/g, ' ')}
                        </span>
                        {w.customNote && <span className="block text-[10px] text-gray-500 mt-0.5">{w.customNote}</span>}
                      </td>

                      <td className="p-3.5 font-titan text-[#E62E00]">
                        {formatNaira(w.totalLossValue)}
                      </td>

                      <td className="p-3.5">
                        <strong className="block text-[#241311]">{w.loggedByName}</strong>
                        <span className="text-[10px] text-gray-400 uppercase">{w.loggedByRole}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ==========================================
          SUB-TAB 6: STOCKTAKE & BLIND COUNT RECONCILIATION
          ========================================== */}
      {activeSubTab === 'stocktake' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-[#E5DEC9]">
            <div>
              <h3 className="font-titan text-sm text-[#4D080F] uppercase flex items-center gap-1.5">
                <ClipboardList className="w-4 h-4 text-[#4D080F]" />
                Physical Stocktake & Cycle Count Variance Reconciliation
              </h3>
              <p className="text-xs text-gray-500 font-montserrat">
                Reconcile physical on-hand counts with perpetual ledger balances to identify shrinkage.
              </p>
            </div>

            <button
              onClick={() => {
                // Initialize stocktake counts with current system balances
                const initialCounts: Record<string, number> = {};
                inventoryItems.forEach((it) => {
                  initialCounts[it.id] = it.locationStock?.[stocktakeLocation]?.stockOnHand ?? it.currentStock?.[stocktakeLocation] ?? 0;
                });
                setStocktakeCounts(initialCounts);
                setIsNewStocktakeOpen(true);
              }}
              className="px-4 py-2 bg-[#4D080F] hover:bg-[#38050A] text-[#FFC700] rounded-xl text-xs font-montserrat font-bold flex items-center gap-1.5 shadow-xs transition-colors"
            >
              <Plus className="w-4 h-4" />
              Launch New Stock Count Session
            </button>
          </div>

          {/* Past Stocktake Sessions */}
          <div className="space-y-3">
            {stockCounts.map((session) => (
              <div
                key={session.id}
                className="bg-white rounded-3xl p-5 border border-[#E5DEC9] space-y-3 shadow-2xs"
              >
                <div className="flex items-center justify-between border-b pb-2.5">
                  <div>
                    <span className="font-titan text-sm text-[#4D080F]">{session.referenceNo}</span>
                    <span className="text-[10px] text-gray-400 block">
                      Conducted at {getLocationName(session.locationId)} on{' '}
                      {new Date(session.startedAt).toLocaleDateString()} by {session.conductedByName}
                    </span>
                  </div>

                  <div className="text-right">
                    <span
                      className={`font-titan text-sm ${
                        session.totalVarianceValue === 0
                          ? 'text-emerald-700'
                          : session.totalVarianceValue < 0
                          ? 'text-red-600'
                          : 'text-blue-700'
                      }`}
                    >
                      Net Variance: {formatNaira(session.totalVarianceValue)}
                    </span>
                    <span className="block text-[10px] text-gray-400 uppercase font-bold">
                      {session.status.replace(/_/g, ' ')}
                    </span>
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs font-montserrat">
                    <thead className="bg-[#FAF7F2] text-gray-600 text-[10px] uppercase font-bold">
                      <tr>
                        <th className="p-2">Item</th>
                        <th className="p-2 text-center">Expected</th>
                        <th className="p-2 text-center">Counted</th>
                        <th className="p-2 text-center">Variance Qty</th>
                        <th className="p-2 text-right">Variance Value</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {session.lines.map((l, idx) => (
                        <tr key={idx}>
                          <td className="p-2 font-bold text-[#241311]">{l.itemName}</td>
                          <td className="p-2 text-center">{l.systemExpectedQty} {l.unit}</td>
                          <td className="p-2 text-center font-bold">{l.physicalCountedQty} {l.unit}</td>
                          <td
                            className={`p-2 text-center font-titan ${
                              l.varianceQty < 0 ? 'text-red-600' : l.varianceQty > 0 ? 'text-blue-600' : 'text-emerald-600'
                            }`}
                          >
                            {l.varianceQty > 0 ? `+${l.varianceQty}` : l.varianceQty} {l.unit}
                          </td>
                          <td className="p-2 text-right font-titan text-[#4D080F]">
                            {formatNaira(l.varianceValue)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ==========================================
          SUB-TAB 7: RECIPE BOM & COSTING
          ========================================== */}
      {activeSubTab === 'recipes' && (
        <div className="space-y-4">
          <div className="bg-white p-4 rounded-2xl border border-[#E5DEC9] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <h3 className="font-titan text-sm text-[#4D080F] uppercase flex items-center gap-1.5">
                <Utensils className="w-4 h-4 text-[#4D080F]" />
                Recipe Bill of Materials (BOM) & Food Costing
              </h3>
              <p className="text-xs text-gray-500 font-montserrat">
                Connected to POS and Online Checkout — orders automatically deduct raw ingredient fractions.
              </p>
            </div>

            <span className="px-3 py-1 bg-emerald-50 text-emerald-700 rounded-xl text-xs font-montserrat font-bold border border-emerald-200 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" /> {recipes.length} Active Recipes Configured
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {recipes.map((rcp) => {
              const matchedProduct = products.find((p) => p.id === rcp.menuProductId);
              const sellingPrice = matchedProduct ? matchedProduct.price : rcp.totalCostPerPortion * 2.5;
              const margin = sellingPrice - rcp.totalCostPerPortion;
              const foodCostPct = sellingPrice > 0 ? (rcp.totalCostPerPortion / sellingPrice) * 100 : 0;

              return (
                <div
                  key={rcp.id}
                  className="bg-white rounded-3xl p-5 border border-[#E5DEC9] space-y-3 shadow-2xs"
                >
                  <div className="flex items-center justify-between border-b pb-2.5">
                    <div>
                      <h4 className="font-titan text-base text-[#4D080F]">{rcp.menuProductName}</h4>
                      <span className="text-[10px] text-gray-500 font-montserrat">
                        Yield: {rcp.yieldPortions} Portion(s) | Category: {rcp.category}
                      </span>
                    </div>

                    <div className="text-right">
                      <span className="font-titan text-sm text-[#E62E00]">
                        Cost: {formatNaira(rcp.totalCostPerPortion)}
                      </span>
                      <span className="block text-[10px] text-emerald-700 font-bold">
                        Food Cost: {foodCostPct.toFixed(1)}%
                      </span>
                    </div>
                  </div>

                  {/* Ingredients Breakdown */}
                  <div className="space-y-1.5 bg-[#FAF7F2] p-3 rounded-2xl border border-[#E5DEC9]">
                    <span className="text-[10px] font-titan uppercase text-[#4D080F] block">
                      Ingredients & Raw Material Fractions
                    </span>
                    {rcp.ingredients.map((ing, idx) => (
                      <div key={idx} className="flex justify-between text-xs font-montserrat">
                        <span className="text-gray-700">
                          {ing.quantity} {ing.unit} {ing.ingredientName}
                          {ing.wastePercentage > 0 && ` (+${ing.wastePercentage}% waste)`}
                        </span>
                        <strong className="text-[#4D080F]">{formatNaira(ing.calculatedCost)}</strong>
                      </div>
                    ))}
                  </div>

                  <div className="flex items-center justify-between text-xs font-montserrat pt-1">
                    <span className="text-gray-500">Target Selling Price:</span>
                    <strong className="font-titan text-[#4D080F]">{formatNaira(sellingPrice)}</strong>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ==========================================
          SUB-TAB 8: ACTUAL VS THEORETICAL VARIANCE ANALYTICS
          ========================================== */}
      {activeSubTab === 'analytics' && (
        <div className="space-y-4">
          <div className="bg-white p-4 rounded-2xl border border-[#E5DEC9] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <h3 className="font-titan text-sm text-[#4D080F] uppercase flex items-center gap-1.5">
                <BarChart3 className="w-4 h-4 text-emerald-700" />
                Actual vs. Theoretical Variance Analytics
              </h3>
              <p className="text-xs text-gray-500 font-montserrat">
                Formula: Opening + Receipts + Transfers In - Transfers Out - Wastage - POS Recipe Theoretical Consumption vs Physical Count.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-[#4D080F]">Analyzing Branch:</span>
              <select
                value={activeLocationFilter === 'all' ? 'gra' : activeLocationFilter}
                onChange={(e) => setActiveLocationFilter(e.target.value)}
                className="bg-[#FAF7F2] border border-[#E5DEC9] text-xs font-montserrat font-bold rounded-xl px-3 py-1.5 text-[#4D080F]"
              >
                <option value="gra">GRA Hub</option>
                <option value="okabere">Okabere Hub</option>
                <option value="ugbowo">Ugbowo Hub</option>
                <option value="general_store">General Store (Commissary)</option>
              </select>
            </div>
          </div>

          <div className="bg-white rounded-3xl border border-[#E5DEC9] overflow-hidden shadow-2xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-montserrat">
                <thead className="bg-[#FAF7F2] text-[#4D080F] font-titan uppercase text-[10px] border-b border-[#E5DEC9]">
                  <tr>
                    <th className="p-3.5">Raw Material</th>
                    <th className="p-3.5 text-center">Opening</th>
                    <th className="p-3.5 text-center">Receipts / In</th>
                    <th className="p-3.5 text-center">Theo. POS Sold</th>
                    <th className="p-3.5 text-center">Wastage</th>
                    <th className="p-3.5 text-center">Expected Close</th>
                    <th className="p-3.5 text-center">Actual Physical</th>
                    <th className="p-3.5 text-right">Variance Value</th>
                    <th className="p-3.5 text-center">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E5DEC9]">
                  {varianceData.map((v, idx) => (
                    <tr key={idx} className="hover:bg-[#FFF8E7]/40 transition-colors">
                      <td className="p-3.5">
                        <strong className="block text-[#241311]">{v.itemName}</strong>
                        <span className="text-[10px] font-mono text-gray-500">{v.sku}</span>
                      </td>

                      <td className="p-3.5 text-center text-gray-600">{v.openingStock}</td>
                      <td className="p-3.5 text-center text-emerald-700 font-bold">+{v.purchasesReceipts + v.transfersIn}</td>
                      <td className="p-3.5 text-center text-purple-700">-{v.theoreticalPOSConsumption}</td>
                      <td className="p-3.5 text-center text-red-600">-{v.wastageLogged}</td>
                      <td className="p-3.5 text-center font-bold text-[#4D080F]">{v.expectedClosingStock}</td>
                      <td className="p-3.5 text-center font-titan text-blue-700">{v.actualPhysicalStock}</td>

                      <td className="p-3.5 text-right font-titan">
                        <span className={v.costVarianceNaira < 0 ? 'text-red-600' : 'text-emerald-700'}>
                          {formatNaira(v.costVarianceNaira)}
                        </span>
                      </td>

                      <td className="p-3.5 text-center">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-titan uppercase ${
                            v.status === 'healthy'
                              ? 'bg-emerald-100 text-emerald-800'
                              : v.status === 'investigate'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-red-100 text-red-800'
                          }`}
                        >
                          {v.status.replace('_', ' ')}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ==========================================
          MODAL 1: QUICK STOCK ADJUSTMENT
          ========================================== */}
      {isQuickAdjustOpen && (
        <div className="fixed inset-0 z-60 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3">
          <div className="bg-white rounded-3xl w-full max-w-md p-6 space-y-4 shadow-2xl border-2 border-[#FFC700]">
            <div className="flex items-center justify-between border-b pb-3">
              <div>
                <span className="text-[10px] font-titan text-[#4D080F] uppercase">Direct Count Correction</span>
                <h3 className="font-titan text-lg text-[#4D080F]">{isQuickAdjustOpen.name}</h3>
              </div>
              <button
                onClick={() => setIsQuickAdjustOpen(null)}
                className="p-1.5 rounded-full hover:bg-gray-100 text-gray-500"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleQuickAdjust} className="space-y-4">
              <div>
                <label className="text-xs font-montserrat font-bold text-gray-700 block mb-1">
                  Target Stock Location
                </label>
                <select
                  value={adjustLocation}
                  onChange={(e) => setAdjustLocation(e.target.value)}
                  className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-2 text-xs font-montserrat font-bold text-[#4D080F]"
                >
                  <option value="general_store">General Store (Central Commissary)</option>
                  <option value="gra">GRA Branch</option>
                  <option value="okabere">Okabere Branch</option>
                  <option value="ugbowo">Ugbowo Branch</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-montserrat font-bold text-gray-700 block mb-1">
                  New Verified Stock Count ({isQuickAdjustOpen.unit})
                </label>
                <input
                  type="number"
                  step="0.1"
                  required
                  value={adjustQuantity}
                  onChange={(e) => setAdjustQuantity(e.target.value)}
                  className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-2 text-sm font-titan text-[#4D080F]"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsQuickAdjustOpen(null)}
                  className="px-4 py-2 bg-gray-100 text-gray-700 text-xs font-montserrat font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#4D080F] hover:bg-[#38050A] text-[#FFC700] text-xs font-titan uppercase rounded-xl shadow-xs"
                >
                  Update & Record Ledger
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ==========================================
          MODAL 2: LOG WASTAGE / SPOILAGE
          ========================================== */}
      {isLogWastageOpen && (
        <div className="fixed inset-0 z-60 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3">
          <div className="bg-white rounded-3xl w-full max-w-lg p-6 space-y-4 shadow-2xl border-2 border-red-500">
            <div className="flex items-center justify-between border-b pb-3">
              <div>
                <span className="text-[10px] font-titan text-red-600 uppercase">Loss Prevention Logging</span>
                <h3 className="font-titan text-lg text-[#4D080F]">Log Wastage & Spoilage</h3>
              </div>
              <button
                onClick={() => setIsLogWastageOpen(false)}
                className="p-1.5 rounded-full hover:bg-gray-100 text-gray-500"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleLogWastage} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-montserrat font-bold text-gray-700 block mb-1">
                    Stock Location
                  </label>
                  <select
                    value={wasteLocation}
                    onChange={(e) => setWasteLocation(e.target.value)}
                    className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-2 text-xs font-montserrat font-bold text-[#4D080F]"
                  >
                    <option value="general_store">General Store (Central Commissary)</option>
                    <option value="gra">GRA Branch</option>
                    <option value="okabere">Okabere Branch</option>
                    <option value="ugbowo">Ugbowo Branch</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-montserrat font-bold text-gray-700 block mb-1">
                    Root Cause Code
                  </label>
                  <select
                    value={wasteReason}
                    onChange={(e) => setWasteReason(e.target.value)}
                    className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-2 text-xs font-montserrat font-bold text-red-700"
                  >
                    <option value="expired_spoilage">Expired / Spoilage</option>
                    <option value="burnt_overcooked">Burnt / Overcooked in Kitchen</option>
                    <option value="dropped_spill">Dropped / Prep Spill</option>
                    <option value="cold_chain_failure">Power Outage / Cold Chain Loss</option>
                    <option value="customer_return">Customer Dissatisfaction Return</option>
                    <option value="trim_yield_loss">Trim & Butcher Yield Loss</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs font-montserrat font-bold text-gray-700 block mb-1">
                  Select Raw Material / Ingredient
                </label>
                <select
                  required
                  value={wasteItem}
                  onChange={(e) => setWasteItem(e.target.value)}
                  className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-2 text-xs font-montserrat font-bold text-[#241311]"
                >
                  <option value="">-- Select Inventory Item --</option>
                  {inventoryItems.map((it) => (
                    <option key={it.id} value={it.id}>
                      {it.name} ({it.sku}) — {it.unit}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs font-montserrat font-bold text-gray-700 block mb-1">
                  Quantity Lost
                </label>
                <input
                  type="number"
                  step="0.1"
                  required
                  placeholder="e.g. 5.5"
                  value={wasteQty}
                  onChange={(e) => setWasteQty(e.target.value)}
                  className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-2 text-sm font-titan text-red-600"
                />
              </div>

              <div>
                <label className="text-xs font-montserrat font-bold text-gray-700 block mb-1">
                  Specific Observation / Note
                </label>
                <textarea
                  rows={2}
                  placeholder="e.g. Compressor trip in GRA walk-in freezer overnight"
                  value={wasteNote}
                  onChange={(e) => setWasteNote(e.target.value)}
                  className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl p-2 text-xs font-montserrat text-[#241311]"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsLogWastageOpen(false)}
                  className="px-4 py-2 bg-gray-100 text-gray-700 text-xs font-montserrat font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-titan uppercase rounded-xl shadow-xs"
                >
                  Commit Waste Record & Debit Stock
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ==========================================
          MODAL 3: RAISE BRANCH INDENT / REQUISITION
          ========================================== */}
      {isNewRequestOpen && (
        <div className="fixed inset-0 z-60 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3">
          <div className="bg-white rounded-3xl w-full max-w-xl p-6 space-y-4 shadow-2xl border-2 border-[#FFC700]">
            <div className="flex items-center justify-between border-b pb-3">
              <div>
                <span className="text-[10px] font-titan text-[#4D080F] uppercase">Commissary Requisition</span>
                <h3 className="font-titan text-lg text-[#4D080F]">Raise Branch Stock Indent</h3>
              </div>
              <button
                onClick={() => setIsNewRequestOpen(false)}
                className="p-1.5 rounded-full hover:bg-gray-100 text-gray-500"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateRequest} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-montserrat font-bold text-gray-700 block mb-1">
                    Requesting Branch
                  </label>
                  <select
                    value={indentBranch}
                    onChange={(e) => setIndentBranch(e.target.value)}
                    className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-2 text-xs font-montserrat font-bold text-[#4D080F]"
                  >
                    <option value="gra">GRA Hub</option>
                    <option value="okabere">Okabere Hub</option>
                    <option value="ugbowo">Ugbowo Hub</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-montserrat font-bold text-gray-700 block mb-1">
                    Urgency Priority
                  </label>
                  <select
                    value={indentPriority}
                    onChange={(e) => setIndentPriority(e.target.value as any)}
                    className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-2 text-xs font-montserrat font-bold text-[#4D080F]"
                  >
                    <option value="normal">Normal (Routine Daily Re-stock)</option>
                    <option value="high">High (Running Low on Key Prep)</option>
                    <option value="urgent">Urgent / 86 Imminent</option>
                  </select>
                </div>
              </div>

              {/* Items in Request */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-montserrat font-bold text-gray-700">Requested Items</label>
                  <button
                    type="button"
                    onClick={() => {
                      if (inventoryItems.length > 0) {
                        setIndentItems([...indentItems, { itemId: inventoryItems[0].id, requestedQty: 10 }]);
                      }
                    }}
                    className="text-xs font-titan text-[#4D080F] hover:text-[#E62E00] flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" /> Add Line
                  </button>
                </div>

                {indentItems.map((item, idx) => (
                  <div key={idx} className="flex items-center gap-2">
                    <select
                      value={item.itemId}
                      onChange={(e) => {
                        const copy = [...indentItems];
                        copy[idx].itemId = e.target.value;
                        setIndentItems(copy);
                      }}
                      className="flex-1 bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-1.5 text-xs font-montserrat text-[#241311]"
                    >
                      {inventoryItems.map((it) => (
                        <option key={it.id} value={it.id}>
                          {it.name} ({it.unit})
                        </option>
                      ))}
                    </select>

                    <input
                      type="number"
                      step="1"
                      placeholder="Qty"
                      value={item.requestedQty}
                      onChange={(e) => {
                        const copy = [...indentItems];
                        copy[idx].requestedQty = Number(e.target.value);
                        setIndentItems(copy);
                      }}
                      className="w-20 bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-1.5 text-xs font-titan text-[#4D080F]"
                    />

                    <button
                      type="button"
                      onClick={() => setIndentItems(indentItems.filter((_, i) => i !== idx))}
                      className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>

              <div>
                <label className="text-xs font-montserrat font-bold text-gray-700 block mb-1">
                  Special Kitchen Note
                </label>
                <input
                  type="text"
                  placeholder="e.g. Expected Friday evening rush in GRA Lounge"
                  value={indentNotes}
                  onChange={(e) => setIndentNotes(e.target.value)}
                  className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-2 text-xs font-montserrat text-[#241311]"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsNewRequestOpen(false)}
                  className="px-4 py-2 bg-gray-100 text-gray-700 text-xs font-montserrat font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#4D080F] hover:bg-[#38050A] text-[#FFC700] text-xs font-titan uppercase rounded-xl shadow-xs"
                >
                  Submit Requisition to Commissary
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ==========================================
          MODAL 4: PHYSICAL STOCKTAKE SESSION
          ========================================== */}
      {isNewStocktakeOpen && (
        <div className="fixed inset-0 z-60 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3">
          <div className="bg-white rounded-3xl w-full max-w-2xl p-6 space-y-4 shadow-2xl border-2 border-[#FFC700] max-h-[90vh] flex flex-col">
            <div className="flex items-center justify-between border-b pb-3 shrink-0">
              <div>
                <span className="text-[10px] font-titan text-emerald-700 uppercase">Physical Audit Session</span>
                <h3 className="font-titan text-lg text-[#4D080F]">Conduct Stocktake Count</h3>
              </div>
              <button
                onClick={() => setIsNewStocktakeOpen(false)}
                className="p-1.5 rounded-full hover:bg-gray-100 text-gray-500"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex items-center gap-3 shrink-0">
              <label className="text-xs font-montserrat font-bold text-gray-700">Audit Store Location:</label>
              <select
                value={stocktakeLocation}
                onChange={(e) => {
                  setStocktakeLocation(e.target.value);
                  const initialCounts: Record<string, number> = {};
                  inventoryItems.forEach((it) => {
                    initialCounts[it.id] = it.locationStock?.[e.target.value]?.stockOnHand ?? it.currentStock?.[e.target.value] ?? 0;
                  });
                  setStocktakeCounts(initialCounts);
                }}
                className="bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-1.5 text-xs font-montserrat font-bold text-[#4D080F]"
              >
                <option value="gra">GRA Branch</option>
                <option value="okabere">Okabere Branch</option>
                <option value="ugbowo">Ugbowo Branch</option>
                <option value="general_store">General Store (Central Commissary)</option>
              </select>
            </div>

            {/* Editable Count Table */}
            <div className="flex-1 overflow-y-auto border border-[#E5DEC9] rounded-2xl">
              <table className="w-full text-left text-xs font-montserrat">
                <thead className="bg-[#FAF7F2] text-[#4D080F] font-titan uppercase text-[10px] sticky top-0 border-b border-[#E5DEC9]">
                  <tr>
                    <th className="p-3">Item & SKU</th>
                    <th className="p-3 text-center">System Expected</th>
                    <th className="p-3 text-center">Physical Count</th>
                    <th className="p-3 text-center">Variance</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {inventoryItems.map((it) => {
                    const expected = it.locationStock?.[stocktakeLocation]?.stockOnHand ?? it.currentStock?.[stocktakeLocation] ?? 0;
                    const counted = stocktakeCounts[it.id] ?? expected;
                    const variance = counted - expected;

                    return (
                      <tr key={it.id} className="hover:bg-[#FFF8E7]/40">
                        <td className="p-3">
                          <strong className="block text-[#241311]">{it.name}</strong>
                          <span className="text-[10px] font-mono text-gray-400">{it.sku}</span>
                        </td>
                        <td className="p-3 text-center text-gray-600 font-bold">
                          {expected} {it.unit}
                        </td>
                        <td className="p-3 text-center">
                          <input
                            type="number"
                            step="0.5"
                            value={counted}
                            onChange={(e) => {
                              setStocktakeCounts({
                                ...stocktakeCounts,
                                [it.id]: Number(e.target.value),
                              });
                            }}
                            className="w-24 bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl text-center py-1 text-xs font-titan text-[#4D080F]"
                          />
                        </td>
                        <td
                          className={`p-3 text-center font-titan ${
                            variance < 0 ? 'text-red-600' : variance > 0 ? 'text-blue-600' : 'text-emerald-700'
                          }`}
                        >
                          {variance > 0 ? `+${variance}` : variance} {it.unit}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            <div className="pt-2 flex items-center justify-end gap-2 shrink-0">
              <button
                type="button"
                onClick={() => setIsNewStocktakeOpen(false)}
                className="px-4 py-2 bg-gray-100 text-gray-700 text-xs font-montserrat font-bold rounded-xl"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => handleSubmitStocktake(true)}
                className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-titan uppercase rounded-xl shadow-xs"
              >
                Submit & Auto-Reconcile Ledger
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==========================================
          MODAL 5: DRAFT PURCHASE ORDER (PO)
          ========================================== */}
      {isNewPOOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 space-y-4 border border-[#E5DEC9] shadow-2xl">
            <div className="flex items-center justify-between border-b pb-3">
              <div>
                <h3 className="font-titan text-base text-[#4D080F] uppercase">Draft Purchase Order (PO)</h3>
                <p className="text-xs text-gray-500 font-montserrat">Issue an official procurement order to a verified Choplife Republic vendor.</p>
              </div>
              <button onClick={() => setIsNewPOOpen(false)} className="text-gray-400 hover:text-gray-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreatePO} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-montserrat font-bold text-gray-700 block mb-1">Approved Supplier</label>
                  <select
                    value={poSupplierId}
                    onChange={(e) => setPoSupplierId(e.target.value)}
                    className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-2 text-xs font-montserrat font-bold text-[#4D080F]"
                  >
                    {suppliers.map((sup) => (
                      <option key={sup.id} value={sup.id}>
                        {sup.name} ({sup.paymentTerms || 'Net 14'})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-xs font-montserrat font-bold text-gray-700 block mb-1">Receiving Stock Location</label>
                  <select
                    value={poDestLoc}
                    onChange={(e) => setPoDestLoc(e.target.value)}
                    className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-2 text-xs font-montserrat font-bold text-[#4D080F]"
                  >
                    <option value="general_store">General Store (Central Commissary)</option>
                    <option value="gra">GRA Flagship Kitchen</option>
                    <option value="okabere">Okabere Branch</option>
                    <option value="ugbowo">Ugbowo Branch</option>
                  </select>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-montserrat font-bold text-gray-700">PO Line Items</label>
                  <button
                    type="button"
                    onClick={() => {
                      const fallback = inventoryItems[0];
                      if (fallback) {
                        setPoItems([
                          ...poItems,
                          {
                            itemId: fallback.id,
                            orderQuantity: 10,
                            purchaseUnit: fallback.unit || 'kg',
                            unitPrice: fallback.costPerUnit || 1500,
                          },
                        ]);
                      }
                    }}
                    className="text-xs font-montserrat font-bold text-[#4D080F] hover:underline flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" /> Add Line
                  </button>
                </div>

                <div className="space-y-2 max-h-52 overflow-y-auto pr-1">
                  {poItems.map((line, idx) => (
                    <div key={idx} className="grid grid-cols-12 gap-2 items-center bg-[#FAF7F2] p-2.5 rounded-xl border border-[#E5DEC9]">
                      <div className="col-span-6">
                        <select
                          value={line.itemId}
                          onChange={(e) => {
                            const selected = inventoryItems.find((i) => i.id === e.target.value);
                            const next = [...poItems];
                            next[idx] = {
                              ...next[idx],
                              itemId: e.target.value,
                              purchaseUnit: selected?.unit || 'units',
                              unitPrice: selected?.costPerUnit || 1000,
                            };
                            setPoItems(next);
                          }}
                          className="w-full bg-white border border-[#E5DEC9] rounded-lg px-2 py-1.5 text-xs font-montserrat text-[#241311]"
                        >
                          {inventoryItems.map((inv) => (
                            <option key={inv.id} value={inv.id}>
                              {inv.name} ({inv.unit})
                            </option>
                          ))}
                        </select>
                      </div>
                      <div className="col-span-3">
                        <input
                          type="number"
                          min="1"
                          value={line.orderQuantity}
                          onChange={(e) => {
                            const next = [...poItems];
                            next[idx].orderQuantity = Number(e.target.value);
                            setPoItems(next);
                          }}
                          className="w-full bg-white border border-[#E5DEC9] rounded-lg px-2 py-1.5 text-xs font-titan text-center text-[#4D080F]"
                          placeholder="Qty"
                        />
                      </div>
                      <div className="col-span-2">
                        <input
                          type="number"
                          min="1"
                          value={line.unitPrice}
                          onChange={(e) => {
                            const next = [...poItems];
                            next[idx].unitPrice = Number(e.target.value);
                            setPoItems(next);
                          }}
                          className="w-full bg-white border border-[#E5DEC9] rounded-lg px-2 py-1.5 text-xs font-mono text-right text-[#241311]"
                          placeholder="Unit ₦"
                        />
                      </div>
                      <div className="col-span-1 text-right">
                        <button
                          type="button"
                          onClick={() => setPoItems(poItems.filter((_, i) => i !== idx))}
                          className="text-red-500 hover:text-red-700 p-1"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsNewPOOpen(false)}
                  className="px-4 py-2 bg-gray-100 text-gray-700 text-xs font-montserrat font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  id="btn-submit-po"
                  className="px-5 py-2 bg-[#4D080F] hover:bg-[#3A050A] text-[#FFC700] text-xs font-titan uppercase rounded-xl shadow-xs"
                >
                  Generate & Issue PO
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ==========================================
          MODAL 6: RECEIVE DELIVERY (GRN)
          ========================================== */}
      {isNewGRNOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 space-y-4 border border-[#E5DEC9] shadow-2xl">
            <div className="flex items-center justify-between border-b pb-3">
              <div>
                <h3 className="font-titan text-base text-[#4D080F] uppercase">Receive Delivery — Verified GRN</h3>
                <p className="text-xs text-gray-500 font-montserrat">Inspect supplier delivery, verify invoice quantities & credit receiving stock location.</p>
              </div>
              <button onClick={() => setIsNewGRNOpen(false)} className="text-gray-400 hover:text-gray-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateGRN} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-xs font-montserrat font-bold text-gray-700 block mb-1">Linked PO (Optional)</label>
                  <select
                    value={grnPoId}
                    onChange={(e) => {
                      setGrnPoId(e.target.value);
                      const po = purchaseOrders.find((p) => p.id === e.target.value);
                      if (po) {
                        setGrnSupplierName(po.supplierName);
                        setGrnReceivingLoc(po.destinationLocation || 'general_store');
                      }
                    }}
                    className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-2 text-xs font-montserrat font-bold text-[#4D080F]"
                  >
                    <option value="">Direct Supplier Delivery</option>
                    {purchaseOrders.map((po) => (
                      <option key={po.id} value={po.id}>
                        {po.poNumber} — {po.supplierName}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-xs font-montserrat font-bold text-gray-700 block mb-1">Supplier Invoice #</label>
                  <input
                    type="text"
                    value={grnInvoiceNo}
                    onChange={(e) => setGrnInvoiceNo(e.target.value)}
                    placeholder="e.g. INV-2026-884"
                    className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-2 text-xs font-montserrat text-[#241311]"
                  />
                </div>

                <div>
                  <label className="text-xs font-montserrat font-bold text-gray-700 block mb-1">Receiving Stock Location</label>
                  <select
                    value={grnReceivingLoc}
                    onChange={(e) => setGrnReceivingLoc(e.target.value)}
                    className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-2 text-xs font-montserrat font-bold text-[#4D080F]"
                  >
                    <option value="general_store">General Store (Central Commissary)</option>
                    <option value="gra">GRA Flagship Kitchen</option>
                    <option value="okabere">Okabere Branch</option>
                    <option value="ugbowo">Ugbowo Branch</option>
                  </select>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-montserrat font-bold text-gray-700">Accepted Delivery Lines</label>
                  <button
                    type="button"
                    onClick={() => {
                      const fallback = inventoryItems[0];
                      if (fallback) {
                        setGrnLines([
                          ...grnLines,
                          {
                            itemId: fallback.id,
                            itemName: fallback.name,
                            acceptedQty: 15,
                            unitPrice: fallback.costPerUnit || 1500,
                            batchNumber: `BCH-${Date.now().toString().slice(-4)}`,
                            expiryDate: new Date(Date.now() + 86400000 * 30).toISOString().split('T')[0],
                          },
                        ]);
                      }
                    }}
                    className="text-xs font-montserrat font-bold text-emerald-700 hover:underline flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" /> Add Received Item
                  </button>
                </div>

                <div className="space-y-2 max-h-52 overflow-y-auto pr-1">
                  {grnLines.map((line, idx) => (
                    <div key={idx} className="grid grid-cols-12 gap-2 items-center bg-[#FAF7F2] p-2.5 rounded-xl border border-[#E5DEC9]">
                      <div className="col-span-6">
                        <select
                          value={line.itemId}
                          onChange={(e) => {
                            const selected = inventoryItems.find((i) => i.id === e.target.value);
                            const next = [...grnLines];
                            next[idx] = {
                              ...next[idx],
                              itemId: e.target.value,
                              itemName: selected?.name || 'Item',
                              unitPrice: selected?.costPerUnit || 1000,
                            };
                            setGrnLines(next);
                          }}
                          className="w-full bg-white border border-[#E5DEC9] rounded-lg px-2 py-1.5 text-xs font-montserrat text-[#241311]"
                        >
                          {inventoryItems.map((inv) => (
                            <option key={inv.id} value={inv.id}>
                              {inv.name} ({inv.unit})
                            </option>
                          ))}
                        </select>
                      </div>
                      <div className="col-span-3">
                        <input
                          type="number"
                          min="1"
                          value={line.acceptedQty}
                          onChange={(e) => {
                            const next = [...grnLines];
                            next[idx].acceptedQty = Number(e.target.value);
                            setGrnLines(next);
                          }}
                          className="w-full bg-white border border-[#E5DEC9] rounded-lg px-2 py-1.5 text-xs font-titan text-center text-emerald-700"
                          placeholder="Accepted Qty"
                        />
                      </div>
                      <div className="col-span-2">
                        <input
                          type="number"
                          min="1"
                          value={line.unitPrice}
                          onChange={(e) => {
                            const next = [...grnLines];
                            next[idx].unitPrice = Number(e.target.value);
                            setGrnLines(next);
                          }}
                          className="w-full bg-white border border-[#E5DEC9] rounded-lg px-2 py-1.5 text-xs font-mono text-right text-[#241311]"
                          placeholder="Unit ₦"
                        />
                      </div>
                      <div className="col-span-1 text-right">
                        <button
                          type="button"
                          onClick={() => setGrnLines(grnLines.filter((_, i) => i !== idx))}
                          className="text-red-500 hover:text-red-700 p-1"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsNewGRNOpen(false)}
                  className="px-4 py-2 bg-gray-100 text-gray-700 text-xs font-montserrat font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  id="btn-submit-grn"
                  className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-titan uppercase rounded-xl shadow-xs"
                >
                  Accept GRN & Credit Stock
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ==========================================
          MODAL 1: ADD NEW STOCK ITEM
          ========================================== */}
      {isAddItemOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-60 flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl border border-[#E5DEC9] w-full max-w-3xl my-8 overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
            <div className="p-4 sm:p-5 bg-[#4D080F] text-white flex items-center justify-between shrink-0">
              <div>
                <span className="text-[10px] text-[#FFC700] font-titan uppercase tracking-wider block">
                  COMMISSARY ERP MASTER DATA
                </span>
                <h3 className="font-titan text-lg sm:text-xl text-[#FFC700]">Add New Stock Item</h3>
                <p className="text-xs text-gray-300 font-montserrat">
                  Register a master inventory record with units, thresholds, and optional initial opening balance.
                </p>
              </div>
              <button
                onClick={() => setIsAddItemOpen(false)}
                className="text-gray-300 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateStockItem} className="p-4 sm:p-6 overflow-y-auto space-y-5 text-xs font-montserrat">
              {/* SECTION 1: Item Identity */}
              <div>
                <h4 className="font-titan text-xs text-[#4D080F] uppercase border-b border-[#E5DEC9] pb-1.5 mb-3">
                  1. Item Identification & Categorization
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                  <div className="sm:col-span-2">
                    <label className="font-bold text-gray-700 block mb-1">
                      Item Name <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      id="input-item-name"
                      value={addName}
                      onChange={(e) => setAddName(e.target.value)}
                      placeholder="e.g. Titus Sardine Fish (Frozen 20kg)"
                      className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-2 font-bold text-[#241311] focus:outline-none focus:border-[#4D080F]"
                    />
                  </div>

                  <div>
                    <label className="font-bold text-gray-700 block mb-1">SKU / Code</label>
                    <input
                      type="text"
                      id="input-item-sku"
                      value={addSku}
                      onChange={(e) => setAddSku(e.target.value)}
                      placeholder="e.g. RAW-FSH-009 (Auto if blank)"
                      className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-2 font-mono text-[#241311] focus:outline-none focus:border-[#4D080F]"
                    />
                  </div>

                  <div>
                    <label className="font-bold text-gray-700 block mb-1">Barcode / UPC</label>
                    <input
                      type="text"
                      id="input-item-barcode"
                      value={addBarcode}
                      onChange={(e) => setAddBarcode(e.target.value)}
                      placeholder="e.g. 890123456789"
                      className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-2 font-mono text-[#241311] focus:outline-none focus:border-[#4D080F]"
                    />
                  </div>

                  <div>
                    <label className="font-bold text-gray-700 block mb-1">
                      Category <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={addCategory}
                      onChange={(e) => setAddCategory(e.target.value)}
                      id="select-item-category"
                      className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-2 font-bold text-[#4D080F] focus:outline-none focus:border-[#4D080F]"
                    >
                      <option value="proteins">Proteins (Fish, Beef, Chicken)</option>
                      <option value="ingredients">Raw Ingredients & Spices</option>
                      <option value="bakery">Bakery & Flour</option>
                      <option value="beverages">Beverages & Mocktails</option>
                      <option value="packaging">Branded Packaging</option>
                      <option value="cleaning">Cleaning & Hygiene</option>
                    </select>
                  </div>

                  <div>
                    <label className="font-bold text-gray-700 block mb-1">Subcategory</label>
                    <input
                      type="text"
                      value={addSubcategory}
                      onChange={(e) => setAddSubcategory(e.target.value)}
                      placeholder="e.g. Fresh Seafood, Grains"
                      className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-2 text-[#241311] focus:outline-none focus:border-[#4D080F]"
                    />
                  </div>

                  <div className="sm:col-span-3">
                    <label className="font-bold text-gray-700 block mb-1">Description</label>
                    <textarea
                      rows={2}
                      value={addDescription}
                      onChange={(e) => setAddDescription(e.target.value)}
                      placeholder="Detailed item description, handling instructions, or specification notes..."
                      className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-2 text-[#241311] focus:outline-none focus:border-[#4D080F]"
                    />
                  </div>
                </div>
              </div>

              {/* SECTION 2: Storage & Units */}
              <div>
                <h4 className="font-titan text-xs text-[#4D080F] uppercase border-b border-[#E5DEC9] pb-1.5 mb-3">
                  2. Storage Location & Units of Measurement
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                  <div>
                    <label className="font-bold text-gray-700 block mb-1">Storage Area</label>
                    <select
                      value={addStorageArea}
                      onChange={(e) => setAddStorageArea(e.target.value)}
                      className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-2 font-bold text-[#4D080F]"
                    >
                      <option value="dry_store">Dry Food Store</option>
                      <option value="cold_store">Cold Room / Freezer (-18°C)</option>
                      <option value="chiller">Prep Chiller (+4°C)</option>
                      <option value="packaging_bay">Packaging Bay</option>
                      <option value="chemical_store">Sanitation & Chemicals</option>
                      <option value="bar_cellar">Bar Cellar</option>
                    </select>
                  </div>

                  <div>
                    <label className="font-bold text-gray-700 block mb-1">Inventory Type</label>
                    <select
                      value={addInventoryType}
                      onChange={(e) => setAddInventoryType(e.target.value)}
                      className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-2 font-bold text-[#4D080F]"
                    >
                      <option value="raw_material">Raw Ingredient</option>
                      <option value="packaging">Packaging Material</option>
                      <option value="intermediate">Prepared Sub-Recipe</option>
                      <option value="finished_good">Finished Product</option>
                      <option value="consumable">Operational Consumable</option>
                    </select>
                  </div>

                  <div>
                    <label className="font-bold text-gray-700 block mb-1">Base Unit</label>
                    <select
                      value={addBaseUnit}
                      onChange={(e) => {
                        setAddBaseUnit(e.target.value);
                        setAddUnit(e.target.value);
                      }}
                      className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-2 font-bold text-[#4D080F]"
                    >
                      <option value="kg">kg (Kilograms)</option>
                      <option value="g">g (Grams)</option>
                      <option value="litre">litre (Litres)</option>
                      <option value="ml">ml (Millilitres)</option>
                      <option value="pcs">pcs (Pieces)</option>
                      <option value="pack">pack (Packs)</option>
                      <option value="bag">bag (Bags)</option>
                      <option value="carton">carton (Cartons)</option>
                      <option value="bottle">bottle (Bottles)</option>
                    </select>
                  </div>

                  <div>
                    <label className="font-bold text-gray-700 block mb-1">Purchase Unit & Factor</label>
                    <div className="flex items-center gap-1.5">
                      <input
                        type="text"
                        value={addPurchaseUnit}
                        onChange={(e) => setAddPurchaseUnit(e.target.value)}
                        placeholder="bag"
                        className="w-1/2 bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-2.5 py-2 text-[#241311]"
                      />
                      <input
                        type="number"
                        min="1"
                        value={addPurchaseUnitFactor}
                        onChange={(e) => setAddPurchaseUnitFactor(Number(e.target.value) || 1)}
                        placeholder="Qty"
                        className="w-1/2 bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-2 py-2 text-center text-[#241311]"
                        title="How many base units per purchase unit (e.g. 50 kg per bag)"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* SECTION 3: Costing, Pricing & Classification */}
              <div>
                <h4 className="font-titan text-xs text-[#4D080F] uppercase border-b border-[#E5DEC9] pb-1.5 mb-3">
                  3. Costing, Valuation & Pricing
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                  <div>
                    <label className="font-bold text-gray-700 block mb-1">Unit Cost (₦)</label>
                    <input
                      type="number"
                      min="0"
                      id="input-item-cost"
                      value={addCostPerUnit}
                      onChange={(e) => setAddCostPerUnit(e.target.value)}
                      placeholder="0"
                      className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-2 font-mono font-bold text-[#4D080F]"
                    />
                  </div>

                  <div>
                    <label className="font-bold text-gray-700 block mb-1">Selling Price (₦)</label>
                    <input
                      type="number"
                      min="0"
                      id="input-item-selling-price"
                      value={addSellingPrice}
                      onChange={(e) => setAddSellingPrice(e.target.value)}
                      placeholder="0"
                      className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-2 font-mono text-[#241311]"
                    />
                  </div>

                  <div>
                    <label className="font-bold text-gray-700 block mb-1">Replenishment Par Level</label>
                    <input
                      type="number"
                      min="1"
                      value={addParLevel}
                      onChange={(e) => setAddParLevel(e.target.value)}
                      placeholder="50"
                      className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-2 text-[#241311]"
                    />
                  </div>

                  <div>
                    <label className="font-bold text-gray-700 block mb-1">Safety Par Threshold</label>
                    <input
                      type="number"
                      min="0"
                      value={addMinThreshold}
                      onChange={(e) => setAddMinThreshold(e.target.value)}
                      placeholder="10"
                      className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-2 text-[#241311]"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-5 mt-3 pt-2 border-t border-[#FAF7F2] flex-wrap">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={addIsPurchasable}
                      onChange={(e) => setAddIsPurchasable(e.target.checked)}
                      className="rounded text-[#4D080F]"
                    />
                    <span className="font-bold text-gray-700">Can be Purchased from Suppliers</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={addIsSellable}
                      onChange={(e) => setAddIsSellable(e.target.checked)}
                      className="rounded text-[#4D080F]"
                    />
                    <span className="font-bold text-gray-700">Directly Sellable on POS Menu</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer bg-purple-50 px-2.5 py-1 rounded-lg border border-purple-200">
                    <input
                      type="checkbox"
                      id="checkbox-is-demo"
                      checked={addIsDemo}
                      onChange={(e) => setAddIsDemo(e.target.checked)}
                      className="rounded text-purple-700"
                    />
                    <span className="font-bold text-purple-900 flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5 text-purple-600" />
                      Flag as Demo / Placeholder Item
                    </span>
                  </label>
                </div>
              </div>

              {/* SECTION 4: Traceable Opening Stock */}
              <div className="bg-[#FAF7F2] p-3.5 rounded-2xl border border-[#E5DEC9] space-y-3">
                <div className="flex items-start gap-2">
                  <Info className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-titan text-xs text-[#4D080F] uppercase">
                      4. Traceable Opening Stock Balance
                    </h4>
                    <p className="text-[11px] text-gray-600">
                      Choplife Republic strict accounting rule: If you specify an initial stock quantity &gt; 0, an auditable ledger entry will be posted. If left at 0, no ledger transaction is invented.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
                  <div>
                    <label className="font-bold text-gray-700 block mb-1">Initial Opening Quantity</label>
                    <input
                      type="number"
                      min="0"
                      id="input-initial-stock"
                      value={addInitialStock}
                      onChange={(e) => setAddInitialStock(e.target.value)}
                      placeholder="0"
                      className="w-full bg-white border border-[#E5DEC9] rounded-xl px-3 py-2 font-titan text-emerald-700 text-sm focus:outline-none focus:border-[#4D080F]"
                    />
                  </div>

                  <div>
                    <label className="font-bold text-gray-700 block mb-1">Initial Stock Location</label>
                    <select
                      value={addInitialLocation}
                      onChange={(e) => setAddInitialLocation(e.target.value)}
                      id="select-initial-location"
                      className="w-full bg-white border border-[#E5DEC9] rounded-xl px-3 py-2 font-bold text-[#4D080F]"
                    >
                      <option value="general_store">General Store (Commissary)</option>
                      <option value="gra">GRA Flagship Kitchen</option>
                      <option value="okabere">Okabere Branch</option>
                      <option value="ugbowo">Ugbowo Branch</option>
                    </select>
                  </div>

                  <div>
                    <label className="font-bold text-gray-700 block mb-1">Opening Audit Note</label>
                    <input
                      type="text"
                      value={addInitialNotes}
                      onChange={(e) => setAddInitialNotes(e.target.value)}
                      placeholder="Reason for opening balance"
                      className="w-full bg-white border border-[#E5DEC9] rounded-xl px-3 py-2 text-[#241311]"
                    />
                  </div>
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setIsAddItemOpen(false)}
                  className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs font-montserrat font-bold rounded-xl transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  id="btn-submit-add-item"
                  className="px-6 py-2.5 bg-[#4D080F] hover:bg-[#38050A] text-[#FFC700] text-xs font-titan uppercase rounded-xl shadow-xs transition-colors"
                >
                  Create Master Stock Item
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ==========================================
          MODAL 2: EDIT MASTER ITEM SPECIFICATIONS
          ========================================== */}
      {editItemTarget && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-60 flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl border border-[#E5DEC9] w-full max-w-2xl my-8 overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
            <div className="p-4 sm:p-5 bg-[#4D080F] text-white flex items-center justify-between shrink-0">
              <div>
                <span className="text-[10px] text-[#FFC700] font-titan uppercase tracking-wider block">
                  UPDATE MASTER ITEM DETAILS
                </span>
                <h3 className="font-titan text-lg sm:text-xl text-[#FFC700]">
                  {editItemTarget.name}
                </h3>
                <p className="text-xs text-gray-300 font-montserrat">
                  SKU: {editItemTarget.sku} | ID: {editItemTarget.id}
                </p>
              </div>
              <button
                onClick={() => setEditItemTarget(null)}
                className="text-gray-300 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="bg-amber-50 p-3 border-b border-amber-200 text-amber-900 text-[11px] font-montserrat flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0" />
              <span>
                <strong>Important:</strong> Modifying item details and replenishment par levels does NOT alter physical stock-on-hand. Use <em>Quick Count</em> or the <em>Transaction Ledger</em> to adjust quantities.
              </span>
            </div>

            <form onSubmit={handleSaveEditItem} className="p-4 sm:p-6 overflow-y-auto space-y-4 text-xs font-montserrat">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="sm:col-span-2">
                  <label className="font-bold text-gray-700 block mb-1">Item Name</label>
                  <input
                    type="text"
                    required
                    id="edit-item-name"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-2 font-bold text-[#241311]"
                  />
                </div>

                <div>
                  <label className="font-bold text-gray-700 block mb-1">SKU</label>
                  <input
                    type="text"
                    required
                    id="edit-item-sku"
                    value={editSku}
                    onChange={(e) => setEditSku(e.target.value)}
                    className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-2 font-mono text-[#241311]"
                  />
                </div>

                <div>
                  <label className="font-bold text-gray-700 block mb-1">Barcode</label>
                  <input
                    type="text"
                    value={editBarcode}
                    onChange={(e) => setEditBarcode(e.target.value)}
                    className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-2 font-mono text-[#241311]"
                  />
                </div>

                <div>
                  <label className="font-bold text-gray-700 block mb-1">Category</label>
                  <select
                    value={editCategory}
                    onChange={(e) => setEditCategory(e.target.value)}
                    className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-2 font-bold text-[#4D080F]"
                  >
                    <option value="proteins">Proteins</option>
                    <option value="ingredients">Raw Ingredients</option>
                    <option value="bakery">Bakery & Flour</option>
                    <option value="beverages">Beverages</option>
                    <option value="packaging">Packaging</option>
                    <option value="cleaning">Cleaning</option>
                  </select>
                </div>

                <div>
                  <label className="font-bold text-gray-700 block mb-1">Subcategory</label>
                  <input
                    type="text"
                    value={editSubcategory}
                    onChange={(e) => setEditSubcategory(e.target.value)}
                    className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-2 text-[#241311]"
                  />
                </div>

                <div>
                  <label className="font-bold text-gray-700 block mb-1">Unit Cost (₦)</label>
                  <input
                    type="number"
                    min="0"
                    id="edit-item-cost"
                    value={editCostPerUnit}
                    onChange={(e) => setEditCostPerUnit(e.target.value)}
                    className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-2 font-mono font-bold text-[#4D080F]"
                  />
                </div>

                <div>
                  <label className="font-bold text-gray-700 block mb-1">Selling Price (₦)</label>
                  <input
                    type="number"
                    min="0"
                    value={editSellingPrice}
                    onChange={(e) => setEditSellingPrice(e.target.value)}
                    className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-2 font-mono text-[#241311]"
                  />
                </div>

                <div>
                  <label className="font-bold text-gray-700 block mb-1">Replenishment Par Level</label>
                  <input
                    type="number"
                    min="1"
                    value={editParLevel}
                    onChange={(e) => setEditParLevel(e.target.value)}
                    className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-2 text-[#241311]"
                  />
                </div>

                <div>
                  <label className="font-bold text-gray-700 block mb-1">Minimum Safety Par</label>
                  <input
                    type="number"
                    min="0"
                    value={editMinThreshold}
                    onChange={(e) => setEditMinThreshold(e.target.value)}
                    className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-2 text-[#241311]"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="font-bold text-gray-700 block mb-1">Description</label>
                  <textarea
                    rows={2}
                    value={editDescription}
                    onChange={(e) => setEditDescription(e.target.value)}
                    className="w-full bg-[#FAF7F2] border border-[#E5DEC9] rounded-xl px-3 py-2 text-[#241311]"
                  />
                </div>

                <div className="sm:col-span-2 flex items-center gap-4 pt-2">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={editIsActive}
                      onChange={(e) => setEditIsActive(e.target.checked)}
                      className="rounded text-[#4D080F]"
                    />
                    <span className="font-bold text-gray-700">Active Listing Status</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={editIsPurchasable}
                      onChange={(e) => setEditIsPurchasable(e.target.checked)}
                      className="rounded text-[#4D080F]"
                    />
                    <span className="font-bold text-gray-700">Can be Purchased</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={editIsSellable}
                      onChange={(e) => setEditIsSellable(e.target.checked)}
                      className="rounded text-[#4D080F]"
                    />
                    <span className="font-bold text-gray-700">Can be Sold on POS</span>
                  </label>
                </div>
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-[#E5DEC9]">
                <button
                  type="button"
                  onClick={() => setEditItemTarget(null)}
                  className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  id="btn-save-edit-item"
                  className="px-6 py-2.5 bg-blue-700 hover:bg-blue-800 text-white font-titan uppercase rounded-xl shadow-xs"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ==========================================
          MODAL 3: ITEM MOVEMENT HISTORY LEDGER
          ========================================== */}
      {viewLedgerItem && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-60 flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl border border-[#E5DEC9] w-full max-w-4xl my-8 overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
            <div className="p-4 sm:p-5 bg-[#4D080F] text-white flex items-center justify-between shrink-0">
              <div>
                <span className="text-[10px] text-[#FFC700] font-titan uppercase tracking-wider block">
                  PERPETUAL STOCK LEDGER AUDIT
                </span>
                <h3 className="font-titan text-lg sm:text-xl text-[#FFC700]">
                  Movement History: {viewLedgerItem.name}
                </h3>
                <p className="text-xs text-gray-300 font-montserrat">
                  SKU: {viewLedgerItem.sku} | Unit: {viewLedgerItem.unit}
                </p>
              </div>
              <button
                onClick={() => setViewLedgerItem(null)}
                className="text-gray-300 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 sm:p-6 overflow-y-auto space-y-4 text-xs font-montserrat">
              {isHistoryLoading ? (
                <div className="py-12 text-center text-gray-500 font-bold flex items-center justify-center gap-2">
                  <RefreshCw className="w-4 h-4 animate-spin text-[#4D080F]" />
                  Loading movement transactions...
                </div>
              ) : itemLedgerHistory.length === 0 ? (
                <div className="py-12 text-center text-gray-500 font-montserrat">
                  No historical ledger movements recorded for this item yet.
                </div>
              ) : (
                <div className="overflow-x-auto rounded-2xl border border-[#E5DEC9]">
                  <table className="w-full text-left text-xs font-montserrat">
                    <thead className="bg-[#FAF7F2] text-[#4D080F] font-titan uppercase text-[10px] border-b border-[#E5DEC9]">
                      <tr>
                        <th className="p-3">Date & Ref</th>
                        <th className="p-3">Type</th>
                        <th className="p-3 text-center">Location</th>
                        <th className="p-3 text-right">Quantity Delta</th>
                        <th className="p-3 text-center">Balance</th>
                        <th className="p-3">Staff & Notes</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#E5DEC9]">
                      {itemLedgerHistory.map((tx) => (
                        <tr key={tx.id} className="hover:bg-[#FAF7F2]/60">
                          <td className="p-3">
                            <span className="font-mono text-[10px] font-bold text-gray-700 block">
                              {tx.referenceNo}
                            </span>
                            <span className="text-[10px] text-gray-400">
                              {new Date(tx.timestamp).toLocaleString('en-GB', {
                                dateStyle: 'short',
                                timeStyle: 'short',
                              })}
                            </span>
                          </td>
                          <td className="p-3">
                            <span
                              className={`px-2 py-0.5 rounded text-[9px] font-titan uppercase ${
                                tx.transactionType.includes('INCREASE') || tx.transactionType.includes('INTAKE') || tx.transactionType.includes('IN')
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : 'bg-red-100 text-red-800'
                              }`}
                            >
                              {tx.transactionType.replace(/_/g, ' ')}
                            </span>
                          </td>
                          <td className="p-3 text-center font-bold text-[#4D080F] uppercase text-[10px]">
                            {tx.locationId}
                          </td>
                          <td className="p-3 text-right font-titan">
                            <span
                              className={
                                tx.quantityDelta >= 0 ? 'text-emerald-700' : 'text-red-600'
                              }
                            >
                              {tx.quantityDelta >= 0 ? `+${tx.quantityDelta}` : tx.quantityDelta}{' '}
                              {tx.unit}
                            </span>
                          </td>
                          <td className="p-3 text-center text-gray-600 font-mono text-[11px]">
                            {tx.balanceBefore} → <strong>{tx.balanceAfter}</strong>
                          </td>
                          <td className="p-3 text-gray-600">
                            <span className="block font-bold text-[#241311]">
                              {tx.performedByName || 'System'}
                            </span>
                            <span className="text-[10px] text-gray-400 block">{tx.notes}</span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              <div className="flex justify-end pt-2">
                <button
                  type="button"
                  onClick={() => setViewLedgerItem(null)}
                  className="px-5 py-2 bg-[#4D080F] text-[#FFC700] font-titan rounded-xl text-xs uppercase"
                >
                  Close History
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==========================================
          MODAL 4: SAFE DELETE / RETIRE CONFIRMATION
          ========================================== */}
      {deleteItemTarget && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-60 flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl border border-[#E5DEC9] w-full max-w-lg overflow-hidden shadow-2xl">
            <div className="p-4 sm:p-5 bg-[#4D080F] text-white flex items-center justify-between">
              <div>
                <span className="text-[10px] text-[#FFC700] font-titan uppercase tracking-wider block">
                  SAFE DATA RETENTION & AUDIT
                </span>
                <h3 className="font-titan text-lg sm:text-xl text-[#FFC700]">
                  Retire or Delete Stock Item
                </h3>
              </div>
              <button
                onClick={() => {
                  setDeleteItemTarget(null);
                  setDeleteAuditInfo(null);
                }}
                className="text-gray-300 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs font-montserrat">
              <div className="p-3.5 bg-[#FAF7F2] rounded-2xl border border-[#E5DEC9]">
                <strong className="block text-sm text-[#241311] font-bold">
                  {deleteItemTarget.name}
                </strong>
                <span className="text-[11px] text-gray-500 font-mono">
                  SKU: {deleteItemTarget.sku} | Category: {deleteItemTarget.category}
                </span>
              </div>

              {deleteAuditInfo === null ? (
                <div className="py-6 text-center text-gray-500 flex items-center justify-center gap-2">
                  <RefreshCw className="w-4 h-4 animate-spin text-[#4D080F]" />
                  Checking database references & active stock balances...
                </div>
              ) : deleteAuditInfo.canHardDelete ? (
                <div className="space-y-3">
                  <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-900">
                    <strong className="block font-bold">Unreferenced Draft Item Detected</strong>
                    <p className="text-[11px] text-emerald-800 mt-1">
                      This item has zero stock on hand and zero historical transactions across the ledger, recipes, purchase orders, goods receipts, and wastage logs.
                    </p>
                  </div>
                  <p className="text-gray-600">
                    Confirming will <strong>permanently delete</strong> this draft item from the inventory catalogue.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-amber-900">
                    <strong className="block font-bold">Protected Operational Record — Safe Retirement</strong>
                    <p className="text-[11px] text-amber-800 mt-1">
                      This item cannot be hard-deleted because it maintains operational integrity with active references:
                    </p>
                    <ul className="list-disc pl-5 mt-1.5 space-y-0.5 text-[11px]">
                      {deleteAuditInfo.hasPositiveStock && (
                        <li>Active Stock on Hand: {deleteAuditInfo.totalStockOnHand} {deleteItemTarget.unit}</li>
                      )}
                      {deleteAuditInfo.counts.ledger > 0 && (
                        <li>{deleteAuditInfo.counts.ledger} Stock Ledger Movements</li>
                      )}
                      {deleteAuditInfo.counts.recipes > 0 && (
                        <li>{deleteAuditInfo.counts.recipes} Recipe BOM Formulations</li>
                      )}
                      {deleteAuditInfo.counts.purchaseOrders > 0 && (
                        <li>{deleteAuditInfo.counts.purchaseOrders} Purchase Orders</li>
                      )}
                      {deleteAuditInfo.counts.goodsReceiptNotes > 0 && (
                        <li>{deleteAuditInfo.counts.goodsReceiptNotes} Goods Receipt Notes (GRN)</li>
                      )}
                      {deleteAuditInfo.counts.wastage > 0 && (
                        <li>{deleteAuditInfo.counts.wastage} Wastage Incidents</li>
                      )}
                    </ul>
                  </div>
                  <p className="text-gray-600">
                    Confirming will safely <strong>retire and archive</strong> this item (<code>isActive: false, isArchived: true</code>), preserving all historical financials while removing it from active ordering.
                  </p>
                </div>
              )}

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-[#E5DEC9]">
                <button
                  type="button"
                  onClick={() => {
                    setDeleteItemTarget(null);
                    setDeleteAuditInfo(null);
                  }}
                  className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold rounded-xl"
                >
                  Cancel
                </button>

                <button
                  type="button"
                  id="btn-confirm-delete-item"
                  disabled={isDeleting || deleteAuditInfo === null}
                  onClick={handleConfirmDelete}
                  className={`px-5 py-2.5 text-white font-titan uppercase rounded-xl shadow-xs transition-colors ${
                    deleteAuditInfo?.canHardDelete
                      ? 'bg-red-600 hover:bg-red-700'
                      : 'bg-[#4D080F] hover:bg-[#38050A] text-[#FFC700]'
                  }`}
                >
                  {isDeleting
                    ? 'Processing...'
                    : deleteAuditInfo?.canHardDelete
                    ? 'Permanently Delete Draft'
                    : 'Safely Retire & Archive'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
