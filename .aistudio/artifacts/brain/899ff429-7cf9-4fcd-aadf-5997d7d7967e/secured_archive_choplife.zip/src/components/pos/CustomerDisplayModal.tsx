import React from 'react';
import { ShoppingBag, CheckCircle2, Clock, ShieldCheck, Sparkles, X, Monitor } from 'lucide-react';
import { CartItem } from '../../types';

interface CustomerDisplayModalProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  subtotal: number;
  packagingFee: number;
  discount: number;
  total: number;
  branchName: string;
  cashierName?: string;
  paymentStatus?: 'unpaid' | 'paid' | 'pending';
  lastCompletedOrderNumber?: string;
}

export const CustomerDisplayModal: React.FC<CustomerDisplayModalProps> = ({
  isOpen,
  onClose,
  cart,
  subtotal,
  packagingFee,
  discount,
  total,
  branchName,
  cashierName,
  paymentStatus = 'unpaid',
  lastCompletedOrderNumber,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200">
      <div className="bg-[#FAF7F2] rounded-3xl w-full max-w-4xl shadow-2xl border-4 border-[#FFC700] overflow-hidden flex flex-col max-h-[90vh]">
        {/* Top Header Banner */}
        <div className="bg-[#241311] text-white p-5 sm:p-6 flex items-center justify-between border-b-2 border-[#FFC700]">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-[#FFC700] text-[#241311] flex items-center justify-center shadow-lg">
              <Monitor className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-titan uppercase tracking-widest text-[#FFC700] bg-white/10 px-2.5 py-0.5 rounded-full">
                  CUSTOMER DISPLAY MODE
                </span>
                <span className="text-[10px] font-montserrat font-bold text-emerald-400 flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span> LIVE SYNC
                </span>
              </div>
              <h2 className="font-titan text-xl sm:text-2xl text-white tracking-wide">
                CHOPLIFE REPUBLIC — {branchName.toUpperCase()}
              </h2>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
            title="Close Customer Display"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Main Content Grid */}
        <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden">
          {/* Left: Cart Items & Modifiers */}
          <div className="lg:col-span-7 p-6 overflow-y-auto space-y-4 border-r border-[#E5DEC9]">
            <div className="flex items-center justify-between pb-2 border-b border-[#E5DEC9]">
              <h3 className="font-titan text-sm text-[#4D080F] uppercase tracking-wider flex items-center gap-2">
                <ShoppingBag className="w-4 h-4 text-[#E62E00]" /> CURRENT ORDER ITEMS ({cart.reduce((sum, i) => sum + i.quantity, 0)})
              </h3>
              {cashierName && (
                <span className="text-xs font-montserrat font-semibold text-[#7A6A65]">
                  Served by: <strong className="text-[#241311]">{cashierName}</strong>
                </span>
              )}
            </div>

            {cart.length === 0 ? (
              <div className="py-16 text-center space-y-3">
                <div className="w-16 h-16 rounded-full bg-[#E5DEC9]/40 flex items-center justify-center mx-auto text-[#7A6A65]">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <h4 className="font-titan text-base text-[#4D080F]">Waiting for order items...</h4>
                <p className="text-xs font-montserrat text-[#7A6A65] max-w-xs mx-auto">
                  Items added by the cashier at the POS terminal will appear here instantly in real time.
                </p>
                {lastCompletedOrderNumber && (
                  <div className="mt-4 p-3 bg-emerald-50 border border-emerald-200 rounded-2xl inline-block text-xs font-montserrat text-emerald-800">
                    <CheckCircle2 className="w-4 h-4 inline mr-1.5 text-emerald-600" />
                    Last Order <strong>#{lastCompletedOrderNumber}</strong> completed successfully! Thank you!
                  </div>
                )}
              </div>
            ) : (
              <div className="space-y-3">
                {cart.map((item) => (
                  <div
                    key={item.id}
                    className="p-4 bg-white rounded-2xl border border-[#E5DEC9] shadow-xs flex items-center justify-between gap-4 transition-all"
                  >
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="w-7 h-7 rounded-lg bg-[#FFC700]/20 text-[#4D080F] font-titan text-xs flex items-center justify-center shrink-0">
                          {item.quantity}x
                        </span>
                        <h4 className="font-titan text-sm text-[#241311] truncate">{item.product?.name || 'Item'}</h4>
                      </div>
                      {item.customization && item.customization.specialInstructions && (
                        <div className="text-[11px] font-montserrat text-[#7A6A65] mt-1 pl-9">
                          • Note: {item.customization.specialInstructions}
                        </div>
                      )}
                    </div>
                    <div className="text-right shrink-0">
                      <div className="font-titan text-sm sm:text-base text-[#4D080F]">
                        ₦{(item.unitPrice * item.quantity).toLocaleString()}
                      </div>
                      <div className="text-[10px] font-montserrat text-[#7A6A65]">
                        ₦{item.unitPrice.toLocaleString()} each
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Right: Summary & Payment Status */}
          <div className="lg:col-span-5 bg-white p-6 flex flex-col justify-between border-t lg:border-t-0 border-[#E5DEC9]">
            <div className="space-y-4">
              <h3 className="font-titan text-sm text-[#4D080F] uppercase tracking-wider border-b border-[#E5DEC9] pb-2">
                TRANSACTION SUMMARY
              </h3>

              <div className="space-y-2.5 font-montserrat text-xs sm:text-sm text-[#7A6A65]">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <strong className="text-[#241311] font-bold">₦{subtotal.toLocaleString()}</strong>
                </div>
                {packagingFee > 0 && (
                  <div className="flex justify-between">
                    <span>Packaging & Containers</span>
                    <strong className="text-[#241311] font-bold">₦{packagingFee.toLocaleString()}</strong>
                  </div>
                )}
                {discount > 0 && (
                  <div className="flex justify-between text-emerald-600 font-semibold">
                    <span>Approved Discount</span>
                    <span>-₦{discount.toLocaleString()}</span>
                  </div>
                )}
              </div>

              {/* Grand Total Highlight Box */}
              <div className="bg-[#241311] text-white p-5 rounded-2xl shadow-md space-y-1">
                <span className="text-[10px] font-titan uppercase tracking-widest text-[#FFC700] block">
                  TOTAL AMOUNT PAYABLE
                </span>
                <div className="font-titan text-2xl sm:text-3xl text-[#FFC700]">
                  ₦{total.toLocaleString()}
                </div>
              </div>

              {/* Payment Status Indicator */}
              <div className="pt-2">
                {paymentStatus === 'paid' ? (
                  <div className="bg-emerald-50 border-2 border-emerald-300 text-emerald-900 p-4 rounded-2xl text-center space-y-1 animate-in zoom-in-95 duration-200">
                    <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto" />
                    <div className="font-titan text-base text-emerald-800">PAYMENT SUCCESSFUL</div>
                    <p className="text-xs font-montserrat text-emerald-700">Thank you for dining with Choplife Republic!</p>
                  </div>
                ) : paymentStatus === 'pending' ? (
                  <div className="bg-amber-50 border-2 border-amber-300 text-amber-900 p-4 rounded-2xl text-center space-y-1 animate-pulse">
                    <Clock className="w-8 h-8 text-amber-600 mx-auto animate-spin" />
                    <div className="font-titan text-base text-amber-800">AWAITING PAYMENT</div>
                    <p className="text-xs font-montserrat text-amber-700">Please present card or cash to cashier terminal.</p>
                  </div>
                ) : (
                  <div className="bg-[#FAF7F2] border border-[#E5DEC9] text-[#7A6A65] p-4 rounded-2xl text-center space-y-1">
                    <ShieldCheck className="w-6 h-6 text-[#4D080F] mx-auto" />
                    <div className="font-titan text-xs text-[#4D080F]">READY FOR SETTLEMENT</div>
                    <p className="text-[11px] font-montserrat">Review items on the left before payment confirmation.</p>
                  </div>
                )}
              </div>
            </div>

            {/* Footer Brand Tagline */}
            <div className="pt-4 border-t border-[#E5DEC9] text-center">
              <span className="text-[10px] font-titan uppercase tracking-widest text-[#7A6A65] flex items-center justify-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-[#FFC700]" /> AUTHENTIC NIGERIAN HOSPITALITY & FLAVOR
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
