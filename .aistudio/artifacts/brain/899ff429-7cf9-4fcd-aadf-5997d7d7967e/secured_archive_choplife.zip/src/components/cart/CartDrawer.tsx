import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Trash2,
  Plus,
  Minus,
  ShoppingBag,
  ArrowRight,
  Sparkles,
  MessageCircle,
  Tag,
  ShieldCheck,
  Truck,
  Store,
  ChevronRight,
  Info,
  RotateCcw,
} from 'lucide-react';

export const CartDrawer: React.FC = () => {
  const {
    isCartOpen,
    setIsCartOpen,
    cart,
    removeFromCart,
    updateCartQuantity,
    clearCart,
    cartCount,
    cartSubtotal,
    cartPackagingFee,
    deliveryFee,
    cartDiscount,
    cartTotal,
    amountAwayFromFreeDelivery,
    appliedCoupon,
    applyCoupon,
    removeCoupon,
    orderType,
    setOrderType,
    currentBranch,
    selectedBranchId,
    formatNaira,
    setIsCheckoutOpen,
    generateWhatsAppCartText,
    getBranchWhatsAppUrl,
    products,
    addToCart,
    orders,
    setIsAccountModalOpen,
  } = useApp();

  const [couponInput, setCouponInput] = useState('');
  const [couponFeedback, setCouponFeedback] = useState<{ success?: boolean; message?: string } | null>(null);

  if (!isCartOpen) return null;

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponInput) return;
    const res = applyCoupon(couponInput);
    setCouponFeedback(res);
    if (res.success) {
      setCouponInput('');
    }
  };

  const handleProceedToCheckout = () => {
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  // Upsell suggestions (e.g. Zobo, Chicken Pie, Parfait)
  const upsellItems = products
    .filter((p) => (p.id === 'prod-drink-zobo-1000' || p.id === 'prod-snack-chicken-pie' || p.id === 'prod-drink-parfait-sm') && !cart.some((c) => c.productId === p.id))
    .slice(0, 2);

  return (
    <div
      className="fixed inset-0 z-50 overflow-hidden bg-black/60 backdrop-blur-xs flex justify-end animate-in fade-in duration-200"
      id="cart-drawer-overlay"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          setIsCartOpen(false);
        }
      }}
    >
      <div className="bg-white w-full max-w-md h-full shadow-2xl flex flex-col justify-between overflow-hidden border-l border-[#E5DEC9] animate-in slide-in-from-right duration-250" id="cart-drawer">
        
        {/* Cart Header */}
        <div className="p-4 sm:p-5 bg-[#4D080F] text-white flex items-center justify-between shrink-0 shadow-md z-20">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#FFC700] text-[#4D080F] flex items-center justify-center font-titan text-xl">
              🛒
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-titan text-lg sm:text-xl text-white">
                  YOUR ORDER CART
                </h2>
                <span className="bg-[#E62E00] text-[#FFC700] font-titan text-[10px] px-2 py-0.5 rounded-full">
                  {cartCount} {cartCount === 1 ? 'item' : 'items'}
                </span>
              </div>
              <p className="text-[11px] text-white/70 font-montserrat">
                Branch: <span className="font-bold text-[#FFC700]">{currentBranch.shortName}</span>
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsCartOpen(false)}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
            id="close-cart-btn"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Standard Delivery Notice */}
        {cart.length > 0 && orderType === 'delivery' && (
          <div className="bg-[#FFF8E7] px-4 py-2.5 border-b border-[#FFC700]/40 flex items-center justify-between text-xs font-montserrat font-bold text-[#4D080F]">
            <span className="flex items-center gap-1.5">
              <Truck className="w-3.5 h-3.5 text-[#E62E00]" />
              Standard Delivery Time: <span className="text-[#E62E00] font-titan">30–90 MINS</span>
            </span>
            <span className="text-[10px] text-[#7A6A65] font-normal">All Benin Locations</span>
          </div>
        )}

        {/* Cart Content */}
        <div className="p-4 sm:p-5 space-y-5 flex-1 overflow-y-auto">
          
          {/* Order Type Toggle in Cart */}
          <div className="grid grid-cols-2 gap-2 bg-[#FAF7F2] p-1 rounded-2xl border border-[#E5DEC9]">
            <button
              onClick={() => setOrderType('delivery')}
              className={`py-2 rounded-xl text-xs font-montserrat font-bold flex items-center justify-center gap-1.5 transition-all ${
                orderType === 'delivery'
                  ? 'bg-[#E62E00] text-white shadow-xs'
                  : 'text-[#5C4D49] hover:text-black'
              }`}
              id="cart-delivery-btn"
            >
              <Truck className="w-3.5 h-3.5" />
              Delivery ({formatNaira(deliveryFee)})
            </button>
            <button
              onClick={() => setOrderType('pickup')}
              className={`py-2 rounded-xl text-xs font-montserrat font-bold flex items-center justify-center gap-1.5 transition-all ${
                orderType === 'pickup'
                  ? 'bg-[#E62E00] text-white shadow-xs'
                  : 'text-[#5C4D49] hover:text-black'
              }`}
              id="cart-pickup-btn"
            >
              <Store className="w-3.5 h-3.5" />
              Pickup (Free)
            </button>
          </div>

          {/* Empty Cart State */}
          {cart.length === 0 ? (
            <div className="text-center py-16 space-y-4">
              <div className="w-20 h-20 rounded-full bg-[#FAF7F2] border border-[#E5DEC9] flex items-center justify-center font-titan text-3xl mx-auto text-[#4D080F]">
                🥘
              </div>
              <h3 className="font-titan text-xl text-[#4D080F]">Your cart is empty!</h3>
              <p className="text-xs text-[#7A6A65] font-montserrat max-w-xs mx-auto">
                Explore our famous small chops, double shawarmas, firewood party jollof, and flame grills.
              </p>
              <div className="flex flex-col gap-2 max-w-xs mx-auto pt-2">
                <button
                  onClick={() => {
                    setIsCartOpen(false);
                    const el = document.getElementById('menu-explorer-section');
                    if (el) el.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="w-full bg-[#E62E00] hover:bg-[#C92200] text-white font-titan text-xs px-6 py-3 rounded-xl shadow-md transition-all active:scale-95"
                >
                  BROWSE MENU NOW
                </button>

                {orders.length > 0 && (
                  <button
                    onClick={() => {
                      setIsCartOpen(false);
                      setIsAccountModalOpen(true);
                    }}
                    className="w-full bg-[#FFF8E7] hover:bg-[#FFEEC2] text-[#4D080F] border border-[#FFC700] font-montserrat font-bold text-xs px-4 py-2.5 rounded-xl shadow-2xs flex items-center justify-center gap-1.5 transition-all active:scale-95"
                    id="cart-empty-reorder-history-btn"
                  >
                    <RotateCcw className="w-3.5 h-3.5 text-[#E62E00]" />
                    <span>Reorder from Past Orders ({orders.length})</span>
                  </button>
                )}
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              {cart.map((item) => (
                <div
                  key={item.id}
                  className="bg-[#FAF7F2] rounded-2xl p-3.5 border border-[#E5DEC9] space-y-2 relative"
                  id={`cart-item-${item.id}`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <img
                      src={item.product.image}
                      alt={item.product.name}
                      className="w-14 h-14 rounded-xl object-cover shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <h4 className="font-titan text-xs sm:text-sm text-[#241311] leading-snug">
                        {item.product.name}
                      </h4>
                      <p className="font-titan text-xs text-[#E62E00] mt-0.5">
                        {formatNaira(item.unitPrice)} each
                      </p>

                      {/* Customization Badges */}
                      {item.customization?.selectedOptions && item.customization.selectedOptions.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-1">
                          {item.customization.selectedOptions.map((opt, i) => (
                            <span key={i} className="text-[9px] bg-white px-1.5 py-0.5 rounded text-[#5C4D49] border border-[#E5DEC9]">
                              {opt.choiceName}
                            </span>
                          ))}
                        </div>
                      )}

                      {item.customization?.selectedAddOns && item.customization.selectedAddOns.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-0.5">
                          {item.customization.selectedAddOns.map((add, i) => (
                            <span key={i} className="text-[9px] bg-[#FFF8E7] px-1.5 py-0.5 rounded text-[#4D080F] border border-[#FFC700]/50 font-bold">
                              +{add.name}
                            </span>
                          ))}
                        </div>
                      )}

                      {item.customization?.specialInstructions && (
                        <p className="text-[10px] text-[#7A6A65] italic mt-1 line-clamp-1">
                          Note: {item.customization.specialInstructions}
                        </p>
                      )}
                    </div>

                    <button
                      onClick={() => removeFromCart(item.id)}
                      className="text-[#7A6A65] hover:text-[#E62E00] p-1 transition-colors"
                      title="Remove item"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Quantity & Item Subtotal */}
                  <div className="flex items-center justify-between pt-2 border-t border-[#E5DEC9]/60">
                    <div className="flex items-center gap-2 bg-white px-2 py-1 rounded-xl border border-[#E5DEC9]">
                      <button
                        onClick={() => updateCartQuantity(item.id, item.quantity - 1)}
                        className="w-5 h-5 rounded bg-[#FAF7F2] hover:bg-[#E5DEC9] flex items-center justify-center text-xs font-bold text-[#4D080F]"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="font-titan text-xs w-4 text-center text-[#241311]">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => updateCartQuantity(item.id, item.quantity + 1)}
                        className="w-5 h-5 rounded bg-[#E62E00] hover:bg-[#C92200] flex items-center justify-center text-xs font-bold text-white"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>

                    <span className="font-titan text-sm text-[#4D080F]">
                      {formatNaira(item.unitPrice * item.quantity)}
                    </span>
                  </div>
                </div>
              ))}

              <div className="flex justify-end pt-1">
                <button
                  onClick={clearCart}
                  className="text-[11px] font-montserrat font-bold text-rose-700 hover:underline"
                >
                  Clear entire cart
                </button>
              </div>
            </div>
          )}

          {/* Upsells Strip in Cart */}
          {cart.length > 0 && upsellItems.length > 0 && (
            <div className="bg-[#FAF7F2] p-3.5 rounded-2xl border border-[#E5DEC9] space-y-2">
              <div className="flex items-center gap-1.5 text-[11px] font-titan text-[#4D080F] uppercase tracking-wider">
                <Sparkles className="w-3.5 h-3.5 text-[#E62E00]" />
                COMPLETE YOUR ORDER (FREQUENTLY ADDED)
              </div>
              <div className="grid grid-cols-2 gap-2">
                {upsellItems.map((up) => (
                  <div key={up.id} className="bg-white p-2 rounded-xl border border-[#E5DEC9] flex items-center gap-2">
                    <img src={up.image} alt={up.name} className="w-10 h-10 rounded-lg object-cover" />
                    <div className="flex-1 min-w-0">
                      <p className="text-[10px] font-titan truncate text-[#241311]">{up.name}</p>
                      <p className="text-[10px] font-bold text-[#E62E00]">{formatNaira(up.basePrice)}</p>
                      <button
                        onClick={() => addToCart(up, 1)}
                        className="text-[9px] font-titan bg-[#E62E00] text-white px-2 py-0.5 rounded-md hover:bg-[#C92200] mt-0.5"
                      >
                        + Add
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Coupon Code Box - Coming Soon */}
          {cart.length > 0 && (
            <div className="bg-[#FAF7F2] p-3.5 rounded-2xl border border-[#E5DEC9] space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-montserrat font-bold text-[#4D080F] flex items-center gap-1.5">
                  <Tag className="w-3.5 h-3.5 text-[#E62E00]" /> Promo Codes & Discounts
                </span>
                <span className="text-[10px] font-titan uppercase bg-[#E5DEC9]/50 text-[#7A6A65] px-2 py-0.5 rounded-md">
                  COMING SOON
                </span>
              </div>
              <p className="text-[11px] font-montserrat text-[#7A6A65]">
                Discount codes and special promotional vouchers will be available soon.
              </p>
            </div>
          )}

        </div>

        {/* Cart Footer & Checkout Action */}
        {cart.length > 0 && (
          <div className="bg-[#FAF7F2] p-4 sm:p-5 pb-6 sm:pb-6 rounded-t-3xl border-t border-[#E5DEC9] shadow-2xl space-y-3 shrink-0 z-20">
            
            {/* Calculation Breakdown */}
            <div className="space-y-1.5 text-xs font-montserrat text-[#5C4D49]">
              <div className="flex items-center justify-between">
                <span>Subtotal ({cartCount} items)</span>
                <span className="font-bold text-[#241311]">{formatNaira(cartSubtotal)}</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Packaging & Thermal Box</span>
                <span className="font-bold text-[#241311]">{formatNaira(cartPackagingFee)}</span>
              </div>
              {orderType === 'delivery' && (
                <div className="flex items-center justify-between">
                  <span>Estimated Delivery Fee</span>
                  <span className={`font-bold ${deliveryFee === 0 ? 'text-emerald-700 font-titan' : 'text-[#241311]'}`}>
                    {deliveryFee === 0 ? 'FREE' : formatNaira(deliveryFee)}
                  </span>
                </div>
              )}
              {cartDiscount > 0 && (
                <div className="flex items-center justify-between text-emerald-700 font-bold">
                  <span>Promo Discount</span>
                  <span>-{formatNaira(cartDiscount)}</span>
                </div>
              )}
              <div className="flex items-center justify-between pt-2 border-t border-[#E5DEC9] text-sm font-titan text-[#4D080F]">
                <span>TOTAL AMOUNT</span>
                <span className="text-xl text-[#E62E00]">{formatNaira(cartTotal)}</span>
              </div>
            </div>

            {/* Primary Action Button: Proceed to Checkout */}
            <button
              onClick={handleProceedToCheckout}
              className="w-full bg-[#E62E00] hover:bg-[#C92200] text-white font-titan text-sm sm:text-base py-4 px-6 rounded-2xl shadow-xl transition-all transform active:scale-95 flex items-center justify-between group"
              id="proceed-to-checkout-btn"
            >
              <span className="flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-[#FFC700]" />
                <span>CHECKOUT NOW</span>
              </span>
              <span className="flex items-center gap-1 text-[#FFC700]">
                <span>{formatNaira(cartTotal)}</span>
                <ChevronRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </span>
            </button>

            {/* Secondary WhatsApp Fallback Ordering Button */}
            <a
              href={getBranchWhatsAppUrl(selectedBranchId, generateWhatsAppCartText())}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full bg-[#25D366]/15 hover:bg-[#25D366]/25 text-[#006a33] border border-[#25D366]/50 font-montserrat font-bold text-xs py-2.5 px-4 rounded-xl transition-colors flex items-center justify-center gap-2"
              id="cart-order-via-whatsapp-btn"
            >
              <MessageCircle className="w-4 h-4 text-[#25D366] fill-[#25D366]" />
              <span>Or Order via WhatsApp ({currentBranch.shortName})</span>
            </a>

          </div>
        )}

      </div>
    </div>
  );
};
