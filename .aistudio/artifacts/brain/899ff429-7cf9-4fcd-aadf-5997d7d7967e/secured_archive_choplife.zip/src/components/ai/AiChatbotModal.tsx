import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { Product } from '../../types';
import {
  X,
  Send,
  ShoppingBag,
  Plus,
  Tag,
  Wheat,
  Clock,
  MapPin,
  CheckCircle2,
  ExternalLink,
  Box,
  Utensils,
  Flame,
  ArrowRight,
  MessageCircle,
} from 'lucide-react';

interface ChatMessage {
  id: string;
  sender: 'bot' | 'user';
  text: string;
  timestamp: string;
  recommendedProducts?: Product[];
  suggestedAction?: {
    type: 'open_cart' | 'open_builder' | 'open_catering' | 'open_locations' | 'view_category' | 'whatsapp';
    label: string;
    payload?: string;
  };
}

export const AiChatbotModal: React.FC = () => {
  const {
    isAiChatbotOpen,
    setIsAiChatbotOpen,
    products,
    branches,
    selectedBranchId,
    currentBranch,
    addToCart,
    setIsCartOpen,
    setIsCateringModalOpen,
    setIsLocationsModalOpen,
    setIsSmallChopsBuilderOpen,
    getBranchWhatsAppUrl,
    setActiveCategory,
    getProductPrice,
    formatNaira,
  } = useApp();

  const [inputMessage, setInputMessage] = useState('');
  const [addedProductIds, setAddedProductIds] = useState<Record<string, boolean>>({});
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome-1',
      sender: 'bot',
      text: `👋 Hello! I am **Chop Paddy**, your food and ordering assistant at **${currentBranch.name}**.\n\nI can help you find approved menu items, build custom small chops boxes, locate fresh 100% bromate-free bread, or check branch hours and delivery details. How can I help you today?`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isAiChatbotOpen) {
      scrollToBottom();
    }
  }, [messages, isAiChatbotOpen]);

  if (!isAiChatbotOpen) {
    return (
      <button
        onClick={() => setIsAiChatbotOpen(true)}
        className="fixed bottom-20 md:bottom-6 right-4 sm:right-6 z-40 bg-[#4D080F] hover:bg-[#38050a] text-white p-3.5 sm:px-4 sm:py-3 rounded-full shadow-2xl border-2 border-[#FFC700] flex items-center gap-2.5 transition-all hover:scale-105 active:scale-95 group"
        id="open-chop-paddy-btn"
        title="Chat with Chop Paddy"
      >
        <div className="relative">
          <div className="w-8 h-8 rounded-full bg-[#E62E00] flex items-center justify-center text-lg">
            🧑🏽‍🍳
          </div>
          <span className="absolute -top-1 -right-1 w-3 h-3 bg-[#FFC700] rounded-full border-2 border-[#4D080F] animate-ping" />
          <span className="absolute -top-1 -right-1 w-3 h-3 bg-[#FFC700] rounded-full border-2 border-[#4D080F]" />
        </div>
        <div className="hidden sm:block text-left">
          <p className="text-[11px] font-titan uppercase tracking-wide text-[#FFC700] leading-none">
            Chop Paddy
          </p>
          <p className="text-[10px] text-white/90 font-montserrat leading-tight">
            Ask questions & order
          </p>
        </div>
      </button>
    );
  }

  const findProduct = (id: string): Product | undefined => {
    return products.find((p) => p.id === id);
  };

  const generateBotReply = (userPrompt: string) => {
    setIsTyping(true);

    setTimeout(() => {
      const lower = userPrompt.toLowerCase();
      let replyText = '';
      let recommended: Product[] = [];
      let action: ChatMessage['suggestedAction'] = undefined;

      // 1. Bakery / Bread Queries
      if (lower.includes('bread') || lower.includes('bakery') || lower.includes('bromate') || lower.includes('loaf') || lower.includes('jumbo') || lower.includes('wholesale')) {
        replyText = `🍞 **Choplife Bakery** produces 100% bromate-free and saccharine-free bread baked fresh daily with whole eggs and full cream milk.\n\nFresh daily retail prices:\n• Small Bread (350g): ₦500\n• Special Bread (600g): ₦1,200\n• Family Bread (800g): ₦1,700\n• Jumbo Bread (1.2kg): ₦2,000\n\nWholesale crates are also available for commercial retailers and schools.`;
        
        const b1 = findProduct('prod-bakery-special-350g');
        const b2 = findProduct('prod-bakery-special-600g');
        const b3 = findProduct('prod-bakery-family-800g');
        recommended = [b1, b2, b3].filter(Boolean) as Product[];
        
        action = {
          type: 'view_category',
          label: 'View Full Bakery Catalogue 🥖',
          payload: 'bakery',
        };
      }
      // 2. Party & Large Group Feasts
      else if (lower.includes('party') || lower.includes('group') || lower.includes('people') || lower.includes('feed') || lower.includes('crowd') || lower.includes('guests') || lower.includes('30k') || lower.includes('50k') || lower.includes('100k')) {
        replyText = `🎉 For group orders and gatherings, we offer structured party platters and bulk packages:\n\n• **Regular Pack (₦21,000)**: Serves 2–4 guests\n• **Bronze Pack (₦49,500)**: Serves 6–10 guests\n• **Prince Order (₦73,000)**: Serves 12–18 guests\n• **King Order (₦111,000)**: Large celebrations\n\nYou can also request custom catering quotes for events and conferences.`;
        
        const sc1 = findProduct('prod-sc-regular-21000');
        const sc2 = findProduct('prod-sc-bronze-49500');
        const sc3 = findProduct('prod-sc-prince-order');
        recommended = [sc1, sc2, sc3].filter(Boolean) as Product[];
        
        action = {
          type: 'open_catering',
          label: 'Open Catering & Bulk Order Request 📋',
        };
      }
      // 3. Small Chops Specific / Mini Packs
      else if (lower.includes('small chop') || lower.includes('samosa') || lower.includes('spring roll') || lower.includes('puff puff') || lower.includes('mini pack') || lower.includes('munch') || lower.includes('platter')) {
        replyText = `🥟 Our Small Chops are prepared fresh with crispy spring rolls, spiced samosas, fluffy puff puff, and peppered proteins.\n\nPopular menu packages include:\n• 2000 Mini Pack (₦2,000)\n• 2500 Mini Pack (₦2,500)\n• 3700 Mini Pack (₦3,700)\n• 4200 Mini Pack (₦4,200)\n• 5500 Munch (₦5,500)\n• Regular Pack (₦21,000)`;
        
        const sc1 = findProduct('prod-sc-2000-mini');
        const sc2 = findProduct('prod-sc-2500-mini');
        const sc3 = findProduct('prod-sc-5500-munch');
        const sc4 = findProduct('prod-sc-regular-21000');
        recommended = [sc1, sc2, sc3, sc4].filter(Boolean) as Product[];
        
        action = {
          type: 'open_builder',
          label: 'Launch Custom Box Builder 🥟',
        };
      }
      // 4. Rice & Main Meals / QSR / Soups
      else if (lower.includes('rice') || lower.includes('jollof') || lower.includes('fried rice') || lower.includes('native') || lower.includes('banga') || lower.includes('black soup') || lower.includes('swallow') || lower.includes('soup') || lower.includes('yam') || lower.includes('food')) {
        replyText = `🍲 Our Kitchen serves authentic rice dishes and local Edo delicacies:\n\n• Jollof Rice (₦1,000 / portion)\n• Fried Rice (₦1,200 / portion)\n• Pepper Rice (₦1,200 / portion)\n• Banga Soup (₦1,800 / portion)\n• Black Soup (Omobe) (₦1,800 / portion)\n• Egusi Soup (₦1,500 / portion)\n• Boiled Yam (₦1,000 / portion)`;
        
        const r1 = findProduct('prod-qsr-jollof-rice');
        const r2 = findProduct('prod-qsr-banga-soup-portion');
        const r3 = findProduct('prod-qsr-black-soup-portion');
        recommended = [r1, r2, r3].filter(Boolean) as Product[];
        
        action = {
          type: 'view_category',
          label: 'View All Food & Soups 🍲',
          payload: 'food',
        };
      }
      // 5. Shawarma, Meat & Grills
      else if (lower.includes('shawarma') || lower.includes('wrap') || lower.includes('grill') || lower.includes('turkey') || lower.includes('croaker') || lower.includes('fish') || lower.includes('chicken') || lower.includes('beef') || lower.includes('suya') || lower.includes('pie')) {
        replyText = `🍗 Our Snacks and Grills selection includes fresh pastries, chicken shawarma, and seasoned meats:\n\n• Chicken Shawarma (Single/Double Sausage)\n• Chicken Pie (₦1,400)\n• Medium Turkey (₦4,000)\n• Whole Croaker Fish (₦9,000)\n• Fried Beef & Soup Beef (₦1,400)`;
        
        const s1 = findProduct('prod-snack-shawarma-chicken-sp') || findProduct('prod-snack-chicken-pie');
        const s2 = findProduct('prod-grill-med-turkey');
        const s3 = findProduct('prod-grill-croaker-fish');
        recommended = [s1, s2, s3].filter(Boolean) as Product[];
        
        action = {
          type: 'view_category',
          label: 'View Snacks & Grills 🌯',
          payload: 'snacks',
        };
      }
      // 6. Drinks & Refreshments
      else if (lower.includes('drink') || lower.includes('coke') || lower.includes('fanta') || lower.includes('sprite') || lower.includes('zobo') || lower.includes('tiger nut') || lower.includes('water') || lower.includes('malt') || lower.includes('parfait')) {
        replyText = `🥤 We serve cold soft drinks, juices, and natural refreshments:\n\n• Coke, Fanta, Sprite (50cl PET) – ₦600\n• Zobo Punch (50cl) – ₦1,000\n• Fresh Tiger Nut (50cl) – ₦1,500\n• Chivita 1L Juice – ₦2,200\n• Bottled Water – ₦300`;
        
        const d1 = findProduct('prod-drink-zobo-1000');
        const d2 = findProduct('prod-drink-tigernut');
        const d3 = findProduct('prod-drink-coke-bg');
        recommended = [d1, d2, d3].filter(Boolean) as Product[];
        
        action = {
          type: 'view_category',
          label: 'View Drinks Menu 🥤',
          payload: 'drinks',
        };
      }
      // 7. Discounts & Promo Codes
      else if (lower.includes('budget') || lower.includes('cheap') || lower.includes('affordable') || lower.includes('discount') || lower.includes('promo') || lower.includes('coupon') || lower.includes('code') || lower.includes('free delivery')) {
        replyText = `💰 **Promotional Policy Update**:\n\nPromotional discount codes and free delivery campaigns are currently **COMING SOON**. All items are sold at our approved transparent menu rates across all three branches.`;
        
        const d1 = findProduct('prod-sc-2000-mini');
        const d2 = findProduct('prod-bakery-special-350g');
        recommended = [d1, d2].filter(Boolean) as Product[];
        
        action = {
          type: 'view_category',
          label: 'Browse Menu 🥟',
          payload: 'small-chops',
        };
      }
      // 8. Branch Locations & Hours
      else if (lower.includes('location') || lower.includes('branch') || lower.includes('where') || lower.includes('address') || lower.includes('time') || lower.includes('hours') || lower.includes('open') || lower.includes('close') || lower.includes('delivery time')) {
        const branchListText = branches
          .map(
            (b, idx) =>
              `${idx + 1}. **${b.name}**\n• Address: ${b.address}\n• Operating Hours: ${b.openingHours}\n• Delivery Hours: ${b.deliveryHours}`
          )
          .join('\n\n');
        replyText = `📍 **Choplife Republic Branches in Benin City**:\n\n${branchListText}\n\n⏱️ **Delivery Time**: 30–90 minutes standard for all locations.`;
        
        action = {
          type: 'open_locations',
          label: 'View Interactive Branch Map & Details 📍',
        };
      }
      // 9. Human WhatsApp / Phone Support
      else if (lower.includes('human') || lower.includes('whatsapp') || lower.includes('call') || lower.includes('manager') || lower.includes('phone') || lower.includes('contact')) {
        replyText = `📱 You can reach out directly to the management team at **${currentBranch.name}** for table space reservations, urgent delivery queries, or event consultations.`;
        action = {
          type: 'whatsapp',
          label: `Chat with ${currentBranch.shortName} on WhatsApp 💬`,
        };
      }
      // 10. Default General Response
      else {
        replyText = `Here are some popular approved choices from **${currentBranch.shortName}** available for immediate dispatch or collection:`;
        const p1 = findProduct('prod-sc-2500-mini') || products[0];
        const p2 = findProduct('prod-bakery-special-600g') || products[1];
        const p3 = findProduct('prod-qsr-jollof-rice') || products[2];
        recommended = [p1, p2, p3].filter(Boolean) as Product[];
      }

      setMessages((prev) => [
        ...prev,
        {
          id: `bot-${Date.now()}`,
          sender: 'bot',
          text: replyText,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          recommendedProducts: recommended.length > 0 ? recommended : undefined,
          suggestedAction: action,
        },
      ]);
      setIsTyping(false);
    }, 350);
  };

  const handleSendMessage = (textToSend?: string) => {
    const text = (textToSend || inputMessage).trim();
    if (!text) return;

    setMessages((prev) => [
      ...prev,
      {
        id: `user-${Date.now()}`,
        sender: 'user',
        text,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);

    setInputMessage('');
    generateBotReply(text);
  };

  const handleAddToCartFromChat = (product: Product) => {
    addToCart(product, 1);
    setAddedProductIds((prev) => ({ ...prev, [product.id]: true }));
    setTimeout(() => {
      setAddedProductIds((prev) => ({ ...prev, [product.id]: false }));
    }, 2000);
  };

  const handleViewProductInMenu = (category: string) => {
    setActiveCategory(category);
    setIsAiChatbotOpen(false);
    document.getElementById('menu-explorer-section')?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleActionClick = (action: NonNullable<ChatMessage['suggestedAction']>) => {
    if (action.type === 'open_cart') {
      setIsCartOpen(true);
    } else if (action.type === 'open_builder') {
      setIsSmallChopsBuilderOpen(true);
    } else if (action.type === 'open_catering') {
      setIsCateringModalOpen(true);
    } else if (action.type === 'open_locations') {
      setIsLocationsModalOpen(true);
    } else if (action.type === 'view_category' && action.payload) {
      handleViewProductInMenu(action.payload);
    } else if (action.type === 'whatsapp') {
      const url = getBranchWhatsAppUrl(
        selectedBranchId,
        'Hello Choplife Republic, I was chatting with Chop Paddy and need some assistance with my order!'
      );
      const a = document.createElement('a');
      a.href = url;
      a.target = '_blank';
      a.rel = 'noopener noreferrer';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-end sm:justify-end sm:p-6 animate-in fade-in duration-200"
      id="chop-paddy-window"
    >
      <div className="bg-[#FAF7F2] rounded-t-3xl sm:rounded-3xl w-full sm:w-[480px] h-[90vh] sm:h-[660px] shadow-2xl border-2 border-[#FFC700] flex flex-col justify-between overflow-hidden">
        
        {/* Chatbot Header */}
        <div className="bg-[#4D080F] text-white p-4 rounded-t-3xl flex items-center justify-between border-b-2 border-[#FFC700] shrink-0">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-10 h-10 rounded-2xl bg-[#E62E00] text-[#FFC700] flex items-center justify-center font-titan text-xl shadow-md">
                🧑🏽‍🍳
              </div>
              <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 rounded-full border-2 border-[#4D080F]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-titan text-sm text-white tracking-wide">
                  CHOP PADDY
                </h3>
                <span className="bg-[#FFC700] text-[#4D080F] text-[9px] font-titan uppercase px-2 py-0.5 rounded-full">
                  Live Assistant
                </span>
              </div>
              <p className="text-[11px] text-white/80 font-montserrat flex items-center gap-1">
                <MapPin className="w-3 h-3 text-[#FFC700]" />
                <strong>{currentBranch.shortName}</strong>
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsAiChatbotOpen(false)}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
            id="close-chop-paddy-btn"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Messages Scroll Area */}
        <div className="flex-1 p-4 overflow-y-auto space-y-4 font-montserrat text-xs sm:text-sm">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-[92%] rounded-2xl p-3.5 shadow-sm leading-relaxed ${
                  msg.sender === 'user'
                    ? 'bg-[#E62E00] text-white rounded-tr-none'
                    : 'bg-white text-stone-800 border border-stone-200 rounded-tl-none'
                }`}
              >
                <div className="space-y-1">
                  {msg.text.split('\n').map((line, lIdx) => {
                    const parts = line.split(/(\*\*[^*]+\*\*)/g);
                    return (
                      <p key={lIdx} className="min-h-[1rem]">
                        {parts.map((part, pIdx) => {
                          if (part.startsWith('**') && part.endsWith('**')) {
                            return (
                              <strong key={pIdx} className="font-bold text-[#4D080F]">
                                {part.slice(2, -2)}
                              </strong>
                            );
                          }
                          return part;
                        })}
                      </p>
                    );
                  })}
                </div>

                {/* Structured Recommended Products Cards with Action CTAs */}
                {msg.recommendedProducts && msg.recommendedProducts.length > 0 && (
                  <div className="mt-3 space-y-2 pt-2.5 border-t border-stone-200">
                    <p className="text-[10px] font-bold text-[#4D080F] uppercase tracking-wider font-montserrat">
                      Approved Menu Options:
                    </p>
                    <div className="grid grid-cols-1 gap-2">
                      {msg.recommendedProducts.map((p) => {
                        const price = getProductPrice(p, selectedBranchId);
                        const isAdded = !!addedProductIds[p.id];

                        return (
                          <div
                            key={p.id}
                            className="p-2.5 rounded-xl bg-[#FAF7F2] border border-[#E5DEC9] flex flex-col gap-2"
                          >
                            <div className="flex items-center gap-3">
                              <img
                                src={p.image}
                                alt={p.name}
                                className="w-12 h-12 rounded-lg object-cover shrink-0 border border-stone-200"
                                referrerPolicy="no-referrer"
                              />
                              <div className="flex-1 min-w-0">
                                <p className="font-bold text-xs text-[#241311] truncate">
                                  {p.name}
                                </p>
                                <p className="text-[11px] text-[#7A6A65] truncate font-montserrat">
                                  {p.subcategory || p.category}
                                </p>
                                <p className="text-xs text-[#E62E00] font-titan">
                                  {formatNaira(price)}
                                </p>
                              </div>
                            </div>

                            {/* Dual CTAs: ADD TO CART and VIEW IN MENU */}
                            <div className="flex items-center gap-2 pt-1 border-t border-stone-200/60">
                              <button
                                onClick={() => handleAddToCartFromChat(p)}
                                className={`flex-1 text-xs font-titan py-2 px-2.5 rounded-lg flex items-center justify-center gap-1.5 transition-all shadow-2xs active:scale-95 ${
                                  isAdded
                                    ? 'bg-emerald-600 text-white'
                                    : 'bg-[#E62E00] hover:bg-[#C92200] text-white'
                                }`}
                                id={`chat-add-btn-${p.id}`}
                              >
                                {isAdded ? (
                                  <>
                                    <CheckCircle2 className="w-3.5 h-3.5" /> Added!
                                  </>
                                ) : (
                                  <>
                                    <Plus className="w-3.5 h-3.5" /> Add to Cart ({formatNaira(price)})
                                  </>
                                )}
                              </button>

                              <button
                                onClick={() => handleViewProductInMenu(p.category)}
                                className="text-[11px] font-montserrat font-bold bg-white hover:bg-stone-100 text-[#4D080F] border border-stone-300 py-2 px-2.5 rounded-lg flex items-center gap-1 shrink-0"
                                title="View in menu"
                              >
                                <ArrowRight className="w-3 h-3 text-[#4D080F]" /> View
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Primary Action Button */}
                {msg.suggestedAction && (
                  <div className="mt-3 pt-2.5 border-t border-stone-200">
                    <button
                      onClick={() => handleActionClick(msg.suggestedAction!)}
                      className="w-full bg-[#FFC700] hover:bg-[#FFD733] text-[#4D080F] font-titan text-xs py-2.5 px-3 rounded-xl flex items-center justify-center gap-1.5 shadow-sm transition-transform active:scale-95"
                    >
                      {msg.suggestedAction.label}
                    </button>
                  </div>
                )}

                <span
                  className={`text-[9px] mt-2 block text-right font-montserrat ${
                    msg.sender === 'user' ? 'text-white/70' : 'text-stone-400'
                  }`}
                >
                  {msg.timestamp}
                </span>
              </div>
            </div>
          ))}

          {isTyping && (
            <div className="flex items-center gap-1.5 bg-white border border-stone-200 p-3 rounded-2xl rounded-tl-none w-20 shadow-xs">
              <span className="w-2 h-2 rounded-full bg-[#E62E00] animate-bounce" />
              <span className="w-2 h-2 rounded-full bg-[#E62E00] animate-bounce [animation-delay:0.2s]" />
              <span className="w-2 h-2 rounded-full bg-[#E62E00] animate-bounce [animation-delay:0.4s]" />
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Suggestion Chips - Fully responsive and non-clipped */}
        <div className="px-3 py-2 bg-stone-100/90 border-t border-stone-200 shrink-0">
          <p className="text-[10px] font-bold text-[#7A6A65] font-montserrat mb-1.5 uppercase tracking-wider">
            Quick Inquiries:
          </p>
          <div className="flex flex-wrap gap-1.5">
            <button
              onClick={() => handleSendMessage('Recommend the best Small Chops pack')}
              className="text-[11px] font-montserrat font-bold bg-white text-[#4D080F] hover:bg-[#FFC700]/20 border border-stone-300 px-2.5 py-1.5 rounded-xl flex items-center gap-1 shadow-2xs whitespace-nowrap"
            >
              🥟 Small Chops
            </button>
            <button
              onClick={() => handleSendMessage('What fresh bread is available at the Bakery?')}
              className="text-[11px] font-montserrat font-bold bg-white text-[#4D080F] hover:bg-[#FFC700]/20 border border-stone-300 px-2.5 py-1.5 rounded-xl flex items-center gap-1 shadow-2xs whitespace-nowrap"
            >
              <Wheat className="w-3 h-3 text-[#E62E00]" /> Fresh Bread 🍞
            </button>
            <button
              onClick={() => handleSendMessage('What are the branch locations and opening hours?')}
              className="text-[11px] font-montserrat font-bold bg-white text-[#4D080F] hover:bg-[#FFC700]/20 border border-stone-300 px-2.5 py-1.5 rounded-xl flex items-center gap-1 shadow-2xs whitespace-nowrap"
            >
              <MapPin className="w-3 h-3 text-[#E62E00]" /> Locations & Hours
            </button>
            <button
              onClick={() => handleSendMessage('What rice meals and traditional soups do you have?')}
              className="text-[11px] font-montserrat font-bold bg-white text-[#4D080F] hover:bg-[#FFC700]/20 border border-stone-300 px-2.5 py-1.5 rounded-xl flex items-center gap-1 shadow-2xs whitespace-nowrap"
            >
              <Utensils className="w-3 h-3 text-[#E62E00]" /> Jollof & Soups
            </button>
          </div>
        </div>

        {/* Message Input Form */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="p-3 bg-white border-t border-stone-200 flex items-center gap-2 shrink-0"
        >
          <input
            type="text"
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            placeholder="Ask Chop Paddy anything about our menu or branches..."
            className="flex-1 bg-stone-50 border border-stone-300 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm font-montserrat focus:outline-hidden focus:border-[#4D080F]"
            id="chop-paddy-input"
          />
          <button
            type="submit"
            disabled={!inputMessage.trim()}
            className="bg-[#E62E00] hover:bg-[#FF3E1D] disabled:opacity-50 text-white p-2.5 rounded-xl shadow-md transition-all active:scale-95 shrink-0"
            id="chop-paddy-send-btn"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>

      </div>
    </div>
  );
};
